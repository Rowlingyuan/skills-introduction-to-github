"""
统一模型调用封装
支持六个模型的标准化调用 + 自动重试
"""
import time
from openai import OpenAI
from config import API_KEY, BASE_URL, MODEL_CONFIG

#: **没有配 Key 也要能 import**。openai SDK 在 api_key 为空时**构造就抛异常**，
#: 而 `client` 是模块级对象 —— 一旦 import 失败，连"不依赖大模型"的数字查询、
#: 报表分析都会跟着崩（实测试用者没填 Key 时，测试与 RAG 路径直接 Missing credentials）。
#: 用占位 Key 保证可导入；真的调用时会得到 401，由 ModelError 归类成 auth 并优雅降级。
#:
#: **关掉 SDK 自带的重试**（默认 2 次）。我们自己有重试与降级逻辑，
#: 两层叠加会让"超时 30 秒"实际变成"等 90 秒"，把失败诊断拖得没法看。
client = OpenAI(
    api_key=API_KEY or "not-configured",
    base_url=BASE_URL,
    max_retries=0
)

#: 是否配置了真实 Key（供上层决定要不要尝试调用模型）
HAS_KEY = bool(API_KEY)


class ModelError(RuntimeError):
    """模型调用失败，带**可读的分类**。

    之前所有失败都长一个样（`Request timed out`），调用方和用户都分不清
    是网络断了、key 错了还是被限流 —— 处理方式完全不同。
    """

    #: 哪些失败值得重试。**认证类不重试** —— key 错了重试三次只是白等。
    RETRYABLE = ("timeout", "connection", "rate_limit", "empty", "server")

    def __init__(self, kind: str, detail: str, model: str = "", attempts: int = 1):
        self.kind = kind
        self.detail = detail
        self.model = model
        self.attempts = attempts
        super().__init__(str(self))

    def __str__(self) -> str:
        hint = _HINTS.get(self.kind, "")
        parts = [f"模型调用失败（{self.kind}）"]
        if hint:
            parts.append(hint)
        if self.model:
            parts.append(f"model={self.model}")
        if self.attempts > 1:
            parts.append(f"已尝试 {self.attempts} 次")
        if self.detail:
            parts.append(self.detail[:120])
        return "；".join(parts)


#: 每类失败该给用户什么提示 —— 用户要能据此决定"再试一次"还是"去改配置"。
_HINTS = {
    "timeout": "网关在超时时间内没有响应，通常是网络不稳或网关过载",
    "connection": "连不上网关地址，检查网络或 BASE_URL",
    "auth": "API Key 无效或无权限，检查 .env 里的 API_KEY",
    "rate_limit": "被限流，稍后再试",
    "empty": "网关返回了空内容（200 但没有正文）",
    "server": "网关 5xx，服务端异常",
    "bad_request": "请求参数被拒，检查模型名与参数",
    "unknown": "",
}


def classify_error(exc: Exception) -> str:
    """异常 → 分类。**纯函数**，便于单测（不碰网络）。"""
    text = f"{type(exc).__name__}: {exc}".lower()
    if "timeout" in text or "timed out" in text:
        return "timeout"
    if "connection" in text or "connect" in text:
        return "connection"
    if "401" in text or "403" in text or "unauthorized" in text or "api key" in text:
        return "auth"
    if "429" in text or "rate limit" in text or "too many requests" in text:
        return "rate_limit"
    if "空内容" in text or "empty" in text:
        return "empty"
    if any(code in text for code in ("500", "502", "503", "504")):
        return "server"
    if "400" in text or "invalid" in text:
        return "bad_request"
    return "unknown"


def call_model(role: str, messages: list, **kwargs):
    """
    统一的模型调用接口

    Args:
        role: 模型角色，对应 MODEL_CONFIG 的 key
              "extractor" / "router" / "reasoner" / "reasoner_backup" / "vision" / "vision_mini"
        messages: OpenAI 格式的消息列表
        **kwargs: 覆盖默认参数

    Returns:
        str: 模型回复文本
    """
    if role not in MODEL_CONFIG:
        raise ValueError(f"未知的模型角色: {role}，可选: {list(MODEL_CONFIG.keys())}")

    # **先摘掉控制参数，再合并进 config**：否则 max_retries 会被当成
    # chat.completions.create() 的关键字参数传下去，直接 TypeError。
    max_retries = int(kwargs.pop("max_retries", 3) or 1)

    config = MODEL_CONFIG[role].copy()
    config.update(kwargs)  # 允许调用时覆盖参数

    model = config.pop("model")
    description = config.pop("description", "")

    # 默认超时。网关很慢（实测 2545 字符耗时 61.4 秒），
    # 无超时会让请求挂死在 socket 上。显式传入的 timeout 会覆盖此默认值。
    config.setdefault("timeout", 120)

    # 自动重试（限流 / 网络抖动 / **空回复**）。
    # 重试次数已在上方摘出：生成报告时"卡 6 分钟"比"少一节原文归因"糟糕得多。
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                **config
            )
            content = response.choices[0].message.content
            # **空回复必须重试**：网关偶尔返回 200 但 content 为空。
            # 实测一天内多次出现，而旧代码直接把它当成功返回 ——
            # 上层拿到的是一句空话，报告里那节会**静默消失**，
            # 比报错更难发现。若最后一次仍为空，则抛错交给调用方处理。
            if not (content or "").strip():
                raise ValueError("模型返回空内容")
            return content

        except Exception as e:
            kind = classify_error(e)
            # **只重试瞬时故障**。key 无效（auth）、参数被拒（bad_request）
            # 重试多少次都是同样的结果，只会让用户白等。
            if kind in ModelError.RETRYABLE and attempt < max_retries - 1:
                wait = 2 ** attempt if kind == "rate_limit" else 1
                print(f"⚠️ {kind}：{str(e)[:80]} —— {wait}s 后重试 "
                      f"({attempt + 1}/{max_retries})")
                time.sleep(wait)
                continue
            raise ModelError(kind, str(e), model=model,
                             attempts=attempt + 1) from e

    raise ModelError("unknown", "重试次数用尽", model=model,
                     attempts=max_retries)


# ============================================
# 快捷调用函数（方便后续模块直接引用）
# ============================================

def call_extractor(messages, **kwargs):
    """L1：轻量级数据抽取"""
    return call_model("extractor", messages, **kwargs)


def call_router(messages, **kwargs):
    """路由Agent：任务拆解"""
    return call_model("router", messages, **kwargs)


def call_reasoner(messages, **kwargs):
    """L3：深度推理分析。**主模型失败时自动切备用模型**。

    实测：router（qwen36）正常、reasoner（deepseek_v4_pro）一直 timeout ——
    说明不是"net 全断"，而是**单个模型不可用**。配置里本来就有 `reasoner_backup`，
    不用白不用：主模型只对**瞬时类**失败降级，认证/参数错误照旧直接抛。
    """
    try:
        return call_model("reasoner", messages, **kwargs)
    except ModelError as e:
        if e.kind not in ModelError.RETRYABLE:
            raise
        backup = MODEL_CONFIG.get("reasoner_backup", {}).get("model", "")
        print(f"⚠️ 主模型 {e.model or 'reasoner'} 失败（{e.kind}），"
              f"改用备用模型 {backup}")
        return call_model("reasoner_backup", messages, **kwargs)


def call_vision(messages, **kwargs):
    """L4：多模态图表解析"""
    return call_model("vision", messages, **kwargs)


def ping(timeout: int = 8) -> dict:
    """探测模型网关是否可用。返回 {ok, kind, detail}。

    给终端对话的 `/health` 用：**先确认网关通不通，再去问需要模型的问题**，
    比等到超时才知道好。
    """
    try:
        call_model("router", [{"role": "user", "content": "回复 ok 两个字母即可"}],
                   timeout=timeout, max_retries=1, max_tokens=16)
        return {"ok": True, "kind": "ok", "detail": "网关可用"}
    except ModelError as e:
        return {"ok": False, "kind": e.kind, "detail": str(e)}
    except Exception as e:                       # noqa: BLE001
        return {"ok": False, "kind": classify_error(e), "detail": str(e)[:200]}
