"""文本层：PDF → 逐页文本块。

与 `parser.py` 的分工：`parser` 抽**结构化指标**，本模块抽**全文**（供向量索引与 RAG 引用）。
切块粒度固定为"页"，与 `indexer.py` 的 id 约定 `{company}_{year}_p{page}` 对齐。

刻意不做任何页码假设（一期 Global Constraints）：不跳过前 N 页、不识别封面，
只丢弃抽不出文字的页，避免空白页进索引变成检索噪声。
"""
import pdfplumber


def extract_chunks(pdf_path) -> list:
    """返回 [{"page": int, "text": str}, ...]，page 为 1-based。"""
    chunks = []
    with pdfplumber.open(str(pdf_path)) as pdf:
        for i, page in enumerate(pdf.pages, start=1):
            text = page.extract_text() or ""
            if text.strip():
                chunks.append({"page": i, "text": text})
    return chunks
