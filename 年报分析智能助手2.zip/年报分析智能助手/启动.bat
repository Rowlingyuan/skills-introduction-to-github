@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PIP_INDEX=%ARA_PIP_INDEX%"
if "%PIP_INDEX%"=="" set "PIP_INDEX=https://pypi.tuna.tsinghua.edu.cn/simple"
echo === 年报分析助手 ===

set "SETUP=0"
if /i "%~1"=="--setup" set "SETUP=1"

if exist ".venv\Scripts\python.exe" if "%SETUP%"=="0" (
  .venv\Scripts\python main.py
  pause
  exit /b 0
)

if not exist ".venv\Scripts\python.exe" goto FIRST

rem --setup：已有环境，问怎么处理
echo.
echo 当前环境：.venv
echo   [1] 保持不变（直接回车）
echo   [2] 复用本机已装依赖（不装到系统里）
echo   [3] 删掉重建（全新）
echo.
set /p c=请选择 1/2/3（直接回车 = 1）:
if "%c%"=="2" (rmdir /s /q .venv & goto REUSE)
if "%c%"=="3" (rmdir /s /q .venv & goto FRESH)
.venv\Scripts\python main.py
pause
exit /b 0

:FIRST
where python >nul 2>nul
if errorlevel 1 (
  echo [X] 没找到 Python，请先安装 https://www.python.org/downloads/
  echo     安装时请勾选 "Add Python to PATH"
  pause
  exit /b 1
)
echo.
echo 还没有可用的运行环境，请选择安装方式：
echo   [1] 复用本机已装依赖       -- 快：本机已有的 numpy/pandas 直接拿来用
echo   [2] 全新独立环境（推荐）  -- 慢一些，完全隔离
echo.
set /p c=请选择 1/2（直接回车 = 2）:
if "%c%"=="1" goto REUSE
goto FRESH

:REUSE
echo.
echo [1/2] 创建环境（复用本机已装依赖）...
python -m venv --system-site-packages .venv || (echo [X] 创建失败 & pause & exit /b 1)
echo [2/2] 补装缺少的依赖（已满足的会跳过）
.venv\Scripts\python -m pip install --progress-bar on -i %PIP_INDEX% -r requirements.txt
if errorlevel 1 .venv\Scripts\python -m pip install --progress-bar on -r requirements.txt
if errorlevel 1 (echo [X] 依赖安装失败 & pause & exit /b 1)
echo 就绪（复用本机包，只补缺的部分）
echo.
.venv\Scripts\python main.py
pause
exit /b 0

:FRESH
echo.
echo [1/2] 创建全新环境（完全隔离）...
python -m venv .venv || (echo [X] 创建失败 & pause & exit /b 1)
.venv\Scripts\python -m pip install -q --upgrade pip >nul 2>nul
echo [2/2] 安装核心依赖（约 200 MB）：pip 会显示下载进度
.venv\Scripts\python -m pip install --progress-bar on -i %PIP_INDEX% -r requirements.txt
if errorlevel 1 .venv\Scripts\python -m pip install --progress-bar on -r requirements.txt
if errorlevel 1 (echo [X] 依赖安装失败 & pause & exit /b 1)
echo 环境就绪
echo.
.venv\Scripts\python main.py
pause
