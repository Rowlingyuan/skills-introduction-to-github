"""问答编排层。

职责分工与 `parser.py` 对解析层的关系一致：本模块只做**编排**，
解析在 `parser`、检索在 `retriever`、存储于 `storage`、模型调用在 `client`。

核心决策是**结构优先**：能定位到「公司 + 指标 + 年份」的问题走 SQLite 精确查询；
其余才走语义检索 + LLM。理由是本项目的立身之本是"数字来自规则提取、可追溯"，
让"营业收入是多少"走 RAG 等于把最值钱的资产降级成 LLM 复述。
"""
import re
import sqlite3
import time
from datetime import date
from pathlib import Path

from config import STATEMENT_ALIASES
from storage import load_metrics

_PERIOD_RE = re.compile(r"((?:19|20)\d{2}(?:Q[1-4])?)")

#: 股票代码：`300308` / `SZ300308` / `sz300308` / `600519.SH` / `SH600519`
#: 用户经常直接报代码，尤其是不确定简称写法的时候。
_CODE_RE = re.compile(r"(?<![0-9])(?:(?:SH|SZ|BJ|sh|sz|bj)\s*)?(\d{6})(?![0-9])")


def _norm_name(text: str) -> str:
    """公司名归一化（全角转半角、去空白）。实现移到了 `company_names`。"""
    from company_names import normalise
    return normalise(text)


def match_company(question: str, db_path) -> "str | None":
    """从问句里认出**库里已有的公司**，返回库里的原始写法。

    匹配逻辑在 `company_names.match`（不依赖 agent/analysis，切断循环导入）；
    公司清单从 `storage.known_companies` 取。
    """
    from company_names import match, normalise
    from storage import company_by_code, known_companies

    # **用户直接报代码**（`SZ300308` / `300308`）时先按代码查库
    code = _CODE_RE.search(question or "")
    if code:
        hit = company_by_code(db_path, code.group(1))
        if hit:
            return hit

    names = known_companies(db_path)
    hit = match(question, names)
    if hit:
        return hit

    # **干净的简称**才认：库里叫"格力电器"，用户说"格力" —— 候选名正好是前缀/后缀。
    # 只是"部分重合"的不算（实测 `中旭创科` 会靠"旭创"两字命中"中际旭创"），
    # 那种交给 _try_ingest 的模糊匹配去**反问确认**，不能静默替用户决定。
    cand = _candidate_company(question) or ""
    if len(cand) >= 2:
        c = normalise(cand)
        hits = [n for n in names
                if normalise(n).startswith(c) or normalise(n).endswith(c)]
        if len(hits) == 1:
            return hits[0]
    return None


def _known_companies(db_path) -> list:
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            rows = conn.execute(
                "SELECT DISTINCT company FROM reports").fetchall()
        finally:
            conn.close()
    except sqlite3.Error:
        return []
    return [r[0] for r in rows]


def _find_metric(question: str):
    """返回 (statement, 规范指标名)。按别名表匹配，长别名优先避免子串误命中。"""
    best = None
    for statement, table in STATEMENT_ALIASES.items():
        for canonical, aliases in table.items():
            for alias in [canonical] + list(aliases):
                if alias and alias in question:
                    if best is None or len(alias) > len(best[2]):
                        best = (statement, canonical, alias)
    return (best[0], best[1]) if best else None


def route(question: str, db_path) -> "dict | None":
    """三者（公司/指标/年份）全中才算结构化，否则返回 None 交给 RAG。"""
    period_m = _PERIOD_RE.search(question or "")
    if not period_m:
        return None
    company = match_company(question, db_path)
    if not company:
        return None
    hit = _find_metric(question)
    if not hit:
        return None
    statement, metric = hit
    period = period_m.group(1)
    return {"company": company, "statement": statement, "metric": metric,
            "period": period,
            "report_type": _report_type_hint(question) or _report_type_of(period)}


_QUARTER_TO_REPORT_TYPE = {"1": "一季报", "2": "半年报", "3": "三季报", "4": "年报"}

#: 问题里显式写出的报告类型关键词 → report_type。
#: **顺序即优先级**：「半年度报告」含「年度报告」子串、「一季报」「三季报」也含「季报」，
#: 故更具体的必须排在更宽泛的前面，否则「半年度报告」会被误判成年报。
_TYPE_HINTS = (
    ("一季报", ("一季报", "一季度报", "1季报")),
    ("三季报", ("三季报", "三季度报", "3季报")),
    ("半年报", ("半年报", "半年度报告", "中报")),
    ("年报", ("年报", "年度报告")),
)


def _report_type_hint(question: str) -> "str | None":
    for report_type, keywords in _TYPE_HINTS:
        if any(k in (question or "") for k in keywords):
            return report_type
    return None


def _report_type_of(period: str, hint: "str | None" = None) -> str:
    """期间 → 报告类型。`hint`（问题里显式写出的类型）优先。

    半年报的 period 与年报**同为裸年份**（`models.py:11` 只定义 `"2025"`/`"2025Q1"`），
    靠 report_type 在库里区分（`UNIQUE(company, report_type, period)`）。
    故问题里写了「半年报」就必须按它查 —— 否则半年报数据永远够不着，
    一律默认年报会让用户问「比亚迪2026年营业收入」时只得到"年报口径尚未入库"。
    回答里仍然**声明口径**，用户才分得清拿到的是全年还是半年数。
    """
    if hint:
        return hint
    if "Q" in period:
        return _QUARTER_TO_REPORT_TYPE.get(period.split("Q")[1], "年报")
    return "年报"


#: 资产负债表的核心三项。三者对不上说明抽取有误（或口径混用）。
_CORE_TRIO = ("资产总计", "负债合计", "所有者权益合计")
_IDENTITY_TOL = 1e8      # 与 tests/run_golden 的恒等式默认门禁一致：只抓量级级错误


def _identity_warning(info: dict, db_path) -> str:
    """资产负债表三项对不上时给出**显式告警**（否则返回空串）。

    为什么必须做：抽取层实测有被 pdfplumber 文本策略切坏单元格的报表 —— 茅台 2026
    半年报的 `所有者权益合计` 抽成 62,096,352,174，而真值是 262,096,352,174
    （**首位数字被切走**），恒等式差额恰好 2000 亿。这类值若被当作事实端给用户，
    正是本项目立身之本（"数字可追溯、宁可说不知道"）最不能接受的形态。
    本函数是**运行时的最后一道闸**：能查到就查，查不出（三项不全）就不多话。
    """
    if info["statement"] != "资产负债表":
        return ""
    metrics = load_metrics(info["company"], info["report_type"], info["period"],
                           db_path, statement="资产负债表")
    vals = {(m.name, m.period): m.value for m in metrics}
    bad = []
    for year in sorted({m.period for m in metrics}):
        trio = [vals.get((n, year)) for n in _CORE_TRIO]
        if any(v is None for v in trio):
            continue
        diff = trio[0] - trio[1] - trio[2]
        if abs(diff) > _IDENTITY_TOL:
            bad.append(f"{year} 差额 {diff:,.0f}")
    if not bad:
        return ""
    return ("\n⚠️ 该报表不满足「资产总计 = 负债合计 + 所有者权益合计」（"
            + "；".join(bad) + "），数值可能有误，请以年报原文为准。")


def answer_structured(info: dict, db_path) -> dict:
    period = info["period"]
    report_type = info.get("report_type") or _report_type_of(period)
    metrics = load_metrics(info["company"], report_type, period, db_path,
                           statement=info["statement"])
    hits = [m for m in metrics if m.name == info["metric"]]
    if not hits:
        # **必须区分"报告没入库"与"入库了但这项没抽到"** —— 两种情况该给的建议完全不同。
        # 实测踩到过：格力 2025 年报已入库（利润表/现金流量表都抽到了），只是
        # `资产总计` 没抽到，却提示"请先执行 ingest 把它落库"，会让用户白跑一遍。
        if load_metrics(info["company"], report_type, period, db_path):
            why = (f"该报告已入库，但**未抽到「{info['metric']}」这一项** —— "
                   f"这是抽取覆盖问题，不是没入库，请勿重复 ingest。")
        else:
            why = f"{report_type}口径下该报告尚未入库，请先执行 ingest 把它落库。"
        return {"route": "structured", "metrics": [], "citations": [],
                "answer": f"没有查询到 {info['company']} {period} 的"
                          f"{info['metric']}：{why}"}
    lines = [f"{info['company']} {period} {info['metric']}"
             f"（{report_type}口径）："]
    # **必须逐行标出年份**：库里同一指标存有本期与上期两列（这是同比分析的基础，
    # 见 metric_extractor.extract_metrics），不标年份会输出两串无从分辨的数字。
    # 本期（年份较大者）排在前。
    for m in sorted(hits, key=lambda x: x.period, reverse=True):
        # `source_page=0` 是**结构化来源的标记**，不是"第 0 页"。
        # 三大表已改为取结构化接口，写"第 0 页"会让用户以为解析出错。
        where = "结构化接口" if not m.source_page else f"第 {m.source_page} 页"
        lines.append(f"  {m.period}：{m.value:,.2f}（{where}，置信度 {m.confidence}）")
    return {
        "route": "structured", "citations": [],
        "answer": "\n".join(lines) + _identity_warning(info, db_path),
        "metrics": [{"name": m.name, "period": m.period, "value": m.value,
                     "source_page": m.source_page, "confidence": m.confidence,
                     "statement": m.statement} for m in hits],
    }


def _search(query, company, year, top_k):
    """网络/模型边界的薄封装，便于测试中替换。"""
    from config import ENABLE_RAG
    if not ENABLE_RAG:
        return []            # 向量检索关闭 → 检索不到内容，由上层给出可读提示
    from retriever import ReportRetriever
    return ReportRetriever().search(query, company=company, year=year,
                                    top_k=top_k)


def _call_reasoner(messages):
    from client import call_reasoner
    return call_reasoner(messages)


_SYSTEM = (
    "你是年报分析助手。**只依据给定资料回答**，并用「第N页」标注出处。\n"
    "资料中没有的内容，直接说「未找到」，**不要凭常识补全，更不要编造数字**。"
)


def _covered_companies(hits: list) -> list:
    return sorted({h.get("company", "") for h in hits if h.get("company")})


def build_rag_prompt(question: str, hits: list) -> list:
    covered = _covered_companies(hits)
    if not hits:
        context = "（未找到任何相关资料）"
    else:
        context = "\n\n".join(f"【第{h['page']}页】{h['text']}" for h in hits)
    # **必须声明覆盖范围**：检索可能因为问题里没点名公司而跨公司取回资料，
    # 不声明的话 LLM 会把甲公司的段落当成乙公司的答案（实测踩到过：
    # 问比亚迪捞回的全是格力段落，引用页码也全是格力的）。
    system = _SYSTEM + (
        f"\n本次资料**只覆盖以下公司**：{'、'.join(covered) if covered else '（无）'}。"
        "若问题所问的是其它公司，直接回答「未收录该公司」，"
        "**不得把上述公司的信息安到别的公司头上**。"
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": f"资料：\n{context}\n\n问题：{question}"},
    ]


def _search_context(question: str, db_path) -> tuple:
    """尽力从问题里取出公司与年份，用于**收窄**检索范围；取不到就不加过滤。"""
    m = _PERIOD_RE.search(question or "")
    year = m.group(1)[:4] if m else None
    company = match_company(question, db_path)
    return company, year


def answer_rag(question: str, db_path, top_k: int = 5) -> dict:
    # **库里没有这家公司时，不要拿别家的段落拼答案**。
    # 实测问"上纬新材"却检索到别的公司的页，模型据此答"未收录该公司"，
    # 既没用又容易误导（还附了一串不相干的页码）。这里直接说清楚。
    # 只对"要某公司某份年报"的问句生效；普通问题（"主营业务是什么"）
    # 不该被当成公司名，否则会把正常提问也拦下来。
    asks_report = (any(w in (question or "") for w in _REPORT_WORDS)
                   or any(h in (question or "") for h in _ANALYSIS_HINTS))
    cand = _candidate_company(question) if asks_report else None
    if cand and not match_company(question, db_path):
        return {"route": "rag", "metrics": [], "citations": [], "companies": [],
                "answer": f"没能在巨潮检索到「{cand}」。\n"
                          f"通常是公司简称不准确 —— 试一下全称或股票代码，"
                          f"例如「帮我分析 {cand}股份有限公司 2025年报」。\n"
                          f"（用 /list 可以看到库里已有的 "
                          f"{len(_known_companies(db_path))} 家公司）"}

    company, year = _search_context(question, db_path)
    hits = _search(question, company, year, top_k)

    covered = _covered_companies(hits)
    if not hits:
        # 别只说"没找到"：告诉用户**下一步能做什么**。
        # 实测「帮我下载并分析 五粮液 2025 年年报」因一个 bug 掉到这里，
        # 用户只看到"未找到资料"，完全猜不到是"库里没有这份报告"。
        from config import ENABLE_RAG
        if not ENABLE_RAG:
            return {"route": "rag", "metrics": [], "citations": [], "companies": [],
                    "answer": "向量检索当前是关闭的（EMBEDDING_MODEL=none），"
                              "所以没法检索年报原文。\n"
                              "**不需要它的功能都能用**：查具体数字、三大报表分析、"
                              "附注要点、Word 报告。\n"
                              "要用「问年报里的内容」，请设 EMBEDDING_MODEL=small（约 100MB）后重开。"}
        return {"route": "rag", "metrics": [], "citations": [], "companies": [],
                "answer": "未在已索引的内容中找到相关资料。\n"
                          "如果问的是某家公司某份年报，可以让我去下载并解析，例如："
                          "「帮我下载并分析五粮液2025年报」；"
                          "用 /list 可以看当前已入库的报告。"}
    try:
        reply = _call_reasoner(build_rag_prompt(question, hits))
    except Exception as e:                   # noqa: BLE001
        # 模型不可用（超时/无 Key/限流）时不要把异常抛给用户
        try:
            from client import HAS_KEY
        except Exception:                    # noqa: BLE001
            HAS_KEY = True
        if not HAS_KEY:
            tip = ("当前没有配置 API_KEY，所以没法做「检索原文再归纳」。\n"
                   "**不需要 Key 也能用的**：具体数字查询、三大报表分析、附注要点、Word 报告。")
        else:
            tip = f"调用大模型失败：{str(e)[:80]}\n可以先换成具体数字的问题（不需要模型），或稍后重试。"
        return {"route": "rag", "metrics": [], "citations": [], "companies": covered,
                "answer": "检索到了相关资料，但" + tip}
    return {"route": "rag", "metrics": [], "answer": reply, "companies": covered,
            "citations": [{"page": h["page"], "text": h["text"][:200],
                           "relevance": h["relevance"]} for h in hits]}


def _unservable_metric_question(question: str, db_path) -> "str | None":
    """精确数字问题（**指标 + 年份**）却定位不到已入库公司 → 返回拒绝语，否则 None。

    这类问题**绝不能退到 RAG**。实测：问「比亚迪2025年营业收入是多少」，路由判不出
    公司 → 退 RAG → 检索没有公司护栏，捞回的全是格力的段落（引用页码也全是格力的）。
    本项目立身之本是"数字来自规则提取、可追溯"，让精确数字问题走 LLM 复述
    等于把最值钱的资产降级。故在此直接拒绝，并告知当前已入库的公司。

    与 `route` 互补：`route` 要求「公司+指标+年份」三者全中才走结构化；
    本函数补上"指标+年份都有、唯独公司定位不到"的那一类。
    """
    if not _PERIOD_RE.search(question or "") or _find_metric(question) is None:
        return None
    companies = _known_companies(db_path)
    if match_company(question, db_path):
        return None      # 公司可定位 —— 归 route/answer_structured 管
    have = "、".join(companies) if companies else "（尚未入库任何公司）"
    return (f"无法把这个数字问题定位到已入库的公司，无法给出**可追溯**的数值。\n"
            f"请指明公司名称。当前已入库：{have}。")


#: 触发「出分析报告」的**显式**意图词。刻意不含「情况」「怎么样」这类宽泛词 ——
#: 实测「格力电器2025年经营情况讨论」是开放问题、应当走 RAG，用它当触发词会把
#: 开放问题误劫持成分析报告。
_ANALYSIS_HINTS = ("分析", "总结", "概况", "点评", "梳理")

#: "想看看这份报告"的口语说法。**单列一组**：它们不表示"分析"，
#: 但足以说明用户要的是这份报告 —— `帮我看看格力2025年报` 之前会掉到检索。
_LOOK_HINTS = ("看看", "看一看", "看一下", "查看", "了解", "想知道", "瞧")


#: 生成报告时给原文归因的**硬预算**（秒）与重试次数。
#: 模型网关实测会挂死十几分钟 —— 出一份报告要等那么久，不如先给出去、
#: 缺的那节如实说明。正常情况 20 秒左右就回来了。
_NARRATIVE_TIMEOUT = 30
_NARRATIVE_RETRIES = 1

#: 问句里出现这些词，才去调大模型写「原文归因」。
#: 生成报告默认**不调模型**：网关实测经常超时，白等 20~90 秒还不如先把报告给出去。
#: 想要那一节，就说「并附原文原因」。
_NARRATIVE_HINTS = ("原文", "归因", "为什么", "原因", "解释")


def wants_narrative(question: str) -> bool:
    return any(h in (question or "") for h in _NARRATIVE_HINTS)


def _default_narrative(company, report_type, period, db_path, analysis,
                       timeout=None, max_retries=None):
    from narrative import build_narrative
    return build_narrative(company, report_type, period, db_path, analysis,
                           timeout=timeout, max_retries=max_retries)


#: 原文归因的入口，模块级便于测试替换（真实实现要调检索 + 大模型）。
_narrative = _default_narrative


def _skip_narrative(for_document: bool) -> dict:
    """不调模型时的占位。

    要出文档时**要说明那一节为什么缺**（否则读者以为漏了）；
    只问一句文字分析时**什么都不说**（少一行噪声）。
    """
    if not for_document:
        return {"ok": True, "grounded": False, "citations": [],
                "answer": "", "text": ""}
    return {"ok": True, "grounded": False, "citations": [],
            "answer": "（本次未生成：如需年报原文对变动原因的解释，"
                      "请在问题里加「并附原文原因」）",
            "text": "\n\n【年报原文对变动原因的说明】（本次未生成，"
                    "可加「并附原文原因」重新生成）"}


def _narrative_block(target, analysis, db_path, timeout=None,
                     max_retries=None) -> dict:
    """「年报原文怎么解释这次变动」—— 附在数字分析之后，两者**来源不同、分别标清**。"""
    r = _narrative(target["company"], target["report_type"],
                   target["period"], db_path, analysis,
                   timeout=timeout, max_retries=max_retries)
    head = "\n\n【年报原文对变动原因的说明】"
    if not r.get("ok"):
        text = head + f"（生成失败：{r.get('error', '未知原因')}）"
    elif not r.get("grounded"):
        text = head + r["answer"]
    else:
        cites = "、".join(f"第{c['page']}页" for c in r["citations"])
        text = (head + "（**大模型据年报原文归纳**，非规则抽取；"
                f"出处 {cites}）\n" + r["answer"])
    return {**r, "text": text}


#: 触发「出一份**文档**」的意图词。与"只要文字分析"区分开：
#: 问「分析一下格力2025年报」→ 文字；问「出一份分析报告」→ 落一个 .docx。
_REPORT_HINTS = ("报告", "文档", "word", "Word", "WORD", "docx", "DOCX", "导出")

#: 报告默认落到项目根的 `reports/`，文件名带公司与期间，便于归档。
REPORT_DIR = Path(__file__).resolve().parent / "reports"


def wants_document(question: str) -> bool:
    return any(h in (question or "") for h in _REPORT_HINTS)


def default_report_path(company: str, period: str, report_type: str) -> Path:
    suffix = "年度" if report_type == "年报" else report_type
    return REPORT_DIR / f"{company}{period}{suffix}财务分析报告.docx"


#: 问句里出现这些词，才联网做外部核验（约 20 秒）
_VALIDATE_HINTS = ("核验", "校验", "比对", "验证", "validate")


def wants_validation(question: str) -> bool:
    return any(h in (question or "") for h in _VALIDATE_HINTS)


def build_report(company: str, report_type: str, period: str, db_path,
                 *, analysis=None, narrative=None, out_path=None,
                 with_validation: bool = False) -> dict:
    """生成一份 Word 分析报告，返回 {ok, path}。

    **智能体自己的能力**：`answer()` 识别到"要文档"的意图时直接调它，
    不需要任何人再跑脚本。数字全部来自 `analysis`（SQLite + 页码），
    段落组织与条件判断在 `report_docx` 里。
    """
    if analysis is None:
        from analysis import build_analysis
        analysis = build_analysis(company, report_type, period, db_path)
    if not analysis.get("ok"):
        return {"ok": False, "error": analysis.get("error", "无法生成分析")}
    if with_validation and "validation" not in analysis:
        try:
            import validator as v
            res = v.validate_report(company, report_type, period, db_path)
            if res.get("ok"):
                analysis = {**analysis, "validation": res}
        except Exception:
            pass                      # 核验失败不影响出报告，6.2 节会说明未启用
    try:
        from report_docx import save
    except Exception as e:                       # 缺 python-docx 等
        return {"ok": False, "error": f"报告渲染不可用：{e}"}
    path = Path(out_path) if out_path else default_report_path(
        company, period, report_type)
    try:
        save(analysis, narrative, path)
    except Exception as e:
        return {"ok": False, "error": f"写入失败：{e}"}
    return {"ok": True, "path": str(path)}


def _short(path) -> str:
    """把项目内的绝对路径压成"相对项目根"的形式，便于照着找。"""
    from pathlib import Path

    p = Path(path).resolve()
    root = Path(__file__).resolve().parent
    try:
        return str(p.relative_to(root))
    except ValueError:
        return str(p)


def report_pdf_path(company, period, report_type, db_path):
    """公开入口：查某份报告的 PDF 原文件路径（不存在返回 None）。"""
    return _report_pdf_path(company, period, report_type, db_path)


def _report_pdf_path(company, period, report_type, db_path):
    """查这份报告对应的 PDF 原文件路径（找不到就返回 None）。

    优先用库里记的 `file_path`；记录缺失或文件被清理时，**再按目录兜底找一遍**
    （`data/<公司>/<类型>/` 下文件名含年份的 PDF）——实测有用户为了省空间
    删过 data/ 下的 PDF，也有的老记录 file_path 是空的。
    """
    import sqlite3
    from pathlib import Path

    root = Path(__file__).resolve().parent
    try:
        with sqlite3.connect(str(db_path)) as conn:
            row = conn.execute(
                "SELECT file_path FROM reports WHERE company=? AND period=? "
                "AND report_type=? ORDER BY id DESC LIMIT 1",
                (company, str(period), report_type)).fetchone()
    except Exception:                        # noqa: BLE001
        row = None

    cand = None
    if row and row[0]:
        cand = Path(row[0])
        if not cand.is_absolute():
            cand = root / cand
        if cand.exists():
            return cand

    # 兜底：目录里按年份找
    base = root / "data" / str(company) / str(report_type)
    if not base.is_dir():
        return None
    year = str(period)[:4]
    pdfs = [p for p in base.glob("*.PDF")] + [p for p in base.glob("*.pdf")]
    if not pdfs:
        return None
    exact = [p for p in pdfs if year and year in p.name]
    return sorted(exact or pdfs)[-1]


def _document_suffix(question, company, report_type, period, db_path,
                     analysis, narrative, force: bool = False) -> str:
    """要文档就渲染一份，返回附在回答末尾的说明；否则返回空串。

    `force=True` 用于**下载路径**：既然已经付了下载 + 解析的代价，
    出一份 Word 是自然的交付物，不该再要求用户补一句"出份报告"。
    """
    if not (force or wants_document(question)):
        return ""
    print("📄 正在生成 Word 报告…", flush=True)
    got = build_report(company, report_type, period, db_path,
                       analysis=analysis,
                       narrative=narrative if (narrative or {}).get("grounded") else None,
                       with_validation=wants_validation(question))
    if got.get("ok"):
        # **给可点击的链接，而不是替用户弹出窗口**：报告可能想稍后再看，
        # 自动打开会打断终端里正在读的结论。
        from pathlib import Path

        from terminal_link import link

        report_name = Path(got["path"]).name
        reports_dir = Path(got["path"]).parent
        lines = ["\n\n报告做好啦 ✅ 给你三样东西：", "",
                 "📄 一份分析报告", report_name,
                 f"📍 位置：{_short(reports_dir)}/",
                 "👉 在下方输入框敲 /open，回车就能打开"]

        try:
            from report_html import build_html
            out = build_html(db_path=db_path, default_company=company)
            lines += ["", "📊 一个能自己动手的数据看板", Path(out).name,
                      f"📍 位置：{_short(Path(out).parent)}/",
                      "👉 敲 /html 打开",
                      "打开后可以自己选公司、勾选想看的指标、看趋势变化"]
        except Exception:                    # noqa: BLE001
            pass

        pdf = _report_pdf_path(company, period, report_type, db_path)
        if pdf:
            lines += ["", "📎 还有年报原文（想核对数字时用）",
                      Path(pdf).name,
                      f"📍 位置：{_short(Path(pdf).parent)}/",
                      "👉 敲 /pdf 打开"]
        else:
            lines += ["", "📎 年报原文：本地没有这份 PDF（可能清理过 data/ 目录）",
                      f"👉 想核对原文，说一句「重新下载 {company} {period} {report_type}」即可"]

        return "\n".join(lines)
    return "\n\n（报告文件生成失败：" + str(got.get("error")) + "）"


def _try_analysis(question: str, db_path) -> "dict | None":
    """问句要的是「某公司某期报告的分析」→ 生成分析；否则返回 None。

    仅在**显式说了要分析**、且能定位到一份**已入库**的报告时才触发。
    数字部分全部来自 SQLite（规则抽取）；原文归因另行标注来源与页码。
    """
    if not _wants_report(question or ""):
        return None
    from analysis import brief_text, build_analysis, resolve_report
    target = resolve_report(question, db_path)
    if target is None:
        return None
    # **分析也要有进度**：库里已有的公司虽然只花十来秒，但全程无输出会让人
    # 以为程序卡住了（说明文档里承诺了"依次打印进度"，却只在新下载时有）。
    # **说明这份报告从哪来**：库中已有就直说，免得用户以为又下载了一遍
    try:
        from analysis import _pdf_path as _find_pdf
        pdf = _find_pdf(target["company"], target["report_type"],
                        target["period"], db_path)
    except Exception:                       # noqa: BLE001
        pdf = None
    if pdf:
        print(f"✅ 库中已有该报告，无需下载：{pdf}", flush=True)
    print(f"⏳ 正在分析 {target['company']} {target['period']} "
          f"{target['report_type']}…", flush=True)
    import time as _t
    _t0 = _t.time()
    a = build_analysis(target["company"], target["report_type"],
                       target["period"], db_path)
    if not a.get("ok"):
        return None
    print(f"✅ 分析完成（{_t.time() - _t0:.1f}s）", flush=True)
    # **默认不调大模型**：网关经常超时，一次白等 30~60 秒。
    # 想要「年报原文对变动原因的解释」，在问题里加「并附原文原因」。
    asked_narrative = wants_narrative(question)
    if not asked_narrative:
        narr = _skip_narrative(False)
    else:
        narr = _narrative_block(target, a, db_path,
                                timeout=_NARRATIVE_TIMEOUT,
                                max_retries=_NARRATIVE_RETRIES)
    # **分析也直接出报告**：用户要的是"一份分析"，不是屏幕上翻不完的抽取明细。
    # 终端只回结论摘要 + 文件路径，完整内容进 Word。
    tail = _document_suffix(question, target["company"], target["report_type"],
                            target["period"], db_path, a, narr, force=True)
    # 明确要了原文归因，就在终端也给出来（否则它只出现在 Word 里，用户以为没做）
    nar_text = (narr.get("text") or "") if asked_narrative else ""
    return {"route": "analysis", "metrics": [], "citations": [],
            "companies": [], "analysis": a, "narrative": narr,
            "entity": {"company": target["company"],
                       "report_type": target["report_type"],
                       "period": target["period"]},
            "answer": brief_text(a) + nar_text + tail}


#: 触发「联网下载」的显式意图词。与 `_ANALYSIS_HINTS` 分开：
#: 只说"分析"但公司已在库时**不该联网**（本地已有，秒回）。
_FETCH_HINTS = ("下载", "抓取", "拉取", "获取", "找一下", "帮我找", "去拿")

#: 问句开头的客套与动词，逐层剥掉才能露出公司名。
#: **顺序无关**（反复剥离直到不再命中），但必须只放"不会出现在公司名开头"的词 ——
#: 「中」「东」「华」这类常见首字绝不能进表，否则「中国平安」会被剥成「国平安」。
_LEAD_WORDS = ("请", "帮我", "帮忙", "麻烦", "我想", "我要", "想要", "想", "要",
               "能不能", "可不可以", "可以", "能否", "一下", "给我",
               # "看/查/了解"类动词：`帮我看看周大福2026年报` 曾截出"看看周大福"
               "看看", "看一看", "看下", "看一下", "瞧瞧", "瞅瞅", "瞅一眼",
               "瞅", "看一眼", "查一下", "查查",
               "了解", "了解一下", "想知道", "知道",
               "下载", "抓取", "拉取", "获取", "找一下", "帮我找", "去拿",
               "分析", "总结", "点评", "梳理", "概况",
               "并", "和", "再", "然后", "顺便", "这", "那", "份", "个",
               "最新", "最近的", "公司的")

_REPORT_WORDS = ("年度报告", "年报", "半年度报告", "半年报", "季度报告",
                 "一季报", "三季报", "季报", "财报", "财务报告", "中期报告")

# 上限 12：`中国黄金股份有限公司` 是 10 字，8 字会把全称截成"中国黄金股份有限"
_COMPANY_RE = re.compile(
    # 贪婪吃到年份/报表词前，再由 lookahead 收住；
    # lookahead 里额外放了「分析 / 对应 / 的」，因为用户常写
    # `中际旭创分析对应的2025年财报`，不在这里收住会把整句当成公司名。
    # **非贪婪**：贪婪会吃到"中际旭创分析对应的"才停；非贪婪在遇到
    # 分析/对应/的 时立刻收住，正好截出公司名
    r"([\u4e00-\u9fa5A-Za-z]{2,12}?)(?:公司)?(?:的)?"
    r"(?=(?:19|20)\d{2}|" + "|".join(_REPORT_WORDS) + r"|分析|对应|的|$)")

_PERIOD_SUFFIX_LIKE = {"一季报": "Q1", "三季报": "Q3"}


def _strip_lead(text: str) -> str:
    text = re.sub(r"^[\s，。,.!?、；：:]+", "", text or "")
    changed = True
    while changed:
        changed = False
        for w in _LEAD_WORDS:
            if text.startswith(w) and len(text) > len(w):
                text = text[len(w):]
                changed = True
                break
    return text


def _candidate_company(question: str) -> "str | None":
    """从问句里截出候选公司名（只做候选，真实性由巨潮接口复核）。

    三种常见语序都要认：
      - 公司在前：`帮我分析五粮液2024年报` → 五粮液
      - 年份在前：`帮我分析 2025 年的五粮液年报` → 五粮液
      - 说全称  ：`帮我分析中国黄金股份有限公司 2025 年报` → 中国黄金（去掉法定后缀）
    """
    q = re.sub(r"\s", "", question or "")
    q = _strip_lead(q)
    # 年份+报表词在前：`2025年报 中国黄金`、`2024年度报告 五粮液`
    q = re.sub(r"^(?:19|20)\d{2}\s*年?(?:度)?\s*(?:报告|年报|财报|半年报|季报)\s*", "", q)
    # 年份在前：先摘掉年份前缀再匹配
    q = re.sub(r"^(?:19|20)\d{2}\s*年?(?:的)?", "", q)
    # 报表词打头 + 标点分隔（`年报，中国黄金，2025`）：先剥掉，别让"年报"占位
    q = re.sub(r"^[，,。、；;：:\s]*(?:年报|年度报告|半年报|季报|报告)[，,。、；;：:\s]*", "", q)
    # **去掉"对应的股票代码为SZ300308"这类插入语**：用户常把简称和代码混在一句里，
    # 整段送进正则会被长度上限截断，结果解析不出公司。
    q = re.sub(r"[，,。、；;：:]\s*(?:它|其)?(?:对应|对应为|的)?的?股票代码(?:为|是)?"
               r"(?:(?:SH|SZ|BJ|sh|sz|bj)\s*)?\d{6}", "，", q)
    q = re.sub(r"[，,。、；;：:]", "", q)

    m = _COMPANY_RE.match(q)
    if not m:
        # **用户直接报代码**（`SZ300308`、`300308`）时，把代码当候选交出去，
        # 下游用巨潮的代码检索换成正式简称（resolve_org('300308') 可查到）。
        code = _CODE_RE.search(q)
        return code.group(1) if code else None

    cand = m.group(1)
    # 贪婪匹配可能把"年报/半年报"也吃进来（`2025年的五粮液年报`），先剥掉
    for w in sorted(_REPORT_WORDS, key=len, reverse=True):
        if cand.endswith(w) and len(cand) > len(w):
            cand = cand[: -len(w)]
            break
    cand = strip_legal_suffix(cand).rstrip("的")   # 贪婪匹配会带上"的"
    if not cand:
        return None
    # 通用词 / 含报表词的残片不是公司名（"2025年年报分析" 会截出 "年报分析"）。
    # 注意后缀已在上面剥掉，所以这里可以放心用"公司"做排除条件。
    if cand in ("公司", "这家", "那家", "年报", "报告", "报表", "财务", "上市"):
        return None
    if any(k in cand for k in ("公司", "报告", "报表", "年报", "分析", "研究", "有限")):
        return None
    # 带疑问词的短语不是公司名（`2025年报里的收入确认政策是什么` 会截出"里的收入确认政策是什么"），
    # 这类是"问报告内容"的开放问题，应该走检索而不是被当成公司去下载。
    if any(k in cand for k in ("什么", "怎么", "如何", "为什么", "哪些", "是否", "吗", "呢")):
        return None
    return cand

#: 公司全称的常见后缀。巨潮的检索接口认简称，不认"股份有限公司"这种全称。
_LEGAL_SUFFIXES = ("股份有限公司", "有限责任公司", "集团有限公司", "有限公司",
                   "集团", "控股", "股份", "有限")


def strip_legal_suffix(name: str) -> str:
    """`中国黄金股份有限公司` → `中国黄金`。"""
    out = (name or "").strip()
    changed = True
    while changed:
        changed = False
        for suf in _LEGAL_SUFFIXES:
            if out.endswith(suf) and len(out) > len(suf) + 1:
                out = out[: -len(suf)]
                changed = True
    return out


def _fuzzy_company(name: str, db_path) -> "tuple | None":
    """在**已知公司**里找最像的那个，返回 (公司名, 相似度)。

    为什么需要：用户会把名字记错或打乱 —— 实测「中旭创科」（真名"中际旭创"）、
    「中旭科」都出现过。巨潮对错名是精确匹配，查不到就查不到，
    但我们可以在本地库里按**汉字重合度**找最接近的，然后**反问确认**。
    """
    from company_names import normalise
    from storage import known_companies

    target = set(normalise(name))
    if len(target) < 2:
        return None
    scored = []
    for company in known_companies(db_path):
        n = normalise(company)
        if len(n) < 2:
            continue
        common = len(target & set(n))
        score = common / max(len(target), len(n))
        scored.append((score, company))
    if not scored:
        return None
    scored.sort(reverse=True)
    best = scored[0]
    # 必须有明显优势，否则容易被"中科曙光"之类抢走
    if best[0] < 0.6:
        return None
    if len(scored) > 1 and best[0] - scored[1][0] < 0.1:
        return None
    return best[1], best[0]


def _company_span(question: str) -> "str | None":
    """问句里"年份/报表词之前的那一整段"，作为公司名的**备用关键词**。

    `_candidate_company` 用正则截，可能少截一个字（实测"上纬新材"被截成"上新材"）。
    这里退一步：把年份或报表词之前的内容整段拿来再试一次，能救回这类截断。
    """
    q = re.sub(r"\s", "", question or "")
    q = _strip_lead(q)
    cut = len(q)
    for kw in list(_REPORT_WORDS) + ["19", "20"]:
        i = q.find(kw)
        if i > 0:
            cut = min(cut, i)
    span = q[:cut].strip("的")
    if 2 <= len(span) <= 12 and span != _candidate_company(question):
        return span
    return None


def _suggest_available(name: str, year, report_type: str) -> str:
    """年报还没披露时，看看这一年有没有半年报/季报，给用户一个可执行的建议。"""
    from downloader import list_announcements, resolve_org
    try:
        code, org, _ = resolve_org(name)
    except Exception:                       # noqa: BLE001
        return ""
    found = []
    for alt in ("半年报", "一季报", "三季报"):
        if alt == report_type:
            continue
        try:
            anns = list_announcements(code, org, alt, f"{year}-01-01",
                                      f"{year}-12-31")
        except Exception:                   # noqa: BLE001
            anns = []
        if anns:
            found.append(alt)
    if not found:
        return ""
    opts = "、".join(found)
    return (f"\n\n目前能查到的是 {year} 年的{opts}。"
            f"需要的话说一句「帮我分析 {name} {year} {found[0]}」即可。")


def _ingest_one(company: str, report_type: str, year, db_path) -> dict:
    """下载 → 解析 → 入库（不建向量索引）→ 返回落库的 (公司, 期间)。"""
    from downloader import fetch, resolve_org
    from models import ReportKey
    from parser import parse

    # **每一步都报进度**：下载一份 200 页的年报可能要一两分钟，
    # 不给反馈的话用户只知道"屏幕卡住了"（实测有次整条链路 20 分钟，
    # 全程没有任何输出，根本分不清是在下载、解析还是死锁）。
    def _say(msg: str) -> None:
        print(msg, flush=True)

    _say(f"⏳ 正在解析公司代码：{company}")
    code, _org, name = resolve_org(company)
    _say(f"✅ 公司：{name}（{code}）")

    if year:
        start, end = f"{year}-01-01", f"{year + 3}-12-31"
    else:
        start, end = "2015-01-01", f"{date.today().year + 1}-12-31"
    _say(f"📥 正在从巨潮下载 {name} {report_type}（{year or '最新'}）…")
    t0 = time.time()
    pdf = fetch(name, report_type, start, end, year=year)
    _say(f"✅ 已下载：{Path(pdf).name}（{Path(pdf).stat().st_size / 1e6:.1f} MB，"
         f"{time.time() - t0:.0f}s）")

    # 期间从**落盘文件名**取：`2024年年度报告.PDF` → 2024。
    # 不能直接信用户问句里的年份 —— 文件是接口按标题挑的，两者理论上一致，
    # 但以文件为准可以避免"库里写着 2024、文件其实是 2023"这种错配。
    m = re.search(r"((?:19|20)\d{2})年", Path(pdf).name)
    actual_year = int(m.group(1)) if m else year
    if actual_year is None:
        raise LookupError(f"无法从文件名判断报告年份：{Path(pdf).name}")

    period = f"{actual_year}{_PERIOD_SUFFIX_LIKE.get(report_type, '')}"
    key = ReportKey(name, code, report_type, period)
    # **verify=False：下载路径不调大模型**。
    # `verify=True` 会逐份调 LLM 复核抽出的数字，网关一慢就挂十几分钟
    # （实测「帮我下载并分析 五粮液 2025 年年报」卡死 13 分钟，堆栈停在 llm_verifier）。
    # 数字的正确性由确定性校验保证：恒等式自检 + `main.py validate` 与东财逐项比对。
    _say("🔍 正在解析 PDF（定位三大报表 + 抽取指标）…")
    t0 = time.time()
    res = parse(pdf, key, verify=False, db_path=db_path)
    _say(f"✅ 已入库 {len(res.metrics)} 个指标（{time.time() - t0:.0f}s）")

    # 建向量索引：不建的话后续"开放问题"（为什么变、管理层怎么说）检索不到这份年报，
    # 只能答精确数字。索引失败**不影响**分析本身，故降级为 0 并继续。
    indexed = 0
    from config import ENABLE_RAG
    if not ENABLE_RAG:
        _say("⏭️ 已跳过向量索引（EMBEDDING_MODEL=none）—— 查数字与出报告不受影响")
        return {"company": name, "report_type": report_type, "period": period,
                "pdf": str(pdf), "indexed": 0}

    try:
        from indexer import ReportIndexer
        from text_extractor import extract_chunks
        _say(f"🧠 正在建向量索引（首次需下载模型，可设 EMBEDDING_MODEL=small/m3/none）…")
        t0 = time.time()
        indexed = ReportIndexer().index_report(
            name, period, extract_chunks(pdf))
        _say(f"✅ 已索引 {indexed} 个文本块（{time.time() - t0:.0f}s）")
    except Exception as e:                       # noqa: BLE001
        _say(f"⚠️ 向量索引失败（不影响分析）：{e}")
        indexed = 0

    # **新公司入库后顺手刷新 HTML 看板**，否则看板里永远看不到它
    try:
        from report_html import refresh_quietly
        if refresh_quietly(db_path):
            _say("📊 已刷新数据看板（/html 可打开）")
    except Exception:                    # noqa: BLE001
        pass

    return {"company": name, "report_type": report_type, "period": period,
            "pdf": str(pdf), "indexed": indexed}


def _period_of(year, report_type: str) -> "str | None":
    if year is None:
        return None
    return f"{year}{_PERIOD_SUFFIX_LIKE.get(report_type, '')}"


def has_report(company: str, report_type: str, period: "str | None", db_path) -> bool:
    """库里是否**已有这份**报告（公司+类型+期间三者全中）。

    不能只看公司名：库里已有五粮液 2024 年报，不代表 2025 年报也在。
    实测「帮我下载并分析 五粮液 2025 年年报」就是因为只看公司名被跳过下载，
    最后掉到 RAG 报"未找到资料"。
    """
    if not period:
        return False
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute(
            "SELECT 1 FROM reports WHERE company=? AND report_type=? AND period=?",
            (company, report_type, period)).fetchone()
        return bool(row)
    except sqlite3.Error:
        return False
    finally:
        conn.close()


def _try_ingest(question: str, db_path, *, resolve_fn=None, fetch_and_parse=None,
                announce: bool = True):
    """问句要的是「库外公司 + 某年报告」→ 联网取回、解析入库、直接出分析。

    触发条件**三重且都必须是显式的**：有报表类型词 + 有「分析/总结」类意图，
    且公司不在库中。任一不满足就返回 None，交给原有链路 ——
    绝不因为"像在问公司"就去联网下载 5MB PDF。
    """
    q = question or ""
    if not any(w in q for w in _REPORT_WORDS):
        return None
    if not _wants_report(q):
        return None
    cand = _candidate_company(q)
    if not cand:
        return None
    period_m = _PERIOD_RE.search(q)
    year = int(period_m.group(1)[:4]) if period_m else None
    report_type = _report_type_hint(q) or (
        _report_type_of(period_m.group(1)) if period_m else "年报")

    # **按公司+类型+期间**判断是否已入库（不是只看公司名）。
    known = _known_companies(db_path)
    cand_n = _norm_name(cand)
    db_company = next((c for c in known
                       if cand_n in _norm_name(c) or _norm_name(c) in cand_n), None)
    if db_company:
        if has_report(db_company, report_type, _period_of(year, report_type), db_path):
            return None          # 这份报告本地已有，走原有分析链路（秒回）
        if year is None:
            return None          # 没给年份就无从判断缺哪一份，交给 RAG 追问
        # 公司熟悉但这份报告没有 → 继续走下载

    resolve = resolve_fn
    if resolve is None:
        from downloader import resolve_org as resolve

    # 先用正则截出的候选；失败再用"年份之前那一整段"兜一次
    # （实测"上纬新材"曾被截成"上新材"，精确检索直接查不到）
    # **未知公司也要有进度**：解析代码是一到两次网络请求，不给提示就像卡住了
    if announce and not any(_norm_name(c) in _norm_name(q)
                            for c in _known_companies(db_path)):
        print(f"⏳ 正在巨潮检索「{cand}」…", flush=True)

    name = None
    hint = ""
    # 依次尝试：正则截出的候选 → 年份前整段 → 两者去掉公司后缀的形式。
    # 用户常直接说全称（`中国黄金股份有限公司`），而巨潮只认简称。
    keywords = []
    for raw in (cand, _company_span(q)):
        if not raw:
            continue
        for k in (raw, strip_legal_suffix(raw)):
            if k and k not in keywords:
                keywords.append(k)
    for keyword in keywords:
        if not keyword:
            continue
        try:
            code, _org, name = resolve(keyword)
        except Exception:
            name = None
            continue

        # **简称有歧义时不要默默挑第一个**：巨潮搜"海螺"会先返回 000619 海螺新材，
        # 而用户想要的可能是 600585 海螺水泥。优先选问句里真正出现过的那个，
        # 否则保留首选但明确告警，让用户能当场纠正。
        try:
            from downloader import search_orgs
            alts = search_orgs(keyword)
        except Exception:                    # noqa: BLE001
            alts = []
        qn = _norm_name(q)
        picked = next((a for a in alts if _norm_name(a["name"]) in qn), None)
        if picked:
            code, _org, name = picked["code"], picked["orgId"], picked["name"]
        others = [a for a in alts if a["name"] != name]
        if len(alts) > 1 and others:
            hint = ("⚠️ 「%s」对应多家公司：%s。本次按 %s(%s) 处理；"
                    "如需另一家，请说全称（如「%s%s年报」）"
                    % (keyword,
                       "、".join(f"{a['name']}({a['code']})" for a in alts[:4]),
                       name, code, others[0]["name"], year or ""))
        break
    if name is None:
        # **品牌名不是工商全称**：`绝味鸭脖` 查不到，但 `绝味` 能定位到 `绝味食品`。
        # 逐字截短再试，并要求返回的简称确实以该前缀开头，避免"格力"配到别家。
        # **最多试 3 次**：每截一位就是一次网络请求，候选名长时会把界面拖死
        # （实测一次挂起 20 分钟）。品牌名通常只多 2~4 个字，3 次足够。
        attempts = 0
        for cut in range(len(cand) - 1, 1, -1):
            if attempts >= 3:
                break
            prefix = cand[:cut]
            attempts += 1
            try:
                code, org_id, guess = resolve(prefix)
            except Exception:                # noqa: BLE001
                continue
            if guess and guess.startswith(prefix):
                name, code, hint = guess, code, (
                    f"（「{cand}」不是工商全称，按「{prefix}」定位到「{guess}」）")
                break

    if name is None:
        # **查不到就找相近的**，反问确认，而不是干巴巴一句"检索不到"。
        # 实测用户把"中际旭创"说成"中旭创科"，只得到一句"简称不准确"，很挫败。
        near = _fuzzy_company(cand, db_path)
        if near:
            guess, score = near
            pending = f"分析{guess}{year or ''}{report_type}"
            return {"route": "confirm", "metrics": [], "citations": [],
                    "companies": [], "pending": pending,
                    "answer": (f"巨潮里没有「{cand}」，你找的是不是「{guess}」？\n"
                               f"回复「是」我就分析 {guess} {year or ''} {report_type}；"
                               f"如果不对，请换个说法（全称或股票代码都行）。")}
        return None                      # 查不到这家公司 → 交给 RAG 说明

    # **A 股代码是 6 位**：`周大福` 会被解析成港股 `00659 周大福创建`，
    # 而巨潮的 A 股公告库里没有港股年报 —— 不说清楚，用户只会看到"年报未披露"。
    if len(str(code)) != 6:
        return {"route": "ingest", "metrics": [], "citations": [], "companies": [],
                "entity": {"company": name, "report_type": report_type,
                           "period": str(year) if year else None},
                "answer": f"「{name}」是港股（{code}），不在本系统的支持范围。\n"
                          f"这里只能分析 A 股年报（巨潮的 A 股公告库）。"
                          f"如果它有 A 股主体，用那个简称再问一次。"}

    # 复核：接口返回的简称必须真的出现在问句里，避免把「分析」之类当公司名。
    # **候选是纯代码时跳过这条** —— 用户报的就是代码，简称当然不在句子里。
    # `hint` 非空说明是"品牌名/别名"经由前缀定位得到的，属于有意为之，放行
    if (name and not hint and not cand.isdigit()
            and name not in q and cand not in name):
        return None

    if hint:
        print(hint, flush=True)

    # **明确告诉用户"库里没有，我去下载"** —— 不要让他再说一遍"下载"。
    if year:
        print(f"📭 库里没有 {name} {year} 年{report_type}，正在自动从巨潮下载…",
              flush=True)

    ingest = fetch_and_parse or (lambda: _ingest_one(name, report_type, year, db_path))
    try:
        got = ingest()
    except Exception as e:                       # noqa: BLE001
        msg = str(e)
        # **年报还没披露**是常见且可解释的情况：A 股年报一般次年 4 月底前发布。
        # 与其回一句"下载失败"，不如说清楚现状，并给出能立刻做的下一步。
        if "未找到" in msg or "LookupError" in type(e).__name__:
            tip = _suggest_available(name, year, report_type) if year else ""
            return {"route": "ingest", "metrics": [], "citations": [],
                    "companies": [],
                    "entity": {"company": name, "report_type": report_type,
                               "period": str(year) if year else None},
                    "answer": f"{name}的 {year or ''} 年{report_type}目前还没有披露，"
                              f"巨潮上查不到这份公告。"
                              f"（A 股年报一般在次年 4 月底前发布）{tip}"}
        return {"route": "ingest", "metrics": [], "citations": [], "companies": [],
                "answer": f"下载/解析失败：{msg}"}

    from analysis import brief_text, build_analysis
    a = build_analysis(got["company"], got["report_type"], got["period"], db_path)
    idx_note = (f"，已索引 {got['indexed']} 个文本块"
                if got.get("indexed") else "，向量索引未建立（追问开放问题会检索不到）")
    head = (f"📥 已下载并解析：{got['company']} {got['period']} {got['report_type']}"
            f"（PDF：{Path(got['pdf']).name}{idx_note}）\n\n")
    if not a.get("ok"):
        return {"route": "ingest", "metrics": [], "citations": [], "companies": [],
                "answer": head + a.get("error", "解析后仍无法生成分析")}
    if not wants_narrative(question):
        narr = _skip_narrative(wants_document(question))
    else:
        narr = _narrative_block(got, a, db_path,
                                timeout=_NARRATIVE_TIMEOUT,
                                max_retries=_NARRATIVE_RETRIES)
    tail = _document_suffix(question, got["company"], got["report_type"],
                            got["period"], db_path, a, narr, force=True)
    return {"route": "ingest", "metrics": [], "citations": [], "companies": [],
            "analysis": a, "narrative": narr, "ingested": got,
            "answer": head + brief_text(a) + tail}


#: 出现这些词，说明用户大概率在问"某公司的某份报告"
#: **只收明确指向"某份报告"的词**。`看看/怎么样/情况` 这类太宽，
#: 会把"格力2025年经营情况讨论"这种开放问题也解析成报告，抢走检索的活。
_REPORTY_WORDS = ("年报", "半年报", "季报", "年度报告", "财报", "分析")


#: 看起来像年份、但不在合理区间里的四位数（`1015`、`1899`、`2999`）
_SUSPECT_YEAR_RE = re.compile(r"(?<!\d)(\d{4})(?=\s*年?)")


def _suspect_year(q: str, current_year: int = None) -> "str | None":
    r"""找出"像年份但明显不对"的数字，返回它；没有就返回 None。

    实测用户输入「分析中际旭创 1015 年年报」，`1015` 不匹配 `(19|20)\d{2}`，
    于是"没有年份"→ 跑去检索，看起来像卡住。这种情况应该直接问清楚。
    """
    from datetime import date

    now = current_year or date.today().year
    for m in _SUSPECT_YEAR_RE.finditer(q or ""):
        v = int(m.group(1))
        if 1900 <= v <= now + 1:
            continue                      # 正常年份（含明年，年报可能已预告）
        if v < 1900 or v > now + 1:
            # `2025` 这种正常年份不会走到这里；只报"明显不像年份"的
            if len(m.group(1)) == 4:
                return m.group(1)
    return None


def _wants_report(q: str) -> bool:
    """这句是不是"要某份报告"。

    两种都算：
      - 有动词：分析/看看/下载/查一下…
      - **没有动词但形式明确**：`澜起科技2025年半年报`、`上纬新材2025年度报告`
        （限句长，避免把"2025年报里的收入确认政策是什么"这种内容问题吞进来）
    """
    q = q or ""
    # **问报告内容**（什么/如何/为什么/哪些/是否/吗/呢）走检索，不算"要这份报告"。
    # 注意"怎么样"是评价式提问（想要分析），不含"什么"，因此不会被排除。
    if any(k in q for k in ("什么", "如何", "为什么", "哪些", "是否", "吗", "呢")):
        return False
    if any(h in q for h in _ANALYSIS_HINTS + _LOOK_HINTS):
        return True
    return (any(w in q for w in _REPORT_WORDS)
            and _PERIOD_RE.search(q) is not None
            and len(q) <= 30)


def _needs_semantic_parse(question: str, history=None) -> bool:
    """正则解析不了、但明显是在问报告 → 交给语义解析。

    正则只认"公司名 + 年份"；用户说"中国黄金的年报帮我看看2025年的"就抓不到公司。
    """
    q = question or ""
    has_company = _candidate_company(q) is not None
    has_period = _PERIOD_RE.search(q) is not None
    if any(w in q for w in _REPORTY_WORDS):
        return not (has_company and has_period)
    # 有上文时的模糊追问（"看的怎么样了""然后呢"）也交给模型理解
    if history and not has_company and len(q) <= 20:
        return True
    return False


def _semantic_parse(question: str, db_path, history=None) -> "dict | None":
    """模型理解的兜底路径。返回 None 表示"没帮上忙，按原流程走"。"""
    try:
        import intent
    except Exception:                        # noqa: BLE001
        return None
    try:
        parsed = intent.parse(question, history=history)
    except Exception:                        # noqa: BLE001
        parsed = None
    if not parsed:
        # 明显在问"某年的报告"，但连公司名都没解析出来 → 直接问清楚，别去检索瞎猜
        has_question = any(k in (question or "") for k in
                           ("什么", "怎么", "如何", "为什么", "哪些", "是否", "吗", "呢"))
        # 带疑问词的是"问报告里的内容"（如"2025年报里的收入确认政策是什么"）——
        # 该走检索，不该反问"是哪家公司"。
        if (not has_question and _PERIOD_RE.search(question or "")
                and _candidate_company(question) is None):
            return {"route": "confirm", "metrics": [], "citations": [],
                    "companies": [], "pending": None,
                    "answer": "请问是哪家公司的哪一年报告？"
                              "例如「中国黄金 2025 年报」，我直接给你分析。"}
        return None

    canonical = intent.canonical(parsed)
    # 置信度不够就先问一句，不猜 —— 猜错公司比多问一句代价大得多
    if parsed["confidence"] < intent.CONFIRM_BELOW:
        return {"route": "confirm", "metrics": [], "citations": [],
                "companies": [], "pending": canonical,
                "answer": (f"我不太确定你的意思。你是想问「{parsed['company']} "
                           f"{parsed.get('period') or ''} {parsed.get('report_type', '年报')}」吗？"
                           f"回复「是」我就开始分析；如果是别的公司，直接说公司名即可。")}

    # 用标准问法重跑，不再触发语义解析；**不重复播报进度**
    res = _answer_direct(canonical, db_path, announce=False)
    if res.get("route") == "rag":
        return None                          # 模型的理解也没能落地，按原流程兜底
    prefix = (f"（我理解为：{parsed['company']} {parsed.get('period') or ''} "
              f"{parsed.get('report_type', '年报')}）\n\n")
    res = dict(res)
    res["answer"] = prefix + res.get("answer", "")
    return res


def answer(question: str, db_path, top_k: int = 5, history=None) -> dict:
    # **年份写错就直说**，别当成"没提年份"去检索
    bad = _suspect_year(question)
    if bad and not _PERIOD_RE.search(question or ""):
        return {"route": "confirm", "metrics": [], "citations": [], "companies": [],
                "pending": None,
                "answer": (f"「{bad}」看起来不像年份。你是想说 20{bad[-2:]} 年，"
                           f"还是别的年份？\n再发一次完整的问法就行，"
                           f"例如「分析中际旭创 2025 年年报」。")}

    # **自由语序兜底（前置）**：正则连公司名/年份都抓不到时，先让模型理解。
    if _needs_semantic_parse(question, history):
        parsed = _semantic_parse(question, db_path, history)
        if parsed is not None:
            return parsed

    res = _answer_direct(question, db_path, top_k)

    # **自由语序兜底（后置）**：正则"截到了"但截错（`2025年报 中国黄金`
    # 会截成"报中国黄金"），流程会掉到检索。这时用模型再解析一次意图。
    if (res.get("route") == "rag"
            and any(w in (question or "") for w in _REPORTY_WORDS)
            and (_PERIOD_RE.search(question or "") or history)):
        parsed = _semantic_parse(question, db_path, history)
        if parsed is not None and parsed.get("route") != "rag":
            return parsed
    return res


def _answer_direct(question: str, db_path, top_k: int = 5,
                   announce: bool = True) -> dict:
    info = route(question, db_path)
    if info is not None:
        return answer_structured(info, db_path)
    analysis_res = _try_analysis(question, db_path)
    if analysis_res is not None:
        return analysis_res
    ingest_res = _try_ingest(question, db_path, announce=announce)
    if ingest_res is not None:
        return ingest_res
    refusal = _unservable_metric_question(question, db_path)
    if refusal is not None:
        return {"route": "structured", "metrics": [], "citations": [],
                "companies": [], "answer": refusal}
    return answer_rag(question, db_path, top_k)
