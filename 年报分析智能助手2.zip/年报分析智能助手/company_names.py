"""公司名归一化与匹配。**不依赖 agent / analysis**，避免循环导入。

## 为什么要单独一个模块

`analysis.resolve_report` 曾经 `from agent import match_company`，
而 `agent` 又会在运行时 `from analysis import ...` —— 这是个环。
正常情况能跑，但**改了其中一个模块后**，长驻进程（对话模式）里会出现
"新的 analysis 去旧的 agent 里找不存在的名字"：

    ImportError: cannot import name 'match_company' from 'agent'

把归一化与匹配抽出来，两边都只依赖这个模块，环就断了。
"""
import re
import unicodedata


def normalise(text: str) -> str:
    """全角转半角、去空白。

    巨潮返回的简称常带全角字母（`万科Ａ`、`ＴＣＬ科技`），用户手打的是半角
    `万科A`。不归一化就匹配不上 —— 实测问「帮我出一份万科A2025年报的分析报告」
    被判成"库里没有这家公司"，直接掉到 RAG 答"未收录"。
    """
    return re.sub(r"\s", "", unicodedata.normalize("NFKC", str(text or "")))


def match(question: str, names) -> "str | None":
    """问句里出现**完整公司名**才返回（保留库里的原始写法）。

    简称（`格力`→`格力电器`）和错字（`中旭创科`→`中际旭创`）的处理放在
    `agent.match_company` / `agent._fuzzy_company` 里 —— 那里能拿到候选名，
    才能判断"是干净的简称"还是"部分重合的猜测"，后者必须反问确认。
    """
    q = normalise(question)
    if not q:
        return None
    for name in names or []:
        n = normalise(name)
        if n and n in q:
            return name
    return None
