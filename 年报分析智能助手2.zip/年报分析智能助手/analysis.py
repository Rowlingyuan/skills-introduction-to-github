"""把库里的一份报表变成一份**可核对的**分析。

设计底线（与本项目其余部分一致）：
- **所有数字来自 SQLite**（带页码与置信度），比率由这些数字算出 ——
  不让大模型生成或复述任何数字；
- **缺指标就说缺**，明确标注"未抽到"，绝不用 0 或估算值顶替；
- **不成立就告警**：资产负债表三项对不上时显式提示（见 `identity_violations`）。

本模块只依赖 `storage`，不依赖 agent / 解析层，故可离线单测。
"""
import re
import sqlite3

from storage import load_metrics

#: 资产负债表的三项核心。三者对不上说明抽取有误或口径混用。
CORE_TRIO = ("资产总计", "负债合计", "所有者权益合计")
IDENTITY_TOL = 1e8      # 与 tests/run_golden 的恒等式默认门禁一致：只抓量级级错误

_QUARTER_RE = re.compile(r"^(\d{4})(?:Q(\d))?$")


def period_key(period: str):
    """期间排序键：'2025' → (2025, 4)，'2025Q1' → (2025, 1)。年报排在同年季报之后。"""
    m = _QUARTER_RE.match(period or "")
    if not m:
        return (0, 0, period or "")
    return (int(m.group(1)), int(m.group(2) or 4), period)


def _by_name_period(metrics) -> dict:
    out = {}
    for m in metrics:
        out[(m.name, m.period)] = m
    return out


#: 资产负债表自洽检查：(名称, 方向, 参与指标)。与 `tests/run_golden.py` 的 IDENTITIES
#: 同源，但那边服务于黄金集回归、这边服务于**用户看到的分析**：抽取出来的数字若连
#: 会计上都不可能成立，就必须在分析里点名，而不是当成事实呈现。
IDENTITY_CHECKS = [
    ("资产总计 = 负债合计 + 所有者权益合计", "==",
     ("资产总计", "负债合计", "所有者权益合计")),
    ("流动负债合计 <= 负债合计", "<=", ("流动负债合计", "负债合计")),
    ("流动资产合计 <= 资产总计", "<=", ("流动资产合计", "资产总计")),
    ("流动资产合计 >= 货币资金 + 存货 + 应收账款", ">=",
     ("流动资产合计", "货币资金", "存货", "应收账款")),
]


def identity_violations(metrics) -> list:
    """资产负债表**在会计上不可能成立**的年份，返回 [{year, check, diff}]。

    抽不到参与指标的年份**不算违规**（那是覆盖问题，由 `gaps` 报告），
    否则会把"没测"误报成"错了"—— 这正是本模块最忌讳的静默。
    """
    d = _by_name_period(metrics)
    years = sorted({m.period for m in metrics}, key=period_key)
    out = []
    for y in years:
        for name, direction, terms in IDENTITY_CHECKS:
            vals = [d.get((t, y)) for t in terms]
            if any(v is None for v in vals):
                continue
            v = [x.value for x in vals]
            if name.startswith("资产总计"):
                expect, actual = v[1] + v[2], v[0]
            elif name.startswith("流动负债合计 <="):
                expect, actual = v[1], v[0]
            elif name.startswith("流动资产合计 <="):
                expect, actual = v[1], v[0]
            else:
                expect, actual = v[1] + v[2] + v[3], v[0]
            diff = actual - expect
            ok = (abs(diff) <= IDENTITY_TOL if direction == "=="
                  else diff <= IDENTITY_TOL if direction == "<="
                  else -diff <= IDENTITY_TOL)
            if not ok:
                out.append({"year": y, "check": name, "diff": diff})
    return out


def available_reports(db_path) -> list:
    """库里有哪些报告 —— 供界面下拉与 CLI 列举。"""
    conn = sqlite3.connect(str(db_path))
    try:
        rows = conn.execute(
            "SELECT company, report_type, period FROM reports "
            "ORDER BY company, report_type, period").fetchall()
    finally:
        conn.close()
    return [{"company": c, "report_type": t, "period": p} for c, t, p in rows]


def resolve_report(question: str, db_path) -> "dict | None":
    """从自然语言里定位一份报告：「某某公司某某年年报」→ (company, report_type, period)。

    三者全中才算命中；公司必须已在库（与 `agent.route` 同一纪律：库里没有的公司不猜）。
    """
    # **不 import agent**：agent → analysis 是运行时的单向依赖，
    # 反过来 import 会形成环，改任一模块后长驻进程就会 ImportError。
    from agent import _PERIOD_RE, _report_type_hint, _report_type_of
    from company_names import match
    from storage import known_companies
    m = _PERIOD_RE.search(question or "")
    if not m:
        return None
    period = m.group(1)
    company = match(question, known_companies(db_path))
    if not company:
        return None
    report_type = _report_type_hint(question) or _report_type_of(period)
    have = available_reports(db_path)
    if any(r["company"] == company and r["report_type"] == report_type
           and r["period"] == period for r in have):
        return {"company": company, "report_type": report_type, "period": period}
    return None


# 各报表要看的指标（按重要性排序；库里没有的会进 `gaps`）
PROFIT_ROWS = ["营业收入", "营业成本", "营业总成本", "销售费用", "管理费用",
               "研发费用", "财务费用", "营业利润", "利润总额", "净利润",
               "归母净利润", "基本每股收益"]
BALANCE_ROWS = ["资产总计", "负债合计", "所有者权益合计", "归母净资产",
                "货币资金", "应收账款", "存货",
                # 勾稽关系要用：未分配利润的变动要能被"净利润 − 分红 − 提盈余公积"解释
                "未分配利润", "盈余公积", "应付股利",
                "流动资产合计", "流动负债合计"]
#: 金融业（银行/券商/保险）的报表主干 —— 与工商企业完全是两套科目。
BANK_PROFIT_ROWS = ["营业收入", "利息净收入", "利息收入", "利息支出",
                    "手续费及佣金净收入", "业务及管理费", "信用减值损失",
                    "资产减值损失", "营业利润", "利润总额", "净利润", "归母净利润"]
BANK_BALANCE_ROWS = ["资产总计", "负债合计", "所有者权益合计", "归母净资产",
                     "发放贷款和垫款", "吸收存款", "同业存放", "拆入资金",
                     "存放中央银行款项", "买入返售金融资产"]
BROKER_PROFIT_ROWS = ["营业收入", "手续费及佣金净收入", "利息净收入", "投资收益",
                      "业务及管理费", "营业利润", "利润总额", "净利润", "归母净利润"]
BROKER_BALANCE_ROWS = ["资产总计", "负债合计", "所有者权益合计", "归母净资产",
                       "结算备付金", "融出资金", "买入返售金融资产", "代理买卖证券款"]
INSURER_PROFIT_ROWS = ["营业收入", "已赚保费", "保险业务收入", "赔付支出",
                       "提取保险责任准备金", "手续费及佣金支出", "投资收益",
                       "营业利润", "利润总额", "净利润", "归母净利润"]
INSURER_BALANCE_ROWS = ["资产总计", "负债合计", "所有者权益合计", "归母净资产",
                        "保险合同准备金", "货币资金"]

#: 行业 → (利润表科目, 资产负债表科目)
INDUSTRY_ROWS = {
    "bank": (BANK_PROFIT_ROWS, BANK_BALANCE_ROWS),
    "broker": (BROKER_PROFIT_ROWS, BROKER_BALANCE_ROWS),
    "insurer": (INSURER_PROFIT_ROWS, INSURER_BALANCE_ROWS),
}

INDUSTRY_NAMES = {"bank": "银行", "broker": "证券公司", "insurer": "保险公司",
                  "general": "工商企业"}

#: 名称里带这些字样的，基本可以直接判行业（年报标题/公司简称都带）
_INDUSTRY_NAME_HINTS = [
    ("bank", ("银行",)),
    ("insurer", ("保险", "人寿", "财险", "人保", "太保", "平安")),
    ("broker", ("证券", "期货")),
]


def detect_industry(company: str, metrics=None) -> str:
    """判定行业：bank / broker / insurer / general。

    两级判断：
      1. **公司名**最可靠（`交通银行`、`中信证券`、`中国平安`）；
      2. 名字判不出时看**科目特征**（有"吸收存款"→银行；有"已赚保费"→保险；
         有"结算备付金"→券商）。
    """
    name = company or ""
    for industry, hints in _INDUSTRY_NAME_HINTS:
        if any(h in name for h in hints):
            # "平安"要排除掉非保险主体（平安银行仍是银行）
            if industry == "insurer" and "银行" in name:
                return "bank"
            return industry

    if metrics:
        names = {getattr(m, "name", None) or m.get("name") for m in metrics}
        # **单个科目不足以判定**：格力电器有财务公司，
        # 资产负债表里也有「发放贷款和垫款」，只看这一项会把它当成银行
        # （实测格力 2025 被分到银行口径，利润表主项变成了利息净收入那一套）。
        # 所以要求**两个以上**行业特征科目同时出现。
        # 银行：**必须同时有「吸收存款」和「存放中央银行款项」**（或没有营业成本）。
        # 格力有财务公司，「吸收存款/发放贷款和垫款」它也有，但不会有"存放中央银行款项"，
        # 且利润表有"营业成本" —— 这两条能把它挡在外面。
        if "吸收存款" in names:
            if "存放中央银行款项" in names:
                return "bank"
            if "利息净收入" in names and "营业成本" not in names:
                return "bank"
        if sum(1 for n in ("已赚保费", "赔付支出", "提取保险责任准备金",
                           "保险合同准备金") if n in names) >= 2:
            return "insurer"
        if sum(1 for n in ("结算备付金", "代理买卖证券款", "融出资金")
               if n in names) >= 2:
            return "broker"
    return "general"


#: **有息负债**的构成科目。加总起来才是真实偿债压力 —— 资产负债率把
#: 应付账款这类经营性占款也算进了负债，会把一家好公司说成高杠杆。
INTEREST_BEARING_ROWS = ["短期借款", "一年内到期的非流动负债",
                         "长期借款", "应付债券", "租赁负债"]
CASHFLOW_ROWS = ["经营活动现金流量净额", "投资活动现金流量净额",
                 "筹资活动现金流量净额", "销售商品收到的现金",
                 # 表内勾稽：三类净额之和 = 净增加额；期初 + 净增加 = 期末
                 "汇率变动对现金及现金等价物的影响",
                 "现金及现金等价物净增加额", "期末现金及现金等价物余额",
                 "期初现金及现金等价物余额"]
#: 多年趋势要画的科目。**营业成本与经营现金流也要**：只有收入和利润画不出
#: "毛利率在怎么走""利润有没有现金支撑"，而这两条恰恰是趋势图最有价值的部分。
TREND_METRICS = ["营业收入", "营业成本", "净利润", "归母净利润",
                 "经营活动现金流量净额"]


def _rows_for(names, d, cur, prev) -> list:
    """把指标名清单变成带同比的表格行；缺的记为 None（调用方收进 gaps）。"""
    out = []
    for n in names:
        c = d.get((n, cur))
        p = d.get((n, prev))
        if c is None and p is None:
            continue
        yoy = None
        # **上期为负或为零时不给百分比**。财务费用从 -0.84 亿到 -0.17 亿，
        # 用 ÷|上期| 算出"+79.34%"没有任何经济含义（净利息收入减少而已）；
        # 投资/筹资现金流净额跨零时同样会出现 ±100% 以上的怪数字。
        # 这类科目只看变动额，读者才读得懂。
        if (c is not None and p is not None and p.value is not None
                and p.value > 0):
            yoy = (c.value - p.value) / abs(p.value) * 100
        out.append({
            "label": n,
            "cur": None if c is None else c.value,
            "prev": None if p is None else p.value,
            "yoy": yoy,
            "page": None if c is None else c.source_page,
            "confidence": None if c is None else c.confidence,
            "missing": c is None,
        })
    return out


def _ratio(label, num, den, cur, prev, unit="%"):
    """比率 = 分子 / 分母。任一为 None 或分母为 0 → 不给值（不猜）。

    `num`/`den` 是 {期间: MetricValue}。**调用方负责分清谁在分子上** ——
    实测把 营收/净利 写反会得到 590% 的"净利率"这种一眼假却没人拦的数字。
    """
    def one(y):
        a, b = num.get(y), den.get(y)
        if a is None or b is None or not b or b.value == 0:
            return None
        return a.value / b.value * (100 if unit == "%" else 1)
    return {"label": label, "cur": one(cur), "prev": one(prev), "unit": unit}


def _margin(label, num_name, di, cur, prev) -> dict:
    """利润率 = 指定指标 / 营业收入。缺任一侧或营收为 0 → 不给值（不猜）。"""
    def one(y):
        r, n = di.get(("营业收入", y)), di.get((num_name, y))
        if r is None or n is None or not r.value:
            return None
        return n.value / r.value * 100
    return {"label": label, "cur": one(cur), "prev": one(prev), "unit": "%"}


def _ib_ratio(ib: dict, db_: dict, cur: str, prev: str) -> dict:
    """有息负债 / 资产总计。两个期间各自算，缺任一侧就不给值（不猜）。"""

    def one(year):
        total = ib.get(year)
        assets = db_.get(("资产总计", year))
        if total is None or assets is None or not assets.value:
            return None
        return total / assets.value * 100

    return {"label": "有息负债 / 资产总计", "cur": one(cur),
            "prev": one(prev), "unit": "%"}


def _gross_margin(di, cur, prev) -> dict:
    """毛利率 =（营业收入 − 营业成本）/ 营业收入。"""
    def one(y):
        r, c = di.get(("营业收入", y)), di.get(("营业成本", y))
        if r is None or c is None or not r.value:
            return None
        return (r.value - c.value) / r.value * 100
    return {"label": "毛利率", "cur": one(cur), "prev": one(prev), "unit": "%"}


def _pdf_path(company, report_type, period, db_path) -> "str | None":
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute(
            "SELECT file_path FROM reports WHERE company=? AND report_type=? AND period=?",
            (company, report_type, period)).fetchone()
    finally:
        conn.close()
    return row[0] if row else None


def revenue_mix_section(company, report_type, period, db_path, income_di) -> "dict | None":
    """「收入构成与变动」——**回答"为什么变"的那一节**。

    数据来自年报 MD&A 的构成表（不在三大报表里），故需要回读 PDF。
    抽不到就返回 None，调用方据此说明"该报告未找到构成表"，**不编**。
    """
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    from segments import contributions, extract_revenue_mix     # 惰性：pdfplumber 较重
    mix = extract_revenue_mix(path)
    if not mix:
        return None
    # 上交所格式的构成表不含合计行 → 用利润表的营业收入兜底当分母，否则算不出贡献度
    fallback = None
    if income_di.get(("营业收入", period)):
        cur_m = income_di[("营业收入", period)]
        others = [p for p in {k[1] for k in income_di if k[0] == "营业收入"}
                  if p != period]
        prev_m = income_di.get(("营业收入", others[-1])) if others else None
        fallback = {"cur": cur_m.value,
                    "prev": prev_m.value if prev_m else None}
    # **按报表原有的分组归位**（分行业 / 分产品 / 分地区各自成组），组内再按变动额排序。
    # 早先把三组混成一串按绝对变动额排，读起来是"制造业 / 消费电器 / 内销 / 其他业务…"，
    # 同一维度被拆散、看不出"分产品里谁最拖累"——用户直接点了这一条。
    cons = contributions(mix, fallback)
    grouped = []
    for g in mix.get("groups") or []:
        rows = [c for c in cons if c["group"] == g["name"]]
        if not rows:
            continue
        rows.sort(key=lambda x: abs(x["delta"]), reverse=True)
        grouped.append({"name": g["name"], "rows": rows})
    seen = {g["name"] for g in grouped}
    for c in cons:                       # 没有分组标题的形态（如茅台上交所格式）
        if c["group"] not in seen:
            grouped.append({"name": c["group"],
                            "rows": sorted([x for x in cons if x["group"] == c["group"]],
                                           key=lambda x: abs(x["delta"]), reverse=True)})
            seen.add(c["group"])
    return {
        "page": mix.get("page"), "unit": mix.get("unit"), "kind": mix.get("kind"),
        "total": mix.get("total") or fallback,
        "groups": grouped,
    }


def cash_quality_section(company, report_type, period, db_path) -> "dict | None":
    """资金可用性：期末现金及现金等价物 vs 账面货币资金（读附注）。

    「货币资金 1,105 亿」听起来很有钱，但其中 724 亿是不属于现金等价物的定期存款、
    106 亿是受限保证金 —— 真能动用的只有 276 亿。这一层只有附注能回答。
    """
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    try:
        from notes import extract_cash_quality
        got = extract_cash_quality(path)
    except Exception:
        return None
    return got if got.get("ok") else None


def receivables_section(company, report_type, period, db_path,
                        expected_net=None) -> "dict | None":
    """应收账款账龄结构 + 坏账准备（用报表应收账款净值交叉校验）。"""
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    try:
        from notes import extract_receivables
        got = extract_receivables(path, expected_net=expected_net)
    except Exception:
        return None
    return got if got.get("ok") else None


def goodwill_section(company, report_type, period, db_path) -> "dict | None":
    """商誉金额、占净资产比重、以及减值测试附注的位置。

    **不抽减值测试假设**（折现率/增长率）：各家披露格式差异太大，硬抽容易张冠李戴。
    只做"有没有、多大、去第几页看"这三件事。
    """
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    try:
        from notes import extract_goodwill
        got = extract_goodwill(path)
    except Exception:
        return None
    if not got.get("ok"):
        return {"ok": True, "has": False, "note": got.get("note", "")}

    # 重要性 = 商誉 / 归母净资产
    try:
        ms = load_metrics(company, report_type, period, db_path)
        eq = next((m.value for m in ms
                   if m.statement == "资产负债表" and m.name == "归母净资产"
                   and m.period == got.get("period")), None)
        if eq is None:
            eq = next((m.value for m in ms
                       if m.statement == "资产负债表" and m.name == "所有者权益合计"),
                      None)
    except Exception:
        eq = None
    share = (got["value"] / eq * 100) if (eq and got.get("value")) else None
    return {"ok": True, "has": True, "value": got["value"], "prev": got.get("prev"),
            "page": got.get("page"), "note_page": got.get("note_page"),
            "share": share}


def customer_section(company, report_type, period, db_path) -> "dict | None":
    """前五大客户集中度（读管理层讨论与分析）。"""
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    try:
        from notes import extract_customer_concentration
        got = extract_customer_concentration(path)
    except Exception:
        return None
    return got if got.get("ok") else None


def qualitative_section(company, report_type, period, db_path) -> "dict | None":
    """或有事项 / 承诺事项 / 关联交易：有没有、在第几页、首句是什么。"""
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    try:
        from notes import extract_qualitative_notes
        got = extract_qualitative_notes(path)
    except Exception:
        return None
    return got if got.get("ok") else None


def inventory_section(company, report_type, period, db_path,
                      expected_net=None) -> "dict | None":
    """存货跌价准备（读附注，用报表存货净值交叉校验）。

    `expected_net` 是资产负债表里的存货金额 —— 附注的「账面价值」必须等于它，
    对不上一律不报（`notes.extract_inventory_provision` 内部把关）。
    """
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    try:
        from notes import extract_inventory_provision
        got = extract_inventory_provision(path, expected_net=expected_net)
    except Exception:
        return None
    return got if got.get("ok") else None


def audit_section(company, report_type, period, db_path) -> "dict | None":
    """附注要点：审计意见类型 + 关键审计事项（读原文，不调模型）。

    抓不到（没入库 PDF / 解析失败）返回 None，**不编**。
    半年报通常未经审计，此时 `audited=False`，与"年报里找不到"是两回事。
    """
    path = _pdf_path(company, report_type, period, db_path)
    if not path:
        return None
    try:
        from notes import extract_audit
        got = extract_audit(path, report_type)
    except Exception:
        return None
    return got if got.get("ok") else None


#: 各表"抽到多少个科目"才算正常。低于下限 → 报表很可能没读全（版式/定位问题）。
#: 依据：样本里正常的工商企业报表是 资产负债表 25~32、利润表 36~40、现金流量表 10。
#: 券商/保险的科目结构不同，会天然偏低 —— **这正是我们要提示的**，
#: 而不是让它混在一份看起来很专业的报告里。
MIN_ROWS = {"资产负债表": 12, "利润表": 12, "现金流量表": 5}


def quality_flags(metrics, identity_violations) -> list:
    """**不联网**的数据可信度信号。返回人类可读的告警列表。

    为什么需要：用户问一家没见过的公司时，最危险的不是"抽不到"，
    而是"抽到了但不对" —— 券商报表只抽到 9 个资产科目，报告照样排版精美、
    数字照样带页码，肉眼完全看不出问题。这里用**科目数量 + 恒等式**兜底，
    让报告自己先说"我这份数据可能不可靠"。
    """
    flags = []
    by = {}
    for m in metrics:
        by.setdefault(m.statement, set()).add(m.name)
    for stmt, minimum in MIN_ROWS.items():
        names = by.get(stmt)
        if not names:
            continue          # 整张表没抽到由 gaps/error 负责说
        if len(names) < minimum:
            flags.append(
                f"{stmt}只抽到 {len(names)} 个科目（正常应在 {minimum} 个以上）—— "
                f"该表可能没读全，请核对原文")
    for v in identity_violations:
        flags.append(f"{v['year']} 年「{v['check']}」不成立，差额 {v['diff']:,.0f} 元")
    core = {"资产总计", "负债合计", "所有者权益合计"}
    if by.get("资产负债表") and not core <= by["资产负债表"]:
        missing = "、".join(sorted(core - by["资产负债表"]))
        flags.append(f"资产负债表缺核心科目：{missing}")
    return flags


#: 勾稽校验的容差：报表以"元"为单位、两位小数，2 元的容差足够兜住四舍五入
TIE_TOL = 2.0


def cross_statement_checks(metrics, cur: str, prev: str) -> list:
    """三大报表之间的**勾稽关系**（不只是表内加总）。

    为什么要单独做：单张表内部的恒等式（已有 2.4 节）只能证明"这张表自洽"，
    而三张表之间的数字必须能对上，才说明三张表是从同一套账里出来的。
    这里做四条**可验证、能定位**的检查：

      1. 资产总计 = 负债合计 + 所有者权益合计          （资产负债表内）
      2. 经营 + 投资 + 筹资净额 = 现金及现金等价物净增加额（现金流量表内）
      3. 期初现金 + 净增加额 = 期末现金                  （现金流量表头尾）
      4. 未分配利润变动 vs 净利润                        （跨表：利润表 → 资产负债表）

    第 4 条不判"对错"：差额通常来自分红与提取盈余公积，本报告只把差额列出来，
    让读者知道"少的那部分去哪了"，而不是武断地说报表错了。
    """
    d = {(m.name, m.period): m for m in metrics}

    def val(name, period):
        m = d.get((name, period))
        return None if m is None else m.value

    out = []

    def add(label, left, right, note="", tol=TIE_TOL, judge=True):
        if left is None or right is None:
            out.append({"label": label, "left": left, "right": right,
                        "diff": None, "status": "na", "note": note})
            return
        diff = left - right
        if judge:
            # **相对容差**：现金流量表里常有一两个"未单列的其他项目"，
            # 让"三类净额+汇率"与净增加额差 1~2%。实测即使在权威结构化数据里
            # 也存在（中国平安 1.3%、中信证券 1.8%），若按 2 元绝对容差判，
            # 会把本来正确的报表全判成"不平"。故：差额在净额的 2% 以内算通过。
            limit = max(tol, abs(right) * 0.02) if right else tol
            status = "ok" if abs(diff) <= limit else "mismatch"
        else:
            status = "diff"           # 只列差额，不判对错
        out.append({"label": label, "left": left, "right": right,
                    "diff": diff, "status": status, "note": note})

    # ① 资产 = 负债 + 权益
    assets, liab, equity = (val("资产总计", cur), val("负债合计", cur),
                            val("所有者权益合计", cur))
    if assets is not None and liab is not None and equity is not None:
        add("资产总计 = 负债合计 + 所有者权益合计", assets, liab + equity,
            "资产负债表内恒等式")
    else:
        add("资产总计 = 负债合计 + 所有者权益合计", None, None, "核心三项未抽全")

    # ② 三类净额之和 = 净增加额
    ocf, icf, fcf = (val("经营活动现金流量净额", cur),
                     val("投资活动现金流量净额", cur),
                     val("筹资活动现金流量净额", cur))
    net = val("现金及现金等价物净增加额", cur)
    fx = val("汇率变动对现金及现金等价物的影响", cur)
    if None not in (ocf, icf, fcf, net):
        # **别忘了汇率变动**：三类净额之和并不直接等于净增加额，
        # 中间还有"汇率变动对现金及现金等价物的影响"。
        # 实测格力 2022 差 2.68 亿，正是这一项（漏掉就会误判成报表不平）。
        left = ocf + icf + fcf + (fx or 0.0)
        note = "现金流量表内勾稽（含汇率变动影响）" if fx is not None \
            else "现金流量表内勾稽（汇率影响未抽到，按 0 处理）"
        add("经营 + 投资 + 筹资 + 汇率影响 = 现金净增加额", left, net, note)
    else:
        add("经营 + 投资 + 筹资 + 汇率影响 = 现金净增加额", None, None,
            "三类净额或净增加额未抽到")

    # ③ 期初 + 净增加 = 期末
    beg, end = (val("期初现金及现金等价物余额", cur),
                val("期末现金及现金等价物余额", cur))
    if None not in (beg, end, net):
        add("期初现金 + 净增加额 = 期末现金", beg + net, end,
            "现金流量表头尾勾稽")
    else:
        add("期初现金 + 净增加额 = 期末现金", None, None,
            "期初/期末现金余额未抽到")

    # ④ 未分配利润变动 vs 净利润（不判对错，只交代差额）
    re_c, re_p = val("未分配利润", cur), val("未分配利润", prev)
    np_ = val("净利润", cur)
    if None not in (re_c, re_p, np_):
        add("未分配利润变动 = 净利润", re_c - re_p, np_,
            "差额通常来自分红、提取盈余公积或会计政策变更", judge=False)
    else:
        add("未分配利润变动 = 净利润", None, None, "未分配利润或净利润未抽到")

    return out


def build_analysis(company: str, report_type: str, period: str, db_path) -> dict:
    """生成一份分析。返回结构化 dict（界面/CLI 各自渲染）。"""
    metrics = load_metrics(company, report_type, period, db_path)
    if not metrics:
        return {"ok": False, "error": f"{company} {report_type} {period} 尚未入库"}
    income = [m for m in metrics if m.statement == "利润表"]
    balance = [m for m in metrics if m.statement == "资产负债表"]
    cash = [m for m in metrics if m.statement == "现金流量表"]

    # 本表的两个期间列：本期 = 报告自己的 period，上期 = 另一列
    all_periods = sorted({m.period for m in metrics}, key=period_key)
    cur = period
    others = [p for p in all_periods if p != cur]
    prev = others[-1] if others else None

    di, db_, dc = _by_name_period(income), _by_name_period(balance), _by_name_period(cash)
    val = lambda d, n: d.get((n, cur))          # noqa: E731

    # **金融业是另一套科目**：银行没有"营业成本/存货"，券商没有"营业成本"，
    # 保险没有"应收账款"。不分行业就会把"不适用"当成"未抽到"报出来。
    industry = detect_industry(company, balance + income)
    profit_rows, balance_rows = INDUSTRY_ROWS.get(industry,
                                                  (PROFIT_ROWS, BALANCE_ROWS))

    sections = []
    # **按三大报表组织**（利润表 / 资产负债表 / 现金流量表），每一节讲"这张表怎么变"。
    # 收入构成（"为什么变"）属于利润表的延伸，故挂在利润表这一节里。
    sections.append({
        "title": "利润表分析",
        "mix": None,          # 下面填
        "rows": _rows_for(profit_rows, di, cur, prev),
        "ratios": [
            _gross_margin(di, cur, prev),
            _margin("净利率", "净利润", di, cur, prev),
            _margin("归母净利率", "归母净利润", di, cur, prev),
            _margin("研发费用率", "研发费用", di, cur, prev),
        ],
    })
    if balance:
        ib_rows = _rows_for(INTEREST_BEARING_ROWS, db_, cur, prev)
        ib = {y: sum(d.value for (n, p), d in db_.items()
                     if n in INTEREST_BEARING_ROWS and p == y)
              for y in (cur, prev) if any((n, y) in db_ for n in INTEREST_BEARING_ROWS)}
        sections.append({
            "title": "资产负债表分析",
            "rows": _rows_for(balance_rows, db_, cur, prev),
            "interest_bearing": {
                "rows": ib_rows,
                "total": {"cur": ib.get(cur), "prev": ib.get(prev)},
                "page": next((r["page"] for r in ib_rows if r["page"]), None),
            },
            "ratios": [
                _ratio("资产负债率", {cur: val(db_, "负债合计"), prev: db_.get(("负债合计", prev))},
                       {cur: val(db_, "资产总计"), prev: db_.get(("资产总计", prev))}, cur, prev),
                _ratio("流动比率（倍）",
                       {cur: val(db_, "流动资产合计"), prev: db_.get(("流动资产合计", prev))},
                       {cur: val(db_, "流动负债合计"), prev: db_.get(("流动负债合计", prev))},
                       cur, prev, unit="倍"),
                # 有息负债是"若干科目加总"，没有对应的 MetricValue，故单独算
                _ib_ratio(ib, db_, cur, prev),
            ],
        })
    if cash:
        sections.append({
            "title": "现金流量表分析",
            "rows": _rows_for(CASHFLOW_ROWS, dc, cur, prev),
            "ratios": [
                _ratio("经营现金流 / 净利润",
                       {cur: val(dc, "经营活动现金流量净额"),
                        prev: dc.get(("经营活动现金流量净额", prev))},
                       {cur: val(di, "净利润"), prev: di.get(("净利润", prev))},
                       cur, prev, unit="倍"),
            ],
        })

    # 缺哪些（只看本期；上期缺是常态，不吵）
    wanted = PROFIT_ROWS + (BALANCE_ROWS if balance else []) + (CASHFLOW_ROWS if cash else [])
    gaps = [n for n in wanted if (n, cur) not in di and (n, cur) not in db_
            and (n, cur) not in dc]

    # 多年趋势：同一 (公司, 报告类型) 下的多期对比
    periods = sorted({r["period"] for r in available_reports(db_path)
                      if r["company"] == company and r["report_type"] == report_type},
                     key=period_key)
    trend = None
    if len(periods) >= 2:
        series = {}
        for name in TREND_METRICS:
            pts = []
            for p in periods:
                ms = load_metrics(company, report_type, p, db_path)
                hit = next((m for m in ms if m.name == name and m.period == p), None)
                pts.append({"period": p, "value": None if hit is None else hit.value})
            series[name] = pts
        trend = {"periods": periods, "series": series}
    elif prev:
        # **只入库了一期时的兜底**：年报本身带有上期对照列，
        # 用"本期/上期"两列也能出一张两年趋势表 —— 总比说"只有一个期间"有用。
        # （实测交通银行/中信证券：库里只有 2025 年报，报告却说无法构成趋势。）
        series = {}
        for name in TREND_METRICS:
            pts = []
            for p_ in (prev, cur):
                m = di.get((name, p_)) or db_.get((name, p_)) or dc.get((name, p_))
                pts.append({"period": p_, "value": None if m is None else m.value})
            if any(pt["value"] is not None for pt in pts):
                series[name] = pts
        if series:
            trend = {"periods": [prev, cur], "series": series,
                     "single_report": True}

    # 收入构成挂在利润表那一节下（"为什么变"是利润表的延伸）
    sections[0]["mix"] = revenue_mix_section(company, report_type, period, db_path, di)

    return {
        "ok": True,
        "company": company, "report_type": report_type, "period": period,
        "cur_period": cur, "prev_period": prev,
        "sections": sections,
        "trend": trend,
        "gaps": gaps,
        "identity_violations": identity_violations(balance),
        # **内部可信度信号**（不联网）：科目数是否齐、恒等式是否成立
        "quality_flags": quality_flags(metrics, identity_violations(balance)),
        # 三张表之间的勾稽（比表内恒等式更能说明"三张表出自同一套账"）
        "ties": cross_statement_checks(metrics, cur, prev),
        # 行业决定了"哪些指标适用"：金融业不算毛利率、流动比率
        "industry": industry,
        # 附注层面的信息：审计意见 / 关键审计事项 / 资金可用性
        "audit": audit_section(company, report_type, period, db_path),
        "cash_quality": cash_quality_section(company, report_type, period, db_path),
        # 应收账款账龄：用报表应收账款净值交叉校验
        "receivables": receivables_section(
            company, report_type, period, db_path,
            expected_net=(db_.get(("应收账款", cur)).value
                          if db_.get(("应收账款", cur)) else None)),
        # 商誉与减值风险
        "goodwill": goodwill_section(company, report_type, period, db_path),
        # 前五大客户集中度
        "customers": customer_section(company, report_type, period, db_path),
        # 或有事项 / 承诺事项 / 关联交易（定性）
        "qualitative": qualitative_section(company, report_type, period, db_path),
        # 存货跌价准备：用报表存货净值做交叉校验，对不上就不报
        "inventory": inventory_section(
            company, report_type, period, db_path,
            expected_net=(db_.get(("存货", cur)).value
                          if db_.get(("存货", cur)) else None)),
    }


def _fmt(v, unit="") -> str:
    if v is None:
        return "—"
    if unit == "%":
        return f"{v:.2f}%"
    if unit == "倍":
        return f"{v:.2f}"
    return f"{v:,.2f}"


def _render_mix(mx) -> list:
    """把收入构成画成按分组归位的表格行（组内按变动额排序）。"""
    if not mx:
        return ["  （未找到「营业收入构成 / 主营业务分」表，无法拆解变动来源）"]
    tot = mx.get("total") or {}
    out = ["", f"  ── 收入构成与变动（年报第 {mx['page']} 页，单位 {mx['unit']}，已归一化成元）",
           f"     营业收入合计 {_fmt(tot.get('cur'))}"
           + (f"，同比 {tot['yoy']:+.2f}%" if tot.get("yoy") is not None else "")]
    for g in mx["groups"]:
        out.append(f"     [{g['name']}]")
        for c in g["rows"]:
            ct = f"{c['contrib']:+.1f}%" if c["contrib"] is not None else "—"
            mv = f"  毛利率 {c['margin']:.2f}%" if c.get("margin") is not None else ""
            out.append(f"       {c['name']:<18}{c['cur']:>20,.0f}  同比 {c['yoy']:+7.2f}%"
                       f"  占总变动 {ct}{mv}")
    out.append("     （占总变动 = 该分部变动额 ÷ 合计变动额，组内按变动额排序 —— "
               "排最前的就是该维度的变动主因）")
    return out


def _yi(v) -> str:
    return "—" if v is None else f"{v / 1e8:,.2f} 亿元"


def _pc(v) -> str:
    return "—" if v is None else f"{v:+.2f}%"


def _row(sec, name):
    for r in (sec or {}).get("rows") or []:
        if r.get("label") == name:
            return r
    return {}


def brief_text(a: dict) -> str:
    """终端里给**结论**，不给抽取明细。

    为什么不是 `render_text`：那个是"每个科目一行"的明细表，六十多行，
    用户会把它当成分析结论，也看不出报告到底生成了没有。
    这里只留 5 条判断 + 一句"完整报告见 xxx"。
    """
    secs = {s.get("title"): s for s in a.get("sections") or [] if isinstance(s, dict)}
    inc, bal, cfl = (secs.get("利润表分析") or {}, secs.get("资产负债表分析") or {},
                     secs.get("现金流量表分析") or {})
    rev = _row(inc, "营业收入")
    npf = _row(inc, "归母净利润") or _row(inc, "净利润")
    ocf = _row(cfl, "经营活动现金流量净额")
    gmr = (inc.get("ratios") or [{}])[0]
    nmr = (inc.get("ratios") or [{}, {}])[1]
    lev = (bal.get("ratios") or [{}])[0]
    cfr = next((r for r in (cfl.get("ratios") or [])
                if "经营现金流" in (r.get("label") or "")), {})
    ib = (bal.get("interest_bearing") or {})
    ta = _row(bal, "资产总计")

    lines = [f"{a['company']} {a['period']} {a.get('report_type', '年报')}"
             f"，本期对比上期 {a.get('prev_period') or '—'}"]

    if a.get("quality_flags"):
        lines.append("⚠️ 数据可信度告警：" + "；".join(a["quality_flags"][:2]))

    # **数字不塞括号**：写成"营业收入 149.64 亿元，同比增长 13.81%"，
    # 而不是"营业收入 149.64 亿元（+13.81%）"。百分点统一写"个百分点"。
    def _dir(v, word=("增长", "下降")):
        return word[0] if (v or 0) >= 0 else word[1]

    lines.append(f"规模　营业收入 {_yi(rev.get('cur'))}，"
                 f"同比{_dir(rev.get('yoy'))} {abs(rev.get('yoy') or 0):.2f}%；"
                 f"归母净利润 {_yi(npf.get('cur'))}，"
                 f"同比{_dir(npf.get('yoy'))} {abs(npf.get('yoy') or 0):.2f}%")

    gm_txt, nm_txt = "—", "—"
    if gmr.get("cur") is not None and gmr.get("prev") is not None:
        d = gmr["cur"] - gmr["prev"]
        gm_txt = f"{gmr['cur']:.2f}%，{_dir(d, ('上升', '下降'))} {abs(d):.2f} 个百分点"
    if nmr.get("cur") is not None and nmr.get("prev") is not None:
        d = nmr["cur"] - nmr["prev"]
        nm_txt = f"{nmr['cur']:.2f}%，{_dir(d, ('上升', '下降'))} {abs(d):.2f} 个百分点"
    lines.append(f"盈利　毛利率 {gm_txt}；净利率 {nm_txt}")

    cur_r = "—" if cfr.get("cur") is None else f"{cfr['cur']:.2f}"
    prev_r = "—" if cfr.get("prev") is None else f"{cfr['prev']:.2f}"
    if ocf.get("cur") is None:
        cash_line = "现金　经营现金流未抽到，无法评估利润的现金含量"
    else:
        yoy_txt = ("同比数据缺失" if ocf.get("yoy") is None
                   else f"同比{_dir(ocf.get('yoy'))} {abs(ocf.get('yoy')):.2f}%")
        cash_line = (f"现金　经营现金流 {_yi(ocf.get('cur'))}，{yoy_txt}；"
                     f"现金含量 {cur_r} 倍，上期 {prev_r} 倍")
    lines.append(cash_line)

    if lev.get("cur") is not None:
        ib_txt = ""
        tot = (ib.get("total") or {}).get("cur")
        if tot is not None and ta.get("cur"):
            ib_txt = f"；有息负债 {_yi(tot)}，占资产总计 {tot / ta['cur'] * 100:.2f}%"
        lines.append(f"结构　资产负债率 {lev['cur']:.2f}%{ib_txt}")

    notes = []
    au = a.get("audit") or {}
    if au.get("opinion"):
        kam = [i["title"] for i in (au.get("kam_items") or [])]
        notes.append(f"审计意见 {au['opinion']}"
                     + (f"；KAM {'、'.join(kam)}" if kam else ""))
    inv = a.get("inventory") or {}
    if inv.get("ratio") is not None:
        notes.append(f"存货跌价计提 {inv['ratio']:.2f}%")
    cu = a.get("customers") or {}
    if cu.get("ratio") is not None:
        notes.append(f"前五大客户 {cu['ratio']:.2f}%")
    gw = a.get("goodwill") or {}
    if gw.get("has"):
        notes.append(f"商誉 {_yi(gw.get('value'))}")
    if notes:
        lines.append("附注　" + "；".join(notes))

    lines.append("")
    lines.append("（以上是结论摘要；逐项数字、出处页码与校验结果都在报告里）")
    return "\n".join(lines)


def render_text(a: dict) -> str:
    """CLI 用的纯文本渲染。界面用自己的渲染（同一份 dict）。"""
    if not a.get("ok"):
        return a.get("error", "无法生成分析")
    lines = [f"{a['company']} {a['period']} {a['report_type']}",
             f"本期 {a['cur_period']} / 上期 {a['prev_period'] or '—'}"]
    if a.get("quality_flags"):
        lines.append("")
        lines.append("⚠️ 数据可信度告警（这份报告的数字可能不可靠）：")
        for f in a["quality_flags"]:
            lines.append(f"   · {f}")
    lines.append("")
    w = max((len(r["label"]) for s in a["sections"] for r in s["rows"]), default=8)
    for s in a["sections"]:
        lines.append(f"【{s['title']}】")
        for r in s["rows"]:
            yoy = "" if r["yoy"] is None else f"  同比 {r['yoy']:+.2f}%"
            src = "" if r["missing"] else f"  (第{r['page']}页/{r['confidence']})"
            lines.append(f"  {r['label']:<{w}} {_fmt(r['cur']):>22}"
                         f"  [上期 {_fmt(r['prev'])}]{yoy}{src}")
        for rt in s["ratios"]:
            if rt["cur"] is None and rt["prev"] is None:
                continue
            lines.append(f"  {rt['label']:<{w}} {_fmt(rt['cur'], rt['unit']):>22}"
                         f"  [上期 {_fmt(rt['prev'], rt['unit'])}]")
        if "mix" in s:          # 只有利润表那一节挂收入构成；其余节不画
            lines.extend(_render_mix(s["mix"]))
        lines.append("")
    t = a.get("trend")
    if t:
        lines.append(f"【多年趋势】{'  |  '.join(t['periods'])}")
        for name, pts in t["series"].items():
            cells = "  |  ".join(_fmt(p["value"]) for p in pts)
            lines.append(f"  {name}: {cells}")
        lines.append("")
    cq = a.get("cash_quality")
    if cq:
        lines.append("【资金可用性】")
        eq = cq.get("cash_equiv")
        mc = None
        for sec in a["sections"]:
            for r in sec["rows"]:
                if r["label"] == "货币资金":
                    mc = r["cur"]
        if eq:
            ratio = (eq["cur"] / mc * 100) if mc else None
            lines.append(f"  期末现金及现金等价物 {_fmt(eq['cur'])}"
                         f"（第 {eq['page']} 页）"
                         + (f"；占账面货币资金 "
                            f"{_fmt(mc)} 的 {ratio:.2f}%" if ratio else ""))
        rs = cq.get("restricted")
        if rs:
            lines.append(f"  其中受限资金 {_fmt(rs['cur'])}"
                         f"（第 {rs['page']} 页，{rs['label'].split(' ')[0]}）")
        lines.append("")

    ib = next((s.get("interest_bearing") for s in a["sections"]
               if s.get("interest_bearing")), None)
    if ib and ib.get("total", {}).get("cur") is not None:
        lines.append("【有息负债】")
        lines.append(f"  合计 {_fmt(ib['total']['cur'])}"
                     f"（上期 {_fmt(ib['total']['prev'])}）")
        for r in ib["rows"]:
            if r["cur"] is not None:
                lines.append(f"    {r['label']:<22}{_fmt(r['cur']):>18}")
        lines.append("")

    ar = a.get("receivables")
    if ar:
        lines.append("【应收账款账龄（附注）】")
        lines.append(f"  账面余额 {_fmt(ar['gross'])}；坏账准备 {_fmt(ar['provision'])}"
                     f"（计提比例 {ar['ratio']:.2f}%）；账面价值 {_fmt(ar['net'])}"
                     f"（第 {ar['page']} 页）")
        if ar["gross"]:
            for row in ar["aging"]:
                lines.append(f"    {row['label']:<8}{_fmt(row['cur']):>20}"
                             f"  占 {(row['cur'] or 0) / ar['gross'] * 100:5.2f}%")
        lines.append("")

    gw = a.get("goodwill")
    if gw:
        lines.append("【商誉】")
        if not gw.get("has"):
            lines.append("  资产负债表未列示商誉（或为零）—— 不存在商誉减值风险")
        else:
            share = (f"，占归母净资产 {gw['share']:.2f}%" if gw.get("share") is not None else "")
            lines.append(f"  商誉 {gw['value'] / 1e8:.2f} 亿元{share}（第 {gw.get('page')} 页）")
            if gw.get("note_page"):
                lines.append(f"  减值测试披露见附注第 {gw['note_page']} 页")
        lines.append("")

    cu = a.get("customers")
    if cu:
        lines.append("【客户集中度】")
        extra = (f"（其中关联方 {cu['related_ratio']:.2f}%）"
                 if cu.get("related_ratio") else "")
        lines.append(f"  前五大客户占营业收入 {cu['ratio']:.2f}%{extra}"
                     f"（第 {cu['page']} 页）")
        lines.append("")

    q = a.get("qualitative")
    if q:
        lines.append("【或有事项 / 承诺 / 关联交易（附注）】")
        for it in q["items"]:
            if it["empty"]:
                lines.append(f"  {it['kind']}：无重大事项（第 {it['page']} 页）")
            elif it["excerpt"]:
                lines.append(f"  {it['kind']}（第 {it['page']} 页）：{it['excerpt']}")
            else:
                lines.append(f"  {it['kind']}：见附注第 {it['page']} 页（金额需回原文）")
        lines.append("")

    iv = a.get("inventory")
    if iv:
        c = iv["cur"]
        lines.append("【存货跌价准备（附注）】")
        lines.append(f"  账面余额 {_fmt(c['gross'])}；跌价准备 {_fmt(c['provision'])}"
                     f"（计提比例 {iv['ratio']:.2f}%）；账面价值 {_fmt(c['net'])}"
                     f"（第 {c['page']} 页）")
        if iv.get("prev"):
            pv = iv["prev"]
            delta = c["provision"] - pv["provision"]
            verb = "增加" if delta > 0 else "减少"
            lines.append(f"  上期：账面余额 {_fmt(pv['gross'])}；"
                         f"跌价准备 {_fmt(pv['provision'])}"
                         f"（本期{verb} {_fmt(abs(delta))}）")
        lines.append("")

    au = a.get("audit")
    if au:
        lines.append("【附注要点】")
        if not au.get("audited"):
            lines.append(f"  审计情况：{au.get('note') or '未经审计'}")
        else:
            lines.append(f"  审计意见：{au.get('opinion') or '未识别'}"
                         f"（第 {au.get('opinion_page')} 页）")
            items = au.get("kam_items") or []
            if items:
                pages = sorted({i["page"] for i in items})
                names = "、".join(i["title"] for i in items)
                lines.append(f"  关键审计事项：{names}"
                             f"（第 {'、'.join(map(str, pages))} 页）")
            else:
                lines.append("  关键审计事项：未识别")
        lines.append("")

    if a["identity_violations"]:
        for v in a["identity_violations"]:
            lines.append(f"⚠️ {v['year']} 不成立：{v['check']}"
                         f"（差 {v['diff']:,.0f}），该年数值可能有误，请以原文为准")
    if a["gaps"]:
        lines.append(f"⚠️ 未抽到的指标（{len(a['gaps'])} 项）：{'、'.join(a['gaps'])}")
    return "\n".join(lines)
