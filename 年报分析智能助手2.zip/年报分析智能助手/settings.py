"""用户级设置的持久化（`data/settings.json`）。

只存少量"问一次就够"的选择，目前只有**检索模型档位**：
首次运行时让用户自己选大/中/小/不用，选完记住，不再每次问。

优先级：**环境变量 > 设置文件 > 内置默认**。
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PATH = ROOT / "data" / "settings.json"


def load() -> dict:
    try:
        return json.loads(PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def get(key: str, default=None):
    return load().get(key, default)


def set_value(key: str, value) -> None:
    data = load()
    data[key] = value
    PATH.parent.mkdir(parents=True, exist_ok=True)
    PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
