"""本地服务模式：看板数据**实时**（每次打开都读最新库）。

    python main.py serve            # 起在 127.0.0.1:8765 并打开浏览器

和静态文件的关系：静态文件（`python main.py html`）适合发出去/交付；
这个服务适合自己反复看——新解析的公司不用手动重建就能看到。

**安全**：只绑定 127.0.0.1（本机访问），文件下载限制在 `reports/` 内并做路径校验。
**零新依赖**：只用标准库 `http.server`。
"""
import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
DEFAULT_PORT = 8765


class DashboardHandler(BaseHTTPRequestHandler):
    """只读服务：看板 HTML、数据 JSON、报告列表与下载。"""

    db_path = None

    server_version = "AnnualReportAgent/1.0"

    # ---------- 基础设施 ----------
    def log_message(self, fmt, *args):       # 静音逐请求日志
        pass

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")   # 数据要"最新"，不让浏览器缓存
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, payload) -> None:
        body = json.dumps(payload, ensure_ascii=False, default=str).encode()
        self._send(200, body, "application/json; charset=utf-8")

    def _html(self, text: str) -> None:
        self._send(200, text.encode("utf-8"), "text/html; charset=utf-8")

    # ---------- 路由 ----------
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):                        # noqa: N802  (stdlib 命名)
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                from report_html import render_html
                self._html(render_html(self.db_path))
                return
            if path == "/api/data":
                from report_html import collect
                self._json(collect(self.db_path))
                return
            if path == "/api/reports":
                self._json({"ok": True, "reports": list_reports()})
                return
            if path.startswith("/files/"):
                self._file(path[len("/files/"):])
                return
            if path == "/favicon.ico":
                self._send(204, b"", "image/x-icon")
                return
            self._send(404, b"not found", "text/plain; charset=utf-8")
        except Exception as e:              # noqa: BLE001
            msg = f"{type(e).__name__}: {e}".encode()
            self._send(500, msg, "text/plain; charset=utf-8")

    def _file(self, name: str) -> None:
        """只允许下载 `reports/` 里的文件，挡住 `../` 之类的路径穿越。"""
        target = (REPORTS / Path(name).name).resolve()
        if REPORTS.resolve() not in target.parents or not target.is_file():
            self._send(404, b"not found", "text/plain; charset=utf-8")
            return
        ctype = (mimetypes.guess_type(target.name)[0]
                 or "application/octet-stream")
        self._send(200, target.read_bytes(), ctype)


def list_reports() -> list:
    """`reports/` 下的可下载文件（按修改时间倒序）。"""
    if not REPORTS.exists():
        return []
    files = [p for p in REPORTS.iterdir()
             if p.is_file() and p.suffix.lower() in (".docx", ".html")]
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return [{"name": p.name,
             "url": "/files/" + p.name,
             "size": p.stat().st_size,
             "mtime": int(p.stat().st_mtime)} for p in files]


def make_server(port: int = DEFAULT_PORT, db_path=None,
                tries: int = 10) -> ThreadingHTTPServer:
    """建服务（`port=0` 时由系统分配，测试用）。

    端口被占用时**自动往后找**（8765 → 8766 → …），而不是抛一堆 traceback ——
    用户看到 `OSError: Address already in use` 只会更懵。
    """
    handler = type("BoundHandler", (DashboardHandler,), {"db_path": db_path})
    last = None
    for offset in range(tries if port else 1):
        try:
            return ThreadingHTTPServer(("127.0.0.1", port + offset), handler)
        except OSError as e:                # noqa: PERF203
            last = e
            if port == 0:
                raise
            print(f"⚠️ 端口 {port + offset} 被占用，换一个…")
    raise OSError(f"{port}~{port + tries - 1} 都被占用，请用 --port 指定其他端口") from last


def serve(port: int = DEFAULT_PORT, db_path=None, open_browser: bool = True) -> int:
    httpd = make_server(port, db_path)
    actual = httpd.server_address[1]
    url = f"http://127.0.0.1:{actual}/"
    print()
    print("  ┌─────────────────────────────────────────────────────────┐")
    print(f"  │  看板正在运行：{url:<42}│")
    print("  └─────────────────────────────────────────────────────────┘")
    print("  · 数据实时读取：新解析的公司，刷新页面就能看到")
    print("  · 浏览器没自动打开的话，把上面的地址复制到地址栏")
    print("  · **这个窗口要一直开着**，关掉窗口服务就停了（页面会报连接失败）")
    print("  · 停止：按 Ctrl-C")

    if open_browser:
        from terminal_link import open_path
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:                   # noqa: BLE001
            open_path(url)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")
    finally:
        httpd.server_close()
    return 0
