"""从年报**原文**里取「公司自己怎么解释这次变动」，按原文归纳并逐条标页码。

与数字层的分工（本项目底线，不得混淆）：
- **数字一律来自规则抽取**（`analysis.py`），本模块不生成、不改动、不推算任何数字；
- 本模块只处理**文字**：检索年报原文 → 交给大模型归纳 → 逐条标「第N页」；
- 检索为空时**直接说未找到**，不让大模型凭常识补 —— 与 agent 的 RAG 分支同一纪律。

为什么需要它：数字归因只回答"**谁贡献了多少**"（如消费电器贡献了 82.8% 的降幅），
而"**为什么**"写在年报的管理层讨论与分析正文里（"主要系…所致"）。
两句合起来才是完整答案。
"""
import re

#: 检索用的问句 —— 语义检索吃自然语言，堆关键词反而更差。
#: **要问几个维度**：实测只问"营业收入/净利润变动原因"时，年报里那些写得很明确的
#: 现金流变动说明（格力 2025 年报 p29「经营活动现金流量净额同比变动 57.93%，
#: 主要系…」）根本排不进前几名，于是模型只能答"原文未说明"——**假阴性**。
_QUERIES = (
    "{company}{period}年营业收入、净利润变动的主要原因",
    "{company}{period}年经营活动、投资活动、筹资活动现金流量净额变动的原因说明",
    "{company}{period}年经营情况讨论与分析、主营业务分析、主要财务指标变动说明",
)

_QUESTION = "{company}{period}年主要财务数据（营业收入、利润、现金流）变动的原因是什么？"

_SYSTEM = (
    "你是财报分析助手。材料分两部分：\n"
    "（一）**规则抽取**出来的报表数字（这是事实，只能原样引用来说明「变了多少」，"
    "不得改动、不得据此推算新数字）；\n"
    "（二）年报**原文**片段（每条带页码）。\n\n"
    "请**只依据材料二**解释变动原因；每条结论后用「第N页」标注出处。\n"
    "材料二没有讲到的原因，直接说「年报原文未说明」，**不要凭常识补全、更不要编造**。\n"
    "回答用中文，分点陈述，简洁专业。"
)

#: 分析结果里取来做"事实"的指标（本期/上期/同比）
_FACT_METRICS = ("营业收入", "营业成本", "净利润", "归母净利润")


#: 「变动原因」这类句子**词法上就能认出来**（中文财报的固定说法）。
#: 纯向量检索不够：实测格力 2025 年报 p29「经营活动现金流量净额同比变动 57.93%，
#: 主要系销售商品和提供劳务收到的现金增加…」在"现金流变动原因"这个问题下只排到第 8 名，
#: 被附注页挤掉 —— 于是模型只能答"原文未说明"，是**假阴性**。
#: 故加一条确定性扫描通道，与向量检索互补：扫描保精度，向量补语境。
_REASON_MARKERS = ("主要原因", "主要系", "变动原因", "原因说明", "主要是",
                   "所致", "影响所致", "原因如下")
_SCAN_LIMIT = 8


def scan_reason_passages(pdf_path, limit: int = _SCAN_LIMIT) -> list:
    """确定性扫描：逐页找含"变动原因"类说法的句子。返回 [{page, text}]。"""
    out = []
    try:
        import pdfplumber
        with pdfplumber.open(str(pdf_path)) as pdf:
            for pno, page in enumerate(pdf.pages, 1):
                for line in (page.extract_text() or "").split("\n"):
                    s = line.strip()
                    if len(s) < 16 or not any(m in s for m in _REASON_MARKERS):
                        continue
                    if not any(ch.isdigit() for ch in s):
                        continue          # 纯标题行（如"相关数据变动30%以上的原因说明"）不值得收
                    out.append({"page": pno, "text": s, "relevance": 1.0, "source": "scan"})
                    if len(out) >= limit:
                        return out
    except Exception:
        return out
    return out


_retriever = None


def _search(query, company, year, top_k):
    """网络/模型边界的薄封装，便于测试中替换。

    **检索器只建一次**：构造它要加载 bge-m3（约 10 秒）。多问句检索若每次都新建，
    三次问句就是三次模型加载 —— 实测日志里连着三条 Loading weights，
    纯属白等 20 秒。
    """
    global _retriever
    if _retriever is None:
        from retriever import ReportRetriever
        _retriever = ReportRetriever()
    return _retriever.search(query, company=company, year=year, top_k=top_k)


def _call_reasoner(messages, timeout=None, max_retries=None):
    from client import call_reasoner
    kw = {}
    if timeout:
        kw["timeout"] = timeout
    if max_retries:
        kw["max_retries"] = max_retries
    return call_reasoner(messages, **kw)


def build_digest(analysis: dict) -> str:
    """把已算好的数字压成一段紧凑的"事实"，供大模型**引用而非推算**。"""
    lines = []
    for s in analysis.get("sections", []):
        for r in s.get("rows", []):
            if r["label"] not in _FACT_METRICS or r["cur"] is None:
                continue
            yoy = "" if r["yoy"] is None else f"，同比 {r['yoy']:+.2f}%"
            prev = "" if r["prev"] is None else f"（上期 {r['prev']:,.0f}）"
            lines.append(f"{r['label']}：{r['cur']:,.0f}{prev}{yoy}")
    for sec in analysis.get("sections", []):
        mx = sec.get("mix")
        if not mx:
            continue
        for g in mx.get("groups", []):
            for c in g["rows"][:3]:
                ct = "—" if c["contrib"] is None else f"{c['contrib']:+.1f}%"
                lines.append(f"[{g['name']}] {c['name']}：{c['cur']:,.0f}"
                             f"（同比 {c['yoy']:+.2f}%，占总变动 {ct}）")
    return "\n".join(lines)


def build_prompt(question: str, digest: str, hits: list) -> list:
    """构造问答消息。`hits` 为空时也要有明确的"未找到"指令。"""
    if not hits:
        context = "（未检索到任何年报原文片段）"
    else:
        context = "\n\n".join(f"【第{h['page']}页】{h['text']}" for h in hits)
    return [
        {"role": "system", "content": _SYSTEM},
        {"role": "user", "content":
            f"（一）规则抽取的报表数字：\n{digest or '（无）'}\n\n"
            f"（二）年报原文片段：\n{context}\n\n"
            f"问题：{question}"},
    ]


def _sanitize(text: str) -> str:
    """抹掉 API Key 之类的敏感串（错误信息可能带进上下文）。"""
    return re.sub(r"(sk-|api[_-]?key[\"']?\s*[:=]\s*)\S+", r"\1***",
                  text or "", flags=re.I)


def build_narrative(company: str, report_type: str, period: str, db_path,
                    analysis: dict, top_k: int = 6,
                    search_fn=None, reasoner_fn=None,
                    timeout=None, max_retries=None) -> dict:
    """「年报原文怎么解释这次变动」—— 检索 + 大模型归纳（带页码）。

    任何一步失败都返回 `{"ok": False, "error": ...}`，**不抛异常** ——
    调用方（界面/CLI）必须能照常展示已经算好的数字部分。
    """
    search = search_fn or _search
    reasoner = reasoner_fn or (lambda m: _call_reasoner(
        m, timeout=timeout, max_retries=max_retries))
    question = _QUESTION.format(company=company, period=period)
    # （一）确定性扫描：把年报里"主要系…所致"这类句子**按词法**捞出来（保精度）
    # 库不存在就跳过扫描 —— 注意**不能**直接连，`sqlite3.connect` 会把库文件新建出来，
    # 测试传个假路径就在工作目录里留下垃圾文件。
    from pathlib import Path
    from analysis import _pdf_path
    path = None
    if db_path and Path(str(db_path)).exists():
        try:
            path = _pdf_path(company, report_type, period, db_path)
        except Exception:
            path = None
    scanned = scan_reason_passages(path)      # path 为 None 时它自己会安全返回 []
    # （二）向量检索：分维度问，按页码去重、留相关度最高的一条（补语境）
    best = {}
    try:
        for tpl in _QUERIES:
            for h in search(tpl.format(company=company, period=period),
                            company, period, top_k) or []:
                key = h.get("page")
                if key not in best or h["relevance"] > best[key]["relevance"]:
                    best[key] = h
    except Exception as e:                      # 索引缺失 / Chroma 异常都不该让整份分析挂掉
        if not scanned:
            return {"ok": False, "error": f"检索失败：{_sanitize(str(e))}"}
    hits = scanned + sorted(best.values(), key=lambda h: h["relevance"], reverse=True)[:top_k]
    if not hits:
        return {"ok": True, "answer": "年报里没有检索到与本次变动相关的说明。",
                "citations": [], "grounded": False}
    try:
        answer = reasoner(build_prompt(question, build_digest(analysis), hits))
    except Exception as e:
        # ModelError 的 __str__ 已带分类与处置建议（"模型调用失败（timeout）；…"），
        # 别再套一层前缀；其他异常补上上下文，便于用户看出是哪一步崩的。
        msg = str(e)
        if "模型调用失败" not in msg:
            msg = f"模型调用失败：{msg}"
        return {"ok": False, "error": _sanitize(msg)}
    # 出处按**页码去重**：扫描通道与向量通道会捞到同一页的不同片段，
    # 不去重就会出现"第30页、第30页、第30页"这种列法。
    cites, seen = [], set()
    for h in hits:
        if h["page"] in seen:
            continue
        seen.add(h["page"])
        cites.append({"page": h["page"], "relevance": h["relevance"]})
    return {"ok": True, "grounded": True, "answer": answer, "citations": cites}
