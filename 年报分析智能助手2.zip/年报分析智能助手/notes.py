"""附注层面的**定性信息**抽取：审计意见类型 + 关键审计事项（KAM）。

## 为什么单开一层

三大报表和它的比率只回答"数字是多少"。而"这份报表可不可信、审计师最担心什么"
写在**审计报告**里 —— 数据库没有、报表页没有，只有原文有。

这两项是附注里**写法最标准化**的，适合规则抽取（不调模型、可离线单测）：

| 项 | 各家写法 | 抽取方式 |
|---|---|---|
| 审计意见类型 | `审计意见类型 标准的无保留意见`（格力/五粮液）<br>或只有 `一、审计意见` 标题、正文里写意见 | 先找显式标签；没有就按正文关键字判定 |
| 关键审计事项 | `（一）存货跌价准备的计提`（格力）<br>`(一) 收入确认`（茅台，半角） | 在 KAM 章节内收集条目名 |

## 边界（必须说清楚）

- **半年报通常未经审计**：顺丰 2026 半年报里没有审计报告，此时返回"未经审计"，
  而不是"未找到" —— 两者含义不同。
- 只抽**条目名**，不抽"事项描述/审计应对"的正文。正文长且各家结构不同，
  硬抽容易拼出似是而非的句子；需要正文时交给 RAG 追问。
"""
import re
from functools import lru_cache
from pathlib import Path

@lru_cache(maxsize=4)
def _page_texts_cached(path: str, mtime: float) -> tuple:
    """整份 PDF 的按页文本，按 (路径, mtime) 缓存。

    **一份报告的附注要点有 5 个抽取器**（审计 / 资金 / 存货 / 应收 / 定性），
    每个都自己 `pdfplumber.open` + 逐页 `extract_text` —— 200 多页的 PDF
    等于读五遍，实测占掉大半的生成时间。合并成一次。
    """
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        return tuple((i, page.extract_text() or "")
                     for i, page in enumerate(pdf.pages, 1))


def page_texts(pdf_path) -> tuple:
    p = Path(str(pdf_path))
    return _page_texts_cached(str(p), p.stat().st_mtime)


#: 审计意见的判定顺序。
#: **`无保留意见` 必须排在 `保留意见` 前面** —— 否则「标准的无保留意见」里含
#: 「保留意见」子串，会被判成保留意见（实测格力、五粮液两份标准意见都被误判）。
#: 而「带强调事项段的无保留意见」要先于「标准无保留意见」判，靠 `强调事项` 分流。
#: 每条是 (结论, 必须同时出现的关键词)。**按顺序判定，先中先得**。
#: `无保留意见` 必须排在 `保留意见` 前：否则「标准的无保留意见」含「保留意见」子串会误判。
#: 「带强调事项段」要求两个词**同时**出现，故放在「标准无保留」之前分流。
_OPINION_RULES = (
    ("无法表示意见", ("无法表示意见",)),
    ("否定意见", ("否定意见",)),
    ("带强调事项段的无保留意见", ("无保留意见", "强调事项")),
    ("标准无保留意见", ("无保留意见",)),
    ("保留意见", ("保留意见",)),
    ("标准无保留意见", ("公允反映",)),      # 正文没写"无保留"、但表述为公允反映
)

#: 显式标签写法：`审计意见类型 标准的无保留意见`、`审计意见类型：标准无保留意见`
_LABEL_RE = re.compile(r"审计意见类型\s*[:：]?\s*([^\n]{2,20})")

#: KAM 条目名（写法一）：全角`（一）`、半角`(一)`、带空格都认
_KAM_ITEM_RE = re.compile(r"^[（(]\s*[一二三四五六七八九十]+\s*[）)]\s*(\S.{0,28})$")

#: KAM 条目名（写法二）：阿拉伯数字 `1、货币资金的存在性及完整性`（泸州老窖）。
#: **只认短行且不以句读结尾**——审计应对步骤也写成 `1、了解、测试并评价…；`，
#: 但它们是长句、以 `；` 收尾，用这两条就能分开。
_KAM_NUM_ITEM_RE = re.compile(r"^\d+\s*[、.]\s*(\S.{0,28})$")
_KAM_BAD_TAIL = ("；", ";", "。", "，", ",", "：", ":")

#: 无编号标题的锚点：紧接着的那一行是"事项描述/审计应对"。
_KAM_DESC_RE = re.compile(r"^\d*[.、]?\s*(事项描述|审计应对|事项概述)")

#: 数字编号里**不是事项名**的东西。
#: 审计应对步骤也写成 `1、了解、测试并评价了…`，靠"短行 + 不以句读结尾"分不干净
#: （PDF 折行会让长句没有句读）。故再用**动作动词**兜一层：
#: 事项名是名词短语（"货币资金的存在性及完整性"），步骤是动宾短语（"评价管理层…"）。
_KAM_NOT_A_TITLE = ("事项描述", "审计应对", "审计中的应对", "应对措施",
                    "资产负债表", "利润表", "现金流量表")
#: 审计程序里的动作词。**只要出现在标题里就排除**（仅对数字编号的条目生效）：
#: PDF 折行会让 `2.通过对存货库龄情况进行分析性复核，以确` 这样的长句没有句读，
#: 单靠"短行 + 不以句读结尾"分不干净。
_KAM_ACTION_WORDS = ("了解", "测试", "评价", "获取", "检查", "复核", "执行",
                     "分析", "函证", "监盘", "询问", "观察", "抽样", "重新计算",
                     "查阅", "核对", "比较", "计算", "盘点")


def looks_like_kam_action(title: str) -> bool:
    """是不是审计程序的一步（而不是关键审计事项的名字）。

    事项名是名词短语（"货币资金的存在性及完整性"），审计步骤是动宾短语
    （"通过对存货库龄情况进行分析性复核"）。含动作词即判为步骤。
    """
    t = (title or "").strip()
    return (any(k in t for k in _KAM_NOT_A_TITLE)
            or any(k in t for k in _KAM_ACTION_WORDS))

#: KAM 章节结束标志（下一节标题）
_SECTION_END_RE = re.compile(r"^[四五六]、")

_AUDIT_PAGE_LIMIT = 3      # 审计报告一般 2~3 页


def classify_opinion(text: str) -> "str | None":
    """从审计报告正文判定意见类型。判不出返回 None（**不猜**）。"""
    text = text or ""
    for label, keys in _OPINION_RULES:
        # 多关键词一律要求**全部**出现：“无保留意见” + “强调事项” 才是带强调事项段
        if all(k in text for k in keys):
            return label
    return None


def _audit_pages(pdf, limit: int = _AUDIT_PAGE_LIMIT) -> list:
    """定位审计报告所在页，返回 [(页码, 文本)]（含其后若干页）。

    起点判据：同一页里既有「审计报告」又有「审计意见」。
    只看「审计意见」会把「内部控制审计报告」的摘要页误当财务审计报告
    （实测格力 p55 就是内控那节）。
    """
    texts = [(i, page.extract_text() or "") for i, page in enumerate(pdf.pages, 1)]

    # 首选锚点：「形成审计意见的基础」是**财务审计报告**独有的结构标题。
    # 只用「审计报告 + 审计意见」会抓到「内部控制审计报告」那节 ——
    # 实测格力 p55 就是内控章节，它也含 `审计意见类型` 字样。
    start = next((i for i, t in texts if "形成审计意见的基础" in t), None)
    if start is None:
        # 兜底：含「审计意见」且明显不是内控章节
        start = next((i for i, t in texts
                      if "审计意见" in t and "审计报告" in t
                      and "内部控制审计报告" not in t and "内控审计报告" not in t),
                     None)
    if start is None:
        return []
    # 审计意见段常在锚点前一页（标题页），故向前补一页
    if start > 1 and "审计意见" in texts[start - 2][1]:
        start -= 1
    out = []
    for j in range(start, min(start + limit, len(texts) + 1)):
        out.append(texts[j - 1])
    return out


_MEANINGFUL_RE = re.compile(r"[A-Za-z0-9\u4e00-\u9fa5]")


def is_valid_kam_title(title: str) -> bool:
    """条目名是否像"真事项"，而不是被切碎的标点残块。

    实测踩过两种：
      - 五粮液 2025：`（二）、。` —— 全是标点；
      - 上纬新材 2025：`键审计事项。` —— 跨页断行把"关"字切掉了，剩下半句。
    判据：**必须含实义字符**，且不是句子片段（不以句读结尾）、不含"审计事项"这种标题词。
    """
    t = (title or "").strip()
    if not _MEANINGFUL_RE.search(t):
        return False
    if t.endswith(("。", "；", "，", ";", ",", "：", ":")):
        return False
    if "审计事项" in t:
        return False
    if len(t) > 20:                      # 事项名都很短
        return False
    return True


def extract_audit(pdf_path, report_type: str = "年报") -> dict:
    """返回 {ok, audited, opinion, opinion_page, kam_items, kam_page, note}。

    任何异常都降级为 `ok=False`，**不抛** —— 审计信息缺失不该让整份分析挂掉。
    """
    result = {"ok": False, "audited": False, "opinion": None,
              "opinion_page": None, "kam_items": [], "kam_page": None,
              "note": ""}
    try:
        import pdfplumber
        with pdfplumber.open(str(pdf_path)) as pdf:
            pages = _audit_pages(pdf)
    except Exception as e:
        result["note"] = f"读取失败：{e}"
        return result

    if not pages:
        # 半年报/季报按规则**本来就不审计**，这与"年报里找不到"是两回事
        if report_type != "年报":
            result.update(ok=True, audited=False, note="非年报，按规则未经审计")
        else:
            result["note"] = "未找到审计报告"
        return result

    joined = "\n".join(t for _, t in pages)
    result["ok"] = True
    result["audited"] = True

    # 意见类型：显式标签优先（最可靠），否则按正文判
    label = None
    for pno, text in pages:
        m = _LABEL_RE.search(text)
        if m:
            label, result["opinion_page"] = m.group(1).strip(), pno
            break
    if label:
        result["opinion"] = classify_opinion(label) or label
    else:
        opinion = classify_opinion(joined)
        result["opinion"] = opinion
        result["opinion_page"] = pages[0][0] if opinion else None

    # 关键审计事项：从出现「关键审计事项」的页开始收集条目名
    kam_page = next((pno for pno, t in pages if "关键审计事项" in t), None)
    if kam_page is not None:
        result["kam_page"] = kam_page
        collecting = False
        seen = set()
        for pno, text in pages:
            if pno < kam_page:
                continue
            lines = text.split("\n")
            for idx, line in enumerate(lines):
                s = line.strip()
                if not collecting:
                    if "关键审计事项" in s:
                        collecting = True
                    continue
                if _SECTION_END_RE.match(s):
                    collecting = False
                    break
                m = _KAM_ITEM_RE.match(s)
                if not m:
                    # **写法三：无编号的裸标题**（华工科技 `收入确认` 后面直接跟 `1.事项描述`）。
                    # 锚点用"下一非空行是事项描述/审计应对"——比标题长短可靠得多。
                    nxt = next((l for l in lines[idx + 1:idx + 3] if l), "")
                    if (2 <= len(s) <= 20 and _KAM_DESC_RE.match(nxt)
                            and is_valid_kam_title(s)
                            and not looks_like_kam_action(s)):
                        m = type("M", (), {"group": lambda self, _i, _v=s: _v})()
                if not m:
                    m2 = _KAM_NUM_ITEM_RE.match(s)
                    # 数字编号的只收"短标题"：审计应对步骤同样是 `1、…`，
                    # 但长且以句读收尾，靠这两个条件排除。
                    if (not m2 or len(s) > 30
                            or s.rstrip().endswith(_KAM_BAD_TAIL)
                            or looks_like_kam_action(m2.group(1))):
                        continue
                    m = m2
                title = m.group(1).strip().rstrip("：:")
                # **表格式披露会把"事项名 + 审计应对描述"塞进同一格**，
                # 实测中际旭创：`存货跌价准备的评估 我们了解、评估了与管理层…`。
                # 取第一个空白之前的部分作为事项名。
                title = re.split(r"\s+", title)[0].strip()
                if not is_valid_kam_title(title):
                    continue
                # 续页会重复同一标题并带「（续）」，去重
                key = re.sub(r"[（(]续[）)]", "", title).strip()
                if key in seen:
                    continue
                seen.add(key)
                result["kam_items"].append({"title": key, "page": pno})

    if not result["opinion"]:
        result["note"] = "审计报告内未识别出意见类型"
    return result


# ---------------------------------------------------------------- 资金可用性

#: 「期末现金及现金等价物余额」—— 现金流量表补充资料里的标准行，各家都这么写。
#: 前面可能带「四、」「三、」序号，故只匹配行尾部分。
_CASH_EQUIV_RE = re.compile(r"期末现金及现金等价物余额")
#: 受限资金的几种写法：格力的「使用受到限制的存款」、茅台的「使用受到限制的货币资金」
_RESTRICTED_RE = re.compile(r"使用受到限制|所有权或使用权受到限制|受限资金|受限制的货币资金")

#: 一行里末尾的两列金额（本期/上期）。中文财报金额列在行尾，前面可能有附注号。
_TAIL_NUM_RE = re.compile(
    r"(-?[\d,]+(?:\.\d+)?)\s+(-?[\d,]+(?:\.\d+)?)\s*$")
_ONE_NUM_RE = re.compile(r"(-?[\d,]+(?:\.\d+)?)\s*$")


def _to_float(text: str) -> "float | None":
    try:
        return float(str(text).replace(",", ""))
    except (TypeError, ValueError):
        return None


def _tail_pair(line: str):
    """取行尾两个金额（本期、上期）。只有一个时后一个为 None。"""
    m = _TAIL_NUM_RE.search(line)
    if m:
        return _to_float(m.group(1)), _to_float(m.group(2))
    m = _ONE_NUM_RE.search(line)
    if m:
        return _to_float(m.group(1)), None
    return None, None


def extract_cash_quality(pdf_path) -> dict:
    """货币资金的「含金量」：现金等价物余额、受限资金。

    回答的是一个三大报表答不了的问题：**账面货币资金里有多少真能动**。
    实测格力 2025 年报：货币资金 1,105.53 亿，而期末现金及现金等价物只有
    275.66 亿 —— 差额是受限存款（105.78 亿）与非现金等价物的定期存款（724.09 亿）。
    资产负债率、流动比率都看不出这一层。

    返回 {ok, cash_equiv, restricted, note}，两项各自 {cur, prev, page, label} 或 None。
    找不到就返回 ok=False（**不猜**），由上层决定怎么说。
    """
    result = {"ok": False, "cash_equiv": None, "restricted": None, "note": ""}
    try:
        pages = [t for _, t in page_texts(pdf_path)]
    except Exception as e:
        result["note"] = f"读取失败：{e}"
        return result

    for pno, text in enumerate(pages, 1):
        for line in text.split("\n"):
            s = line.strip()
            if not s:
                continue
            if result["cash_equiv"] is None and _CASH_EQUIV_RE.search(s):
                cur, prev = _tail_pair(s)
                if cur is not None:
                    result["cash_equiv"] = {"cur": cur, "prev": prev,
                                            "page": pno, "label": "期末现金及现金等价物余额"}
            if result["restricted"] is None and _RESTRICTED_RE.search(s):
                cur, prev = _tail_pair(s)
                if cur is not None:
                    result["restricted"] = {"cur": cur, "prev": prev, "page": pno,
                                            "label": s[:40]}
        if result["cash_equiv"] is not None and result["restricted"] is not None:
            break

    result["ok"] = result["cash_equiv"] is not None or result["restricted"] is not None
    if not result["ok"]:
        result["note"] = "未找到现金及现金等价物/受限资金的相关披露"
    return result


# ---------------------------------------------------------------- 存货跌价准备

#: 存货附注里的合计行：`合计 31,450,131,116.46 3,266,666,856.93 28,183,464,259.53`
#: 三列分别是 账面余额 / 存货跌价准备 / 账面价值。
_INV_TOTAL_RE = re.compile(r"^(?:合计|总计)\s+(.+?)\s*$")


def extract_inventory_provision(pdf_path, expected_net=None) -> dict:
    """存货跌价准备：账面余额、计提额、计提比例（当前期与上期）。

    为什么值得单独抽：**审计师把它列为关键审计事项**（格力 KAM 第一条就是它），
    说明这是本期最需要判断的会计估计。而三大报表只给一个**净额**（存货 281.83 亿），
    看不出其中压着多少跌价准备。

    `expected_net` 传资产负债表里的「存货」金额。附注的**账面价值**必须等于它，
    这是挑选正确"合计行"最可靠的判据 —— 实测格力 p138 上还有另一张表的合计行
    （3.96 亿/0.00 亿/3.65 亿），不比对净值就会把它当成存货。

    返回 {ok, cur, prev, ratio, note}：
      cur/prev = {gross 账面余额, provision 跌价准备, net 账面价值, page}
    """
    result = {"ok": False, "cur": None, "prev": None, "ratio": None, "note": ""}
    try:
        pages = list(page_texts(pdf_path))
    except Exception as e:
        result["note"] = f"读取失败：{e}"
        return result

    cands = []
    for pno, text in pages:
        # 只认**同一页里既有「存货跌价准备」又有「账面余额」**的表 ——
        # 光有"存货跌价准备"的页多半是会计政策段落或审计报告正文。
        if "存货跌价准备" not in text or "账面余额" not in text:
            continue
        for line in text.split("\n"):
            m = _INV_TOTAL_RE.match(line.strip())
            if not m:
                continue
            toks = [_to_float(t) for t in m.group(1).split()]
            if len(toks) < 3 or any(t is None for t in toks):
                continue
            # 3 列：本期 账面余额/跌价准备/账面价值（格力，期末与期初各一张表）
            # 6 列：本期三列 + 上期三列（茅台，一张表并排）
            cands.append({"gross": toks[0], "provision": toks[1], "net": toks[2],
                          "page": pno})
            if len(toks) >= 6:
                cands.append({"gross": toks[3], "provision": toks[4],
                              "net": toks[5], "page": pno})

    if not cands:
        result["note"] = "未找到存货附注的合计行（账面余额/跌价准备/账面价值）"
        return result

    pos = 0
    if expected_net:
        # 账面价值必须与资产负债表存货一致（留 1% 容差给四舍五入/单位差异）
        pos = next((i for i, c in enumerate(cands)
                    if abs(c["net"] - expected_net) <= abs(expected_net) * 0.01), None)
        if pos is None:
            # **对不上就不报**。宁可说"没找到"，也不能把别的表的合计当成存货 ——
            # 实测茅台 p93 有个 12.11 亿的三列合计行，而它的存货是 464 亿。
            result["note"] = ("找到若干三列合计行，但没有一行的账面价值与报表存货一致；"
                              "可能是该公司的存货附注结构不同")
            return result

    result["ok"] = True
    result["cur"] = cands[pos]
    # 期初合计紧跟在期末之后
    result["prev"] = cands[pos + 1] if pos + 1 < len(cands) else None
    if cands[pos]["gross"]:
        result["ratio"] = cands[pos]["provision"] / cands[pos]["gross"] * 100
    return result


# ---------------------------------------------------------------- 应收账款账龄

#: 账龄分档的写法：格力用 `1至2年`，也有公司写 `1－2年`、`1-2年`、`1～2年`。
_AGING_LABEL_RE = re.compile(
    r"^(1年以内|1\s*[至－\-～~]\s*2年|2\s*[至－\-～~]\s*3年|3年以上)")
_AGING_TOTAL_RE = re.compile(r"^(小计|合计|减[:：]\s*坏账准备)\s+(.+?)\s*$")


def extract_receivables(pdf_path, expected_net=None) -> dict:
    """应收账款账龄结构 + 坏账准备（读附注）。

    回答的是"收入质量"：应收账款降了，是**回款变好**还是**放宽信用换规模**？
    账龄结构一摊开就清楚了 —— 1 年以内占比上升是好事，3 年以上堆积则是隐忧。

    交叉校验：附注的「合计」（账面价值）必须等于资产负债表里的「应收账款」，
    对不上一律不报（与存货跌价准备同一套纪律）。

    返回 {ok, gross, provision, net, ratio, aging, page, note}：
      aging = [{label, cur, prev}]
    """
    result = {"ok": False, "gross": None, "provision": None, "net": None,
              "ratio": None, "aging": [], "page": None, "note": ""}
    try:
        pages = list(page_texts(pdf_path))
    except Exception as e:
        result["note"] = f"读取失败：{e}"
        return result

    for pno, text in pages:
        lines = text.split("\n")
        # 只认「按账龄披露」那一块，避免命中坏账计提方法、前五大客户等其他表
        start = next((i for i, l in enumerate(lines)
                      if "账龄" in l and "应收账款" not in l) or
                     next((i for i, l in enumerate(lines) if "按账龄" in l), None),
                     None)
        if start is None:
            continue
        aging, gross, provision, net = [], None, None, None
        for line in lines[start + 1:start + 20]:
            s2 = line.strip()
            if not s2:
                if aging:
                    break
                continue
            m_total = _AGING_TOTAL_RE.match(s2)
            if m_total:
                label, rest = m_total.group(1), m_total.group(2)
                nums = [_to_float(t) for t in rest.split()]
                nums = [n for n in nums if n is not None]
                if not nums:
                    continue
                if label.startswith("小计"):
                    gross = nums[0]
                elif label.startswith("减"):
                    provision = nums[0]
                elif label.startswith("合计"):
                    net = nums[0]
                continue
            m = _AGING_LABEL_RE.match(s2)
            if m:
                nums = [_to_float(t) for t in s2[m.end():].split()]
                nums = [n for n in nums if n is not None]
                if nums:
                    aging.append({"label": m.group(1), "cur": nums[0],
                                  "prev": nums[1] if len(nums) > 1 else None})
        if not aging or net is None:
            continue
        if expected_net is not None and abs(net - expected_net) > abs(expected_net) * 0.01:
            continue                      # 对不上就换下一页/不报
        result.update(ok=True, gross=gross, provision=provision, net=net,
                      aging=aging, page=pno)
        if gross:
            result["ratio"] = provision / gross * 100 if provision is not None else None
        return result

    result["note"] = ("未找到与报表应收账款一致的账龄表"
                      if expected_net else "未找到应收账款账龄表")
    return result


# ---------------------------------------------------------------- 或有事项 / 承诺 / 关联交易

#: 附注里的小节标题。**必须是编号标题** —— 会计政策段落里也会出现这些词
#: （"与或有事项相关的业务同时符合以下条件…"），不要求编号会大面积误命中。
_QUAL_HEADING_RE = re.compile(
    r"^(?:[一二三四五六七八九十]+|\d+)\s*[、.]\s*(?:重要)?"
    r"(或有事项|承诺事项|关联方及关联交易|关联交易)")

#: `√适用 □不适用` 这类勾选行不是内容
_CHECKBOX_RE = re.compile(r"^[√□☑■◎]?\s*(适用|不适用)")

#: 明确的"无"：`无。` / `无` / `不适用`
#: 明确表示"没有"的写法。不只认单个"无"字 ——
#: 五粮液写的是"本公司本报告期不存在需要披露的重要或有事项。"
_EMPTY_RE = re.compile(
    r"^(无|无。|不适用|不适用。|本公司无.*。?)$"
    r"|不存在.{0,12}(需要披露|重大|重要)?.{0,6}(或有事项|承诺事项)"
    r"|无需披露.{0,8}(或有事项|承诺事项)"
    r"|无重大.{0,6}(或有事项|承诺事项)")


def _notes_floor(pages) -> int:
    """附注大致的起始页：**审计报告所在页**；找不到就用文档后半部分。

    三大报表 → 审计报告 → 附注 是 A 股年报的固定顺序，故"审计报告之后"
    是找附注小节的可靠下限。
    """
    for pno, text in pages:
        if "形成审计意见的基础" in text:
            return pno
    return max(1, len(pages) // 2)


def extract_qualitative_notes(pdf_path) -> dict:
    """或有事项 / 承诺事项 / 关联交易：**有没有 + 首句 + 页码**。

    这三项是散文，没有可靠的数值锚点（不像存货能拿报表净值反查），
    硬抽金额很容易张冠李戴。故只抽三件事：
      - 这一节是否存在；
      - 是否明确写"无"；
      - 否则摘首句（截断到 80 字）+ 页码，供人工回看。

    这已经足够回答"这家公司有没有表外风险需要留意"这一层问题。
    """
    out = {"ok": False, "items": [], "note": ""}
    try:
        pages = list(page_texts(pdf_path))
    except Exception as e:
        out["note"] = f"读取失败：{e}"
        return out

    # **附注在审计报告之后**。不设这条下限，会命中"重要提示"里的句子
    # （茅台 p23「…存在关联交易…」）和第二节的业绩承诺（格力 p57）。
    # 半年报没有审计报告，退回"文档后半部分"这个较弱的判据。
    floor = _notes_floor(pages) if pages else 0

    seen = set()
    for pno, text in pages:
        if pno < floor:
            continue
        lines = [l.strip() for l in text.split("\n")]
        for idx, line in enumerate(lines):
            m = _QUAL_HEADING_RE.match(line)
            if not m:
                continue
            kind = m.group(1)
            kind = "关联交易" if "关联交易" in kind else kind
            if kind in seen:
                continue
            # 正文行：跳过 `√适用 □不适用` 这类勾选行与页码，取第一行真正的文字
            body = ""
            for cand in lines[idx + 1:]:
                if not cand or cand.isdigit() or _CHECKBOX_RE.match(cand):
                    continue
                body = cand
                break
            if not body:
                continue
            seen.add(kind)
            empty = bool(_EMPTY_RE.search(body))
            # 「无。」只有两个字，但对"有没有或有事项"是完整回答 —— 不能按长度滤掉
            if not empty and len(body) < 4:
                continue
            # 关联交易那节的第一行永远是「1、本公司的母公司情况」这类小节标题，
            # 摘它没有信息量；只记页码，具体金额交给 RAG 追问。
            excerpt = "" if (empty or kind == "关联交易") else body[:80]
            out["items"].append({"kind": kind, "page": pno,
                                 "empty": empty, "excerpt": excerpt})
        if len(seen) == 3:
            break

    out["ok"] = bool(out["items"])
    if not out["ok"]:
        out["note"] = "未找到或有事项/承诺事项/关联交易的编号小节"
    return out


# ---------------------------------------------------------------- 客户集中度

#: "前五名客户" 的几种写法（有的写"前 5 大客户"、有的写"前五名客户销售额"）
_TOP5_RE = re.compile(r"前\s*[五5]\s*(?:名|大)\s*客户")
_PCT_IN_TEXT_RE = re.compile(r"([\d.]+)\s*%")
_AMOUNT_YI_RE = re.compile(r"([\d,]+(?:\.\d+)?)\s*亿元")
_AMOUNT_YUAN_RE = re.compile(r"([\d,]{6,}(?:\.\d+)?)\s*$")


def extract_customer_concentration(pdf_path) -> dict:
    """前五大客户集中度（占营业收入比例）。

    回答"收入依赖少数客户吗" —— 客户集中度高时，一个大客户流失就能打断业绩，
    而三大报表完全看不出这一层。

    实测三种写法都能处理：
      - 表格式（格力 p25）：`前五名客户合计销售金额占年度销售总额比例 14.40%`（下一行）
      - 散文式（宝钢 p16）：`前五名客户销售额571.9亿元，占年度销售总额18.0%`
      - 散文式（中芯 p27）：`第一名和前五名客户销售额分别占…8.0%和35.8%`

    **取块内最大百分比**：同一段里还有"其中关联方销售额占比"（更小），
    取最大即前五大客户合计占比。
    """
    out = {"ok": False, "ratio": None, "related_ratio": None, "amount": None,
           "page": None, "excerpt": "", "note": ""}
    try:
        pages = page_texts(pdf_path)
    except Exception as e:
        out["note"] = f"读取失败：{e}"
        return out

    for pno, text in pages:
        if pno > 120:                 # 客户集中度在管理层讨论与分析里，不会太靠后
            break
        lines = text.split("\n")
        for idx, line in enumerate(lines):
            if not _TOP5_RE.search(line):
                continue
            # **只取同一句**：往后最多 4 行，遇到句号或"供应商"就停。
            # 早先直接取 4 行里的最大百分比，把紧跟着的"前五名供应商 32.3%"也算进来，
            # 宝钢因此被报成 32.3%（真值 18.0%）。
            # **从「前五名客户」出现的位置往后切**：那一行前面可能有别的句子
            # （万科：`…产生较高营业额。报告期内，前 5 名客户…`），
            # 整段按句号切会把关键词所在句一起切掉。
            head = _TOP5_RE.search(line)
            picked = [line[head.start():]]
            for nxt in lines[idx + 1:idx + 4]:
                if "供应商" in nxt:
                    break
                picked.append(nxt)
                if "。" in nxt:
                    break
            block = "\n".join(picked)
            block = block.split("。")[0] or block
            pcts = [float(x) for x in _PCT_IN_TEXT_RE.findall(block)
                    if 0 < float(x) <= 100]
            if not pcts:
                continue
            # **取"占"之后的第一个百分比**，不是最大值：
            # 万科那句后面还有"占…X%"，取最大会挑到别的口径（实测 30.0% vs 真值 1.2%）。
            # 只有"第一名和前五名客户分别占…A%和B%"这种并列写法才取最大
            # （B 是前五名，A 是第一名，B ≥ A）。
            pos = block.find("占")
            after = _PCT_IN_TEXT_RE.findall(block[pos:]) if pos >= 0 else []
            ratio = float(after[0]) if after else pcts[0]
            # 注意要看**原始行**：`第一名和前五名客户…` 里的"第一名"在关键词之前，
            # 从匹配位置往后切之后 block 里已经没有它了。
            if "第一名" in line and len(pcts) >= 2:
                ratio = max(pcts)
            out.update(ok=True, page=pno, excerpt=block.strip()[:120],
                       ratio=ratio)
            # 关联方占比：同一段里"关联方"附近那个百分比
            m = re.search(r"关联方[^\n]{0,30}?([\d.]+)\s*%", block)
            if m:
                out["related_ratio"] = float(m.group(1))
            m = _AMOUNT_YI_RE.search(block)
            if m:
                out["amount"] = float(m.group(1).replace(",", "")) * 1e8
            return out

    out["note"] = "未找到「前五名客户」的披露"
    return out


# ---------------------------------------------------------------- 商誉减值

#: 资产负债表上的商誉行：`商誉 1,621,619.53 1,621,619.53`
_GOODWILL_ROW_RE = re.compile(
    r"^商\s*誉\s+([\d,]+(?:\.\d+)?)(?:\s+([\d,]+(?:\.\d+)?))?\s*$")


def extract_goodwill(pdf_path) -> dict:
    """商誉：账面金额 + 减值测试附注的位置。

    商誉是**只有并购才会产生**的资产，本身不带现金流；一旦被并购标的业绩不达预期，
    减值往往一次性吃掉几个亿利润（"洗大澡"的常见手法）。三大报表只给一个余额，
    看不出背后的减值测试假设，所以这一节要同时给出**金额**和**附注页码**。

    本报告**不抽取**减值测试的具体假设（折现率、增长率），因为各家披露格式差异太大，
    硬抽容易张冠李戴；只做定位 + 金额 + 重要性判断。
    """
    out = {"ok": False, "value": None, "prev": None, "page": None,
           "note_page": None, "share": None, "note": ""}
    try:
        pages = page_texts(pdf_path)
    except Exception as e:
        out["note"] = f"读取失败：{e}"
        return out

    for pno, text in pages:
        for line in text.split("\n"):
            m = _GOODWILL_ROW_RE.match(line.strip())
            if m:
                out.update(ok=True, page=pno,
                           value=_to_float(m.group(1)),
                           prev=_to_float(m.group(2)) if m.group(2) else None)
                break
        if out["ok"]:
            break

    # 减值测试附注：正文里同时出现"商誉"和"资产组/减值测试"的页（排除会计政策段）
    # 减值测试附注：要求**有一行以"商誉"开头**（像小节标题），
    # 且同页出现"资产组/减值测试"。只按关键词命中会落到会计政策段
    # （五粮液 p81「19、长期资产减值」就是被这样误判成附注的）。
    for pno, text in pages:
        if out["page"] and pno <= out["page"]:
            continue
        lines = [l.strip() for l in text.split("\n")]
        has_heading = any(l.startswith("商誉") and len(l) <= 24 for l in lines)
        if not has_heading:
            continue
        if "资产组" in text or "减值测试" in text:
            out["note_page"] = pno
            break

    if not out["ok"]:
        out["note"] = "资产负债表未列示商誉（或金额为零）"
    return out
