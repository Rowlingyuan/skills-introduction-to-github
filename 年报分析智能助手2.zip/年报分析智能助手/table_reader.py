"""单页表格读取：双策略并行提取 + 结构打分选优。

实测结论（见设计文档 §3.4）：两种策略的适配方向是双向的，
不存在"默认失败才回退"的关系，必须都跑一遍再选。
"""
import re
import pdfplumber
from pdfplumber import utils as pdfplumber_utils
from pdfplumber.table import words_to_edges_v

from metric_extractor import has_year_header
from models import ParsedTable

TEXT_SETTINGS = {
    "vertical_strategy": "text",
    "horizontal_strategy": "text",
    "snap_tolerance": 3,
    "join_tolerance": 3,
    "min_words_vertical": 2,
    # 【症状】pdfplumber 默认 text_x_tolerance=3 时，格力年报第 89 页（现金流量表）
    # 一个数字单元格都提不出来，整页 0 命中，现金流量表因此**根本定位不到**
    # （表面症状只是"现金流量表缺失"）。见
    # tests/test_table_reader.py::test_text_strategy_keeps_adjacent_number_columns_parseable。
    #
    # 【修复】任何 text_x_tolerance < 3 都能恢复。实测该页 text 策略的数字单元格数
    # 与 count_metrics(rows, "现金流量表") 随容差的变化：
    #     tol=3 → 2 个数字单元格、0 命中
    #     tol=2 → 82 个、5 命中
    #     tol=1 → 82 个、5 命中
    #     tol=0.5 → 82 个、5 命中
    #     tol=0.1 → 83 个、5 命中
    # tol=1 只是这段平台区里的一个保守取值，并非推导出来的最优解（2 同样可行，
    # 0.5 / 0.1 也行）。容差继续调小会开始把单元格切碎（如 0.05 时 distinct_x
    # 从 6 涨到 12），所以不要贪小。
    #
    # 【机制】确切成因尚未完全查清，**不要**把这里的注释当成定论去按图索骥。
    # 已确证的部分：text 策略的列边界由 `page.extract_words()` 的结果推导，
    # 该函数的 x_tolerance 默认值就是 3；调到 1 后第 89 页会多切出若干词
    # （表头 '2025年度' 变成 '2025' + '年度'，后者 x0=408.84，正是使两个数字列
    # 分离的那个竖直边界的来源），列数由 3 列变 5 列。至于"为什么少了
    # x0=408.84 这一个边界就会连数字也并成一个非数字单元格"，未进一步定位，
    # 暂记为未解释。
    #
    # 【范围】只影响 text 对齐策略；DEFAULT_SETTINGS（框线策略）不受影响。
    #
    # 注意：keep_blank_chars 需经 `text_` 前缀传入（TableSettings.resolve 的约定），
    # 直接写 "text_settings" 会渲染成 `settings=` 而报 TypeError。
    "text_x_tolerance": 1,
}

_HEADER_HITS = ("项目", "附注", "年度", "期末", "年末", "本期", "上期")

#: 同一列边界判定为"同一条线"的容差（pt）。与 pdfplumber 的 cluster 容差一致。
_EDGE_TOL = 0.6


def clipped_left_edges(words, surviving_xs, min_words: int = 2) -> list:
    """找出**被 pdfplumber 丢弃的左边界 x**（纯函数，便于离线单测）。

    【为什么会有边界被丢】pdfplumber 的 `words_to_edges_v` 先把词按 x0 聚成簇，
    再把每个簇的**外接矩形**依次去重：与外接矩形**重叠**者直接丢弃（见
    `pdfplumber/table.py::words_to_edges_v` 的 `condensed_bboxes`）。
    中文财报里经常出现**两种左对齐**——"流动负债合计/资产总计"这类合计行顶格（x0=48），
    而"其他权益工具/少数股东权益"这类明细行缩进（x0=57）。后者的词多得多，
    外接矩形也更大，**把前者的边界整条吃掉**。于是表格左边界落在 57，
    凡从 48 起头的行，**第一个字被切掉**。

    【实测后果（格力 2025 年报 p86–87）】
    `流动负债合计` 被切成 `动负债合计` → 只能匹配到"负债合计"，
    把 2315 亿记成了负债合计；`非流动负债合计` 被切成 `流动负债合计` → 记为流动负债合计；
    `资产总计` 被切成 `产总计` → 谁都匹配不上，直接丢失。
    最终算出**流动比率 14.03 倍**（真值 1.08），且 confidence 仍是 high。

    【只补"表格左边界之外"的线 —— 这条限制是必须的】补回的线会作为
    `explicit_vertical_lines` 贯穿**整页**。若把表格内部的 x0 也补进去，
    这些线会横穿别处的数字：实测 p86 补了 15 条之后，`资产总计 391,371,999,819.49`
    被切成 `3` + `91,371,999,819.49`，整张表变成一堆碎片。
    故只取 `x < 表格左边界`（= 现存边界的最小值）的那些 —— 它们才是"被切掉的头"
    来源，且天然落在所有数字列的左边，不会切坏任何数字。

    `surviving_xs` 传 pdfplumber 实际保留的那批边界（`words_to_edges_v` 的输出）。
    """
    kept = [float(x) for x in surviving_xs or []]
    if not kept:
        return []
    left_edge = min(kept)
    out = []
    for cluster in pdfplumber_utils.cluster_objects(words, lambda w: w["x0"], 1):
        if len(cluster) < min_words:
            continue
        x = float(min(w["x0"] for w in cluster))
        # 已在表格内（或与左边界重合）的线：pdfplumber 自己会处理，补了反而切碎数字
        if x >= left_edge - _EDGE_TOL:
            continue
        out.append(round(x, 2))
    return sorted(set(out))


def _text_settings_for(page) -> dict:
    """TEXT_SETTINGS + 该页被丢弃的左边界（取不到就原样返回）。

    任何一步失败都**退回未修补的 TEXT_SETTINGS** —— 修补是增强，
    不能让它在陌生 PDF 上把整条抽取链路搞挂。
    """
    settings = dict(TEXT_SETTINGS)
    try:
        words = page.extract_words(x_tolerance=settings["text_x_tolerance"])
        surviving = [e["x0"] for e in words_to_edges_v(
            words, word_threshold=settings["min_words_vertical"])]
        extra = clipped_left_edges(words, surviving,
                                   min_words=settings["min_words_vertical"])
    except Exception:
        return settings
    if extra:
        settings["explicit_vertical_lines"] = extra
    return settings


def clean_rows(rows) -> list:
    """去除空行，单元格去掉换行与首尾空白。"""
    out = []
    for row in rows or []:
        cells = [str(c).replace("\n", "").strip() if c is not None else ""
                 for c in row]
        if any(cells):
            out.append(cells)
    return out


#: 母公司报表的标题。一张表里出现它，说明这张表**把合并表与母公司表连在了一起**。
_PARENT_TITLES = ("母公司资产负债表", "母公司利润表", "母公司现金流量表")


def truncate_at_parent_title(rows) -> list:
    """在「母公司XX表」标题处**截断**，只保留它上面的行。

    【为什么必须截】pdfplumber 会把"合并表续表"和紧随其后的"母公司表"**拼成一张表**。
    实测恒瑞医药 2026 半年报 p76：合并资产负债表尾部的 22 行 + 母公司资产负债表 27 行
    合成一张 49 行的表，第 23 行正是被切碎的标题 `['母公','司资','产负债表']`。
    这一张表里两套数字并存，而 `find_year_columns` 只会用**其中一套**表头映射列，
    于是：合并表的行拿到母公司列的年份 → `货币资金` 记成 375.60 亿（母公司口径），
    真值 387.34 亿。指标数还是 14 个、confidence 还是 high，从外观看不出任何异常。

    【截断而不是丢弃】标题**上方**那半张仍是合并表的正文（含合计行），必须保留。
    标题在首行（整张表都是母公司表）则整张丢弃，返回 []。

    判据用"拼接后去空白的行文本包含完整标题"，因为标题在单元格里可能被切碎
    （`['母公','司资','产负债表']`），逐格比对永远匹配不上。
    """
    for i, row in enumerate(rows or []):
        joined = "".join(row).replace(" ", "").replace("\u3000", "")
        if any(t in joined for t in _PARENT_TITLES):
            return list(rows[:i])
    return list(rows or [])


def score_structure(rows) -> float:
    """结构合理性打分。与指标命中数无关，只看"像不像一张财务报表"。"""
    rows = clean_rows(rows)
    if len(rows) < 5:
        return 0.0
    score = 0.0
    head = "".join(rows[0]) + ("".join(rows[1]) if len(rows) > 1 else "")
    score += 10.0 * sum(1 for kw in _HEADER_HITS if kw in head)
    if len(rows) >= 10:
        score += 15.0
    if len(rows) >= 20:
        score += 10.0
    ncols = len(rows[0])
    # 上界放到 12：实测格力季报的报表就是 9 列（设计文档 §3.4），硬卡 8 会把它判成"不像表"
    if 3 <= ncols <= 12:
        score += 15.0
    # 数字行占比：财务报表中过半行应含数字单元格
    numeric_rows = 0
    for r in rows:
        for c in r[1:]:
            t = c.replace(",", "")
            if t and (t.lstrip("-").replace(".", "").isdigit()):
                numeric_rows += 1
                break
    score += 20.0 * (numeric_rows / len(rows))
    return score


_NUM_RE = re.compile(r"[\d,]+\.\d{2}")
_CJK_RE = re.compile(r"[\u4e00-\u9fa5]")


def _has_number(cells) -> bool:
    return any(_NUM_RE.search(str(c or "")) for c in cells)


def merge_wrapped_labels(rows) -> list:
    """把**被折行切断的科目名**拼回去。

    窄列的 PDF 会把 `经营活动产生的现金流量净额` 拆成两行：
        ["经营活动产生的现金流"]
        ["量净额", "501,014,483.51", "385,357,113.69"]
    实测中国黄金 p86 因此整段经营活动现金流都抽不到。
    判据：上一行**没有任何数字**，且当前行开头是一小段中文 + 数字。
    """
    out = []
    for r in rows:
        cells = [str(c or "").strip() for c in r]
        nonempty = [c for c in cells if c]
        if out and not _has_number(out[-1]) and nonempty:
            prev = list(out[-1])
            # 情形 A：标签被切断，后半截和数字在同一行
            prev_only_label = not _has_number(prev)
            if (prev_only_label and 0 < len(nonempty[0]) <= 4
                    and _CJK_RE.search(nonempty[0]) and _has_number(cells)
                    and len(str(prev[0] or "")) + len(nonempty[0]) <= 40):
                prev[0] = str(prev[0] or "").strip() + nonempty[0]
                merged = prev + [c for c in cells if c and c != nonempty[0]]
                out[-1] = merged
                continue
        out.append(cells)
    return out


_WORD_NUM_RE = re.compile(r"^[-−（(]?[\d,]+(?:\.\d+)?[)）]?$")
#: 表头里的期间列：`2025年度` `2024年` `本期` `期末` 等
_PERIOD_TOKEN_RE = re.compile(
    r"^(?:20\d{2}\s*年?(?:度|末|初)?|本期|上期|期末|期初|年末|年初)$")
_FOOTNOTE_TOKEN_RE = re.compile(r"^(?:附注|注释|注)$")
#: 附注**编号**（`七、79（1）`、`五、43`）会夹在标签中间，必须丢掉，
#: 否则拼出 `经营活动产生的现金流七、79（1）量净额`，匹配不上任何科目名
_FOOTNOTE_REF_RE = re.compile(r"^[一二三四五六七八九十]+[、.．]\s*\d*|^注\s*\d+|^[（(]\d+[)）]$")


def _cluster_lines(words, tol=3.0):
    """按 y 坐标把词聚成行，行内按 x 排序。"""
    words = sorted(words, key=lambda w: (w["top"], w["x0"]))
    lines, cur = [], []
    for w in words:
        if cur and abs(w["top"] - cur[-1]["top"]) > tol:
            lines.append(cur)
            cur = []
        cur.append(w)
    if cur:
        lines.append(cur)
    for ln in lines:
        ln.sort(key=lambda w: w["x0"])
    return lines


def _period_anchors(lines):
    """找表头里的期间列锚点：[(x0, 文本), ...]；找不到返回 []。"""
    for ln in lines:
        hits = [(w["x0"], w["text"]) for w in ln
                if _PERIOD_TOKEN_RE.match(w["text"].replace(" ", ""))]
        if len(hits) >= 2:
            return sorted(hits)
    return []


def _footnote_x(lines, anchors) -> float:
    """附注列的左边界。表头里若有「附注」，用它定位；否则按标签列宽度估。"""
    for ln in lines:
        for w in ln:
            if _FOOTNOTE_TOKEN_RE.match(w["text"].replace(" ", "")):
                return w["x0"] - 4.0
    first = anchors[0][0] if anchors else 400.0
    return first - 80.0


def rows_from_words(page, attach_pt=12.0) -> list:
    """按**文字坐标**重建行 —— 专治"无框线、标签被拆碎"的报表。

    实测中国黄金 p86 的现金流量表：没有竖线，pdfplumber 只能按空白切，
    一个科目被拆成三行、数字单独夹在中间：

        top=145  `一、经营活动产生的现金流量：`
        top=159  `销售商品、提供劳务收到的`
        top=167  `73,681,672,975.50  64,308,360,598.88`   ← 只有数字
        top=173  `现金`                                    ← 标签的续行

    做法：
      1. 从表头取期间列锚点（`2025年度` x=359、`2024年度` x=467）；
      2. 数字按**最近的锚点**归列 —— 不能靠"从左到右第几个"，
         缺一列（如本期为空）就会整体错位，把 2024 的数当成 2025；
      3. 标签片段按 y 归到最近的数字行（≤ attach_pt），拼回完整科目名。
    """
    try:
        words = page.extract_words(use_text_flow=False, keep_blank_chars=False)
    except Exception:                        # noqa: BLE001
        return []
    if not words:
        return []

    lines = _cluster_lines(words)
    anchors = _period_anchors(lines)
    fn_x = _footnote_x(lines, anchors)
    num_left = (anchors[0][0] - 20.0) if anchors else min(
        (w["x0"] for w in words if _WORD_NUM_RE.match(w["text"].replace(" ", ""))),
        default=1e9)

    num_words = [w for w in words if w["x0"] >= num_left]
    label_words = [w for w in words
                   if w["x0"] < fn_x
                   and not _FOOTNOTE_REF_RE.match(w["text"].strip())]

    def _slot(x0: float) -> int:
        """数字归到哪一列。没有锚点时按顺序退化。"""
        if not anchors:
            return 0
        return min(range(len(anchors)), key=lambda i: abs(anchors[i][0] - x0))

    rows = []                                # {"y":float, "cells":{slot:txt}}
    for ln in (l for l in _cluster_lines(num_words, tol=3.0) if l):
        cells = {}
        for w in ln:
            txt = w["text"].strip()
            if not txt:
                continue
            if anchors and not _WORD_NUM_RE.match(txt.replace(" ", "")) \
                    and not _PERIOD_TOKEN_RE.match(txt.replace(" ", "")):
                continue                     # 数字列里的杂字（附注编号等）不要
            cells[_slot(w["x0"])] = txt
        if cells:
            rows.append({"y": sum(w["top"] for w in ln) / len(ln), "cells": cells})

    if not rows:
        return []

    for ln in (l for l in _cluster_lines(label_words) if l):
        text = "".join(w["text"] for w in ln).strip()
        if not text:
            continue
        y = sum(w["top"] for w in ln) / len(ln)
        best = min(rows, key=lambda r: abs(r["y"] - y))
        if abs(best["y"] - y) <= attach_pt:
            best.setdefault("labels", []).append((y, text))
        else:
            rows.append({"y": y, "cells": {}, "labels": [(y, text)]})

    ncol = len(anchors) if anchors else max(
        (max(r["cells"]) + 1 for r in rows if r["cells"]), default=0)
    out = []
    for r in sorted(rows, key=lambda r: r["y"]):
        labels = [t for _, t in sorted(r.get("labels") or [])]
        label = "".join(labels).strip()
        cells = [r["cells"].get(i, "") for i in range(ncol)]
        if label or any(cells):
            out.append([label] + cells)
    # **丢掉页眉/表名行**：`中国黄金…2025年年度报告` 里含"2025年"，
    # 会被 find_year_columns 当成年份表头，导致整张表的列错位
    # （实测把 2024 的经营活动净额当成了 2025）。
    out = [r for r in out
           if not (r[0] and not any(r[1:])
                   and ("年度报告" in r[0] or "半年度报告" in r[0]
                        or "现金流量表" == r[0].strip()
                        or "资产负债表" in r[0] or "利润表" in r[0]))]
    return out


def _extract(page, settings) -> list:
    try:
        tables = page.extract_tables(table_settings=settings)
    except Exception:
        return []
    out = []
    for t in (tables or []):
        if not t:
            continue
        out.append(truncate_at_parent_title(clean_rows(t)))
    return [r for r in out if r]


def read_page(page) -> list:
    """返回该页两策略的候选表，按 (指标命中数 + 结构分) 降序。"""
    cands = []
    # settings=None 即 pdfplumber 默认框线策略（已实测可用）
    for strategy, settings in (("default", None),
                               ("text", _text_settings_for(page))):
        for rows in _extract(page, settings):
            cands.append(ParsedTable(
                page=page.page_number,
                rows=rows,
                strategy=strategy,
                score=score_structure(rows),
            ))
    cands.sort(key=lambda t: t.score, reverse=True)
    return cands


#: 出现两次就说明"同一张表印了两遍（合并 + 母公司）"的锚点行
#: 只认现金流量表的锚点：资产负债表/利润表的"两遍"多是左右栏或续表，
#: 按锚点切会把同一张表切成两半（实测格力 2025 一季报定位从第 5 页跳到第 6 页）。
_BLOCK_ANCHORS = ("经营活动产生的现金流量净额",)


def _split_repeated_blocks(cand) -> list:
    """同一张候选表里若某个锚点行出现两次，按第二次出现的位置拆成两块。

    合并报表在前、母公司报表在后，拆开后两块都会进入候选池；
    调用方按"先到先得"去重，合并口径自然优先。
    """
    rows = cand.rows or []
    cut = None
    seen = set()
    for i, row in enumerate(rows):
        label = "".join((c or "").replace(" ", "") for c in row[:1])
        for a in _BLOCK_ANCHORS:
            if a in label:
                if a in seen:
                    cut = i
                seen.add(a)
        if cut is not None:
            break
    if cut is None or cut < 3:
        return [cand]
    head = ParsedTable(page=cand.page, rows=rows[:cut], strategy=cand.strategy,
                       score=cand.score)
    tail = ParsedTable(page=cand.page, rows=rows[cut:], strategy=cand.strategy,
                       score=cand.score)
    return [head, tail]


def read_report_page_all(page, metric_counter, years=None) -> list:
    """该页**所有至少命中一个目标指标**的候选表，按 (命中数, 结构分) 降序。

    为什么不能只取最优的那一张：pdfplumber 常把一页切成多张表。实测茅台 2024 年报
    p61 —— 上半页是上一页资产负债表的**续表**（未分配利润 / 归属于母公司所有者权益合计 /
    少数股东权益 / 所有者权益合计 / 负债和所有者权益总计），下半页是**母公司**资产负债表。
    只取结构分最高的一张（母公司那张）会把续表整块丢掉，`所有者权益合计` 永远抽不到。
    实测 18 份样本里 12 份缺核心三项，这是主因之一。

    多读一张表的风险由调用方的 (指标名, 年份) **先到先得**去重兜住：合并口径的表排在
    前面，母公司/其他表即使命中同一指标也覆盖不了（与 Ruling「茅台现金流量表取合并口径」
    同一机制）。
    """
    # **不能拿 score 反推命中数**：structure 分上界 130 > 100，命中 0 时 score 也可能 ≥100
    # （见 metric_extractor.count_metrics / parser._page_span 的同一条告诫）。
    # 故这里对每张候选表**真数一遍**命中数。
    cands = read_page(page)

    # **第三种策略：按文字坐标重建**。无框线的报表（中国黄金现金流量表）
    # 用前两种策略都切得七零八落，而坐标重建能还原完整科目名。
    # 只在它命中的目标指标**不少于**其它候选时才会排到前面 —— 不会抢走正常的表。
    word_rows = []
    # **只在"本页自带期间表头"时启用**。续页的列含义无从判断，
    # 会把 2024 那一列的数当成 2025（实测中国黄金 p87）。
    # 用页面自身的锚点判断，不依赖调用方是否传了 `years`。
    if _period_anchors(_cluster_lines(page.extract_words())):
        word_rows = rows_from_words(page)
    if word_rows:
        # **排在候选最前面**：同一页里 text 策略切出的碎表会先被读、
        # 先到先得地占掉 (指标名, 年份)，把正确的坐标表挡在外面
        # （实测中国黄金：碎表把 2024 的数当 2025 存进去）
        cands.insert(0, ParsedTable(page=page.page_number, rows=word_rows,
                                    strategy="words",
                                    score=score_structure(word_rows)))

    scored = [(metric_counter(c.rows), c) for c in cands]
    scored = [(n, c) for n, c in scored if n > 0]
    # **带年份表头的表优先**：同一页常有附注散文被切成"表"，它行数多、结构分高，
    # 却会把真报表挤到后面（茅台 2024 p58：碎片表 41.3 分 vs 真表 0.0 分，两者都只命中 1 项）。
    # `years` 为 None 时退回原行为，不影响老调用方与单测。
    scored.sort(key=lambda t: (t[0], has_year_header(t[1].rows, years)
                               if years else False, t[1].score), reverse=True)
    return [c for _, c in scored]


def read_report_page(page, metric_counter, years=None) -> "ParsedTable | None":
    """按"能抽出多少目标指标"选优。metric_counter 接 List[List[str]] 返回 int。

    指标命中数权重远高于结构分——目的是"能提出正确的表"，
    而不是"看起来像表"。

    调用方若还需要选中表的命中数，自行对 `table.rows` 再跑一次
    metric_counter：命中数无法从 `score` 反推（结构分上界 135 > 100，
    命中数为 0 时结构分也可能 ≥ 100），见 parser._page_span。
    """
    cands = read_page(page)
    if not cands:
        return None
    for c in cands:
        c.score += 100.0 * metric_counter(c.rows)
        # 同样给"带年份表头"一点加权：0.5 远小于 100×命中数，只作打平时的胜负手
        if years and has_year_header(c.rows, years):
            c.score += 0.5
    cands.sort(key=lambda t: t.score, reverse=True)
    return cands[0]
