"""巨潮资讯网下载层。

实测可用的三个端点：
  POST /new/information/topSearch/query     简称 → code + orgId
  POST /new/hisAnnouncement/query           按类别查公告
  GET  static.cninfo.com.cn/finalpage/...   下载 PDF

注意 orgId 有三种编码，必须原样透传，不得做格式假设。
"""
import re
import time
from pathlib import Path

import requests

from models import Announcement

BASE = "http://www.cninfo.com.cn"
STATIC = "http://static.cninfo.com.cn"

CATEGORY = {
    "年报":   "category_ndbg_szsh",
    "半年报": "category_bndbg_szsh",
    "一季报": "category_yjdbg_szsh",
    "三季报": "category_sjdbg_szsh",
}

_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                   "AppleWebKit/537.36 Chrome/120 Safari/537.36"),
    "Referer": f"{BASE}/new/commonUrl?url=disclosure/list/notice",
}

_EXCLUDE = ("摘要", "英文版", "英文", "English")

#: 公告标题里的报告年份：`2024年年度报告` → 2024
_TITLE_YEAR = re.compile(r"((?:19|20)\d{2})年")


def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update(_HEADERS)
    return s


def resolve_org(keyword: str, session=None) -> tuple:
    """公司简称 → (code, orgId, 简称)。找不到抛 LookupError。"""
    s = session or _session()
    r = s.post(f"{BASE}/new/information/topSearch/query",
               data={"keyWord": keyword, "maxNum": 10}, timeout=20)
    r.raise_for_status()
    hits = r.json() or []
    if not hits:
        raise LookupError(f"未找到公司: {keyword}")
    top = hits[0]
    return top["code"], top["orgId"], top.get("zwjc") or keyword


def search_orgs(keyword: str, session=None, limit: int = 10) -> list:
    """关键词 → **A 股候选公司列表** [{code, orgId, name}]。

    `resolve_org` 只取第一个命中，遇到"海螺"这种前缀多家的简称就会挑错
    （000619 海螺新材 vs 600585 海螺水泥）。这里把候选都返回，
    让调用方优先挑问句里真正出现过的那个，挑不出来就告警。
    """
    s = session or _session()
    r = s.post(f"{BASE}/new/information/topSearch/query",
               data={"keyWord": keyword, "maxNum": limit}, timeout=20)
    r.raise_for_status()
    out = []
    for h in r.json() or []:
        if h.get("category") not in (None, "A股"):
            continue
        out.append({"code": h.get("code"), "orgId": h.get("orgId"),
                    "name": h.get("zwjc") or keyword})
    return out


def list_announcements(code: str, org_id: str, report_type: str,
                       start: str, end: str, session=None) -> list:
    """查公告。start/end 形如 '2024-01-01'。"""
    if report_type not in CATEGORY:
        raise ValueError(f"未知报告类型: {report_type}，可选 {list(CATEGORY)}")
    s = session or _session()
    r = s.post(f"{BASE}/new/hisAnnouncement/query",
               data={
                   "pageNum": 1, "pageSize": 30, "column": "szse",
                   "tabName": "fulltext", "plate": "",
                   "stock": f"{code},{org_id}", "searchkey": "", "secid": "",
                   "category": CATEGORY[report_type], "trade": "",
                   "seDate": f"{start}~{end}", "sortName": "", "sortType": "",
                   "isHLtitle": "true",
               }, timeout=25)
    r.raise_for_status()
    out = []
    for a in (r.json().get("announcements") or []):
        adj = a.get("adjunctUrl") or ""
        if not adj:
            continue
        out.append(Announcement(
            title=a["announcementTitle"],
            url=f"{STATIC}/{adj}",
            pub_date=str(a.get("announcementTime", "")),
        ))
    return out


def pick_official(anns: list):
    """挑出正式报告：排除摘要与英文版，多条时取发布日期最早的一条。"""
    ok = [a for a in anns if not any(k in a.title for k in _EXCLUDE)]
    if not ok:
        return None
    return sorted(ok, key=lambda a: a.pub_date)[0]


def pick_for_year(anns: list, year=None):
    """挑出**目标年份**的正式报告；`year=None` 时取公告里最新的那一年的。

    为什么不能直接用 `pick_official`：它按发布日期取**最早**（同一年多版本时取原版，
    见其 docstring）。但查询区间通常跨多年（`2023-01-01~2025-12-31`），
    取最早会拿到区间里**最旧**的那份——实测「下载五粮液年报」拿回了 2022 年年报。
    故先用标题年份收窄到目标年（或最新年），再在同年里按原规则选版本。
    """
    if not anns:
        return None
    if year:
        anns = [a for a in anns if f"{year}年" in a.title]
    else:
        years = [int(m.group(1)) for a in anns
                 if (m := _TITLE_YEAR.search(a.title))]
        if years:
            newest = max(years)
            anns = [a for a in anns if f"{newest}年" in a.title]
    return pick_official(anns)


def title_year(ann: Announcement):
    """公告标题里的报告年份（取不到返回 None）。"""
    m = _TITLE_YEAR.search(ann.title or "")
    return int(m.group(1)) if m else None


def download(ann: Announcement, dest_dir: Path, session=None) -> Path:
    """下载 PDF 到 dest_dir，返回落盘路径。"""
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r'[\\/:*?"<>|]', "_", ann.title)
    path = dest_dir / f"{safe}.PDF"
    if path.exists() and path.stat().st_size > 1024:
        return path
    s = session or _session()
    r = s.get(ann.url, timeout=90)
    r.raise_for_status()
    if not r.content.startswith(b"%PDF"):
        raise ValueError(f"返回内容不是 PDF: {ann.url}")
    path.write_bytes(r.content)
    time.sleep(0.5)  # 限速，避免触发反爬
    return path


def fetch(keyword: str, report_type: str, start: str, end: str,
          dest_root: Path = Path("data"), year=None) -> Path:
    """端到端：简称 + 报告类型 + 日期区间（+ 目标年份）→ PDF 路径。

    `year` 给了就只收标题含 `{year}年` 的公告；不给则取区间内最新的一年。
    """
    code, org_id, name = resolve_org(keyword)
    anns = list_announcements(code, org_id, report_type, start, end)
    ann = pick_for_year(anns, year)
    if ann is None:
        span = f"{year}年" if year else f"{start}~{end}"
        raise LookupError(f"{keyword} {report_type} {span} 无正式报告")
    return download(ann, Path(dest_root) / name / report_type)
