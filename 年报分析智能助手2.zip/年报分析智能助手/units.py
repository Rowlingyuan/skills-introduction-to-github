"""读年报里**声明的金额单位**（元 / 千元 / 万元 / 百万元）。

## 为什么读声明不算"猜"

`parser.parse` 的 `unit_scale` 一直是**由调用方显式声明**的，理由是
"单位声明未必写在报表页上"（比亚迪写在附注里）。但显式声明只覆盖得到 CLI ——
自然语言入口（"帮我分析某某公司的年报"）没有任何地方能传这个参数，
于是招商银行 2024 年报（表头明写`单位：人民币百万元`）被按"元"入库，
金额小了**一百万倍**，而恒等式自检照样通过（两边同倍缩放）。

本模块做的是**读**，不是**猜**：只认页面上写出来的`单位：X`。
读不到就退回"元"并**明确告警**，绝不按数字大小反推量级。
"""
import re

#: `单位：人民币百万元` / `单位: 千元` / `单位：元`。
#: **顺序敏感**：`百万元` 必须排在 `万元` 与 `元` 前面，否则会被短词先匹配掉。
#: 三种常见写法都要认：
#:   1. `单位：人民币百万元`（格力、五粮液）
#:   2. `金额单位为：千元`（比亚迪，写在附注里）
#:   3. `（人民币百万元）`（中国平安，报表标题下单独一行）
_UNIT_RE = re.compile(
    r"(?:金额)?单位\s*(?:为)?\s*[:：]?\s*(?:人民币)?\s*(百万元|千元|万元|元)")
#: 括注式：`（人民币百万元）` / `(单位：千元)`
_PAREN_UNIT_RE = re.compile(r"[（(]\s*(?:单位[:：]?)?\s*(?:人民币)?\s*(百万元|千元|万元)\s*[）)]")

#: 单位 → 归一化成「元」的系数。键必须与正则的捕获组一致。
SCALES = {"元": 1.0, "千元": 1e3, "万元": 1e4, "百万元": 1e6}


def detect_from_texts(texts) -> tuple:
    """从若干页文本里读单位声明 → (scale, 单位名)。读不到返回 (None, None)。

    多页取**出现次数最多**的那个：报表页每页都写一遍，偶发的正文提及不会翻盘。
    """
    counts = {}
    for text in texts or []:
        for m in _UNIT_RE.finditer(text or ""):
            unit = m.group(1)
            counts[unit] = counts.get(unit, 0) + 1
        for m in _PAREN_UNIT_RE.finditer(text or ""):
            unit = m.group(1)
            counts[unit] = counts.get(unit, 0) + 1
    if not counts:
        return None, None
    unit = max(counts, key=counts.get)
    return SCALES[unit], unit


def detect_unit_from_titles(pdf_path) -> tuple:
    """**回退**：只扫「带合并表标题的页」，取表标题下方声明的单位。

    为什么不能整份文档扫：每份年报里都有各种表格写着"万元/千元"，随便取一个必错。
    实测整份统计：宝钢 `元` 181 次、`百万元` 28 次、`千元` 27 次 —— 噪音压过信号。

    为什么不是"离报表页最近的"：万科报表页根本不写单位，附近任何一处声明都可能来自
    别的表，把对的"元"改成错的。

    故判据收窄成：**这一页顶部就是合并表标题，且单位声明在标题附近**。
    找不到就返回 (None, None)，由调用方按"元"处理并告警（宁可告警，不要猜错）。
    """
    try:
        import pdfplumber
        from report_locator import is_consolidated_title
    except Exception:
        return None, None

    counts = {}
    try:
        with pdfplumber.open(str(pdf_path)) as pdf:
            for page in pdf.pages:
                head_lines = (page.extract_text() or "").split("\n")[:8]
                if not any(is_consolidated_title(l.replace(" ", ""))
                           and "附注" not in l for l in head_lines):
                    continue
                scale, unit = detect_from_texts(["\n".join(head_lines)])
                if unit:
                    counts[unit] = counts.get(unit, 0) + 1
    except Exception:
        return None, None

    if not counts:
        return None, None
    unit = max(counts, key=counts.get)
    return SCALES[unit], unit
