"""
向量索引模块
- 用 bge-m3 将年报文本块向量化
- 存入 ChromaDB，支持按公司+年份检索
"""
import os
from embedding import load_embedding_model
import chromadb
from chromadb.config import Settings
from typing import List, Dict
from config import EMBEDDING_MODEL


class ReportIndexer:
    """年报向量索引管理器"""

    def __init__(self, db_path: str = "./chroma_db"):
        self.db_path = db_path
        os.makedirs(db_path, exist_ok=True)

        try:
            import chromadb  # noqa: F401
        except ImportError as e:
            raise RuntimeError(
                "检索组件未安装（chromadb/sentence-transformers）。\n"
                "  需要时执行：.venv/bin/pip install -r requirements-rag.txt\n"
                "  不需要则启动时选「4) 不用」，查数字与出报告照常。") from e

        from config import ENABLE_RAG
        if not ENABLE_RAG:
            raise RuntimeError(
                "向量检索已关闭（EMBEDDING_MODEL=none / ENABLE_RAG=0）；"
                "要启用请去掉该环境变量后重试")
        from embedding import HF_ENDPOINT
        print(f"📦 加载 Embedding 模型: {EMBEDDING_MODEL}（源：{HF_ENDPOINT}）")
        self.model = load_embedding_model(EMBEDDING_MODEL)
        print("✅ Embedding 模型加载完成")

        self.client = chromadb.PersistentClient(path=db_path)
        # **把模型名写进集合元数据**：换模型后能立刻发现维度不一致，
        # 而不是等到查询时报一句看不懂的 1024/512 错误。
        self.collection = self.client.get_or_create_collection(
            name="annual_reports",
            metadata={"hnsw:space": "cosine", "embedding_model": EMBEDDING_MODEL}
        )

    def index_report(self, company: str, year: str, chunks: List[Dict]) -> int:
        """
        将一份年报的所有文本块入库

        Args:
            company: 公司名称
            year: 年份
            chunks: [{"page": int, "text": str}, ...]

        Returns:
            int: 入库的文本块数量
        """
        print(f"\n🔨 正在索引 {company} {year}年年报...")

        batch_size = 32
        total = 0

        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]

            ids = [f"{company}_{year}_p{chunk['page']}" for chunk in batch]
            documents = [chunk["text"] for chunk in batch]
            metadatas = [
                {"company": company, "year": year, "page": chunk["page"]}
                for chunk in batch
            ]

            # 批量生成 embedding
            embeddings = self.model.encode(documents, normalize_embeddings=True).tolist()

            # 入库
            self.collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=documents,
                metadatas=metadatas
            )

            total += len(batch)
            print(f"  ⏳ {total}/{len(chunks)} 块已入库...")

        print(f"✅ 索引完成：{total} 个文本块")
        return total

    def clear_company(self, company: str):
        """清除某公司的所有索引（避免重复入库）"""
        try:
            results = self.collection.get(
                where={"company": company}
            )
            if results["ids"]:
                self.collection.delete(ids=results["ids"])
                print(f"🗑️  已清除 {company} 的旧索引 ({len(results['ids'])} 条)")
        except Exception:
            pass  # collection 为空时可能报错

    def is_indexed(self, company: str, year: str) -> bool:
        """检查某公司+年份是否已入库"""
        try:
            results = self.collection.get(
                where={"company": company, "year": year},
                limit=1
            )
            return len(results["ids"]) > 0
        except Exception:
            return False
