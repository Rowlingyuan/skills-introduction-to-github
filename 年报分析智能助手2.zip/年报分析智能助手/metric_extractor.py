"""表格 → 结构化指标。纯函数，不依赖 PDF。"""
import re

from models import MetricValue

INCOME_METRICS = [
    "营业收入", "利息收入", "营业总成本", "营业成本",
    "税金及附加", "销售费用", "管理费用", "研发费用",
    "财务费用", "投资收益", "营业利润", "营业外收入",
    "营业外支出", "利润总额", "所得税费用", "净利润",
    "归母净利润", "少数股东损益", "基本每股收益", "稀释每股收益",
]

# 从 config 引入，保持单一事实来源
from config import STATEMENT_ALIASES, METRIC_ALIASES

#: **非金额**指标 —— 单位换算（千元→元等）不能作用于它们。
#: 每股收益是"元/股"：宁德时代 2026 半年报以千元列示报表，
#: 若跟着缩放，9.51 元/股 会变成 9,510 元/股。
NON_MONETARY_METRICS = frozenset({"基本每股收益", "稀释每股收益"})

_NUM_RE = re.compile(r"^-?\d+(\.\d+)?$")
_YEAR_RE = re.compile(r"(\d{4})")


def _norm(text) -> str:
    return str(text).replace("\n", "").replace(" ", "").replace("　", "").strip() if text else ""


#: 会计上「括号表示负数」：`(1,234.00)` / `（1,234.00）`。
#: 中文财报的现金流量表、利润表大量使用它（海康 p43 的
#: `投资活动产生的现金流量净额 (270,955,588.95)`）。
#: 不认这个写法，负号会整条丢失，符号直接反掉。
_PAREN_NEG = re.compile(r"^[（(]\s*(.+?)\s*[)）]$")


def _num_text(text) -> str:
    """归一化成可交给 float() 的字符串：去千分位，括号转负号。"""
    t = _norm(text).replace(",", "")
    m = _PAREN_NEG.match(t)
    if m:
        return "-" + m.group(1)
    return t


def is_number(text) -> bool:
    t = _num_text(text)
    return bool(_NUM_RE.match(t)) if t else False


def parse_number(text):
    t = _num_text(text)
    if not _NUM_RE.match(t):
        return None
    return float(t)


#: 行首序号：`一、`、`（一）`、`1.` —— 标签被折行后常留在前半截
_ORDINAL = re.compile(r"^(?:[一二三四五六七八九十]+、|[（(][一二三四五六七八九十]+[)）]|\d+[.、])")


def _strip_ordinal(text: str) -> str:
    return _ORDINAL.sub("", text or "")


def _join_overlap(head: str, tail: str) -> str:
    """拼接被折开的标签，**处理重叠**。

    `经营活动产生的现金` + `现金流量净额` 直接相加会得到"现金现金" ——
    折行把词从中间切开，两半本身是重叠的。这里找最大重叠长度再拼。
    """
    head, tail = head or "", tail or ""
    for k in range(min(len(head), len(tail)), 1, -1):
        if head.endswith(tail[:k]):
            return head + tail[k:]
    return head + tail


#: 附注交叉索引：`六、50(1)`、`五、12`、`七、79（1）`
_NOTE_REF = re.compile(r"^[一二三四五六七八九十]+、\s*\d+(?:[（(]\d+[)）])?$")


def _label_of(row) -> str:
    """行标签 = 从左侧起、直到第一个数字单元格之前的全部单元格的拼接。

    **不能只看 row[0]。** pdfplumber 的文本对齐策略会把带全角冒号的标签切成两列，
    实测格力季报第 7 页：`其中：营业成本 30,150,364,481.08 …` 被切成
    `['：', '营业成本', '30,150,364,481.08', '25,985,115,840.30']`。
    只看首列得到的是 `"："`，匹配不到任何指标，整张表被判 0 分，
    于是季报的利润表永远定位不到（表面症状是"季报找不到利润表"，根因在这里）。

    同样的切分会命中所有 `其中：XXX` 行，年报里也大量存在。
    """
    parts = []
    for cell in row:
        if is_number(cell):
            break
        text = _norm(cell)
        # **附注编号不是标签**：`现金流量净额 | 六、50(1) | 132,441` 里，
        # `六、50(1)` 是附注交叉索引。不收手会把标签拼成
        # `现金流量净额六、50(1)`，任何别名都匹配不上（实测交通银行 p150）。
        if _NOTE_REF.match(text):
            break
        parts.append(text)
    return "".join(parts)


def _has_number(row) -> bool:
    return any(is_number(c) for c in row)


def merge_wrapped_rows(rows) -> list:
    """把「标签被折行切开」的三行拼回一行。

    实测茅台 2024 年报 p61（合并资产负债表**续表**）：
        ['归属于母公司所有者权益', '', '', '']        ← 标签前半
        ['', '', '233,105,984,399.47', '...']         ← 数值行（标签列为空）
        ['或股东权益）合计', '', '', '']              ← 标签后半
    三行本是一行。不拼的话：数值行没有标签、标签行没有数值，
    `所有者权益合计` / `归母净资产` 这类合计项**永远抽不到**
    （18 份样本里 12 份缺核心三项，这是主因之一）。

    规则：某行**有数字但没有标签**时，把紧邻上方/下方**无数字行**的标签碎片并在它身上。
    规则很窄 —— 结构正常的表不会出现"有数字无标签"的行，故不会误并。
    """
    rows = list(rows or [])
    out = []
    i = 0
    while i < len(rows):
        row = rows[i]
        if _label_of(row):
            # **带序号前缀的标签折行才拼**：`五、现金及现金等价物净变`+`动额`。
            # 只认 `一、`/`加：` 这类前缀，避免把普通长标签当成残片拼走
            # （实测：放开长度限制会让中际旭创的现金流量表从 9 个科目掉到 4 个）。
            frag = str(row[0] or "").strip()
            prev_cell = str(out[-1][0] or "").strip() if out else ""
            prefixed = bool(re.match(r"^(?:[一二三四五六七八九十]+、|加：|减：)", prev_cell))
            if (out and prefixed and not _has_number(out[-1]) and _has_number(row)
                    and 0 < len(frag) <= 6):
                out.pop()
                out.append([prev_cell + frag] + list(row)[1:])
                i += 1
                continue
            out.append(row)
        elif _has_number(row):
            head = tail = ""
            if out and not _has_number(out[-1]):
                head = _label_of(out.pop())
            if i + 1 < len(rows) and not _has_number(rows[i + 1]):
                tail = _label_of(rows[i + 1])
                i += 1
            out.append([head + tail] + list(row)[1:])
        # 既无标签也无数字的行：丢弃（产生不了任何指标）
        i += 1
    return out


#: 中文财报的标准括注写法：`所有者权益（或股东权益）`。
#: 折行抽取会把括号切开甚至丢掉 `（`（实测茅台 p61 得到
#: `归属于母公司所有者权益` + `或股东权益）合计`，且另一处 `所有者权益（或股东权` + `）合计`
#: 连 `益` 都丢了），故匹配前先做两步归一化：先删掉成对的括注内容，再删掉残缺的括注片段。
_PAREN_BLOCK = re.compile(r"[（(][^）)]*[）)]")
_PAREN_STUB = re.compile(r"[（(]?或(?:股东|所有者)权益[）)]?")


#: 标签里表示流向的斜杠：顺丰把净额行写成
#: `经营活动产生/(使用)的现金流量净额`、`投资活动(使用)/产生的现金流量净额`
#: —— 括号被 `_PAREN_BLOCK` 去掉后还剩一个 `/`，与别名表的写法对不上。
#: 匹配前一并抹掉，两种写法就都归到 `经营活动产生的现金流量净额`。
_SLASH = re.compile(r"[/／]")


def _match_norm(label) -> str:
    """匹配专用的标签归一化（只影响匹配，不改动 `_norm` 的其它用途）。"""
    s = _norm(label)
    s = _PAREN_STUB.sub("", _PAREN_BLOCK.sub("", s))
    return _SLASH.sub("", s)


def match_metric_detail(label, statement: str = "利润表"):
    """行标签 → (指标名, 别名索引)。索引越小越具体。找不到返回 None。

    statement 决定用哪张别名表。三张表的行项互不相同，用错表会导致
    定位阶段给候选页打错分（见 Task 5）。

    **取命中的「最长别名」，而不是别名表里第一个命中的。** 别名表的顺序
    （"具体在前"）只约束**同一个指标内**的多个别名，管不了**跨指标的子串**：
      - `归属于母公司股东权益合计` 里含 `所有者权益合计` → 若按表序取，
        归母行会被标成 `所有者权益合计`，**真正的合计行反被丢弃**。
        实测这一条让 3 份报表（比亚迪/顺丰/格力一季报）的
        `资产总计 = 负债合计 + 所有者权益合计` 差额恰好等于少数股东权益
        （比亚迪 12,552,384 千元 = 少数股东权益那一行的原值）。
      - `归属于母公司股东的净利润` 里含 `净利润` → 同理，`归母净利润` 永远抽不到。
    取最长别名即可让更长、更具体的别名胜出（`归属于母公司股东权益合计` 13 字
    胜过 `所有者权益合计` 7 字）。

    **平局保持原状**：只在**严格更长**时替换，故同一长度的多个命中仍按表序取第一个
    ——与改动前完全一致，把行为变化收敛到"确实存在更长别名"的那些行
    （如 `其中：营业收入` 7 字胜过 `营业总收入` 5 字，与表序结论相同，值不变）。
    """
    lab = _match_norm(label)
    if not lab:
        return None
    best = None
    for name, aliases in STATEMENT_ALIASES[statement].items():
        for idx, alias in enumerate(aliases):
            if alias in lab and (best is None or len(alias) > best[0]):
                best = (len(alias), name, idx)
    return (best[1], best[2]) if best else None


def match_metric(label, statement: str = "利润表") -> "str | None":
    """行标签 → 指标名。需要区分具体程度时用 match_metric_detail。"""
    m = match_metric_detail(label, statement)
    return m[0] if m else None


def _label_year(label) -> "str | None":
    m = _YEAR_RE.search(_norm(label))
    return m.group(1) if m else None


def find_year_columns(rows, default_years) -> dict:
    """返回 {调用方给的期间标签: 列号}。

    标签由调用方决定（年报是 '2025'，季报可能是 '2025Q1' 或 '2024'——见 Ruling 15），
    本函数只负责把表头里的 **4 位年份** 对应到标签上。
    """
    want = {_label_year(y): y for y in default_years if _label_year(y)}
    for row in rows[:4]:
        found = {}
        for idx, cell in enumerate(row):
            cell_n = _norm(cell)
            m = _YEAR_RE.search(cell_n)
            # 必须带"年"字，避免把 "1,234" 之类误判为年份列
            if m and "年" in cell_n and m.group(1) in want:
                # **第一个命中优先**，不是最后一个。有的报表把「合并」与「公司」
                # 两套数并排（顺丰：合并2026 | 合并2025 | 公司2026 | 公司2025），
                # 年份会在同一行出现两遍；取最后一个会落到**公司（母公司）列**上，
                # 而那两列常常整列是 `-`，于是整张现金流量表只抽出 1 个指标。
                # 中文财报惯例是合并列在左，故 setdefault 取最左。
                found.setdefault(want[m.group(1)], idx)
        if len(found) >= 2:
            return found
    # 兜底：表头没有年份时，按数字列的位置分配。
    #
    # 中文财报的惯例是**当年列在左、上年列在右**（default_years[0] 是最新年）。
    # 关键是取**最右边的 len(default_years) 个**数字列，而不是最左边几个：
    # 非数值列（附注号列、空占位列）也含数字/会被 `is_number` 计入，
    # 从左数会把整张映射整体左移一列，于是把附注号当成本期数、
    # 把本期数当成上期数 —— **带着 confidence="high" 输出一个凭空捏造的数字**。
    #
    # 实测两例（均为表头无年份，故走本兜底）：
    #   茅台 p57 资产负债表  ['应收账款', '5', '2,609,048.49', '18,974,192.75']
    #     → 列 1 是附注号："2025" = 5.00（附注号！），"2024" = 2,609,048.49（实为 2025）
    #   格力 p87            ['一年内到期的非流动负债', '五、39', '', '13,668,113,331.54', …]
    #     → 列 2 是空占位列，同样整体左移，负债合计 231,569,831,196.26（实为 2025）被报成 2024
    # 数值列永远在最右侧：附注号与占位空列都在它左边。
    if not rows:
        return {}
    ncols = max(len(r) for r in rows)
    numeric_cols = []
    for c in range(1, ncols):
        hits = sum(1 for r in rows if c < len(r) and is_number(r[c]))
        if hits >= 1:
            numeric_cols.append(c)
    window = numeric_cols[-len(default_years):] if len(default_years) else []
    return {y: window[i] for i, y in enumerate(default_years) if i < len(window)}


def _numeric_hits(rows, col: int) -> int:
    """该列有多少行是**金额**单元格。用于判断列映射是否落空。

    只算"像金额"的数字：整数 1~999 视为**附注序号**不计入
    （实测中国平安 p189：附注列是 41、42，被当成 2025 年的数值，
    权益合计因此差三个数量级）。
    """
    hits = 0
    for r in rows:
        if col >= len(r) or not is_number(r[col]):
            continue
        v = parse_number(r[col])
        if v is None:
            continue
        if float(v).is_integer() and 0 < abs(v) < 1000:
            continue          # 附注序号
        hits += 1
    return hits


def realign_year_columns(rows, found: dict) -> dict:
    """表头比数据**整体右移**时，把年份列拉回来。

    【症状】pdfplumber 偶尔把表头行单独切歪：恒瑞医药 2026 半年报 p75 的表头是
        `['', '项目', '', '', '附注', '', '', '2026 年 6 月 30日', '', '', '2025 年 12 月 31日', '']`
    而数据行是
        `['货币资金', '', '', '七、1', '', '', '38,734,324,278.37', '', '', '40,955,482,467.79', '', '']`
    —— 表头的标签列在 index 1，数据的标签列在 0。于是 `find_year_columns` 把年份定位到
    第 7/10 列，而数字在第 6/9 列，`extract_metrics` **一条都抽不出来**（或抽到碎片）。

    【判据只认"落空"】只有当年份列**一个数字都没有**、而相邻列有 ≥3 个数字时才平移。
    正常表的年份列本来就满是数字，不会被这条规则动到 —— 保守，避免把对的改错。
    """
    out = dict(found or {})
    for year, col in out.items():
        if _numeric_hits(rows, col) > 0:
            continue
        best_col, best_n = col, 0
        for cand in (col - 1, col + 1):
            if cand < 0:
                continue
            n = _numeric_hits(rows, cand)
            if n > best_n:
                best_col, best_n = cand, n
        # 阈值从 3 降到 1：**只要本列一个数字都没有**（附注编号列就是这种），
        # 相邻列有数字就说明表头错位。实测交通银行 p150：2025 指向
        # `六、50(1)` 这一列，而数字在右邻列（132,441），阈值 3 时移不过去。
        if best_n >= 1:
            out[year] = best_col
    return out


def has_year_header(rows, years) -> bool:
    """表头里是否**明写**了目标期间（如 `2024年12月31日 / 2023年12月31日`）。

    为什么要单独判：同一页上往往混着**附注散文**被 pdfplumber 切成的"表"。
    实测茅台 2024 年报 p58：审计报告正文那张 31 行的碎片表结构分 41.3，
    把只有 4 行的真·资产负债表（表头 + 货币资金两行）挤到后面，
    而两张表**都只有 1 个指标命中**，结构分成了唯一的胜负手 ——
    于是 `货币资金 2024` 取到了碎片表里的**附注号 `1`**（1 元），真值 592.96 亿。

    判据用"表头里 ≥2 个目标年份"，而不是"有年份"：
    碎片表也可能在某行里蹭到一个年份，但凑不出两个。
    """
    want = {y for y in (_label_year(x) for x in years) if y}
    if not want:
        return False
    for row in (rows or [])[:4]:
        found = set()
        for cell in row:
            cell_n = _norm(cell)
            if "年" not in cell_n:
                continue
            m = _YEAR_RE.search(cell_n)
            if m:
                found.add(m.group(1))
        if len(found & want) >= 2:
            return True
    return False


#: 被切开的数字：`'2'` + `'62,096,352,174.36'`。
#: 尾巴必须是**千分位首组恰好两位**（`\d{2},`）—— 这是"前面少了一位"的特征。
#: 若首组是一位（`'2,609,048.49'`），那是完整数字，绝不能和前一个格拼，
#: 否则附注号 `5` 会和它拼成 `52,609,048.49`。
_SPLIT_TAIL = re.compile(r"^\d{2},\d{3}(?:,\d{3})+(?:\.\d+)?$")
_LONE_DIGIT = re.compile(r"^\d$")


def merge_split_numbers(rows) -> list:
    """把被 pdfplumber 切成两格的数字拼回去（`'2'` + `'62,096,352,174.36'`）。

    【症状】茅台 2026 半年报 p28 的续表：`所有者权益（或股东权益）合计`
    抽成 `62,096,352,174.36`，真值 `262,096,352,174.36` —— **首位丢失 2000 亿**，
    而恒等式检查恰好能抓到（差额正好 2000 亿），故一直挂在缺陷清单里。

    【为什么会切】pdfplumber 的 text 策略会用「词中心对齐」造竖直边界，
    某行的词边界可能正好落进另一行更长的数字里。

    【安全性】三条同时成立才拼：前一格是**单个数字**、后一格首组恰好两位、
    且**前一格所在列整列都是单数字**（说明它是碎片列而不是真的数据列）。
    附注列由表头里的「附注」定位，定位得到就额外排除。
    """
    rows = list(rows or [])
    note_col = None
    for row in rows[:4]:
        for i, cell in enumerate(row):
            if "附注" in _norm(cell):
                note_col = i
                break
        if note_col is not None:
            break

    out = []
    for row in rows:
        row = list(row)
        # **数字被切成两格**（交行/中信的现金流量表）：`'(35,48'`+`'8)'`、
        # `'161,95'`+`'0'`。判据用"拼起来才是个数字"——比逐个列举形态稳。
        for i in range(len(row) - 1):
            cur, nxt = _norm(row[i]), _norm(row[i + 1])
            if not cur or not nxt or "附注" in cur:
                continue
            v_join = parse_number(cur + nxt)
            if parse_number(cur) is not None:
                # **截断的数字**：`'161,95'` 会被解析成 161.95（逗号当小数点），
                # 但真实是 `161,950`。判据只看"逗号后不足三位"——
                # 正常的千分位末尾一定恰好三位，不足就是被切走了几位。
                tail = cur.rsplit(",", 1)[-1] if "," in cur else ""
                if (tail.isdigit() and len(tail) != 3 and len(nxt) <= 3
                        and nxt[:1].isdigit() and v_join is not None):
                    row[i] = cur + nxt
                    row[i + 1] = ""
                    break
                continue
            if v_join is not None:
                row[i] = cur + nxt
                row[i + 1] = ""
                break
        # **表头被切开**：`'2025'` + `'年'` → `'2025 年'`。
        # 不拼的话年份列会落到旁边一列（实测交行 p153：2025 被定到"本行"那一列，
        # 于是净增加额/期初/期末全读成了另一套数）。
        for i in range(len(row) - 1):
            cur, nxt = _norm(row[i]), _norm(row[i + 1])
            if re.fullmatch(r"(?:19|20)\d{2}", cur) and nxt in ("年", "年度"):
                row[i] = cur + nxt
                row[i + 1] = ""
                break
        for i in range(len(row) - 1):
            if i == note_col:
                continue
            head, tail = _norm(row[i]), _norm(row[i + 1])
            if not (_LONE_DIGIT.match(head) and _SPLIT_TAIL.match(tail)):
                continue
            # **整列都是单数字** → 这一列不是数字列，而是「被切碎的首位」列，可以拼。
            # 茅台 p28 的续表没有表头（是上一页的延续），靠「附注」二字定位不到列，
            # 故用列形态兜底：真正的数字列里会出现完整金额，碎片列里清一色是单数字。
            if not _is_fragment_column(rows, i):
                continue
            row[i + 1] = head + tail
            row[i] = ""
            break
        out.append(row)
    return out


def _is_fragment_column(rows, col: int) -> bool:
    """该列是不是「被切碎的首位」列 —— 非空格子清一色是单个数字。

    只看形态，不看列名：茅台 p28 的续表没有表头，靠「附注」定位不到列。
    真数字列里总会出现完整金额（`99,683,216,816.20`），碎片列里只有 `2`、`3`、`1`。
    """
    vals = [_norm(r[col]) for r in rows if col < len(r) and _norm(r[col])]
    return bool(vals) and all(_LONE_DIGIT.match(v) for v in vals)


def _drop_empty_columns(rows) -> list:
    """删掉**整列为空**的列，让数据列与表头重新对齐。

    为什么要这一步：`'(35,48' + '8)'`、`'132,44' + '1'` 这类被切开的数字，
    拼接时会把内容放到后一格、并把前一格清空 —— 于是整列变空，
    而表头没有这一列，年份列号整体右移一位，取值全部错位
    （实测交通银行 p150：132,441 落在第 4 列，表头指向第 3 列）。
    """
    rows = [list(r) for r in (rows or [])]
    if not rows:
        return rows
    width = max(len(r) for r in rows)
    keep = [i for i in range(width)
            if any(i < len(r) and _norm(r[i]) for r in rows)]
    return [[r[i] if i < len(r) else "" for i in keep] for r in rows]


def extract_metrics(rows, page, years, statement: str = "利润表") -> list:
    """抽指标：**每个 (指标名, 年份) 产出一条 MetricValue**。

    上年同期值不是装饰——同比与趋势分析全靠它，绝不能只留最新一年。

    同一指标名可能命中多行："一、营业总收入" 与 "其中：营业收入" 都归属
    "营业收入"。此时取**别名最具体**的那一行（别名表有序，索引越小越具体），
    而不是"最后一行"——后者依赖行序，换个公司的排版顺序就会取错值。
    """
    # **先拼数字碎片、再拼标签碎片**：标签拼接要求"本行有数字"，
    # 而银行表的数字恰好也被切成两格（`'(35,48'`+`'8)'`），先拼标签会判定为"无数字"而漏拼
    # （实测交通银行 p153：`五、现金及现金等价物净变` + `动额` 拼不上，净增加额永远抽不到）。
    rows = merge_wrapped_rows(merge_split_numbers(rows))
    rows = _drop_empty_columns(rows)
    year_cols = find_year_columns(rows, default_years=years)
    # 表头整体右移一列时，年份列会落在空格子上 —— 拉回来（见 realign_year_columns）
    year_cols = realign_year_columns(rows, year_cols)
    if not year_cols:
        return []

    best = {}          # name -> {year: (别名索引, 值)}
    row_hits = {}      # name -> 命中的行数，用于判断置信度
    for idx, row in enumerate(rows):
        if not row:
            continue
        label = _label_of(row)
        matched = match_metric_detail(label, statement)
        values_row = row

        # **标签折成两行/两列**（银行/券商报表）：交通银行 p150 的真实形态是
        #   ['一、', '经营活动产生的现金', ...] + ['', '现金流量净额', '六、50(1)', '132,441']
        # 标签横跨第 0/1 列，数字在下一行。碎片取**下一行整段标签**，
        # 并按"重叠"拼（`…产生的现金` + `现金流量净额` 会重复"现金"）。
        # 只在"拼起来确实能匹配别名"时才借用下一行的数字，且**不改动行本身**。
        if matched is None and idx + 1 < len(rows) and not _has_number(row):
            nxt = rows[idx + 1]
            if _has_number(nxt):
                frag = _label_of(nxt)
                if frag and len(frag) <= 12:
                    joined = _join_overlap(label, frag)
                    for cand_label in (joined, _strip_ordinal(joined)):
                        m2 = match_metric_detail(cand_label, statement)
                        if m2 is not None:
                            matched, values_row = m2, nxt
                            break
        if matched is None:
            continue

        name, alias_idx = matched
        row_hits[name] = row_hits.get(name, 0) + 1
        for year, col in year_cols.items():
            if col >= len(values_row):
                continue
            v = parse_number(values_row[col])
            if v is None:
                continue
            prev = best.setdefault(name, {}).get(year)
            if prev is None or alias_idx < prev[0]:
                best[name][year] = (alias_idx, v)

    out = []
    for name, years_map in best.items():
        conf = "medium" if row_hits.get(name, 0) > 1 else "high"
        for year, (_idx, value) in years_map.items():
            out.append(MetricValue(name=name, period=year, value=value,
                                   source_page=page, confidence=conf,
                                   statement=statement))
    return out


#: **不参与定位打分**的指标。它们在附注的明细表里也成片出现，对"这页是不是报表"
#: 没有区分度，反而会把附注页抬到真报表之上：
#: 实测格力 2024 半年报加了借款类科目后，资产负债表被定位到 p186（附注的金融工具风险表）。
#: 它们照常**抽取**，只是不给定位加分。
_SCORING_EXCLUDE = frozenset({
    "短期借款", "一年内到期的非流动负债", "长期借款", "应付债券", "租赁负债",
})


def count_metrics(rows, statement: str = "利润表") -> int:
    """供 table_reader / report_locator 打分：能匹配到多少个不同的**数据行**指标。

    **只匹配标签是不够的。** 附注页的散文里也会出现"货币资金""应收账款"这些词——
    实测格力半年报第 185 页，8 个"命中"全部是文字段落（"本公司金融资产包括货币资金、
    应收款项融资等"），数字单元格数为 0，却因此反超了第 68 页的真资产负债表。

    判别依据很简单：**真正的报表数据行一定带数字**，说明文字没有。
    """
    # **先做与抽取阶段同样的拼接再计数**：否则"标签/数字被切成两格"的页
    # 一个别名都匹配不上，命中数=0 → 整页被当成非报表丢掉（实测交通银行 p153）。
    rows = merge_wrapped_rows(merge_split_numbers(rows))
    found = set()
    for i, r in enumerate(rows):
        if not r:
            continue
        if not any(is_number(c) for c in r):
            # **标签折行**：本行是标签、数字在下一行（银行现金流量表）。
            # 抽取阶段就是这么配对的，计数阶段必须一致，否则整页命中数=0
            # 被当成非报表丢掉（实测交通银行 p150/p151）。
            if i + 1 < len(rows) and any(is_number(c) for c in rows[i + 1]):
                frag = str(rows[i + 1][0] or "").strip()
                if frag and len(frag) <= 8:
                    name = match_metric(_label_of(r) + frag, statement)
                    if name and name not in _SCORING_EXCLUDE:
                        found.add(name)
            continue
        name = match_metric(_label_of(r), statement)
        if name and name not in _SCORING_EXCLUDE:
            found.add(name)
    return len(found)
