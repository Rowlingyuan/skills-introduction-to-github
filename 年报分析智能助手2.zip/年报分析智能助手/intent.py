"""用大模型理解**自由语序**的问句，提取 (公司, 报告类型, 年份)。

## 为什么需要它

正则只认"公司名 + 年份"这一种顺序。实测这些说法全都抓不到：

    中国黄金的年报帮我看看2025年的
    我想知道2025年中国黄金的年报情况
    2025年报 中国黄金
    帮我看看中国黄金去年年报
    年报，中国黄金，2025

真实用户不会按套路说话，所以必须有语义解析兜底。但它**只负责理解意图**，
不产生任何数字 —— 数字仍然全部由确定性代码从 PDF 里抽。

## 拿不准就问

模型给出自我评估的 confidence；低于阈值时**不执行**，而是返回一个
"你问的是不是 X 的 Y 年报"的确认请求。宁可多问一句，也不猜错公司
（A 股"海螺新材 / 海螺水泥"这种撞名太多了）。
"""
import json
import re
import time
from datetime import date
from pathlib import Path

#: 低于这个置信度就先问一句，不直接跑。
CONFIRM_BELOW = 0.75

_PROMPT = """你在帮一个"年报分析助手"理解用户这一句话。只输出 JSON，不要解释。

任务：判断用户**此刻要做什么**，以及涉及哪家公司、哪一期报告。

字段：
- action：analyze（分析某份报告）/ query（查某个具体数字）/ unknown
- company：公司简称或全称；**如果这句没提，但上文正在聊某家公司，就沿用上文那家**
- report_type：年报 / 半年报 / 一季报 / 三季报，没提就沿用上文，再没有就是年报
- period：四位年份；"去年""前年""24 年"等要换算；没提就沿用上文
- confidence：0 到 1，你对 company 与 period 的把握

今天是 {today} 年 {month} 月。

判断要点：
- 用户只说"2024 年年报""换成 24 年""那半年报呢"这类**省略公司**的话，是在接着上文说，
  company 取上文那家，不要填 null。
- 用户说了另一家公司，就换掉，不要沿用。
- 用户可能在纠错（"说错了""不是 26 是 24"），以**最后说的**为准。

{history}用户这一句：{question}

输出：
"""



#: 解析结果缓存。同一句话第二次问就不再调模型 ——
#: 语义解析能带来 3~10 秒的等待，而"这句话问的是哪家公司哪一期"是稳定映射。
_CACHE_PATH = Path(__file__).resolve().parent / "data" / "intent_cache.json"
_CACHE_MAX = 500


def _cache_load() -> dict:
    try:
        return json.loads(_CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:                        # noqa: BLE001
        return {}


def _cache_save(cache: dict) -> None:
    try:
        _CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        # 只留最近 500 条，避免无限增长
        if len(cache) > _CACHE_MAX:
            keep = sorted(cache.items(), key=lambda kv: kv[1].get("ts", 0),
                          reverse=True)[:_CACHE_MAX]
            cache = dict(keep)
        _CACHE_PATH.write_text(json.dumps(cache, ensure_ascii=False, indent=1),
                               encoding="utf-8")
    except Exception:                        # noqa: BLE001
        pass


def _cache_key(question: str) -> str:
    from company_names import normalise
    return normalise(question)[:80]


def _extract_json(text: str):
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:                        # noqa: BLE001
        return None


def _history_block(history) -> str:
    """把最近几轮对话渲染成提示词里的一小段。

    这是"随便怎么问都能懂"的关键：模型看到上文，才知道"2024 年年报"是哪家公司。
    """
    if not history:
        return ""
    lines = ["最近的对话（从旧到新）："]
    for item in history[-4:]:
        said = (item.get("text") or "").strip()[:60]
        ent = item.get("entity") or {}
        if ent.get("company"):
            lines.append(f"- 用户：{said} → 理解为 {ent['company']} "
                         f"{ent.get('period') or ''} {ent.get('report_type') or '年报'}")
        else:
            lines.append(f"- 用户：{said}")
    return "\n".join(lines) + "\n\n"


def parse(question: str, history=None) -> "dict | None":
    """返回 {company, report_type, period, confidence}；模型不可用时返回 None。

    命中缓存就直接返回 —— 同一句话不必重复花 3~10 秒调模型。
    """
    cache = _cache_load() if not history else {}
    key = _cache_key(question)
    hit = cache.get(key) if cache else None
    if hit:
        return {k: hit[k] for k in ("company", "report_type", "period",
                                    "confidence") if k in hit}

    from client import call_model
    today = date.today()
    try:
        raw = call_model(
            "router",
            [{"role": "user", "content": _PROMPT.format(
                today=today.year, month=today.month,
                history=_history_block(history), question=question)}],
            # 网关实测 10~20 秒很常见，20 秒超时会把正常响应掐掉；
            # 上下文提示词也更长，输出留 300 token
            temperature=0, max_tokens=300, timeout=35, max_retries=2)
    except Exception:                        # noqa: BLE001
        return None

    got = _extract_json(raw)
    if not isinstance(got, dict):
        return None

    company = (got.get("company") or "").strip() or None
    rtype = got.get("report_type") or "年报"
    if rtype not in ("年报", "半年报", "一季报", "三季报"):
        rtype = "年报"
    period = str(got.get("period") or "").strip()
    if not re.fullmatch(r"(?:19|20)\d{2}", period or ""):
        period = None
    try:
        conf = float(got.get("confidence"))
    except Exception:                        # noqa: BLE001
        conf = 0.0
    if not company:
        return None
    result = {"company": company, "report_type": rtype, "period": period,
              "confidence": max(0.0, min(1.0, conf))}
    # **只缓存成功结果**，且只缓存"没有上文"的解析 ——
    # 带上下文时同一句话的含义可能不同，缓存会串味
    if not history:
        cache[key] = {**result, "ts": time.time()}
        _cache_save(cache)
    return result


def canonical(parsed: dict) -> str:
    """把解析结果改写成管道认识的标准问法。"""
    period = parsed.get("period") or str(date.today().year)
    return f"分析{parsed['company']}{period}{parsed.get('report_type', '年报')}"
