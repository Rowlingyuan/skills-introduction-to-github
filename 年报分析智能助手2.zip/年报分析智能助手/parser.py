"""编排层：PDF → ParseResult。

职责仅限编排。定位、提取、校验、存储各自在独立模块中。
"""
import re
import sys
from pathlib import Path

import pdfplumber

from metric_extractor import (NON_MONETARY_METRICS, count_metrics,
                              extract_metrics)
from models import ParseResult, ReportKey
from report_locator import candidate_pages, is_parent_only_page, locate
from storage import init_db, save_result
from table_reader import read_report_page, read_report_page_all

DEFAULT_DB = Path("data") / "structured.db"


def _period_labels(period: str, statement: str) -> list:
    """返回两列的期间标签：本期在前、上期在后。

    年报：['2025', '2024']。
    季报**按报表类型分化**（Ruling 15）：

    | 报表 | 第一列 | 第二列 |
    |---|---|---|
    | 利润表 / 现金流量表 | 本期 `2025Q1` | 上年**同期** `2024Q1` |
    | 资产负债表 | 期末余额 `2025Q1` | 上年**年末** `2024` |

    **第一列一律带季度**：季报本期就是 2025 年 1–3 月，`2025` 会与全年 2025 混淆，
    正是 Ruling 15 要修的那个缺陷。**只有第二列按报表类型分化**：
      - 利润表/现金流量表第二列是"上年同期"（2024Q1），与全年 2024 不是一回事 → 标 2024Q1；
      - 资产负债表第二列是"上年年末"（2024-12-31），就是年报里那份资产负债表
        → 标 2024，好让它与年报正确 join。
    """
    m = re.search(r"(\d{4})", period or "")
    if not m:
        raise ValueError(f"无法从 period 解析年份: {period}")
    y = int(m.group(1))
    q = re.search(r"Q(\d)", period or "")
    if not q:
        return [str(y), str(y - 1)]
    qq = q.group(1)
    prev = f"{y - 1}Q{qq}" if statement in ("利润表", "现金流量表") else str(y - 1)
    return [f"{y}Q{qq}", prev]


def _page_span(pdf, rtype: str, pno: int, end: "int | None" = None) -> list:
    """报表的抽取区间。

    `locate()` 选的是**命中最多**的页，实测在季报里那是报表的**中间页**而不是起始页
    （格力一季报利润表：p6 顶行 3 命中、p7 主体 15 命中 → locate 给 p7）。
    只读 `(pno, pno+1)` 会丢掉起始页上的顶行（营业收入！）。

    故区间取：**从定位页向前回溯到连续命中的起点**，终点保持 `pno + 1`。

    - **起点**用"向前回溯连续命中页"，而不是 `min(candidates)`/`max(candidates)`。
      实测 `candidate_pages` 是关键词扫出的**宽集合**，含大量远处页：
      格力年报利润表的候选跨 p80..p126（附注页 94/95 也命中 15/1 次）。
      用候选的 min/max 定区间会把 2 页读成 40 页，把附注整段当成报表。
    - 终点由调用方给出（`end`，含）：**一张表一直读到下一张表开始的那一页**。
      实测一张表可跨三页：茅台 2024 年报的合并资产负债表是 p59(资产)/p60(负债)/
      p61(权益合计)，固定 `pno + 1` 只到 p60，`所有者权益合计` 等合计行**从未被读**
      （18 份样本里 12 份缺核心三项，一半以上源于此）。`locate()` 已知三张表各自的
      页码，故终点取"下一个更大的定位页"，没有下一张表时退回 `pno + 1`。
      **为什么跨到下一张表的首页也不怕**：`extract_metrics` 的结果按 (指标名, 年份)
      **先到先得**去重（`parse()` 里的 `seen`），合并报表的页一定排在母公司/其他表之前，
      故多读的页不会覆盖合并口径的值 —— 与 Ruling「茅台现金流量表取合并口径」同一机制。
      实测影响面（4 个样本 12 个报表）：**8 个区间与改动前完全一致**，
      **4 个向前多读若干页**——茅台年报 资产负债表（p57→56）、茅台年报 现金流量表
      （p65→64）、格力一季报 利润表（p7→6，本任务要修的那个）、
      格力半年报 现金流量表（p79→78）。四页均各 1..3 个命中。
      全部由文档内容推导，不引入任何绝对页码。
    """
    cands = set(candidate_pages(pdf, rtype))

    def hits(pg: int) -> int:
        """该页选中表的目标指标命中数（0 表示回溯应在此断开）。

        先在**不含命中数权重**的纯结构分下选表，再对选中表的 `rows` 直接
        数一遍命中数。这两步刻意分开，不做任何合并：

        命中数**不能**从 `read_report_page` 的评分里反推。该函数给候选表加的是
        `100.0 * 命中数`（`table_reader.py`），而 `score_structure` 的上界是
        **130**（表头关键词 7×10 + 行数 15+10 + 列数 15 + 数字行占比 20），
        并不小于 100。因此 `score // 100 == 命中数 + floor(结构分 / 100)`，
        只有当结构分 < 100 时才等于命中数。一页表头词多、行数多、数字密集的表
        可以在**命中数为 0** 时结构分 ≥ 100，反推就会把 0 读成 1，
        使本应断开的回溯继续向左跑——正是本函数要避免的"把 2 页读成 40 页"。
        故这里保留显式的一次 `count_metrics`，它的成本相对
        `page.extract_tables()` 可以忽略。
        """
        table = read_report_page(
            pdf.pages[pg - 1],
            lambda rows, _s=rtype: count_metrics(rows, statement=_s),
        )
        return count_metrics(table.rows, statement=rtype) if table else 0

    # 起点：从定位页**向前回溯**，只要相邻候选页仍有目标指标命中就继续，直到断掉。
    #
    # `(start - 1) in cands` 这个候选页资格判断是**刻意保留**的（审查意见 3 要求
    # 把它从"偶然"变成"有理由"）。理由与代价：
    #
    # 1. 它的实际约束力极弱。`candidate_pages` 是"命中关键词的页 ± 1"，所以有真命中的
    #    页必是候选页；能挡住回溯的只有"**命中页的下一页**"（如 p+1 作为 p 的邻居入候选，
    #    但自身无命中）。也就是说它禁掉的只是一次**注定返回 0、本来就会终止循环**的探测，
    #    **不改变任何一份实测样本的区间**。保留它不会让任何报表少读一页。
    # 2. 但它换掉了回溯的**触发前提**：若去掉它，回溯的动力就只剩"下一页恰好有目标指标"，
    #    与报表边界无关。最坏情况下（正文某页同行项但列结构判错）会顺着附注一路向左跑——
    #    正是本函数开头否决 `min/max(candidates)` 时要躲开的那个 2 页变 40 页的坑。
    #    保留候选资格，等于要求"往回退的那一页至少出现过本表的关键词或其邻居"。
    # 3. 代价：茅台 p64/p65。现金流量表定位页是 p65，p64 是它的起始页；
    #    p65 的正文（续表行项）**不含**"合并现金流量表"字样，它靠 p64 的 +1 邻居资格成为候选页，
    #    p64 又因 p63 的 +1 邻居资格成为候选页，回溯因此通过。但这依赖"标题页
    #    与续表的距离 ≤ 1"这一排版事实：若某份报告的续表再往后挪一页，
    #    识别 p64 的关键词扫这一路就会断，起点会停在 p65，顶行照丢。
    #    届时正确的方向是换判据（如按关键字回读起始页标题），而不是简单删掉本条件——
    #    删掉它只放宽了守卫，并不补上判据。
    start = pno
    while start - 1 >= 1 and (start - 1) in cands and hits(start - 1):
        start -= 1
    stop = pno + 1 if end is None else end

    # **按标题向前延伸**：报表常跨多页，而调用方给的 `end` 只知道"下一张表在哪"，
    # 最后一张表的 `end` 会退化成 `pno+1`（交通银行现金流量表跨 p149–154，
    # 只读 p149 就只抽到 1 个指标）。这里顺着"同名的（续）页"往后找到真正的末页。
    title = {"资产负债表": "资产负债表", "利润表": "利润表",
             "现金流量表": "现金流量表"}.get(rtype, rtype)
    last = pno
    for nxt in range(pno + 1, min(pno + 7, len(pdf.pages)) + 1):
        head = "\n".join((pdf.pages[nxt - 1].extract_text() or "").split("\n")[:4])
        # **续页常常没有表名**（实测中际旭创 p99：顶部直接是"筹资活动产生的现金流量净额"），
        # 只认标题会断在上一页，尾部科目整块丢失。故"标题在页首"或"该页仍能命中目标科目"
        # 任一成立就继续往下读，最多再读 6 页，避免顺着一路读进附注。
        if title in head or hits(nxt) > 0:
            last = nxt
        else:
            break
    stop = max(stop, last)

    return [p for p in range(start, stop + 1) if 1 <= p <= len(pdf.pages)]


#: 利润表里的**成本费用类**科目。列示惯例一旦是"减："式（造价为负），
#: 这一族都必须一起翻正，否则毛利率会算成 (收入 − (−成本)) / 收入 > 100%。
_EXPENSE_METRICS = frozenset({
    "营业成本", "营业总成本", "税金及附加", "销售费用", "管理费用",
    "研发费用", "财务费用", "营业外支出", "所得税费用", "少数股东损益",
})


def normalise_expense_signs(metrics) -> list:
    """把"减："式列示的成本费用翻成正数（**按期间**判定，就地改）。

    实测顺丰控股 2026 半年报 p90：利润表把成本费用写成括号负数 ——
    `减：营业成本 (134,593,933)`、`销售费用 (1,892,187)`（单位千元）。
    我们的解析忠实于原文（−1345.94 亿），但分析层会因此算出
    **毛利率 186%** —— 数字本身没错，错在没有归一化列示惯例。

    判据只看**营业成本是否为负**：成本在经济上不可能是负数，
    它一为负就说明整张表用了"减："式，同族的费用一起翻。
    **不碰财务费用等可能天然为负的科目**的单独判断 —— 格力 2025 的
    财务费用本来就是 −40.86 亿（利息净收入），那张表的营业成本是正的，故不触发。
    """
    for period in {m.period for m in metrics}:
        cost = next((m for m in metrics
                     if m.name == "营业成本" and m.period == period), None)
        if cost is None or cost.value is None or cost.value >= 0:
            continue
        for m in metrics:
            if m.period == period and m.name in _EXPENSE_METRICS and m.value:
                m.value = -m.value
    return metrics


def parse(pdf_path, key: ReportKey, verify: bool = True, db_path=None,
          unit_scale: "float | None" = None) -> ParseResult:
    """抽取一份报表。

    `unit_scale` 是该报表**财报数字的单位换算系数**（元=1、千元=1000、万元=10000），
    抽出的每个数都乘上它，统一归一化成**元**。

    - 传具体数字：按调用方声明处理（CLI `--unit` 走这条）；
    - 传 `None`（默认）：**读报表页上的单位声明**（`units.py`）。读不到才退回"元"并告警。
      自然语言入口没有地方传这个参数，若一律按"元"处理，招商银行年报（百万元）
      会小一百万倍，而恒等式自检照样通过。
    **仍然不做启发式猜测**：只认页面上写出来的`单位：X`，绝不按数字大小反推量级。

    **缩放放在 LLM 校验之后**：校验是拿抽出的数字与该页原文逐字比对的，
    先缩放会让两边对不上，把正确数字误标成 conflict。
    """
    pdf_path = str(pdf_path)

    sections = locate(pdf_path, years := _period_labels(key.period, "利润表"))
    print(f"📍 定位结果: {sections}")

    # 每张表的读取终点 = **下一个更大的定位页**（含它，保住"尾页同时是下一张表首页"
    # 的排版，实测格力一季报 p8）；没有下一张表时退回 pno + 1。
    # 依据见 `_page_span` docstring：一张表可能跨三页，固定 +1 会漏掉合计行。
    _located = sorted(sections.values())

    def _statement_start(pdf, rtype: str, pno: int) -> int:
        """定位页若是**续页**（没有报表标题），往前找到标题页。

        实测中国黄金：现金流量表跨 p86（标题`合并现金流量表`）与 p87（续页）。
        定位器选了 p87（结构分更高），只解析它就会丢掉整段经营活动现金流 ——
        抽到的 3 个科目全是投资/筹资。
        """
        from report_locator import is_consolidated_title
        keys = [rtype, rtype.replace("表", "")] if rtype else []
        for back in range(0, 4):
            pg = pno - back
            if pg < 1:
                break
            head = (pdf.pages[pg - 1].extract_text() or "").split("\n")[:6]
            for line in head:
                flat = line.replace(" ", "")
                if any(k and k in flat for k in keys) or is_consolidated_title(flat):
                    return pg
        return pno

    def _span_end(pno: int) -> int:
        nxt = [p for p in _located if p > pno]
        return min(nxt) if nxt else pno + 1

    metrics = []
    unit_label = "元" if unit_scale is not None else None
    with pdfplumber.open(pdf_path) as pdf:
        if unit_scale is None:
            from units import detect_from_texts
            pages_hit = sorted(set(sections.values()))
            scale, unit = detect_from_texts(
                [(pdf.pages[p - 1].extract_text() or "")
                 for p in pages_hit if 1 <= p <= len(pdf.pages)])
            if scale is None:
                # **回退到全文档扫描**：声明常写在报表页之外（中国建筑 p13-15 的
                # `单位：千元`、比亚迪附注、中国平安的 `（人民币百万元）`）。
                from units import detect_unit_from_titles as _scan_doc
                scale, unit = _scan_doc(pdf_path)
            if scale is None:
                unit_scale, unit_label = 1.0, "元"
                print("⚠️ 全文未找到金额单位声明，按「元」处理 —— 请核对量级")
            else:
                unit_scale, unit_label = scale, unit
                print(f"💱 单位声明：{unit} → 归一化为元（×{scale:g}）")

        for rtype, pno in sections.items():
            # 期间标签**按报表类型分化**（Ruling 15）：季报的利润表/现金流量表第二列是
            # 上年同期（2024Q1），资产负债表第二列是上年年末（2024-12-31，等同年报口径）。
            # 故必须在循环内按 rtype 取，不能提到函数开头只算一次。
            years = _period_labels(key.period, rtype)

            # 每类报表用各自的别名表，见 Task 4 / ledger D3
            def counter(rows, _s=rtype):
                return count_metrics(rows, statement=_s)

            # 报表常跨页：实测格力季报的利润表 7→8、现金流量表 8→9。
            # 只取定位页会丢掉次页的尾部指标（每股收益、筹资活动现金流等）。
            # 定位页始终是**起始页**（指标最密、综合分最高），故连同下一页一起抽取，
            # 按 (指标名, 年份) 合并，先出现者优先。
            #
            # 已知的一期限制：pno+1 未必是本表的续表——实测格力年报 利润表=88、
            # 现金流量表=89，茅台 资产负债表=57、利润表=61，次页其实是**另一张表**的首页，
            # 会被套在本表的别名表下抽取（恒等地标成 statement=rtype）。
            # 但反过来，格力一季报 p8 既是利润表的尾页、又是现金流量表的定位首页，
            # 而 locate() 只返回 {报表类型: 页码}、不含跨度信息，故仅凭 sections
            # 无法区分"续表页"与"他家首页"。任何按页码身份跳过的规则都会连带丢掉
            # 利润表尾部的基本每股收益。为保住 spec §9 的跨页续表，这里保留无条件读取。
            # **续页要读同页的全部表，定位页只读最优的一张。**
            # pdfplumber 常把一页切成多张：实测茅台 p61（资产负债表续页）上半页是本表尾部、
            # 下半页是母公司表，只取分高者会把本表尾部（所有者权益合计…）整块丢掉。
            # 但定位页上分数最高的那张**就是本表**，同页其余多为附注碎片 —— 实测对它
            # 一视同仁地读会把碎片值当成当期数（恒瑞 p75 的 2026 列、茅台半年报 p28 同理）。
            # 故只在**续页**放开，且先到先得去重保证合并口径优先。
            extracted, seen, first_table = [], set(), None
            start = _statement_start(pdf, rtype, pno)
            for pg in _page_span(pdf, rtype, start, end=_span_end(pno)):
                page = pdf.pages[pg - 1]
                # 跨页区间可能把「母公司报表」整页包进来（海康 p43），跳过
                if is_parent_only_page(page):
                    continue
                if pg == pno:
                    # **首页也读全部候选表**（按命中数排序，最优的在前）。
                    # 早先只读一张，理由是怕把碎片值当期数；但一页里可能同时有
                    # 「报表开头」和「续表」两张表 —— 茅台 2026 半年报 p28 就是这样，
                    # 只读第一张会丢掉 `所有者权益合计`，于是它从后面某页取到个 1.49 亿。
                    # 碎片问题现在由 `truncate_at_parent_title`（母公司表截断）和
                    # `merge_split_numbers`（首位碎片拼回）在表内解决，不再靠"只读一张"。
                    tables = read_report_page_all(page, counter, years=years)
                    if not tables:
                        best = read_report_page(page, counter, years=years)
                        tables = [best] if best is not None else []
                else:
                    tables = read_report_page_all(page, counter, years=years)
                for table in tables:
                    if first_table is None:
                        first_table = table
                    for m in extract_metrics(table.rows, page=pg, years=years,
                                             statement=rtype):
                        if (m.name, m.period) not in seen:
                            seen.add((m.name, m.period))
                            extracted.append(m)

            if first_table is not None:
                print(f"   {rtype} 第{pno}页 策略={first_table.strategy} "
                      f"结构分={first_table.score:.1f} 指标数={len(extracted)}")

            if verify and extracted:
                from llm_verifier import apply_outcome, verify as run_verify
                # LLM 调用粒度固定为单页（见 Global Constraints）：只校验定位页，
                # 续页指标不参与校验。这是已知的一期限制。
                text = pdf.pages[pno - 1].extract_text() or ""
                try:
                    outcome = run_verify(extracted, text, page_no=pno)
                    extracted = apply_outcome(extracted, outcome)
                    print(f"      LLM校验: correct={outcome.is_correct} "
                          f"{outcome.explanation[:60]}")
                except Exception as e:
                    print(f"      ⚠️ LLM校验跳过: {e}")
            metrics.extend(extracted)

    # 成本费用的"减："式列示 → 翻成正数（必须在缩放之前/之后都无所谓，翻的是符号）
    normalise_expense_signs(metrics)

    if unit_scale != 1.0:
        # 归一化到元（见 docstring：必须在 LLM 校验之后，否则校验对不上原文）。
        # **每股收益不缩放**：它是"元/股"，不是金额。宁德时代半年报以千元列示，
        # 缩放过一次就把 9.51 元/股 记成了 9,510 元/股。
        for m in metrics:
            if m.name in NON_MONETARY_METRICS:
                continue
            m.value = m.value * unit_scale

    result = ParseResult(key=key, file_path=pdf_path,
                         sections=sections, metrics=metrics,
                         unit=unit_label or "元")
    if db_path:
        init_db(db_path)
        save_result(result, db_path)
    return result


def main():
    from downloader import fetch
    if len(sys.argv) < 4:
        print("用法: python parser.py <公司简称> <报告类型> <起> <止>")
        print("示例: python parser.py 格力电器 年报 2025-01-01 2025-12-31")
        return
    keyword, rtype, start, end = sys.argv[1:5]
    pdf_path = fetch(keyword, rtype, start, end)
    print(f"✅ 已下载: {pdf_path}")
    code, _, name = __import__("downloader").resolve_org(keyword)
    key = ReportKey(name, code, rtype, start[:4])
    res = parse(pdf_path, key, verify=True, db_path=DEFAULT_DB)
    print(f"\n📊 提取 {len(res.metrics)} 个指标")
    for m in res.metrics:
        flag = " ⚠️待复核" if m.confidence == "conflict" else ""
        print(f"   {m.name} {m.period}: {m.value:,.2f}  (p{m.source_page}){flag}")


if __name__ == "__main__":
    main()
