#!/usr/bin/env python3
"""**结构化数据源 vs PDF 抽取**的逐项比对。

用途：在把三大表切到结构化接口之前，先证明"两套数一致"；
不一致的项挑出来人工核对，避免换源换出问题。

用法：
    python scripts/em_compare.py            # 全部报告
    python scripts/em_compare.py 交通银行   # 单家
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DB = ROOT / "data" / "structured.db"

#: 允许的差异（元）。财务报表原值到分，2 元足够兜住四舍五入/单位换算。
TOL = 2.0


def main(argv) -> int:
    import sqlite3

    import analysis
    import em_source

    only = argv[1] if len(argv) > 1 else None

    conn = sqlite3.connect(str(DB))
    rows = conn.execute(
        "SELECT company, code, report_type, period FROM reports").fetchall()
    conn.close()

    if only:
        rows = [r for r in rows if r[0] == only]

    agree = differ = only_em = only_pdf = skipped = sign_only = 0
    diffs = []

    for company, code, rtype, period in rows:
        if not code:
            skipped += 1
            print(f"跳过（无股票代码）：{company} {period}")
            continue
        em = em_source.fetch_metrics(code, period, rtype)
        if not em:
            skipped += 1
            print(f"跳过（结构化取不到）：{company} {period}")
            continue

        pdf = {m.name: m.value
               for m in analysis.load_metrics(company, rtype, period, str(DB))}

        for name, ev in em.items():
            pv = pdf.get(name)
            if pv is None:
                only_em += 1
                continue
            if abs(ev - pv) <= TOL:
                agree += 1
            elif abs(ev + pv) <= TOL:
                # **只是符号相反**：报表把费用类列成"减："式（PDF 取到负数），
                # 东财统一给正数。不是数据分歧，单独统计。
                sign_only += 1
            else:
                differ += 1
                diffs.append((company, period, name, pv, ev))
        only_pdf += len([n for n in pdf if n not in em])

    total = agree + differ + sign_only
    print("\n" + "=" * 60)
    if total:
        print(f"可比项 {total}：数值一致 {agree}，仅符号相反 {sign_only}，"
              f"真实分歧 {differ}")
        print(f"  → 扣除符号约定后一致率 {(agree + sign_only) / total * 100:.1f}%")
    print(f"仅结构化有 {only_em} 项；仅 PDF 有 {only_pdf} 项；跳过 {skipped} 份")

    if diffs:
        print("\n不一致明细（前 20）：")
        for company, period, name, pv, ev in diffs[:20]:
            rel = abs(ev - pv) / max(abs(pv), 1)
            print(f"  {company:8} {period} {name:22} PDF={pv / 1e8:>12,.2f} 亿"
                  f"  EM={ev / 1e8:>12,.2f} 亿  差 {rel * 100:.2f}%")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
