#!/usr/bin/env python3
"""导出**只含代码、文档与数据**的副本压缩包（不含运行环境与下载缓存）。

    python scripts/export_code_zip.py

体积从 2 GB 降到约 2 MB：跳过 `.venv`、`chroma_db`、`data/` 下的 PDF 与模型缓存、
`pdfs/`、`legacy/`、`.git`、`.env`（本地密钥）、用户设置与测试样本 PDF。
解压后仍是可运行工程：双击 启动.command / 启动.bat 即可。
"""
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "年报分析智能助手.zip"
ROOT_NAME = "年报分析智能助手"

#: 顶层文件（通配 + 指名）
TOP_GLOBS = ["*.py"]
TOP_FILES = [
    "README.md", "快速开始.md", "项目骨架.txt",
    "requirements.txt", "requirements-rag.txt",
    ".gitignore", "pytest.ini", "启动.command", "启动.bat",
]
#: 整目录收录
DIRS = ["tests", "scripts", "reports"]

#: 任何路径含这些名字就跳过
SKIP = {"__pycache__", ".DS_Store", ".env", "settings.json", ".pytest_cache",
        "unused.db", "_chunks_backup.json"}


def main() -> int:
    if OUT.exists():
        OUT.unlink()

    n = 0
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        def add(p: Path, arc: str) -> None:
            nonlocal n
            if any(s in p.parts or p.name == s for s in SKIP):
                return
            info = zipfile.ZipInfo.from_file(p, arc)
            info.compress_type = zipfile.ZIP_DEFLATED
            if p.suffix in (".command", ".bat"):          # 保留可执行位，否则双击报错
                info.external_attr = (0o755 << 16)
            z.writestr(info, p.read_bytes())
            n += 1

        for pattern in TOP_GLOBS:
            for p in sorted(ROOT.glob(pattern)):
                add(p, f"{ROOT_NAME}/{p.name}")
        for name in TOP_FILES:
            p = ROOT / name
            if p.exists():
                add(p, f"{ROOT_NAME}/{name}")

        db = ROOT / "data" / "structured.db"
        if db.exists():
            add(db, f"{ROOT_NAME}/data/structured.db")

        for d in DIRS:
            base = ROOT / d
            if not base.exists():
                continue
            for p in sorted(base.rglob("*")):
                if p.is_file():
                    add(p, f"{ROOT_NAME}/{p.relative_to(ROOT).as_posix()}")

    print(f"✅ 已生成：{OUT.name}（{n} 个文件，{OUT.stat().st_size / 1e6:.1f} MB，在项目根目录）")
    print("   已跳过：.venv / chroma_db / data 下的 PDF 与模型缓存 / pdfs / legacy / .env")
    print("   解压后双击 启动.command（macOS）或 启动.bat（Windows）即可运行。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
