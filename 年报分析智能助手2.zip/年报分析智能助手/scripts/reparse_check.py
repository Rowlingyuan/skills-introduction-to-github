#!/usr/bin/env python3
"""用**当前解析器**把所有报告重解析一遍（写临时库），与数据库基线对比。

为什么不能只跑 `metric_snapshot.py diff`：那个读的是生产库，只要没重新入库就
永远"一致"。改解析器时真正要回答的是——

    **换上新解析器后，每一份报告抽到的指标会不会变少？**

本脚本把每份 PDF 解析进一个临时 SQLite，逐表对比数量，只报告"变少"的。
"""
> **注意（2026-11 之后）**：三大表已改为从东方财富结构化接口取数，
> 库里存的是结构化数据（50 个映射科目）；本脚本用 PDF 重新解析后比对，
> 自然会报「变少」。**这是预期的**，不代表解析器退化。
> 只有在"回退到 PDF 抽取"的场景下调解析器，这个脚本才有参考价值。

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DB = ROOT / "data" / "structured.db"


def main() -> int:
    import sqlite3
    from collections import Counter

    from models import ReportKey
    from parser import parse
    from storage import init_db

    conn = sqlite3.connect(str(DB))
    rows = conn.execute(
        "SELECT company, code, report_type, period, file_path FROM reports").fetchall()
    base = {}
    for rid, company, rtype, period in conn.execute(
            "SELECT id, company, report_type, period FROM reports"):
        c = Counter()
        for (stmt,) in conn.execute("SELECT statement FROM metrics WHERE report_id=?", (rid,)):
            c[stmt] += 1
        base[f"{company}|{rtype}|{period}"] = dict(c)
    conn.close()

    tmp = Path(tempfile.mkdtemp(prefix="reparse-")) / "x.db"
    init_db(str(tmp))

    worse, better, skipped = [], [], []
    for company, code, rtype, period, pdf in rows:
        if not pdf or not Path(pdf).exists():
            skipped.append(f"{company} {period}")
            continue
        key = f"{company}|{rtype}|{period}"
        try:
            res = parse(pdf, ReportKey(company, code or "", rtype, period),
                        verify=False, db_path=str(tmp))
            cur = Counter(m.statement for m in res.metrics)
        except Exception as e:                # noqa: BLE001
            skipped.append(f"{key}（解析失败：{type(e).__name__}）")
            continue
        b = base.get(key, {})
        for stmt in ("资产负债表", "利润表", "现金流量表"):
            nb, nc = b.get(stmt, 0), cur.get(stmt, 0)
            if nc < nb:
                worse.append((key, stmt, nb, nc))
            elif nc > nb:
                better.append((key, stmt, nb, nc))

    print(f"\n共 {len(rows)} 份，跳过 {len(skipped)}")
    for key, stmt, nb, nc in better:
        print(f"  ↑ {key} {stmt}: {nb} → {nc}")
    for key, stmt, nb, nc in worse:
        print(f"  ↓ {key} {stmt}: {nb} → {nc}")
    if skipped:
        print("  跳过：", "；".join(skipped[:5]))
    print(f"\n变多 {len(better)} 处，变少 {len(worse)} 处")
    return 1 if worse else 0


if __name__ == "__main__":
    sys.exit(main())
