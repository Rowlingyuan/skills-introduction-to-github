#!/usr/bin/env python3
"""把**所有已入库报告**的三大表切到结构化数据源（东方财富）。

PDF 抽取的附注类指标不动；只覆盖 `em_source.FIELD_MAP` 映射到的科目。
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DB = ROOT / "data" / "structured.db"


def main() -> int:
    import sqlite3

    import em_source

    conn = sqlite3.connect(str(DB))
    rows = conn.execute(
        "SELECT company, code, report_type, period FROM reports ORDER BY company, period"
    ).fetchall()
    conn.close()

    ok = skip = fail = 0
    total_upd = 0
    for company, code, rtype, period in rows:
        if not code:
            print(f"跳过（无代码）：{company} {period}")
            skip += 1
            continue
        try:
            res = em_source.sync_to_db(company, code, period, rtype, str(DB))
        except Exception as e:                      # noqa: BLE001
            print(f"✗ {company} {period}：{type(e).__name__}: {e}")
            fail += 1
            continue
        if res.get("error"):
            print(f"跳过（{res['error']}）：{company} {period}")
            skip += 1
            continue
        total_upd += res["updated"] + res["inserted"]
        ok += 1
        print(f"✓ {company} {period} {rtype}：覆盖 {res['updated']} 项，新增 {res['inserted']} 项")
    print(f"\n完成：成功 {ok}，跳过 {skip}，失败 {fail}，共写入 {total_upd} 个指标")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
