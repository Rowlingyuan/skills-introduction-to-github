#!/usr/bin/env python3
"""泛化能力抽样：拿**没在库里**的公司走完整链路，看能出报告的比例与失败类型。

不必补某一家公司的特例 —— 要的是"随便问一家能不能出报告"。
每家公司记四件事：三张表是否定位到 / 各表指标数 / 与东财的校验结果 / 失败原因。
"""
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import sqlite3
from collections import Counter

from downloader import fetch, resolve_org
from models import ReportKey
from parser import parse
from storage import init_db, load_metrics

DB = str(ROOT / "data" / "structured.db")

#: 行业刻意打散：保险、券商、地产、建筑、钢铁、科创板半导体。
#: 与既有样本（家电/白酒/新能源/医药/银行）几乎不重叠。
TARGETS = [
    ("中国平安", "年报", 2025),
    ("中信证券", "年报", 2025),
    ("万科A",   "年报", 2025),
    ("中国建筑", "年报", 2025),
    ("宝钢股份", "年报", 2025),
    ("中芯国际", "年报", 2025),
]


def probe(company, rtype, year) -> dict:
    row = {"company": company, "ok": False, "reason": "", "metrics": {},
           "validate": "", "pages": ""}
    try:
        code, _org, name = resolve_org(company)
        pdf = fetch(name, rtype, f"{year}-01-01", f"{year + 3}-12-31", year=year)
        key = ReportKey(name, code, rtype, str(year))
        res = parse(pdf, key, verify=False, db_path=DB)
        ms = load_metrics(name, rtype, str(year), DB)
        by = Counter(m.statement for m in ms)
        row["metrics"] = dict(by)
        row["pages"] = str({k: v for k, v in res.sections.items()})
        row["ok"] = bool(by.get("利润表") and by.get("资产负债表"))
    except Exception as e:                       # noqa: BLE001
        row["reason"] = f"{type(e).__name__}: {e}"[:120]
        return row

    try:
        import validator as v
        vr = v.validate_report(name, rtype, str(year), DB)
        if vr.get("ok"):
            s = vr["summary"]
            row["validate"] = (f"{s['ok']}/{s['checked']} 一致，"
                               f"不符 {s['mismatch']}，漏抽 {s['missing_ours']}")
        else:
            row["validate"] = f"无法核验（{vr.get('error')[:40]}）"
    except Exception as e:                       # noqa: BLE001
        row["validate"] = f"核验异常 {type(e).__name__}"

    if not row["metrics"].get("利润表"):
        row["reason"] = "利润表未定位到"
    elif not row["metrics"].get("现金流量表"):
        row["reason"] = "现金流量表未定位到"
    return row


def main() -> int:
    init_db(DB)
    rows = []
    for company, rtype, year in TARGETS:
        print(f"\n=== {company} {year} {rtype}", flush=True)
        r = probe(company, rtype, year)
        rows.append(r)
        print(f"  指标：{r['metrics']}", flush=True)
        print(f"  核验：{r['validate']}", flush=True)
        if r["reason"]:
            print(f"  ⚠️ {r['reason']}", flush=True)

    print("\n\n================ 汇总 ================", flush=True)
    good = sum(1 for r in rows if r["ok"])
    for r in rows:
        state = "✅" if r["ok"] and "不符 0" in r["validate"] else (
            "🟡" if r["ok"] else "❌")
        print(f"{state} {r['company']:<8}{r['metrics']}  {r['validate']}  "
              f"{r['reason']}", flush=True)
    print(f"\n可出报告：{good}/{len(rows)}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
