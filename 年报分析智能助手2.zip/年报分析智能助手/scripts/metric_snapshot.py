#!/usr/bin/env python3
"""全库解析结果快照：每份报告抽到多少个指标。

## 为什么需要它

改解析器（表格策略、标签合并、页面跨度）时，只看一家公司根本不够 ——
实测两次"修复中国黄金现金流量表"的改动，都把**格力资产负债表**搞坏了：

    改动前 现金流量表 6 个 → 改动后 0 个（目的没达到）
    改动前 利润表  40 个 → 改动后 27 个（顺手弄坏别的）

这类回归在小样本测试里看不出来。有了快照，改完跑一次 diff 就知道每份报告
是变多、变少还是不变，再决定要不要留下这次改动。

## 用法

    python scripts/metric_snapshot.py save     # 存基线（改代码前）
    python scripts/metric_snapshot.py diff     # 与基线比较（改代码后）
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DB = ROOT / "data" / "structured.db"
SNAP = ROOT / "data" / "metric_snapshot.json"


def snapshot() -> dict:
    """{ "公司|类型|期间": {"资产负债表": n, "利润表": n, "现金流量表": n} }"""
    import sqlite3
    from collections import Counter

    conn = sqlite3.connect(str(DB))
    rows = conn.execute(
        "SELECT r.id, r.company, r.report_type, r.period FROM reports r").fetchall()
    out = {}
    for rid, company, rtype, period in rows:
        cnt = Counter()
        for (stmt,) in conn.execute(
                "SELECT statement FROM metrics WHERE report_id=?", (rid,)):
            cnt[stmt] += 1
        out[f"{company}|{rtype}|{period}"] = dict(cnt)
    conn.close()
    return out


def save() -> int:
    data = snapshot()
    SNAP.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    total = sum(sum(v.values()) for v in data.values())
    print(f"已保存基线：{len(data)} 份报告，共 {total} 个指标 → {SNAP}")
    return 0


def diff() -> int:
    if not SNAP.exists():
        print("还没有基线，先跑 `save`")
        return 1
    base = json.loads(SNAP.read_text(encoding="utf-8"))
    cur = snapshot()
    worse, better = [], []
    for key in sorted(set(base) | set(cur)):
        b, c = base.get(key, {}), cur.get(key, {})
        for stmt in ("资产负债表", "利润表", "现金流量表"):
            nb, nc = b.get(stmt, 0), c.get(stmt, 0)
            if nc < nb:
                worse.append((key, stmt, nb, nc))
            elif nc > nb:
                better.append((key, stmt, nb, nc))

    for key, stmt, nb, nc in better:
        print(f"  ↑ {key} {stmt}: {nb} → {nc}")
    for key, stmt, nb, nc in worse:
        print(f"  ↓ {key} {stmt}: {nb} → {nc}")
    if not better and not worse:
        print("与基线完全一致")
    else:
        print(f"\n变多 {len(better)} 处，变少 {len(worse)} 处")
    # **有任何一处变少就返回非 0**，方便在 CI / 提交前拦一下
    return 1 if worse else 0


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "diff"
    sys.exit(save() if cmd == "save" else diff())
