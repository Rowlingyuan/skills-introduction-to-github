#!/usr/bin/env python3
"""重建向量索引（**换过检索模型之后必须跑一次**）。

为什么需要：向量维度由模型决定（small 512 / base 768 / m3 1024）。
换了模型，旧索引的维度对不上，查询会直接报
`Collection expecting embedding with dimension of 1024, got 512`。

重建**不需要重新下载年报**：文本块本来就存在索引里，取出来用新模型重新编码即可。
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main(argv=None) -> int:
    """`--clean` 彻底重建（先导出文本、删掉整个向量库目录再写回），能消除历史残留。"""
    import sys as _sys

    clean = "--clean" in (argv if argv is not None else _sys.argv)

    import chromadb

    from config import EMBEDDING_MODEL
    from embedding import load_embedding_model

    client = chromadb.PersistentClient(path=str(ROOT / "chroma_db"))
    col = client.get_or_create_collection("annual_reports")
    total = col.count()
    if total == 0:
        print("索引是空的，无需重建。")
        return 0

    print(f"当前索引 {total} 个文本块；将改用 {EMBEDDING_MODEL} 重新编码…")

    data = col.get(include=["documents", "metadatas"])
    docs = data["documents"]
    metas = data["metadatas"]

    print("📦 加载新模型…")
    model = load_embedding_model(EMBEDDING_MODEL)

    # **先建到新目录，成功后整体替换**。
    # 早期版本是"新建集合同库再改名"，会留下旧集合的物理文件（实测 148M→275M），
    # 而且同一个进程里删库再建会撞上 chroma 的进程内缓存（Collection already exists）。
    target = ROOT / "chroma_db_new"
    import shutil
    shutil.rmtree(target, ignore_errors=True)

    client2 = chromadb.PersistentClient(path=str(target))
    new = client2.create_collection(
        "annual_reports",
        metadata={"hnsw:space": "cosine", "embedding_model": EMBEDDING_MODEL})

    batch = 64
    for i in range(0, len(docs), batch):
        chunk = docs[i:i + batch]
        emb = model.encode(chunk, normalize_embeddings=True).tolist()
        new.add(ids=[f"c{i + j}" for j in range(len(chunk))], documents=chunk,
                metadatas=metas[i:i + batch], embeddings=emb)
        print(f"  {min(i + batch, len(docs))}/{len(docs)}", end="\r")

    print(f"\n✅ 编码完成：{new.count()} 个文本块")
    del new, client2, col, client
    shutil.rmtree(ROOT / "chroma_db", ignore_errors=True)
    target.rename(ROOT / "chroma_db")
    print(f"✅ 索引已替换：模型 {EMBEDDING_MODEL}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
