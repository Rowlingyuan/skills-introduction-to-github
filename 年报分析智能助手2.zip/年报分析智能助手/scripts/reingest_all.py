#!/usr/bin/env python3
"""用当前的科目表重新解析**所有已入库**的报告（写回主库）。

什么时候需要：给 `BALANCE_ROWS` / `CASHFLOW_ROWS` 加了新科目之后 ——
旧记录的指标是按旧清单抽的，不重解析就永远缺新科目。

幂等：`parse()` 对同一份报告是覆盖写，重复跑安全。
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DB = ROOT / "data" / "structured.db"


def main() -> int:
    import sqlite3

    from models import ReportKey
    from parser import parse

    conn = sqlite3.connect(str(DB))
    rows = conn.execute(
        "SELECT company, code, report_type, period, file_path FROM reports").fetchall()
    conn.close()

    ok = skip = fail = 0
    for company, code, rtype, period, path in rows:
        if not path or not Path(path).exists():
            print(f"跳过（文件不在）：{company} {period}")
            skip += 1
            continue
        try:
            res = parse(path, ReportKey(company, code or "", rtype, period),
                        verify=False, db_path=str(DB))
            print(f"✓ {company} {period} {rtype}：{len(res.metrics)} 个指标")
            ok += 1
        except Exception as e:                # noqa: BLE001
            print(f"✗ {company} {period}：{type(e).__name__}: {e}")
            fail += 1
    print(f"\n完成：成功 {ok}，跳过 {skip}，失败 {fail}")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
