"""
语义检索模块
"""
import os

from embedding import load_embedding_model
import chromadb
from typing import List, Dict
from config import EMBEDDING_MODEL


def build_where_filter(company: str = None, year: str = None):
    """把「公司/年份」收窄条件转成 ChromaDB 的 `where`。

    **多条件必须包成 `$and`**：ChromaDB 的 `where` 只接受**恰好一个**操作符，
    直接把 `{"company": .., "year": ..}` 传给 `query` 会抛
    `ValueError: Expected where to have exactly one operator`（实测踩到，
    整条 RAG 链路直接崩）。单条件原样透传，无条件返回 `None`（不加过滤）。
    """
    conds = []
    if company:
        conds.append({"company": company})
    if year:
        conds.append({"year": year})
    if not conds:
        return None
    return conds[0] if len(conds) == 1 else {"$and": conds}


class ReportRetriever:
    """年报语义检索器"""

    def __init__(self, indexer=None, db_path: str = "./chroma_db"):
        # 加载细节统一在 embedding.py（离线优先），别在这里再写一份
        self.model = load_embedding_model(EMBEDDING_MODEL)

        self.client = chromadb.PersistentClient(path=db_path)
        self.collection = self.client.get_or_create_collection("annual_reports")
        self._check_model_match()

    def _check_model_match(self) -> None:
        """索引是用哪个模型建的？和当前不一致就**明确报错并给出修法**。

        不做这个检查的话，用户换模型后只会看到
        `Collection expecting embedding with dimension of 1024, got 512`，
        完全不知道该怎么办。
        """
        try:
            meta = dict(self.collection.metadata or {})
        except Exception:                 # noqa: BLE001
            return
        built_with = meta.get("embedding_model")
        if built_with and built_with != EMBEDDING_MODEL:
            raise RuntimeError(
                f"向量索引是用 {built_with} 建的，当前检索模型是 {EMBEDDING_MODEL}，"
                "维度不一致无法查询。\n"
                "  修复：python scripts/reindex.py（用新模型重建索引，约几分钟）\n"
                "  或者：把 EMBEDDING_MODEL 改回 " + str(built_with))

    def search(
            self,
            query: str,
            company: str = None,
            year: str = None,
            top_k: int = 5
    ) -> List[Dict]:
        """
        语义检索

        Args:
            query: 用户问题
            company: 可选，限定公司
            year: 可选，限定年份
            top_k: 返回数量

        Returns:
            [{"page": int, "text": str, "relevance": float}, ...]
        """
        query_embedding = self.model.encode(query, normalize_embeddings=True).tolist()

        # 构建过滤条件
        where_filter = build_where_filter(company, year)

        # **先多取一些**：融合需要两路各有一份候选，只取 top_k 就没得融合了
        wide = max(top_k * 4, 20)
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=wide,
            where=where_filter,
            include=["documents", "metadatas", "distances"]
        )

        if not (results["ids"] and results["ids"][0]):
            return []

        ids = results["ids"][0]
        docs = results["documents"][0]
        metas = results["metadatas"][0]
        dists = results["distances"][0]

        # **混合检索**：向量排名（已有顺序）× 关键词排名（BM25）× RRF 融合。
        # 纯向量在专有名词上会漏（"合同负债""递延收益"），纯关键词在口语化提问上会漏，
        # 两路融合后取长补短。见 hybrid.py。
        from hybrid import hybrid_rank

        vector_order = list(range(len(ids)))
        order = hybrid_rank(query, docs, vector_order, top_n=wide)

        formatted = []
        for rank, idx in enumerate(order[:top_k]):
            meta = metas[idx]
            relevance = max(0, 1 - dists[idx])          # cosine distance → 相似度
            # 融合后排名靠前的，给一点"混检加成"，避免下游按 relevance 排序时
            # 又把关键词命中的段落压下去
            bonus = 0.05 * (1 - rank / max(len(order), 1))
            formatted.append({
                "page": meta.get("page", "?"),
                "text": docs[idx],
                "relevance": round(min(1.0, relevance + bonus), 4),
                "company": meta.get("company", ""),
                "year": meta.get("year", ""),
                "retrieval": "hybrid",
            })

        return formatted
