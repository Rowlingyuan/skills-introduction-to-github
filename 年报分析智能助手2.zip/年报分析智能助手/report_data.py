#!/usr/bin/env python3
"""现算一份报告所需的数据，写成 JSON 供 `make_report_docx.py` 渲染。

分两步是因为两边依赖不同：
  - 本脚本要 `pdfplumber`（读年报 PDF 抽收入构成）与 `chromadb`/`bge-m3`（检索原文），
    跑在项目 venv 里；
  - 渲染要 `python-docx`，跑在 harness 的 bundled python 里。
强行合并就得把两套依赖装进同一个环境，没必要。

用法：
    .venv/bin/python report_data.py 格力电器 2025
    .venv/bin/python report_data.py 比亚迪 2026 --report-type 半年报 --no-narrative
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_DB = ROOT / "data" / "structured.db"
DEFAULT_OUT = ROOT / "data" / "report_input.json"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="report_data.py")
    ap.add_argument("company")
    ap.add_argument("period")
    ap.add_argument("--report-type", default="年报",
                    choices=["年报", "半年报", "一季报", "三季报"])
    ap.add_argument("--db", default=str(DEFAULT_DB))
    ap.add_argument("-o", "--output", default=str(DEFAULT_OUT))
    ap.add_argument("--no-narrative", action="store_true",
                    help="跳过「年报原文对变动原因的解释」（省一次检索 + 大模型调用）")
    ap.add_argument("--validate", action="store_true",
                    help="联网用 AkShare 逐项核验，把结果写进报告 6.2 节（约 20 秒）")
    args = ap.parse_args(argv)

    from analysis import build_analysis
    data = build_analysis(args.company, args.report_type, args.period, args.db)
    if not data.get("ok"):
        print(data.get("error", "无法生成分析"))
        return 1

    narrative = None
    if not args.no_narrative:
        from narrative import build_narrative
        res = build_narrative(args.company, args.report_type, args.period,
                              args.db, data)
        if res.get("ok") and (res.get("answer") or "").strip():
            narrative = res
            print(f"原文归因：{len(res['answer'])} 字，"
                  f"{len(res.get('citations') or [])} 处候选出处")
        else:
            print(f"（原文归因未生成：{res.get('error') or '模型返回空'}）")

    if args.validate:
        import validator as v
        res = v.validate_report(args.company, args.report_type, args.period, args.db)
        if res.get("ok"):
            data["validation"] = res
            s = res["summary"]
            print(f"外部核验：一致 {s['ok']}，不符 {s['mismatch']}，"
                  f"口径差异 {s['restated'] + s['reclassified']}，"
                  f"漏抽 {s['missing_ours']}")
        else:
            print(f"（外部核验跳过：{res.get('error')}）")

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(
        json.dumps({"analysis": data, "narrative": narrative},
                   ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"saved: {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
