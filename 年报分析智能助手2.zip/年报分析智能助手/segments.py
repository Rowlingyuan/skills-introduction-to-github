"""从年报「管理层讨论与分析」里抽取**收入/成本构成**，并算出变动贡献度。

为什么需要单独一层：三大报表只给一个"营业收入合计"，而"**为什么变**"要看构成 ——
分行业 / 分产品 / 分地区各自多少、各自同比多少。这些数据在 MD&A 的构成表里，
**不在财务报表中**，财报抽取完全看不到。

实测三种真实形态（都在本仓库样本里）：

| 报告 | 表 | 形状 |
|---|---|---|
| 格力 2025 年报 p24 | 营业收入构成 | `名称 本期 占比% 上期 上期占比% 同比%` |
| 比亚迪 2026 半年报 p26 | 营业收入构成 | 同上，但**标签被折行切开**、占比写作 `100%` |
| 茅台 2025 年报 p10 | 主营业务分行业/分产品情况 | `名称 营收 成本 毛利率% 营收同比% 成本同比%`（**无上期金额**，由同比反推） |

**两条腿都要走**：
- **文本行**：行是一整行、形状固定（格力适用）；但标签被折行时会把名字切断（比亚迪不适用）。
- **表格单元格**：框线策略的标签是完整的（比亚迪适用）；但同一格里的数字可能被切成
  `'371,28' '0,948,00' '0.' '00'` 四片（格力适用性差）。
两者取**行数多者**，互补覆盖。
"""
import re

import pdfplumber

#: 金额：允许**整数**（宁德时代写成 `192,124,890` 而非 `...890.00`）
_MONEY = re.compile(r"-?[\d,]+(?:\.\d+)?")
_PCT = re.compile(r"-?\d+(?:\.\d+)?%")
_AMT = r"-?[\d,]+(?:\.\d+)?"

#: 可能承载构成表的标题（各家写法不同：营业收入构成 / 主营业务分… / 分产品或服务 / 分业务）
_TRIGGERS = ("营业收入构成", "主营业务分", "分产品或服务", "分行业", "分产品",
             "分地区", "分业务")

#: 收入构成表的分组标题（自己成行 / 单独成格）
_GROUP_TITLES = ("分行业", "分产品", "分地区", "分销售模式")

#: 表结束标志：出现下一节或"10%以上"那张表就停，别把别处的数字吃进来
_STOP_MARKERS = ("（2）", "(2)", "占公司营业收入或营业利润", "10%以上")

_UNIT_RE = re.compile(r"单位[:：]\s*((?:人民币)?\s*(?:千元|万元|百万元|元))")
_UNIT_SCALES = {"元": 1.0, "人民币元": 1.0, "千元": 1e3, "人民币千元": 1e3,
                "万元": 1e4, "人民币万元": 1e4, "百万元": 1e6, "人民币百万元": 1e6}

_MIX_ROW = re.compile(
    r"^(.+?)\s+(" + _AMT + r")\s+(\d+(?:\.\d+)?)%\s+"
    r"(" + _AMT + r")\s+(\d+(?:\.\d+)?)%\s+(-?\d+(?:\.\d+)?)%$")
#: 「名称 营收 成本 毛利率 [营收同比 [成本同比 [毛利率同比]]]」——**按位解析、尾部宽松**。
#: 各家写法不同：茅台写成 `酒类 168,774,585,187.65 14,805,900,139.59 91.23 -1.08 8.63`
#: （毛利率不带 %、尾部 3 项），宁德时代写成
#: `动力电池系统 192,124,890 152,492,111 20.63% 46.02% 49.38% -1.78%`（都带 %、尾部 4 项）。
#: 早期版本把 `%` 与项数写死在正则里，两家都匹配不上。
#: 尾部限制为 **3~4 个不带千分位逗号的数**（可带 %）。这一条把 mix 行挡在外面：
#: mix 行的尾部里含有带逗号的金额（`... 169,715,353,002.47 ...`），匹配不上。
_BIZ_TAIL = r"(?:(?:-?\d+(?:\.\d+)?%?)\s+){2,3}-?\d+(?:\.\d+)?%?"
_BIZ_ROW = re.compile(r"^(.+?)\s+(" + _AMT + r")\s+(" + _AMT + r")\s+(" + _BIZ_TAIL + r")$")


def _f(s: str) -> float:
    return float(str(s).replace(",", "").replace("%", ""))


#: **严格**数字形态：千分位必须是完整的三位一组。用它判断"这一格是否已攒成一个完整数"。
#: 宽松形态会把 `371,280,948,00`（还差一位）提前收下，也会把 `...000.00` 与紧随的
#: `100%` 吞成 `...000.00100`。
_MONEY_STRICT = re.compile(r"-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?")
_PCT_STRICT = re.compile(r"-?\d+(?:\.\d+)?%")


def _tokens(cells) -> list:
    """把一行单元格归一化成 [(是否百分比, 数值)]。

    同一格里的数字会被 pdfplumber 切成多片（`'371,28' '0,948,00' '0.' '00'`），
    故逐格累积、**攒成完整数才收下**。用严格形态判断完整性：片段 `371,280,948,00`
    不是合法数字（末组只有两位），会一直攒到 `...000.00` 为止。
    """
    out, buf = [], ""
    for c in cells:
        buf += str(c).strip()
        tok = buf.strip()
        if _MONEY_STRICT.fullmatch(tok) or _PCT_STRICT.fullmatch(tok):
            out.append(tok)
            buf = ""
    return [(t.endswith("%"), _f(t)) for t in out]


def _name_of(cells) -> str:
    """首格作名字。名字里的数字/百分号说明这格不是标签，返回空串。"""
    name = re.sub(r"[\s　]", "", str(cells[0])) if cells else ""
    if not name or _MONEY.fullmatch(name) or _PCT.fullmatch(name):
        return ""
    return name


def _mk_row(name, kind, toks) -> "dict | None":
    """按表形状把 token 序列落成一行。形状不符返回 None。"""
    vals = [v for _, v in toks]
    if kind == "mix" and len(vals) == 5 and [k for k, _ in toks] == [0, 1, 0, 1, 1]:
        return {"name": name, "cur": vals[0], "share": vals[1],
                "prev": vals[2], "prev_share": vals[3], "yoy": vals[4]}
    if kind == "biz" and 4 <= len(vals) <= 6 and vals[0] > 0 and 0 <= vals[2] <= 150:
        row = {"name": name, "cur": vals[0], "cost": vals[1], "margin": vals[2],
               "yoy": vals[3], "cost_yoy": vals[4] if len(vals) > 4 else None,
               "margin_delta": vals[5] if len(vals) > 5 else None}
        # 该表不给上期金额，由同比反推（同比 ≤ -100% 无法反推）
        row["prev"] = (row["cur"] / (1 + row["yoy"] / 100)
                       if row["yoy"] is not None and row["yoy"] > -99.99 else None)
        return row
    return None


def _from_lines(lines, kind) -> list:
    """从页面文本行解析。

    只吃**名字与数字同行**的行 —— 正则已把这一形状钉死。标签被折行切开的报告
    （比亚迪形态）在这里匹配不上，交给 `_from_tables`（框线策略的标签是完整的）。
    刻意**不做跨行拼接**：实测那样会把表头文字（'营业收入比上'…）当成名字碎片
    拼进标签里，反而更脏。
    """
    rows, started = [], False
    pat = _MIX_ROW if kind == "mix" else _BIZ_ROW
    for raw in lines:
        line = (raw or "").strip()
        if not started:
            if not any(t in line for t in _TRIGGERS):
                continue
            started = True      # 触发词本身可能就是第一个分组标题，故不 continue
        if any(m in line for m in _STOP_MARKERS):
            break
        if line in _GROUP_TITLES:
            rows.append({"group": line})
            continue
        m = pat.match(line)
        if not m:
            continue
        g = m.groups()
        name = g[0].strip()
        if kind == "mix":
            rows.append({"name": name, "cur": _f(g[1]), "share": _f(g[2]),
                         "prev": _f(g[3]), "prev_share": _f(g[4]), "yoy": _f(g[5])})
        else:
            # 把「营收 / 成本 / 尾部（毛利率与各同比）」一起归一化 —— `_mk_row` 要的是
            # **整行**的 token 序列；只喂尾部会因为长度不够被判形状不符而整行丢弃。
            row = _mk_row(name, "biz", _tokens([g[1], g[2]] + g[3].split()))
            if row:
                rows.append(row)
    return rows


def _from_tables(page, kind) -> list:
    """从表格单元格解析（框线策略的标签完整，适合标签被折行的报告）。"""
    rows, best = [], None
    for settings in (None, {"vertical_strategy": "text", "horizontal_strategy": "text",
                            "snap_tolerance": 3, "join_tolerance": 3,
                            "min_words_vertical": 2, "text_x_tolerance": 1}):
        try:
            tables = page.extract_tables(table_settings=settings) or []
        except Exception:
            continue
        for t in tables:
            cand = []
            for raw in t:
                cells = [(str(c).replace("\n", "") if c is not None else "") for c in raw]
                cells = [c for c in cells if c.strip()]
                if not cells:
                    continue
                name = _name_of(cells)
                if not name:
                    continue
                if name in _GROUP_TITLES:
                    cand.append({"group": name})
                    continue
                row = _mk_row(name, kind, _tokens(cells[1:]))
                if row:
                    cand.append(row)
            if sum(1 for c in cand if "cur" in c) > sum(
                    1 for b in [best or []] for c in b if "cur" in c):
                best = cand
    return best or []


def _normalise(rows, kind, scale) -> dict:
    """统一结构：抽出合计行与分组；金额归一化成元。

    **没有分组标题时也要收**：上交所格式（茅台）的分组标题混在表头行里
    （`分行业 营业收入 营业成本 毛利率（%）`），不单独成行，故数据行前面
    可能没有任何 group 标记。早期版本在这种情况下把行**整批丢掉**，
    表现为"茅台找不到构成表"。
    """
    total, groups = None, []
    for r in rows:
        if "group" in r:
            groups.append({"name": r["group"], "rows": []})
            continue
        if scale != 1.0:
            for k in ("cur", "prev", "cost"):
                if r.get(k) is not None:
                    r[k] *= scale
        if r["name"].endswith("合计") and total is None:
            total = r
            continue
        if not groups:
            groups.append({"name": "分部", "rows": []})
        groups[-1]["rows"].append(r)
    groups = [g for g in groups if g["rows"]]
    if total is None and not groups:
        return {}
    return {"total": total, "groups": groups}


def extract_revenue_mix(pdf_path) -> "dict | None":
    """找「营业收入构成」/「主营业务分行业」表 → 分部数据（金额统一成**元**）。

    两种形态都试，取**行数多者**（互有盲区，见模块 docstring）。
    """
    try:
        with pdfplumber.open(str(pdf_path)) as pdf:
            for pno, page in enumerate(pdf.pages, 1):
                text = page.extract_text() or ""
                # 两种形状都试 —— 各家标题写法不同，别死认标题（见 _TRIGGERS）
                kinds = []
                if "营业收入构成" in text:
                    kinds = ["mix", "biz"]
                elif any(t in text for t in _TRIGGERS[1:]):
                    kinds = ["biz", "mix"]
                if not kinds:
                    continue
                unit_hit = _UNIT_RE.search(text)
                unit = unit_hit.group(1).replace(" ", "") if unit_hit else "元"
                scale = _UNIT_SCALES.get(unit, 1.0)
                cands = []
                for rank, kind in enumerate(kinds):
                    for parse in (_from_lines(text.split("\n"), kind),
                                  _from_tables(page, kind)):
                        c = _normalise(parse, kind, scale)
                        if c and sum(len(g["rows"]) for g in c["groups"]) >= 2:
                            c.update({"page": pno, "unit": unit, "kind": kind,
                                      "unit_scaled": scale != 1.0})
                            cands.append(c)
                if not cands:
                    continue
                # 选优顺序：**有合计行** > 标题所指形态 > 行数多
                return max(cands, key=lambda c: (
                    c.get("total") is not None,
                    kinds.index(c["kind"]) == 0,
                    sum(len(g["rows"]) for g in c["groups"])))
    except Exception:
        return None
    return None


def contributions(mix: dict, fallback_total: "dict | None" = None) -> list:
    """各分部对**总变动**的贡献度（%），按绝对变动额降序 —— 这就是"变动主要原因"。

    贡献度 = 该分部变动额 / 合计变动额。合计没变（分母为 0）则不给贡献度。

    上交所格式（茅台）的构成表**不含合计行**，故允许调用方用利润表的
    营业收入（本期/上期）兜底当分母 —— 否则整块归因都算不出来。
    """
    total = (mix or {}).get("total") or fallback_total
    groups = (mix or {}).get("groups") or []
    if not total or total.get("prev") is None or total.get("cur") is None:
        return []
    delta_total = total["cur"] - total["prev"]
    out = []
    for g in groups:
        for r in g["rows"]:
            if r.get("prev") is None:
                continue
            delta = r["cur"] - r["prev"]
            out.append({"group": g["name"], "name": r["name"], "cur": r["cur"],
                        "prev": r["prev"], "delta": delta,
                        "contrib": (delta / delta_total * 100) if delta_total else None,
                        "yoy": r.get("yoy"), "share": r.get("share"),
                        "margin": r.get("margin")})
    out.sort(key=lambda x: abs(x["delta"]), reverse=True)
    return out
