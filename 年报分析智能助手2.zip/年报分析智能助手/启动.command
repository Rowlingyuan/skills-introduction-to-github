#!/bin/bash
# 双击启动（macOS）。一个入口：选模式，环境设置收在菜单第三项里。
cd "$(dirname "$0")" || exit 1

echo "=== 年报分析助手 ==="

PIP_INDEX="${ARA_PIP_INDEX:-https://pypi.tuna.tsinghua.edu.cn/simple}"

PY=""
for c in python3.12 python3.11 python3.10 python3; do
  command -v "$c" >/dev/null 2>&1 && { PY="$c"; break; }
done

venv_ok() { [ -x ".venv/bin/python" ]; }

create_venv() {
  echo
  echo "[1/2] 创建全新环境（完全隔离）…"
  "${PY}" -m venv .venv || { echo "❌ 创建失败"; return 1; }
  .venv/bin/python -m pip install -q --upgrade pip >/dev/null 2>&1 || true
  echo "[2/2] 安装核心依赖（约 200 MB）：pip 会显示下载进度"
  .venv/bin/python -m pip install --progress-bar on -i "$PIP_INDEX" -r requirements.txt \
    || .venv/bin/python -m pip install --progress-bar on -r requirements.txt \
    || { echo "❌ 依赖安装失败"; return 1; }
  echo "✅ 就绪"
}

create_reuse() {
  echo
  echo "[1/2] 创建环境（复用本机已装依赖）…"
  "${PY}" -m venv --system-site-packages .venv || { echo "❌ 创建失败"; return 1; }
  echo "[2/2] 补装缺少的依赖（已满足的会跳过）"
  .venv/bin/python -m pip install --progress-bar on -i "$PIP_INDEX" -r requirements.txt \
    || .venv/bin/python -m pip install --progress-bar on -r requirements.txt \
    || { echo "❌ 依赖安装失败"; return 1; }
  echo "✅ 就绪（复用本机包，只补缺的部分）"
}

# 环境设置（只在选 [3] 或首次进入时触发）
setup_env() {
  if venv_ok; then
    echo
    echo "当前环境：.venv"
    echo "  [1] 保持不变（直接回车）"
    echo "  [2] 复用本机已装依赖（${PY}，不装到系统里）"
    echo "  [3] 删掉重建（全新）"
    echo
    read -r -p "请选择 1/2/3（直接回车 = 1）：" c
    case "${c}" in
      2) rm -rf .venv; create_reuse ;;
      3) rm -rf .venv; create_venv ;;
    esac
  else
    echo
    echo "还没有可用的运行环境，请选择安装方式："
    echo "  [1] 复用本机已装依赖       —— 快：本机已有的 numpy/pandas 直接拿来用"
    echo "  [2] 全新独立环境（推荐）  —— 慢一些，完全隔离"
    echo
    echo "  依赖从国内镜像下载：$PIP_INDEX"
    echo
    read -r -p "请选择 1/2（直接回车 = 2）：" c
    [ "${c}" = "1" ] && { create_reuse || create_venv; } || create_venv
  fi
}

launch() {
  case "${1}" in
    board) exec .venv/bin/python main.py serve ;;
    *)     exec .venv/bin/python main.py ;;
  esac
}

# ---------- 首次运行 / --setup：先配环境；否则直接进对话 ----------
WANT_SETUP=0
[ "${1:-}" = "--setup" ] && WANT_SETUP=1

if ! venv_ok || [ "$WANT_SETUP" = "1" ]; then
  [ -n "${PY}" ] || {
    echo "❌ 没找到 Python 3。请先安装：https://www.python.org/downloads/"
    read -r -p "按回车退出…" _; exit 1; }
  setup_env
  venv_ok || { read -r -p "环境未就绪，按回车退出…" _; exit 1; }
fi

# **启动就进对话**：看板是在对话里 /html 或报告生成后打开的，
# 不需要一开始就选"要看板还是对话"。
exec .venv/bin/python main.py
