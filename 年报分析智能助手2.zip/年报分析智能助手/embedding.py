"""Embedding 模型的**唯一加载入口**。

## 三件在这个文件里解决的事

1. **别去 HuggingFace 拉元数据**：`sentence-transformers` 默认每次都要联网查配置，
   网络一慢就卡在 `hf_hub_download → http_backoff` 里十几分钟没有输出。
   已经缓存的模型必须**纯本地加载**。

2. **国内下载慢**：默认走 **hf-mirror.com**（国内镜像，实测可达），
   想用官方源或自建镜像，设 `HF_ENDPOINT` 即可。

3. **别往 `~/.cache` 写**：macOS 上写用户主目录容易触发「授予文件夹访问权限」，
   对不熟悉电脑的用户是个坎。模型缓存统一放在**项目目录内**
   （`data/hf_cache`），删项目即删缓存，也不弹权限框。
"""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent

#: 模型缓存目录：项目内，避免 macOS 权限弹窗
HF_HOME = os.environ.get("HF_HOME") or str(ROOT / "data" / "hf_cache")

#: 下载源：默认国内镜像；官方源 = https://huggingface.co
HF_ENDPOINT = os.environ.get("HF_ENDPOINT") or "https://hf-mirror.com"


def _prepare_env() -> None:
    os.environ.setdefault("HF_HOME", HF_HOME)
    os.environ.setdefault("HF_ENDPOINT", HF_ENDPOINT)
    # 关掉遥测/进度条，避免刷屏
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")


def load_embedding_model(model_name: str):
    """加载模型：**先本地**，没有缓存才下载（默认走国内镜像）。"""
    _prepare_env()

    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as e:
        raise RuntimeError(
            "检索组件未安装（sentence-transformers）。\n"
            "  需要时执行：.venv/bin/pip install -r requirements-rag.txt\n"
            "  不需要则启动时选「4) 不用」。") from e

    # 1) 纯本地加载：已缓存的机器不该有任何网络请求
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    try:
        return SentenceTransformer(model_name, local_files_only=True)
    except Exception:                     # noqa: BLE001
        pass

    # 2) 需要下载 → 放开离线限制
    os.environ.pop("HF_HUB_OFFLINE", None)
    os.environ.pop("TRANSFORMERS_OFFLINE", None)

    print(f"⬇️ 正在下载模型 {model_name}")
    print(f"   源：{HF_ENDPOINT}（国内镜像；换源设 HF_ENDPOINT）")
    print(f"   缓存：{HF_HOME}")
    print("   首次较慢，之后不再下载。")

    try:
        return SentenceTransformer(model_name)
    except Exception as e:                # noqa: BLE001
        # 3) 镜像挂了就退回官方源再试一次（人在国外时镜像反而可能慢）
        if os.environ.get("HF_ENDPOINT") != "https://huggingface.co":
            print(f"⚠️ 镜像下载失败（{type(e).__name__}），改用官方源重试…")
            os.environ["HF_ENDPOINT"] = "https://huggingface.co"
            return SentenceTransformer(model_name)
        raise
