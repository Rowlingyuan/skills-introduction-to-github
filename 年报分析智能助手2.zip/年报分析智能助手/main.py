#!/usr/bin/env python3
"""年报分析助手 CLI。

只做参数解析与流程编排，业务逻辑分别在 agent / parser / downloader / indexer。
旧的 V0 链路保留在 `main-v1.py` 作为历史参考。

**模块级只 import 轻量模块**（argparse / models）：重依赖（chromadb、
sentence-transformers、openai）一律在函数内惰性导入，否则 `import main`
会拉起整条链路，测试被迫等待数十秒。
"""
import argparse
import os
import sys
from pathlib import Path

def _pip_install(py: str, args: list, project: Path, title: str,
                 size_hint: str = "") -> int:
    """跑 pip 并**显示进度**，返回退出码。

    为什么不上 `-q`：实测用户卡在"正在安装（几分钟）…"这行字上，
    屏幕几分钟不动，以为程序死了。pip 自己的下载进度条能给出明确反馈。
    """
    import subprocess
    import time

    print(f"   {title}{('（' + size_hint + '）') if size_hint else ''}")
    print("   pip 会显示下载与安装进度；包多时会有几段停顿，属正常。", flush=True)
    t0 = time.time()
    rc = subprocess.call([py, "-m", "pip", "install",
                          "--progress-bar", "on", *args], cwd=project)
    took = time.time() - t0
    print(f"   {'✅ 完成' if rc == 0 else '❌ 失败'}（{took:.0f} 秒）", flush=True)
    return rc


def _offer_install(project: Path) -> bool:
    """交互式安装依赖：让用户选「装到本机」还是「新建环境」。

    返回 True 表示已经换到新解释器（`os.execv`），调用方不必再往下走。
    只有在终端里（isatty）才提问 —— 管道/脚本场景仍走下面的手动指引。
    """
    import subprocess

    index = os.environ.get("ARA_PIP_INDEX") or \
        "https://pypi.tuna.tsinghua.edu.cn/simple"

    if not sys.stdin.isatty():
        return False

    print("请选择安装方式（依赖约 200 MB，从国内镜像下载）：\n")
    print("  [1] 复用本机已装依赖       —— 快：本机已有的 numpy/pandas 直接拿来用")
    print("  [2] 全新独立环境（推荐）  —— 慢一些，完全隔离\n")
    print("  （选 1 会建一个 --system-site-packages 环境：能看见本机包，但不往系统里装东西。")
    print("   很多 Python 是 externally-managed，直接装包会被 PEP 668 拒绝。）\n")
    try:
        choice = input("请选择 1/2（直接回车 = 2）：").strip() or "2"
    except (EOFError, KeyboardInterrupt):
        return False

    if choice in ("1", "2"):
        reuse = choice == "1"
        print(f"\n[1/2] 创建环境{'(复用本机已装依赖)' if reuse else '（完全隔离）'}…",
              flush=True)
        venv = project / ".venv"
        venv_args = ["-m", "venv"] + (["--system-site-packages"] if reuse else [])
        subprocess.call([sys.executable, *venv_args, str(venv)], cwd=project)
        py = venv / "bin" / "python"
        if not py.exists():
            py = venv / "Scripts" / "python.exe"
        if py.exists():
            subprocess.call([str(py), "-m", "pip", "install", "-q",
                             "--upgrade", "pip"])
            rc = _pip_install(str(py), ["-i", index, "-r", "requirements.txt"],
                              project,
                              "[2/2] 补装缺少的依赖" if reuse else "[2/2] 安装核心依赖",
                              "约 200 MB" if not reuse else "已满足的会跳过")
            if rc == 0:
                os.environ["ARA_REEXEC"] = "1"
                os.execv(str(py), [str(py), str(project / "main.py"),
                                   *sys.argv[1:]])
        print("❌ 环境准备失败，请手动执行下面的命令。\n")
    return False


def _ensure_venv() -> None:
    """**用错解释器时自动切到项目 venv**。

    项目依赖（pdfplumber / chromadb / sentence-transformers…）都装在 `.venv` 里。
    用户很自然会敲 `python main.py`（系统 Python / conda base），于是第一条
    要解析 PDF 的命令就报 `No module named 'pdfplumber'` —— 实测他就是这样
    撞上的，并因此以为"库里没有的公司分析不了"。

    这里做两件事：依赖齐全就照常跑；不齐且存在 `.venv`，就地 `execv` 换过去。
    用环境变量防止无限递归。
    """
    if os.environ.get("ARA_REEXEC") == "1":
        return
    try:
        import pdfplumber  # noqa: F401  —— 只探一个代表
        return
    except ImportError:
        pass

    venv_py = Path(__file__).resolve().parent / ".venv" / "bin" / "python"
    if venv_py.exists() and Path(sys.executable).resolve() != venv_py.resolve():
        os.environ["ARA_REEXEC"] = "1"
        os.execv(str(venv_py),
                 [str(venv_py), str(Path(__file__).resolve()), *sys.argv[1:]])
        return

    # **依赖不全且没有 .venv** —— 直接给可执行的指引并退出。
    # 如果不在这里拦，报错会发生在"正在分析…"之后，用户看到的是 traceback，
    # 完全不知道是自己用了系统 Python（实测试用者就是这样撞上的）。
    print("缺少运行依赖：pdfplumber 等没有安装。"
          "（当前用的是系统 Python，不是项目环境）\n")

    if _offer_install(Path(__file__).resolve().parent):
        return

    print("请先装依赖，再启动（二选一）：\n")
    print("  方式一：全新独立环境（推荐，完全隔离）")
    print("    python3 -m venv .venv")
    print("    .venv/bin/pip install -i https://pypi.tuna.tsinghua.edu.cn/simple "
          "-r requirements.txt\n")
    print("  方式二：复用本机已装依赖（快；不往系统里装东西）")
    print("    python3 -m venv --system-site-packages .venv")
    print("    .venv/bin/pip install -i https://pypi.tuna.tsinghua.edu.cn/simple "
          "-r requirements.txt\n")
    print("更省事的办法：双击 启动.command / 启动.bat，它会引导你选。")
    sys.exit(2)

# **在导入任何业务模块之前**先确保依赖齐全 —— 否则报错会出现在
# "正在分析…"之后，用户只看到 traceback，不知道是自己用错了 Python。
_ensure_venv()

from models import ReportKey




DEFAULT_DB = "data/structured.db"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="main.py", description="年报分析助手")
    sub = p.add_subparsers(dest="command", required=True)

    chat = sub.add_parser("chat", help="进入对话模式（跑一次，一直聊）")
    chat.add_argument("--db", default=DEFAULT_DB)

    ask = sub.add_parser("ask", help="提问（也能直接说『把某某公司某年报分析一下』）")
    ask.add_argument("question")
    ask.add_argument("--db", default=DEFAULT_DB)

    rep = sub.add_parser("report", help="生成某份报告的结构化分析")
    rep.add_argument("company")
    rep.add_argument("report_type",
                     choices=["年报", "半年报", "一季报", "三季报"])
    rep.add_argument("period", help='如 2025 或 2025Q1')
    rep.add_argument("--db", default=DEFAULT_DB)
    rep.add_argument("--narrative", action="store_true",
                     help="并附年报原文对变动原因的归纳（需检索 + 大模型，约 1 分钟）")

    ls = sub.add_parser("list", help="列出库里已入库的报告")
    ls.add_argument("--db", default=DEFAULT_DB)

    val = sub.add_parser("validate",
                         help="用 AkShare 的外部真值校验库里抽到的数字")
    val.add_argument("--company", default=None, help="只校验这家公司；缺省校验全库")
    val.add_argument("--db", default=DEFAULT_DB)
    val.add_argument("--detail", action="store_true",
                     help="逐项列出不一致 / 漏抽的科目")

    sv = sub.add_parser("serve", help="起本地看板服务（数据实时，127.0.0.1）")
    sv.add_argument("--port", type=int, default=8765)
    sv.add_argument("--db", default=DEFAULT_DB)
    sv.add_argument("--no-open", action="store_true", help="不自动打开浏览器")

    ht = sub.add_parser("html", help="生成 HTML 数据看板（单文件，双击即开）")
    ht.add_argument("--company", nargs="*", default=None,
                    help="只导出这几家；缺省导出全库")
    ht.add_argument("-o", "--output", default=None)
    ht.add_argument("--db", default=DEFAULT_DB)

    ing = sub.add_parser("ingest", help="下载 → 解析 → 入库 → 建索引")
    ing.add_argument("keyword", help="公司简称/全名；给了 --pdf 则视为全名")
    ing.add_argument("report_type",
                     choices=["年报", "半年报", "一季报", "三季报"])
    ing.add_argument("start")
    ing.add_argument("end")
    ing.add_argument("--db", default=DEFAULT_DB)
    ing.add_argument("--pdf", default=None,
                     help="改用本地 PDF，跳过下载与联网公司名规范化")
    ing.add_argument("--unit", default="元",
                     choices=sorted(UNIT_SCALES),
                     help="该报表财报数字的单位，入库时统一归一化成元（默认元）")
    ing.add_argument("--reindex", action="store_true",
                     help="先清除该公司旧索引再重建")
    return p


#: 财报单位 → 归一化成「元」的换算系数。
#: **必须显式声明**：单位声明未必写在报表页上（实测比亚迪写在附注里），
#: 不做启发式猜测；猜错会带来 1000 倍误差，且会计恒等式自检查不出来（两边同倍缩放）。
UNIT_SCALES = {"元": 1.0, "千元": 1000.0, "万元": 10000.0}


#: 报告类型 → `ReportKey.period` 的季度后缀。
#: **季报必须带季度**，否则 Task 2 的季度期间标签永远不会触发，
#: 季报的三个月数据会重新掉回与全年混用的状态（Ruling 15）。
#: 半年报没有对应形态（`models.py:11` 只定义了 "2025" 与 "2025Q1"），
#: 故留空 —— 它与年报在库里靠 report_type 区分，回答时会声明口径。
_PERIOD_SUFFIX = {"一季报": "Q1", "三季报": "Q3"}


def _report_key(keyword: str, report_type: str, start: str,
                resolve: bool = True) -> ReportKey:
    """构造 `ReportKey`。

    `resolve=True`（默认，下载路径）：用巨潮 API 把简称/别名规范成公司全名与代码。
    `resolve=False`（本地 `--pdf` 路径）：`keyword` 即公司全名，代码留空 ——
    本地回灌**不该依赖网络**（离线环境会直接失败），且 `code` 只是元数据，
    查询链路（`storage.load_metrics`）根本不读它。
    """
    if resolve:
        from downloader import resolve_org
        code, _, name = resolve_org(keyword)
    else:
        code, name = "", keyword
    period = start[:4] + _PERIOD_SUFFIX.get(report_type, "")
    return ReportKey(name, code, report_type, period)


def _cmd_chat(args) -> int:
    from chat import run_repl
    return run_repl(args.db)


def _cmd_ask(args) -> int:
    from agent import answer
    res = answer(args.question, args.db)
    print(res["answer"])
    if res["citations"]:
        print("\n出处：")
        for c in res["citations"]:
            print(f"  第{c['page']}页（相关度 {c['relevance']}）")
    return 0


def _cmd_ingest(args) -> int:
    from parser import parse

    if args.pdf:
        pdf = args.pdf
        print(f"📄 使用本地文件: {pdf}")
    else:
        from downloader import fetch
        pdf = fetch(args.keyword, args.report_type, args.start, args.end)
        print(f"✅ 已下载: {pdf}")

    key = _report_key(args.keyword, args.report_type, args.start,
                      resolve=not args.pdf)
    # parse 在传 db_path 时会自行 init_db + save_result，此处不重复落库。
    res = parse(pdf, key, verify=True, db_path=args.db,
                unit_scale=UNIT_SCALES[args.unit])
    print(f"📊 已入库 {len(res.metrics)} 个指标（{args.db}，"
          f"单位 {args.unit} → 元）")

    from indexer import ReportIndexer
    from text_extractor import extract_chunks
    idx = ReportIndexer()
    if args.reindex:
        idx.clear_company(key.company)
    n = idx.index_report(key.company, key.period, extract_chunks(pdf))
    print(f"🔍 已索引 {n} 个文本块")

    # 新公司进库后刷新 HTML 看板，否则看板里看不到它
    from report_html import refresh_quietly
    out = refresh_quietly(args.db)
    if out:
        print(f"📊 已刷新数据看板：{out}")
    return 0


def _cmd_report(args) -> int:
    from analysis import build_analysis, render_text
    a = build_analysis(args.company, args.report_type, args.period, args.db)
    print(render_text(a))
    if args.narrative and a.get("ok"):
        from agent import _narrative_block
        block = _narrative_block(
            {"company": args.company, "report_type": args.report_type,
             "period": args.period}, a, args.db)
        print(block["text"])
    return 0


def _cmd_list(args) -> int:
    from analysis import available_reports
    rows = available_reports(args.db)
    if not rows:
        print(f"（{args.db} 里还没有报告）")
        return 0
    print(f"{'公司':<12}{'类型':<8}期间")
    for r in rows:
        print(f"{r['company']:<12}{r['report_type']:<8}{r['period']}")
    print(f"\n共 {len(rows)} 份")
    return 0


def _fmt_val(metric: str, v) -> str:
    """体检表里的数值格式：金额压成「亿元」，每股收益按「元」（它不是金额）。"""
    from validator import NON_MONEY_METRICS
    if v is None:
        return "—"
    if metric in NON_MONEY_METRICS:
        return f"{v:,.2f} 元"
    return f"{v / 1e8:,.2f} 亿"


def _cmd_serve(args) -> int:
    """本地看板服务：数据实时，不落盘。"""
    from serve import serve
    return serve(port=args.port, db_path=args.db,
                 open_browser=not args.no_open)


def _cmd_html(args) -> int:
    """生成自包含的 HTML 看板（选公司 / 选指标 / 看趋势）。"""
    from report_html import build_html
    from terminal_link import link, open_path

    first = (args.company or [None])[0]
    out = build_html(db_path=args.db, companies=args.company,
                     out_path=args.output, default_company=first)
    print(f"📊 看板已生成：{link(out)}")
    print("   双击这个文件即可打开：可选公司、勾选指标、看多年趋势（不联网）")
    if getattr(args, "open", False):
        open_path(out)
    return 0


def _cmd_validate(args) -> int:
    """外部真值体检表。**只报告，不改库** —— 差异并排列出，由人判断口径。"""
    import validator as v

    try:
        code_map = v.load_code_map()
    except Exception as e:
        print(f"取公司代码表失败（需要联网）：{e}")
        return 1

    targets = [r for r in v.available_reports(args.db)
               if args.company is None or r[0] == args.company]
    if not targets:
        print("（没有可校验的报告）")
        return 1

    total = {"ok": 0, "mismatch": 0, "restated": 0, "reclassified": 0,
             "missing_ours": 0}
    bad_reports = 0
    print(f"{'公司':<10}{'类型':<7}{'期间':<8}{'一致':>5}{'不符':>5}{'口径':>5}{'漏抽':>5}")
    for company, report_type, period in targets:
        res = v.validate_report(company, report_type, period, args.db,
                               code_map=code_map)
        if not res.get("ok"):
            print(f"{company:<10}{report_type:<7}{period:<8}  ⚠️ {res['error']}")
            bad_reports += 1
            continue
        s = res["summary"]
        for k in total:
            total[k] += s.get(k, 0)
        soft = s["restated"] + s["reclassified"]
        mark = "  " if s["mismatch"] == 0 else " ❌"
        print(f"{company:<10}{report_type:<7}{period:<8}"
              f"{s['ok']:>5}{s['mismatch']:>5}{soft:>5}{s['missing_ours']:>5}{mark}")
        if args.detail:
            for r in res["rows"]:
                if r["status"] == "ok":
                    continue
                flag = {"mismatch": "❌ 不符",
                        "restated": "≈ 重述",
                        "reclassified": "≈ 重分类",
                        "missing_ours": "◻︎ 漏抽",
                        "missing_theirs": "◻︎ 外部缺"}[r["status"]]
                page = f" | 第{r['page']}页" if r["page"] else ""
                note = f"  {r['note']}" if r.get("note") else ""
                print(f"    {flag:<9} {r['statement']} {r['metric']:<14}"
                      f" 我们 {_fmt_val(r['metric'], r['ours']):>12}"
                      f" | AkShare {_fmt_val(r['metric'], r['theirs']):>12}"
                      f"{page}{note}")

    checked = (total["ok"] + total["mismatch"] + total["restated"]
               + total["reclassified"])
    acc = f"{total['ok'] / checked * 100:.1f}%" if checked else "—"
    soft = total["restated"] + total["reclassified"]
    explained = f"{(total['ok'] + soft) / checked * 100:.1f}%" if checked else "—"
    print(f"\n合计：比对 {checked} 项 —— 一致 {total['ok']}，不符 {total['mismatch']}，"
          f"口径差异 {soft}（重述 {total['restated']} / 重分类 {total['reclassified']}），"
          f"漏抽 {total['missing_ours']}")
    print(f"      严格一致率 {acc}；把口径差异算作可解释后 {explained}")
    if bad_reports:
        print(f"⚠️ {bad_reports} 份报告取不到外部真值，未计入")
    return 0 if total["mismatch"] == 0 else 2


#: 检索模型档位：编号 → (设置值, 名称, 体积, 能用什么 / 不能用什么)
_RAG_CHOICES = {
    "1": ("small", "小  bge-small-zh", "约 100 MB",
          ["问年报原文：常见问法够用"],
          []),
    "2": ("base", "中  bge-base-zh", "约 400 MB",
          ["问年报原文：比小号更准一些"],
          []),
    "3": ("m3", "大  bge-m3", "约 2.2 GB",
          ["问年报原文：最准；中英文混排、长句、专业表述都稳"],
          []),
    "4": ("none", "不用（关闭向量检索）", "不下载",
          ["查具体数字（营业收入、净利润…）",
           "三大报表分析 + Word 报告",
           "附注要点（审计意见/存货/账龄/客户/商誉）"],
          ["问「年报里怎么解释这个变动」这类开放问题",
           "问「收入确认政策是什么」这类原文内容"]),
}

#: 首次下载的**预计时间**（按 2 MB/s 的保守网速估）
_RAG_ETA = {"1": "约 1 分钟", "2": "约 3~4 分钟", "3": "约 15~20 分钟", "4": "无需下载"}

#: 四种选择都**一定**能用的功能 —— 避免用户以为选了"不用"就废了
_ALWAYS_AVAILABLE = "查数字 · 三大报表分析 · 附注要点 · 生成 Word 报告（这四项与模型无关）"


def _model_status() -> str:
    """当前用的检索模型（一句话），用于启动时显示。"""
    import os

    from settings import get

    from config import EMBEDDING_MODEL, ENABLE_RAG

    if not ENABLE_RAG:
        return "检索模型：不用（已关闭向量检索）—— 查数字/分析/出报告照常，问原文不可用"
    if os.environ.get("EMBEDDING_MODEL"):
        src = "环境变量"
    elif get("embedding_model"):
        src = "上次的选择"
    else:
        src = "默认"
    short = {"BAAI/bge-small-zh-v1.5": "小", "BAAI/bge-base-zh-v1.5": "中",
             "BAAI/bge-m3": "大"}.get(EMBEDDING_MODEL, EMBEDDING_MODEL)
    return f"检索模型：{short}（{EMBEDDING_MODEL}，来自{src}）；输入 /model 可更换"


def _rag_deps_installed() -> bool:
    try:
        import sentence_transformers  # noqa: F401
        import chromadb              # noqa: F401
        return True
    except Exception:                # noqa: BLE001
        return False


def ensure_rag_deps(interactive: bool = True) -> None:
    """选了模型但没装检索组件时，**当场告诉用户怎么装**（约 1.5 GB，别偷偷装）。

    设计取舍：核心依赖只有约 200 MB，装了就能查数字、出报告；
    检索组件 1.5 GB（主要是 torch），只在真的要「问原文」时才需要。
    所以不在安装脚本里预装，而是等用户选了模型再问一次。
    """
    if _rag_deps_installed():
        return

    print("\n⚠️ 还需要安装「检索组件」（约 1.5 GB，主要是 torch）才能用这个模型。")
    print("   现在不装也能用：查数字、三大报表分析、附注要点、Word 报告。")
    print("   装的话视网速约 3~15 分钟，过程中会显示下载进度，不会卡住不报错。\n")
    cmd = ".venv/bin/pip install -r requirements-rag.txt"
    if not interactive or not __import__("sys").stdin.isatty():
        print(f"   需要时手动装：{cmd}\n")
        return
    try:
        ans = input("   现在安装吗？(y/N)：").strip().lower()
    except (EOFError, KeyboardInterrupt):
        ans = ""
    if ans not in ("y", "yes", "是"):
        print(f"   好，先跳过。以后要装：{cmd}\n")
        return

    import subprocess
    import sys
    from pathlib import Path

    pip = Path(sys.executable).parent / "pip"
    print("   [1/1] 安装检索组件（约 1.5 GB）…", flush=True)
    rc = subprocess.call([str(pip), "install", "--progress-bar", "on",
                          "-r", "requirements-rag.txt"])
    print("   ✅ 安装完成" if rc == 0 else "   ❌ 安装失败，请稍后手动执行上面的命令")
    print()


def ask_embedding_model(force: bool = False) -> None:
    """问一次「要哪个检索模型」，并把选择记进 `data/settings.json`。

    - 首次运行（没有记录、也没有环境变量）→ 自动问
    - `/model` 命令（force=True）→ 随时重选
    - 非交互（脚本/管道）→ 不问，用当前设置
    """
    import os
    import sys

    from settings import get

    if not force:
        if os.environ.get("EMBEDDING_MODEL"):   # 显式指定过 → 尊重它
            return
        if get("embedding_model"):              # 选过了
            return
        if not sys.stdin.isatty():              # 非交互 → 用默认
            return

    print("\n请选择「问年报原文」用的检索模型。")
    print("模型下载到本地运行，年报内容不会上传。\n")

    for key, (_v, name, size, can, cannot) in _RAG_CHOICES.items():
        eta = _RAG_ETA.get(key, "")
        print(f"  {key}) {name}　{size}　首次下载 {eta}")
        for item in can:
            print(f"        ✅ {item}")
        for item in cannot:
            # "首次下载要几分钟"是**代价**不是"不支持"，别用 ❌ 让用户以为缺功能
            mark = "⚠️" if item.startswith(("首次", "需要")) else "❌"
            print(f"        {mark} {item}")
        print()

    print(f"  —— 无论选哪个，这四项都能用：{_ALWAYS_AVAILABLE}")
    print("  —— 模型从国内镜像 hf-mirror.com 下载，缓存在项目内 data/hf_cache\n")
    print("  直接回车 = 3（大模型，效果最好）\n")

    try:
        choice = input("请输入 1-4：").strip() or "3"
    except (EOFError, KeyboardInterrupt):
        return
    value = _RAG_CHOICES.get(choice, ("m3",))[0]

    from settings import set_value
    set_value("embedding_model", value)
    picked = _RAG_CHOICES.get(choice, ("m3", "大  bge-m3"))[1]
    print(f"✅ 已选择：{picked}")
    print("   如需换个档位：再输入 /model，或改 data/settings.json。")
    if value != "none":
        ensure_rag_deps(interactive=True)
    else:
        print("   （不下载模型；查数字/分析/出报告照常）\n")


def main(argv=None) -> int:
    _ensure_venv()          # 必须在任何重依赖导入之前
    argv = list(sys.argv[1:] if argv is None else argv)
    # **不带参数 = 进对话模式**：`python main.py` 是最自然的入口，
    # 不该报 "the following arguments are required: command"。
    if not argv:
        argv = ["chat"]
    args = build_parser().parse_args(argv)
    if args.command in ("chat", "ask", "ingest"):
        ask_embedding_model()
    return {"chat": _cmd_chat, "ask": _cmd_ask, "ingest": _cmd_ingest,
            "report": _cmd_report, "list": _cmd_list,
            "validate": _cmd_validate, "html": _cmd_html,
            "serve": _cmd_serve}[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
