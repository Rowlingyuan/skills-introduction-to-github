"""全局数据结构定义。仅含数据，不含业务逻辑。"""
from dataclasses import dataclass, field

CONFIDENCE_LEVELS = ("high", "medium", "low", "conflict")


@dataclass(frozen=True)
class ReportKey:
    company: str
    code: str
    report_type: str   # 年报 / 半年报 / 一季报 / 三季报
    period: str        # "2025" 或 "2025Q1"


@dataclass(frozen=True)
class Announcement:
    title: str
    url: str
    pub_date: str


@dataclass
class ParsedTable:
    page: int
    rows: list
    strategy: str      # "default" | "text"
    score: float = 0.0


@dataclass
class MetricValue:
    name: str
    period: str
    value: float
    source_page: int
    confidence: str
    statement: str = "利润表"   # 利润表 / 资产负债表 / 现金流量表

    def __post_init__(self):
        if self.confidence not in CONFIDENCE_LEVELS:
            raise ValueError(
                f"非法 confidence: {self.confidence}，可选 {CONFIDENCE_LEVELS}"
            )


@dataclass
class VerifyOutcome:
    is_correct: bool
    corrections: dict = field(default_factory=dict)
    explanation: str = ""


@dataclass
class ParseResult:
    key: ReportKey
    file_path: str
    sections: dict = field(default_factory=dict)
    metrics: list = field(default_factory=list)
    unit: str = "元"      # 报表声明的金额单位（已按它归一化到元）；读不到时为「元」
