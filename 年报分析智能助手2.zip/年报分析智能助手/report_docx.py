"""把 `analysis.build_analysis` 的结果渲染成 Word 财务分析报告。

**这是智能体的能力，不是一个独立脚本**：`agent.build_report()` 直接调
`report_docx.save()` 生成文件；`make_report_docx.py` 只是留给命令行的薄壳。

设计原则：**数字全部来自传入的 analysis dict**（它来自 SQLite，带页码），
这个模块只负责组织段落、判断该说什么话、排版。任何一处都不自己算数。
"""

import json
import re
import sys
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parent
DEFAULT_DB = ROOT / "data" / "structured.db"

BODY_FONT = "宋体"
HEAD_FONT = "黑体"
ACCENT = RGBColor(0x1F, 0x3B, 0x63)
GREY = RGBColor(0x59, 0x59, 0x59)


# ---------------------------------------------------------------- 数值格式

def yi(v) -> str:
    """元 → 亿元字符串。"""
    return "—" if v is None else f"{v / 1e8:,.2f}"


def pct(v, digit=2) -> str:
    return "—" if v is None else f"{v:.{digit}f}%"


def signed(v, digit=2) -> str:
    return "—" if v is None else f"{v:+.{digit}f}%"


def num(v, digit=2) -> str:
    return "—" if v is None else f"{v:,.{digit}f}"


def yoy_phrase(v, *, base: str = "上年") -> str:
    """同比 → 「比上年增长 20.29%」。**正文不用括号套数字**。"""
    if v is None:
        return f"与{base}不可比"
    return f"比{base}{'增长' if v >= 0 else '下降'} {abs(v):.2f}%"


def pp_phrase(v) -> str:
    """百分点 → 「上升 2.26 个百分点」。"""
    if v is None:
        return "变化不可比"
    return f"{'上升' if v >= 0 else '下降'} {abs(v):.2f} 个百分点"


def pp(v, digit=2) -> str:
    """百分点：`+0.84 pp`。**不能复用 signed()** —— 那个会补一个 %，
    拼出来是 `+0.84% pp`，单位叠了两层。"""
    return "—" if v is None else f"{v:+.{digit}f} pp"


#: 不是金额的科目 —— 按「元」打印，不压成亿元（每股收益 5.20 元 ≠ 0.00 亿元）
NON_MONEY_LABELS = {"基本每股收益"}


def cell_value(label: str, v) -> str:
    """表格单元格里的指标值：金额走亿元，每股收益走元。"""
    if v is None:
        return "—"
    if label in NON_MONEY_LABELS:
        return f"{v:,.2f} 元"
    return yi(v)


# ---------------------------------------------------------------- docx 底层

def set_cell_shading(cell, hex_color: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tc_pr.append(shd)


def set_run(run, size=10.5, bold=False, font=BODY_FONT, color=None):
    run.font.name = font
    run.font.size = Pt(size)
    run.bold = bold
    if color is not None:
        run.font.color.rgb = color
    # 中文字形必须显式给 eastAsia，否则 Word 会退回默认字体
    run._element.rPr.rFonts.set(qn("w:eastAsia"), font)


def style_document(doc):
    normal = doc.styles["Normal"]
    normal.font.name = BODY_FONT
    normal.font.size = Pt(10.5)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.25

    for name, size in (("Heading 1", 15), ("Heading 2", 12.5), ("Heading 3", 11)):
        st = doc.styles[name]
        st.font.name = HEAD_FONT
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = ACCENT
        st.element.rPr.rFonts.set(qn("w:eastAsia"), HEAD_FONT)
        st.paragraph_format.space_before = Pt(14 if size == 15 else 10)
        st.paragraph_format.space_after = Pt(6)

    sec = doc.sections[0]
    sec.top_margin = Cm(2.4)
    sec.bottom_margin = Cm(2.2)
    sec.left_margin = Cm(2.6)
    sec.right_margin = Cm(2.4)


def add_page_number(paragraph):
    run = paragraph.add_run()
    for instr in ("PAGE",):
        fld = OxmlElement("w:fldSimple")
        fld.set(qn("w:instr"), instr)
        run._element.addnext(fld)


def add_rich(p, text, *, bold=False, **fmt):
    """把 `**强调**` 渲染成真正的粗体。

    Word 不认 markdown —— 直接把 `**` 写进 run，读者看到的是星号（实测报告里
    出现了 "**很可能没有抽全**" 这种字面量）。这里按 `**` 切分，奇数段加粗。
    """
    parts = str(text).split("**")
    for i, seg in enumerate(parts):
        if not seg:
            continue
        r = p.add_run(seg)
        set_run(r, bold=bold or (i % 2 == 1), **fmt)


def para(doc, text, *, size=10.5, bold=False, color=None, align=None,
         space_after=4, indent=True, font=BODY_FONT):
    p = doc.add_paragraph()
    if align is not None:
        p.alignment = align
    if indent:
        p.paragraph_format.first_line_indent = Pt(size * 2)
    p.paragraph_format.space_after = Pt(space_after)
    add_rich(p, text, size=size, bold=bold, font=font, color=color)
    return p


def bullet(doc, text, *, size=10.5):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.left_indent = Pt(size * 1.6)
    add_rich(p, text, size=size)
    return p


_TABLE_NO = {"n": 0}
_FIG_NO = {"n": 0}


#: 结构化数据源的标记（`source_page=0`）—— 它没有页码，不能写"第 0 页"
STRUCTURED_PAGE_LABEL = "结构化接口"


def page_text(page) -> str:
    """页码字符串：PDF 抽取给"第 N 页"，结构化接口给"结构化接口"。"""
    if not page:
        return STRUCTURED_PAGE_LABEL
    return f"第 {page} 页"


def caption_auto(doc, title):
    """表号自动递增。**别再手写编号** —— 手写必然漏号
    （这份报告曾出现 表 2 → 表 5 → 表 10 的断号，因为中途删过小节）。"""
    _TABLE_NO["n"] += 1
    caption(doc, "表 %d  %s" % (_TABLE_NO["n"], title))


def caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text)
    set_run(r, size=9, bold=True, font=HEAD_FONT, color=ACCENT)


def note(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(8)
    add_rich(p, text, size=8.5, color=GREY)


def table(doc, headers, rows, widths=None, *, align_right_from=1,
          header_fill="1F3B63", zebra=True):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    # **必须关掉 autofit**，否则 Word 会按内容重算列宽，下面设的 widths 全部失效
    t.autofit = False

    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.space_before = Pt(2)
        r = p.add_run(h)
        set_run(r, size=9, bold=True, font=HEAD_FONT,
                color=RGBColor(0xFF, 0xFF, 0xFF))
        set_cell_shading(hdr[i], header_fill)

    # 跨页时重复表头，否则续表会脱离列名，读不出哪个数是哪一列
    tr_pr = t.rows[0]._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)

    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for ci, val in enumerate(row):
            cells[ci].text = ""
            p = cells[ci].paragraphs[0]
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.space_before = Pt(1)
            p.alignment = (WD_ALIGN_PARAGRAPH.RIGHT if ci >= align_right_from
                           else WD_ALIGN_PARAGRAPH.LEFT)
            r = p.add_run(str(val))
            set_run(r, size=9)
            if zebra and ri % 2 == 1:
                set_cell_shading(cells[ci], "F2F5F9")

    if widths:
        for i, w in enumerate(widths[:len(t.columns)]):
            t.columns[i].width = Cm(w)
            for cell in t.columns[i].cells:
                cell.width = Cm(w)
    return t


def _liquidity_word(ratio: dict) -> str:
    """流动比率的定性描述。1.5 倍以上视为充裕，1 倍以下提示短期压力。"""
    cur, prev = ratio.get("cur"), ratio.get("prev")
    if cur is None:
        return "流动比率无法计算"
    direction = "上升" if (prev is not None and cur > prev) else (
        "下降" if (prev is not None and cur < prev) else "持平")
    if cur >= 1.5:
        return (f"短期偿债能力{direction}，但整体仍处充裕区间"
                if direction == "下降" else f"短期偿债能力{direction}，处于充裕区间")
    if cur >= 1:
        return f"短期偿债能力{direction}，仍可覆盖流动负债"
    return f"短期偿债能力{direction}，流动比率低于 1 倍，短期压力值得关注"


#: 分项合计占营业收入多少，才算"这张构成表是全的"。
#: 低于它就**不允许**下"变动最大的分部是 X"这种结论 —— 实测华工科技的分产品表
#: 只覆盖 25% 收入（只剩一行），却照样写出"激光加工装备…是变动最大的分部（+5.5%）"，
#: 而同一页分行业表里另一项占 +85.7%，报告自己打自己脸。
_GROUP_COVERAGE_MIN = 0.6


def _group_coverage(group, revenue) -> float:
    if not revenue:
        return 0.0
    total = sum(c.get("cur") or 0 for c in group.get("rows") or [])
    return total / revenue if revenue else 0.0


def _top_contributor(mix, revenue=None):
    """「对总变动贡献最大」的分部，**只在数据完整时才给结论**。

    返回 (row, coverage, group_name)；没有可信结论时 row 为 None。
    优先「分产品」组，但**必须**该组分项合计≥营业收入的 60%，否则换一组，
    全都不够就返回 None —— 宁可不说，也不套模板句式。
    """
    if not mix:
        return None, 0.0, None
    groups = mix.get("groups") or []
    if not groups:
        return None, 0.0, None
    best = (None, 0.0, None)
    for g in groups:
        cov = _group_coverage(g, revenue)
        rows = [c for c in g.get("rows") or [] if c.get("contrib") is not None]
        if not rows:
            continue
        if cov > best[1]:
            best = (None, cov, g.get("name"))
        if cov >= _GROUP_COVERAGE_MIN:
            top = max(rows, key=lambda c: abs(c["contrib"]))
            if best[0] is None or abs(top["contrib"]) > abs(best[0]["contrib"]):
                best = (top, cov, g.get("name"))
    return best


class _NoneRow(dict):
    """缺科目时的占位行：取任何字段都返回 None，**不抛 KeyError**。"""

    def __getitem__(self, k):
        return None

    def get(self, k, default=None):
        return None


class _RowMap(dict):
    """{指标名: 行}。**访问不存在的指标返回 _NoneRow**。

    券商没有「营业成本/流动资产合计/销售费用」，银行没有「存货」。
    模板里 `bal["流动资产合计"]["cur"]` 这种写法一遇到就崩，
    给这类公司出报告会直接报错（实测中信证券）。用这个包装后，缺失科目
    统一变成 None，由 `yi()/pct()/signed()` 渲染成「—」。
    """

    def __missing__(self, k):
        return _NoneRow()


def _v(rows: dict, label: str, field: str = "cur"):
    """从 {指标名: 行} 里安全取值 —— **缺科目就返回 None，不抛 KeyError**。

    券商没有"营业成本"、银行没有"存货"：模板若直接 `inc["营业成本"]["cur"]`，
    给这类公司出报告会当场崩掉（实测中信证券）。
    """
    row = (rows or {}).get(label)
    return None if row is None else row.get(field)


# ---------------------------------------------------------------- 报告正文

def build(data: dict, narrative: dict | None) -> Document:
    # **每次生成都要把编号归零**：这是模块级状态，同一进程里连着生成多份报告
    # （对话模式、批处理、测试）会累积，第二份就从"表 7"开始。
    # 早先这行没写进去（replace 没加断言，静默失败），单跑测试看不出来。
    _TABLE_NO["n"] = 0
    _FIG_NO["n"] = 0
    doc = Document()
    style_document(doc)

    company = data["company"]
    period = data["period"]
    prev = data["prev_period"]
    rtype = data.get("report_type", "年报")
    suffix = "年度" if rtype == "年报" else rtype
    title = f"{company} {period} {suffix}财务分析报告"

    # ---------------- 封面标题
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(30)
    p.paragraph_format.space_after = Pt(4)
    set_run(p.add_run(title), size=21, bold=True, font=HEAD_FONT, color=ACCENT)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(18)
    set_run(p.add_run("——基于年报三大报表与附注的自动化分析"),
            size=11, color=GREY, font=HEAD_FONT)

    table(doc, ["项目", "内容"], [
        ["公司名称", company],
        ["报告类型", f"{period} 年{suffix}报告"],
        ["比较期间", f"本期 {period} 年 / 上期 {prev} 年"],
        ["数据来源", "年报 PDF 规则抽取，落库 SQLite（带页码与置信度）"],
        ["外部核验", "AkShare（东方财富）资产负债表 / 利润表 / 现金流量表逐项比对"],
        ["生成日期", date.today().isoformat()],
    ], widths=[3.4, 12.4], align_right_from=99, zebra=True)
    note(doc, "说明：本报告全部金额单位为人民币亿元，比率保留两位小数。"
              "每个科目后的「第 N 页」为该数字在年报 PDF 中的出处页，可逐项回查。")

    doc.add_page_break()

    # ---------------- 摘要
    # **行业决定"哪些指标适用"**：银行没有营业成本/存货，券商没有营业成本，
    # 保险没有应收账款。不分行业就会把"不适用"写成"未抽到"。
    industry = data.get("industry") or "general"
    is_fin = industry in ("bank", "broker", "insurer")
    industry_cn = {"bank": "银行", "broker": "证券公司",
                   "insurer": "保险公司"}.get(industry, "")

    # **缺表不能崩**：银行/保险常常抽不到现金流量表（实测交通银行）。
    # 给三张表都准备一个空壳，后面 `sec["现金流量表分析"]` 才拿得到东西。
    empty = {"title": "", "rows": [], "ratios": []}
    sec = {"利润表分析": dict(empty), "资产负债表分析": dict(empty),
           "现金流量表分析": dict(empty)}
    for item in data.get("sections") or []:
        if isinstance(item, dict) and item.get("title") in sec:
            sec[item["title"]] = item
    # 比率行也可能整块缺失（缺表时），用 None 占位让后面的取值不崩
    _ratio_stub = {"label": "", "cur": None, "prev": None, "unit": "%"}
    _ir = (sec["利润表分析"].get("ratios") or []) + [_ratio_stub] * 4
    _br = (sec["资产负债表分析"].get("ratios") or []) + [_ratio_stub] * 3
    def _ratio_of(label):
        """按标签取比率行 —— **不能用下标**：金融业会把毛利率/研发费用率过滤掉，
        下标随之错位（实测交通银行取 `ratios[3]` 直接 IndexError）。"""
        return next((r for r in _ir if r["label"] == label), _ratio_stub)

    inc = _RowMap({r["label"]: r for r in sec["利润表分析"].get("rows") or []})
    bal = _RowMap({r["label"]: r for r in sec["资产负债表分析"].get("rows") or []})
    cfl = _RowMap({r["label"]: r for r in sec["现金流量表分析"].get("rows") or []})

    rev, cost = _v(inc, "营业收入"), _v(inc, "营业成本")
    np_ = _v(inc, "净利润")
    # 毛利只在两个科目都在时才算（券商没有营业成本）
    gp = (rev - cost) if (rev is not None and cost is not None) else None
    ocf = cfl["经营活动现金流量净额"]["cur"]
    ta, tl = bal["资产总计"]["cur"], bal["负债合计"]["cur"]

    # **可信度告警放在最前面**：数字不可靠时，不能让读者先读完三页再发现
    flags = data.get("quality_flags") or []
    if flags:
        p_warn = doc.add_paragraph()
        p_warn.paragraph_format.space_after = Pt(6)
        r = p_warn.add_run("⚠️ 数据可信度告警：本报告的数字可能不可靠")
        set_run(r, size=11, bold=True, font=HEAD_FONT,
                color=RGBColor(0xB0, 0x2A, 0x2A))
        for f in flags:
            bullet(doc, f)
        note(doc, "出现以上告警，通常说明该报告的表格式与常见版式差异较大"
                  "（金融业报表科目结构与工商企业不同是最常见的原因）。"
                  "请以年报原文为准；如需逐项核对，生成时加「核验」会附上与东方财富的比对表。")

    doc.add_heading("摘要", level=1)
    gm0 = _ir[0]
    d_rev = _v(inc, "营业收入", "yoy") or 0.0
    d_np = (_v(inc, "归母净利润", "yoy")
            if _v(inc, "归母净利润", "yoy") is not None
            else (_v(inc, "净利润", "yoy") or 0.0))
    up_down = "增长" if d_rev >= 0 else "下降"
    d_gm = (gm0["cur"] - gm0["prev"]) if (gm0["cur"] is not None and gm0["prev"] is not None) else 0.0
    flat = abs(d_gm) < 0.05        # 0.05pp 以内视为持平，避免"降 0.03pp 就以让价换量"
    if flat:
        verdict = "毛利率基本持平，利润变化主要随收入规模与费用波动"
    elif d_rev < 0 and d_gm > 0:
        verdict = "说明收入下滑主要来自规模收缩，而非定价或成本失控"
    elif d_rev < 0 and d_gm < 0:
        verdict = "毛利率同时走低，说明下滑既有量的因素，也有价格或成本的压力"
    elif d_rev > 0 and d_gm > 0:
        verdict = "收入与毛利率同步上行，量价两端均有贡献"
    else:
        # **删掉"让价"**：单价没有数据支撑，只能说成本增速快于收入
        verdict = "毛利率走低，说明成本增速快于收入，增长的质量需要打折扣"
    # **逐句组装**：缺哪个科目就少说哪一句，不能整段崩掉（券商没有营业成本/归母净利润）
    parts = [f"{period} 年，{company}实现营业收入 {yi(rev)} 亿元，"
             f"同比{up_down} {abs(d_rev):.2f}%"]
    profit_row = "归母净利润" if _v(inc, "归母净利润") is not None else "净利润"
    if _v(inc, profit_row) is not None:
        parts.append(f"{profit_row} {yi(_v(inc, profit_row))} 亿元，"
                     f"同比{'增长' if d_np >= 0 else '下降'} {abs(d_np):.2f}%")
    text = "；".join(parts) + "。"
    if gm0["cur"] is not None and gm0["prev"] is not None:
        text += (f"毛利率由 {pct(gm0['prev'])} 变为 {pct(gm0['cur'])}，{verdict}。")
    else:
        text += "（该公司报表未列示营业成本，故不计算毛利率。）"
    para(doc, text)
    # 经营现金流可能没抽到（中国黄金只抽到 3 个现金流科目）—— 不能直接除
    ocf_r = (ocf / np_) if (ocf is not None and np_) else None
    prev_ocf = cfl["经营活动现金流量净额"]["prev"]
    prev_np = _v(inc, "净利润", "prev")
    ocf_r_prev = ((prev_ocf / prev_np)
                  if (prev_ocf is not None and prev_np) else None)
    if ocf_r is not None and ocf_r_prev is not None:
        if ocf_r > ocf_r_prev and d_np < 0:
            cash_note = "利润下滑的年份里现金回款反而改善，是本年度最积极的信号。"
        elif ocf_r > ocf_r_prev:
            cash_note = "利润增长的同时现金回款同步改善，盈利的现金支撑更扎实。"
        else:
            cash_note = "利润的现金含量有所下降，回款质量需要关注。"
    else:
        cash_note = "现金含量因缺少净利润或经营现金流而无法计算。"
    if ocf is None:
        # 经营现金流没抽到时不写"同比增长 0.00%"这种假话
        para(doc, "现金流量表中「经营活动现金流量净额」未能抽取，"
                  "因此本报告不计算现金含量与现金流结构 —— "
                  "这一项的空缺可能低估或高估回款质量，请回看年报报表页。")
    else:
        ocf_yoy_v = cfl["经营活动现金流量净额"]["yoy"]
        para(doc, f"更值得关注的是现金流：经营活动现金流量净额 {yi(ocf)} 亿元，"
                  f"{yoy_phrase(ocf_yoy_v)}，为净利润的 {num(ocf_r)} 倍"
                  f"（上期为 {num(ocf_r_prev)} 倍）。{cash_note}")
    def _yoy_text(v) -> str:
        """同比写成「（+6.34%）」，缺失就写「（同比 —）」。"""
        return yoy_phrase(v) if v is not None else "与上年不可比"

    lev0 = _br[0]
    d_lev0 = (lev0["cur"] - lev0["prev"]
              if lev0["cur"] is not None and lev0["prev"] is not None else None)
    lev_dir = "上升" if (d_lev0 or 0) > 0 else "下降"
    para(doc, f"资产负债端，资产总计 {yi(ta)} 亿元{_yoy_text(_v(bal, '资产总计', 'yoy'))}，"
              f"负债合计 {yi(tl)} 亿元{_yoy_text(_v(bal, '负债合计', 'yoy'))}，"
              f"资产负债率 {pct(lev0['cur'])}"
              + (f"，较上年{lev_dir} {abs(d_lev0):.2f} 个百分点" if d_lev0 is not None else "")
              + ("；金融业不划分流动/非流动，不计算流动比率。" if is_fin
                 else f"；流动比率 {num(_br[1]['cur'])} 倍"
                      f"（上年 {num(_br[1]['prev'])} 倍），"
                      f"{_liquidity_word(_br[1])}。"))

    doc.add_heading("核心结论", level=2)
    top, cov, group_name = _top_contributor(sec["利润表分析"].get("mix"), rev)

    # **正文里的数字不进括号**：写"比上年增长 20.29%"，
    # 不写"（+20.29%）"；百分点写"个百分点"，不用 pp（pp 是 percentage point
    # 的缩写，中文报告里读者不认，且容易和 % 混）。
    rev_yoy = inc["营业收入"]["yoy"]
    if top:
        contrib = top["contrib"]
        bullet(doc,
               f"收入端：营业收入 {yi(rev)} 亿元，"
               f"比上年{'增长' if (rev_yoy or 0) >= 0 else '下降'} "
               f"{abs(rev_yoy or 0):.2f}%；按{group_name}口径，"
               f"{top['name']}是变动最大的分部，占总变动 "
               f"{abs(contrib):.1f}%，自身比上年"
               f"{'增长' if (top['yoy'] or 0) >= 0 else '下降'} "
               f"{abs(top['yoy'] or 0):.2f}%，详见 1.3。")
    elif cov:
        bullet(doc,
               f"收入端：营业收入 {yi(rev)} 亿元，"
               f"比上年{'增长' if (rev_yoy or 0) >= 0 else '下降'} "
               f"{abs(rev_yoy or 0):.2f}%；但年报披露的构成表只覆盖 "
               f"{cov * 100:.0f}% 的收入，不足以判断变动主要来自哪个分部，"
               f"详见 1.3 的说明。")
    else:
        bullet(doc,
               f"收入端：营业收入 {yi(rev)} 亿元，"
               f"比上年{'增长' if (rev_yoy or 0) >= 0 else '下降'} "
               f"{abs(rev_yoy or 0):.2f}%；年报未披露可拆解的构成表，"
               f"变动来源无法归因。")

    r_gm, r_nm = _ir[0], _ir[1]
    d_gm_v = (r_gm["cur"] - r_gm["prev"]) if None not in (r_gm["cur"], r_gm["prev"]) else 0.0
    d_nm_v = (r_nm["cur"] - r_nm["prev"]) if None not in (r_nm["cur"], r_nm["prev"]) else 0.0
    gm_word = "上升" if d_gm_v > 0.05 else ("下降" if d_gm_v < -0.05 else "基本持平")
    nm_word = "上升" if d_nm_v > 0.05 else ("下降" if d_nm_v < -0.05 else "基本持平")
    if gm_word == "基本持平" and nm_word == "基本持平":
        relation = "两者都基本持平，费用端没有明显变化"
    elif gm_word == nm_word:
        relation = "两者同向，费用端未额外侵蚀利润"
    elif "基本持平" in (gm_word, nm_word):
        relation = "两者一个持平一个变化，差额主要反映费用与非经营性项目的净影响"
    else:
        relation = "两者背离，差额主要来自费用、投资收益等非经营性项目"
    def _margin_sentence(label, cur, d, word):
        if word == "基本持平":
            return f"{label} {pct(cur)}，与上年基本持平"
        return f"{label} {pct(cur)}，比上年{word} {abs(d):.2f} 个百分点"

    if r_gm["cur"] is None and r_nm["cur"] is None:
        bullet(doc, "盈利端：利润表未抽到毛利率/净利率所需的科目，无法判断盈利能力变化。")
    else:
        bullet(doc, "盈利端：" + _margin_sentence("毛利率", r_gm["cur"], d_gm_v, gm_word)
               + "；" + _margin_sentence("净利率", r_nm["cur"], d_nm_v, nm_word)
               + "。" + relation + "。")

    if ocf_r is None or ocf_r_prev is None:
        bullet(doc, "现金端：现金流量表的关键科目未能抽取，"
                    "无法评估利润的现金含量（请回看报表页）。")
    else:
        bullet(doc,
               f"现金端：经营现金流是净利润的 {num(ocf_r)} 倍，上年为 "
               f"{num(ocf_r_prev)} 倍，利润的现金含量"
               f"{'改善' if ocf_r > ocf_r_prev else '弱化'}。")

    lev = _br[0]
    d_lev = (lev["cur"] - lev["prev"]) if None not in (lev["cur"], lev["prev"]) else 0.0
    lev_word = ("杠杆水平基本稳定" if abs(d_lev) < 1
                else ("杠杆有所上升" if d_lev > 0 else "杠杆有所下降"))
    if lev["cur"] is None:
        bullet(doc, "结构端：资产负债表未抽到资产负债率所需的科目，无法判断杠杆水平。")
    else:
        if is_fin:
            bullet(doc,
                   f"结构端：资产负债率 {pct(lev['cur'])}，比上年"
                   f"{'上升' if d_lev >= 0 else '下降'} {abs(d_lev):.2f} 个百分点；"
                   f"{industry_cn}不划分流动/非流动，不计算流动比率。")
        else:
            bullet(doc,
                   f"结构端：资产负债率 {pct(lev['cur'])}，比上年"
                   f"{'上升' if d_lev >= 0 else '下降'} {abs(d_lev):.2f} 个百分点；"
                   f"流动比率 {num(_br[1]['cur'])} 倍，"
                   f"{lev_word}。")

    # ---------------- 一、利润表
    doc.add_heading("一、利润表分析", level=1)
    doc.add_heading("1.1 主要损益项目", level=2)
    def _yoy_cell(r):
        """上期为负时**不列百分比，改列变动额**（负数基数的百分比没法解读）。"""
        if r["yoy"] is not None:
            return signed(r["yoy"])
        if r["cur"] is not None and r["prev"] is not None:
            return f"{signed((r['cur'] - r['prev']) / 1e8)} 亿"
        return "—"

    rows = [[r["label"], cell_value(r["label"], r["cur"]),
             cell_value(r["label"], r["prev"]), _yoy_cell(r),
             page_text(r['page'])] for r in sec["利润表分析"].get("rows") or []]
    caption_auto(doc, f"{period} 年利润表主要项目（单位：亿元）")
    table(doc, ["项目", "本期", "上期", "同比", "出处"], rows,
          widths=[4.4, 3.2, 3.2, 2.6, 2.4])
    note(doc, "同比 =（本期 − 上期）÷ |上期|。上期为年报同一张表的上年同期列，"
              "与本期同口径（含追溯重述），故不直接与数据库中的历史年度数据混用。"
              "**上期为负数的科目（如财务费用、投资/筹资现金流净额）不计算百分比**，"
              "改列变动额 —— 负数基数上的增长率会得到 +79%、-131% 这类无法解读的数字。")

    doc.add_heading("1.2 盈利能力", level=2)
    # 金融业没有"营业成本"口径，毛利率与研发费用率都不适用 —— 直接不列，
    # 免得读者以为"未抽到"
    # 去掉空占位行（`_ir` 为了安全取值补了 stub，标签为空）
    ratios = [r for r in _ir if r["label"]]
    if is_fin:
        ratios = [r for r in ratios if r["label"] not in ("毛利率", "研发费用率")]
    if is_fin:
        para(doc, f"{industry_cn}的利润表不列示「营业成本」，毛利率与研发费用率均不适用；"
                  "下面用净利率与成本收入比衡量盈利能力。")
    rows = [[r["label"], pct(r["cur"]) if r["unit"] == "%" else num(r["cur"]),
             pct(r["prev"]) if r["unit"] == "%" else num(r["prev"]),
             signed(r["cur"] - r["prev"]) if r["cur"] is not None and r["prev"] is not None else "—"]
            for r in ratios]
    caption_auto(doc, "盈利能力指标")
    table(doc, ["指标", "本期", "上期", "变动"], rows,
          widths=[5.2, 3.4, 3.4, 3.2])

    gm = _ratio_of("毛利率")
    if is_fin:
        # 成本收入比（业务及管理费 / 营业收入）：银行/券商最常用的效率指标
        # **费用取绝对值**：银行/保险把"业务及管理费"放在支出段落，
        # 抽取时可能带负号（实测交通银行 −728 亿 → 成本收入比算成 −27%）。
        fee = inc["业务及管理费"]["cur"]
        fee = abs(fee) if fee is not None else None
        rev = inc["营业收入"]["cur"]
        if fee is not None and rev:
            cir = fee / rev * 100
            fee_p = inc["业务及管理费"]["prev"]
            fee_p = abs(fee_p) if fee_p is not None else None
            rev_p = inc["营业收入"]["prev"]
            if fee_p is not None and rev_p:
                cir_prev = fee_p / rev_p * 100
                direction = "上升" if cir > cir_prev else "下降"
                para(doc, f"成本收入比 {cir:.2f}%，上年 {cir_prev:.2f}%，"
                          f"{direction} {abs(cir - cir_prev):.2f} 个百分点"
                          + ("，费用管控效率改善。" if cir < cir_prev
                             else "，费用效率有所弱化。"))
            else:
                para(doc, f"成本收入比 {cir:.2f}%（业务及管理费 / 营业收入）。")
        else:
            para(doc, "业务及管理费或营业收入未抽到，本报告未计算成本收入比。")
    elif gm["cur"] is None or gm["prev"] is None:
        # 券商/保险不列示"营业成本"，毛利率无从计算 —— 说清楚，别崩
        para(doc, "本报告未计算毛利率：该公司的利润表未列示「营业成本」"
                  "（金融业报表通常如此），收入与成本的对应关系需查阅附注。")
    else:
        d_gmv = gm["cur"] - gm["prev"]
        cost_yoy = _v(inc, "营业成本", "yoy") or 0.0
        rev_yoy = _v(inc, "营业收入", "yoy") or 0.0
        cost_faster = cost_yoy > rev_yoy
        para(doc, f"毛利率 {pct(gm['cur'])}，较上年"
                  f"{'上升' if d_gmv > 0.05 else ('下降' if d_gmv < -0.05 else '基本持平')} "
                  f"{abs(d_gmv):.2f} 个百分点。营业成本同比 {signed(cost_yoy)}，"
                  f"营业收入同比 {signed(rev_yoy)}，成本增速"
                  f"{'快于' if cost_faster else '慢于'}收入，对毛利率形成"
                  f"{'负向' if cost_faster else '正向'}影响。")

    doc.add_heading("1.3 收入构成与变动归因", level=2)
    mix = sec["利润表分析"].get("mix")
    if mix:
        para(doc, "三大报表只给出一个营业收入合计数，「为什么变」要看年报管理层讨论与分析"
                  "中的构成表。下表把各分部的变动额拆出来，并按「占总变动」排序——"
                  "排在最前的就是该维度的变动主因。")
        # 有的构成表给毛利率、有的不给（格力不给）。整列都是空就不画这一列，
        # 免得读者以为"毛利率缺了"而不是"这张表本来就没有"。
        has_margin = any(c.get("margin") is not None
                         for g in mix["groups"] for c in g["rows"])
        for g in mix["groups"]:
            rows = []
            for c in g["rows"]:
                row = [c["name"], yi(c["cur"]), signed(c["yoy"]),
                       signed(c["contrib"], 1) if c["contrib"] is not None else "—"]
                if has_margin:
                    row.append(pct(c["margin"]) if c.get("margin") is not None else "—")
                rows.append(row)
            caption_auto(doc, f"收入构成——{g['name']}（年报第 {mix['page']} 页）")
            head = ["分部", "本期收入", "同比", "占总变动"]
            widths = [5.6, 3.0, 2.6, 2.6]
            if has_margin:
                head.append("毛利率")
                widths.append(2.6)
            table(doc, head, rows, widths=widths)
            # **每张构成表都自报覆盖率**：分项加起来远小于营业收入，说明这张表
            # 没抽全（华工科技的分产品表只剩一行、只覆盖 25%），此时任何
            # "谁贡献最大"的结论都不成立。
            cov = _group_coverage(g, rev)
            if cov and cov < _GROUP_COVERAGE_MIN:
                para(doc, f"⚠️ 这张表的分项合计只占营业收入的 {cov * 100:.0f}%"
                          f"，表内仅 {len(g['rows'])} 行，**很可能没有抽全**，"
                          f"不要据此判断「谁贡献最大」。")
        note(doc, "占总变动 = 该分部变动额 ÷ 营业收入合计变动额。合计为负（收入下降）时，"
                  "正值表示该分部是降幅的贡献者，负值表示逆势增长、抵减了降幅。")
    else:
        para(doc, "本报告未在年报中定位到「营业收入构成」表，故无法拆解变动来源。")

    doc.add_heading("1.4 小结", level=2)

    # 同样的道理：金融业没有销售费用/管理费用/研发费用，逐项取、缺就不说
    fees = [(n, _v(inc, n, "yoy")) for n in ("销售费用", "管理费用", "研发费用")]
    fees = [(n, v) for n, v in fees if v is not None]
    # **不把数字塞进括号**：读者要的是"收入同比增长 20.29%"，
    # 不是"收入同比（+20.29%）"。单位也统一成"个百分点"，不再写 pp。
    rev_yoy = _v(inc, "营业收入", "yoy") or 0.0
    text = (f"收入{'增长' if rev_yoy >= 0 else '下降'} {abs(rev_yoy):.2f}%")
    if gm["cur"] is not None and gm["prev"] is not None:
        d = gm["cur"] - gm["prev"]
        text += f"，毛利率{'上升' if d >= 0 else '下降'} {abs(d):.2f} 个百分点"
    if fees:
        detail = "、".join(
            f"{n}{'增长' if v >= 0 else '下降'} {abs(v):.2f}%" for n, v in fees)
        text += f"；{detail}"
    _nm = _ratio_of("净利率")
    if _nm["cur"] is not None and _nm["prev"] is not None:
        d = _nm["cur"] - _nm["prev"]
        text += f"；净利率{'上升' if d >= 0 else '下降'} {abs(d):.2f} 个百分点"
    rd_delta = None
    _rd = _ratio_of("研发费用率")
    if _rd["cur"] is not None and _rd["prev"] is not None:
        rd_delta = _rd["cur"] - _rd["prev"]
        text += (f"；研发费用率由 {pct(_rd['prev'])} 变为 "
                 f"{pct(_rd['cur'])}，"
                 f"{'上升' if rd_delta >= 0 else '下降'} {abs(rd_delta):.2f} 个百分点")
    para(doc, text + "。")

    # 研发强度被摊薄这件事值得单独说：对一家自称科技制造的公司，
    # 费用率下降往往不是"省钱"，而是收入跑得比研发投入快 —— 竞争力信号。
    if (rd_delta is not None and rd_delta <= -0.5
            and _v(inc, "研发费用", "yoy") is not None
            and _v(inc, "营业收入", "yoy") is not None):
        para(doc, f"研发费用率下降 {abs(rd_delta):.2f} 个百分点，而研发费用本身只增 "
                  f"{_v(inc, '研发费用', 'yoy'):.2f}%、收入增 "
                  f"{_v(inc, '营业收入', 'yoy'):.2f}% —— 是**研发强度被收入摊薄**，"
                  f"不是研发投入收缩。对科技属性公司，这是需要跟踪的竞争力信号："
                  f"若连续多年摊薄，说明投入没跟上规模。")

    # ---------------- 1.5 原文归因（可选，来自 narrative 链路）
    if narrative and (narrative.get("answer") or "").strip():
        doc.add_heading("1.5 年报原文对变动原因的解释", level=2)
        para(doc, "以下内容由大模型依据年报原文片段归纳，不是规则抽取；"
                  "每条结论后标注原文页码，可与 1.1 节的数字分别核对。")
        for line in narrative["answer"].split("\n"):
            text = line.strip().lstrip("-*· ").replace("**", "")
            if text:
                para(doc, text, indent=False, space_after=5)
        # 只列正文真正引用的页码：检索会捞回 8 页，但答案可能只用到其中 3 页，
        # 全列出来会让读者以为答案引了 8 处。
        used = sorted({int(n) for n in re.findall(r"第\s*(\d+)\s*页",
                                                  narrative["answer"])})
        if used:
            note(doc, "原文出处：" + "、".join(f"第{n}页" for n in used))

    # ---------------- 二、资产负债表
    doc.add_heading("二、资产负债表分析", level=1)
    doc.add_heading("2.1 主要项目", level=2)
    rows = [[r["label"], yi(r["cur"]), yi(r["prev"]), signed(r["yoy"]),
             page_text(r['page'])] for r in sec["资产负债表分析"].get("rows") or []]
    caption_auto(doc, f"{period} 年末资产负债表主要项目（单位：亿元）")
    table(doc, ["项目", "期末", "期初", "变动", "出处"], rows,
          widths=[4.4, 3.2, 3.2, 2.6, 2.4])
    note(doc, "资产负债表的上期列是「上年年末」，与利润表的「上年同期」不同，"
              "故两者不可直接相加或交叉计算。")

    doc.add_heading("2.2 偿债能力", level=2)
    bal_ratios = sec["资产负债表分析"].get("ratios") or []
    if is_fin:
        # 金融业不划分流动/非流动，流动比率无从计算 —— 不列这一行
        bal_ratios = [r for r in bal_ratios if r["label"] != "流动比率"]
    rows = [[r["label"], num(r["cur"]) if r["unit"] == "倍" else pct(r["cur"]),
             num(r["prev"]) if r["unit"] == "倍" else pct(r["prev"])]
            for r in bal_ratios]
    caption_auto(doc, "偿债能力指标")
    table(doc, ["指标", "期末", "期初"], rows, widths=[6.4, 4.2, 4.2])

    if is_fin:
        para(doc, f"{industry_cn}的资产负债表不区分流动/非流动，因此不计算流动比率；"
                  "偿债能力主要看资产负债率与有息负债占比，"
                  "监管口径的流动性指标（流动性覆盖率、净稳定资金比例）见年报「风险管理」章节。")

    cr = _br[1]
    ca, cl = bal["流动资产合计"], bal["流动负债合计"]
    if is_fin:
        pass
    elif None in (cr["cur"], cr["prev"], ca["cur"], cl["cur"]):
        para(doc, "流动比率无法计算：该公司的资产负债表未区分流动/非流动资产与负债"
                  "（金融业报表通常如此）。这类公司的短期偿付能力应看"
                  "「有息负债 / 资产总计」与流动性覆盖率，而非流动比率。")
    else:
        d_cr = cr["cur"] - cr["prev"]
        para(doc, f"流动比率 {num(cr['cur'])} 倍，较上年"
                  f"{'上升' if d_cr > 0 else '下降'} {abs(d_cr):.2f}，"
                  f"流动负债{yoy_phrase(cl['yoy'])}，"
                  f"{'快于' if (cl['yoy'] or 0) > (ca['yoy'] or 0) else '慢于'}"
                  f"流动资产的{yoy_phrase(ca['yoy'])}。")
        # 三项主要流动资产的增量：**缺哪项就不提哪项**，不硬凑
        parts = []
        for label in ("货币资金", "应收账款", "存货"):
            row = bal[label]
            if row["cur"] is not None and row["prev"] is not None:
                d_row = row["cur"] - row["prev"]
                parts.append(f"{label}{'增加' if d_row >= 0 else '减少'} "
                             f"{abs(d_row) / 1e8:.2f} 亿元")
        if ca["cur"] is not None and ca["prev"] is not None:
            delta = ca["cur"] - ca["prev"]
            # **"增加 -0.59 亿元"是病句**：方向词要跟着符号走
            line = f"流动资产{'增加' if delta >= 0 else '减少'} {yi(abs(delta))} 亿元"
            three = 0.0
            if parts:
                line += "，其中 " + "、".join(parts)
                for label in ("货币资金", "应收账款", "存货"):
                    row = bal[label]
                    if row["cur"] is not None and row["prev"] is not None:
                        three += row["cur"] - row["prev"]
                gap = delta - three
                # **缺口必须交代**，不能一句"其余需回看"打发：
                # 分项之和与合计不等时，读者没法判断是漏抽还是真有大额其他科目
                # 注意：这里单位是**亿元**，不能用 signed()（它会补一个 %）
                line += (f"；这三项合计 {three / 1e8:+.2f} 亿元，与流动资产"
                         f"{'增加' if delta >= 0 else '减少'}额相差 "
                         f"{yi(gap)} 亿元，差额来自本报告未逐项抽取的其他流动资产科目")
            para(doc, line + "（可回看报表页及附注核实）。")

    # ---------------- 2.3 资金可用性与有息负债
    doc.add_heading("2.3 资金可用性与有息负债", level=2)
    cq = data.get("cash_quality") or {}
    eq = cq.get("cash_equiv") or {}
    cash_cur = bal["货币资金"]["cur"]
    if cash_cur and eq.get("cur"):
        share = eq["cur"] / cash_cur * 100
        para(doc, f"货币资金 {yi(cash_cur)} 亿元，而现金流量表口径的「期末现金及现金"
                  f"等价物」为 {yi(eq['cur'])} 亿元，占 {share:.2f}%"
                  f"（第 {eq.get('page')} 页）。差额部分主要是受限资金、"
                  f"定期存款或不属于现金等价物的理财，不能直接用于偿债。")
        if share < 60:
            para(doc, "这个比例偏低：说明账面「货币资金」里有相当一部分并非随时可动用，"
                      "评估短期偿债能力时不能直接拿货币资金去比流动负债。")
        restricted = cq.get("restricted") or {}
        if restricted.get("cur"):
            para(doc, f"年报另披露受限资金 {yi(restricted['cur'])} 亿元"
                      f"（第 {restricted.get('page')} 页）。")
    else:
        para(doc, "未定位到现金流量表的「期末现金及现金等价物」，故无法判断"
                  "货币资金中有多少是真正可动用的 —— 这一层缺口可能低估偿债压力。")

    ib = next((x.get("interest_bearing") for x in data.get("sections", [])
               if isinstance(x, dict) and x.get("interest_bearing")), None)
    ib_rows = (ib or {}).get("rows") or []
    total = (ib or {}).get("total") or {}
    if ib_rows and total.get("cur") is not None:
        para(doc, "有息负债是把若干报表科目加总得到的，单看资产负债率会低估真实偿债压力。"
                  "本报告采用的构成如下：")
        caption_auto(doc, "有息负债构成（单位：亿元）")
        rows_ib = [[r["label"], cell_value(r["label"], r["cur"]),
                    cell_value(r["label"], r["prev"])] for r in ib_rows]
        # **合计必须和各行的单位一致**：行是亿元，合计曾用 num() 打成元，
        # 出现"短期借款 0.05、合计 40,428,531.01"这种荒唐表
        rows_ib.append(["合计", yi(total.get("cur")), yi(total.get("prev"))])
        table(doc, ["科目", "期末", "期初"], rows_ib, widths=[6.4, 4.2, 4.2])
        ta = bal["资产总计"]["cur"]
        if ta:
            share = total["cur"] / ta * 100
            para(doc, f"有息负债合计 {yi(total['cur'])} 亿元，占资产总计 {share:.2f}%。"
                      f"这个比率的分子就是上表各科目之和，可逐项回查报表页。")
        note(doc, "租赁负债、一年内到期的非流动负债是否计入，各研究口径不一；"
                  "本报告一并计入，故口径偏保守。")
    else:
        para(doc, "未抽到有息负债的相关科目（短期借款 / 长期借款 / 应付债券 / 租赁负债等），"
                  "因此本报告不对有息负债给出任何比率 —— 缺数据时不给结论。")

    doc.add_heading("2.4 会计恒等式核验", level=2)
    viol = data.get("identity_violations") or []
    if viol:
        for v in viol:
            para(doc, f"⚠️ {v['year']} 年「{v['check']}」不成立，差额 "
                      f"{yi(v['diff'])} 亿元，该年数值可能有误，请以原文为准。")
    else:
        para(doc, f"「资产总计 = 负债合计 + 所有者权益合计」在本期与上期均成立："
                  f"{yi(ta)} = {yi(tl)} + {yi(bal['所有者权益合计']['cur'])}，"
                  f"差额 0。资产负债表内部自洽，说明抽取到的合计类科目彼此一致。")
    note(doc, "恒等式只能校验内部自洽，校验不了「与外部真值一致」——"
              "标签整体错位这类错误在错完之后往往仍然自洽，故必须辅以外部核验（见第六节）。")

    doc.add_heading("2.5 小结", level=2)
    y_ta, y_tl = bal["资产总计"]["yoy"] or 0.0, bal["负债合计"]["yoy"] or 0.0
    cr_now, cr_prev = _br[1]["cur"], _br[1]["prev"]
    cr_dir = ("上升" if (cr_now or 0) > (cr_prev or 0)
              else ("下降" if (cr_now or 0) < (cr_prev or 0) else "持平"))
    cash_dir = "增加" if (bal["货币资金"]["yoy"] or 0) >= 0 else "减少"
    para(doc, f"资产总计 {signed(y_ta)}，负债合计 {signed(y_tl)}，"
              f"{'负债增速快于资产，杠杆被动抬升' if y_tl > y_ta else '资产增速快于负债，杠杆有所摊薄'}；"
              f"资产负债率 {pct(_br[0]['cur'])}。"
              f"流动性方面，流动比率 {num(cr_now)} 倍（上年 {num(cr_prev)} 倍，{cr_dir}），"
              f"货币资金比{cash_dir} {abs(bal['货币资金']['yoy'] or 0):.2f}%。")

    # ---------------- 三、现金流量表
    doc.add_heading("三、现金流量表分析", level=1)
    doc.add_heading("3.1 三类现金流", level=2)
    cf_rows = sec["现金流量表分析"].get("rows") or []
    ocf_cur = cfl["经营活动现金流量净额"]["cur"]
    rows = [[r["label"], yi(r["cur"]), yi(r["prev"]), signed(r["yoy"]),
             f"第 {r['page']} 页"] for r in cf_rows]
    caption_auto(doc, f"{period} 年现金流量表主要项目（单位：亿元）")
    table(doc, ["项目", "本期", "上期", "同比", "出处"], rows,
          widths=[5.0, 3.2, 3.0, 2.4, 2.4])

    if ocf_cur is None:
        # **整节降级**：把 None 当 0 会写出"同比增长 0.00%、现金含量弱化"，
        # 那是编出来的结论（实测中国黄金只抽到 3 个现金流科目）。
        para(doc, f"本表只抽到 {len(cf_rows)} 个科目，「经营活动现金流量净额」"
                  f"未能抽取，因此本节不计算现金含量、收现比与现金流结构。"
                  f"这通常意味着该页版式特殊或报表被切分，请回看年报报表页核对。")
        note(doc, "缺数据时不给结论 —— 这是本报告的一贯原则。")
    else:
        cfr = ((sec["现金流量表分析"].get("ratios") or []) + [{"cur": None, "prev": None}])[0]
        ocf_yoy = cfl["经营活动现金流量净额"]["yoy"] or 0.0
        np_yoy = _v(inc, "净利润", "yoy") or 0.0
        trend_word = "改善" if (cfr["cur"] or 0) > (cfr["prev"] or 0) else "弱化"
        para(doc, f"经营活动现金流量净额 {yi(ocf)} 亿元，{yoy_phrase(ocf_yoy)}；"
                  f"同期净利润{yoy_phrase(np_yoy)}。"
                  f"经营现金流{'增速快于利润' if ocf_yoy > np_yoy else '增速慢于利润'}，"
                  f"现金含量（经营现金流 ÷ 净利润）由 {num(cfr['prev'])} 倍变为 "
                  f"{num(cfr['cur'])} 倍，{trend_word}。")
        sales_cash = cfl.get("销售商品收到的现金")
        if sales_cash:
            ratio = sales_cash["cur"] / rev if rev else 0.0
            ar_yoy = bal["应收账款"]["yoy"] or 0.0
            # **收现比要说含税口径**：销售收现含增值税，营业收入不含税，
            # 所以 1.0 不等于"收回全部收入"。正常年份（增值税率 13% 为主）
            # 应在 1.10 以上才算基本足额回款，1.0 附近其实已经偏弱。
            if ratio >= 1.10:
                verdict_cash = "回款充分（销售收现含增值税，1.10 以上才算基本足额）"
            elif ratio >= 1.0:
                verdict_cash = ("回款偏弱 —— 销售收现含增值税，扣除税额后"
                                "实际低于营业收入，仍有部分收入未收回现金")
            else:
                verdict_cash = "回款明显偏弱 —— 有相当比例的收入尚未转化为现金"
            para(doc, f"销售商品、提供劳务收到的现金 {yi(sales_cash['cur'])} 亿元"
                      f"，{yoy_phrase(sales_cash['yoy'])}。收现比为 "
                      f"{ratio:.3f}，{verdict_cash}；"
                      f"应收账款同比 {signed(ar_yoy)}"
                      f"{'，回款端同步改善' if ar_yoy < 0 else '，占款有所增加'}。")
            note(doc, "口径提醒：销售收现是**含增值税**的现金流入，营业收入**不含税**，"
                      "两者不能直接按 1:1 比较。")
        inv_c, inv_p = cfl["投资活动现金流量净额"]["cur"], cfl["投资活动现金流量净额"]["prev"]
        fin_c, fin_p = cfl["筹资活动现金流量净额"]["cur"], cfl["筹资活动现金流量净额"]["prev"]
        def _flow(v):
            """现金流净额的方向 + 金额。**上年与本期各自判方向** ——
            早期版本按本期符号给上期套话术，出现了「上年净流入 -237.03 亿元」这种病句。"""
            if v is None:
                return "数据缺失"
            return f"净{'流入' if v >= 0 else '流出'} {yi(abs(v))} 亿元"

        inv_txt = f"投资活动{_flow(inv_c)}（上年{_flow(inv_p)}）"
        fin_txt = f"筹资活动{_flow(fin_c)}（上年{_flow(fin_p)}）"
        if (inv_c is not None and fin_c is not None and inv_p is not None
                and inv_c < 0 and fin_c > 0 and inv_p < 0):
            tail = ("投资端大额净流出与筹资端转为净流入并存，指向本年度存在较大规模的"
                    "资金配置动作（如购买理财、定期存款或长期资产投入），"
                    "具体构成需查阅年报现金流量表补充资料与附注。")
        else:
            tail = ("投资与筹资的净额方向、规模都直接决定资金从哪来、到哪去，"
                    "其明细（购建资产、对外投资、借款与偿债结构）需查阅现金流量表补充资料与附注。")
        para(doc, f"{inv_txt}，{fin_txt}。{tail}")

        doc.add_heading("3.2 小结", level=2)
        parts = []
        if ocf_yoy is not None:
            parts.append("经营活动" + ("净流入扩大" if ocf_yoy > 0 else "净流入收窄"))
        if inv_c is not None:
            parts.append("投资活动净" + ("流出" if inv_c < 0 else "流入"))
        if fin_c is not None:
            parts.append("筹资活动净" + ("流入" if fin_c > 0 else "流出"))
        para(doc, "现金流结构呈现「" + "、".join(parts) + "」的组合。"
                  "经营现金流的质量是判断盈利含金量的关键；投资与筹资的规模、方向则反映"
                  "资金配置与融资安排，其明细（购建资产、对外投资、借款与偿债结构）"
                  "需查阅现金流量表补充资料与附注——这正是当前系统尚未覆盖的部分（见第五节）。")

    # ---------------- 3.3 三大报表勾稽关系（放在三张表都讲完之后）
    ties = data.get("ties") or []
    doc.add_heading("3.3 三大报表勾稽关系", level=2)
    if not ties:
        para(doc, "未做勾稽校验（缺少相关科目）。")
    else:
        para(doc, "单张表内部的恒等式只能说明「这张表自洽」。三张表之间的数字能对上，"
                  "才说明它们出自同一套账。以下四条是按报表原文数字直接核对的：")
        caption_auto(doc, "三大报表勾稽校验（单位：亿元）")
        rows = []
        for t in ties:
            left = yi(t["left"]) if t["left"] is not None else "—"
            right = yi(t["right"]) if t["right"] is not None else "—"
            diff = (f"{t['diff'] / 1e8:+.2f}" if t.get("diff") is not None else "—")
            # 通过但仍有小额差额（≤净额 2%）时，别只写"通过"——读者会疑惑
            # 22 亿的差额为什么也是通过。写"通过*"并在下方说明容差来源。
            if t["status"] == "ok" and t.get("diff") and abs(t["diff"]) > 2:
                state = "通过*"
            else:
                state = {"ok": "通过", "mismatch": "不平", "diff": "见注",
                         "na": "无法核验"}[t["status"]]
            rows.append([t["label"], left, right, diff, state])
        table(doc, ["勾稽关系", "左式", "右式", "差额", "结论"], rows,
              widths=[6.6, 2.8, 2.8, 2.2, 2.2])

        bad = [t for t in ties if t["status"] == "mismatch"]
        for t in ties:
            if t["status"] == "na":
                note(doc, f"「{t['label']}」未做校验：{t['note']}")
        if bad:
            para(doc, "⚠️ 有 " + str(len(bad)) + " 条勾稽关系不平："
                      + "；".join(f"{t['label']}（差 {t['diff'] / 1e8:+.2f} 亿元）"
                                  for t in bad)
                      + "。常见原因是**合并报表与母公司报表印在同一页**，"
                        "抽取时把两张表的数字混在了一起（实测中际旭创 2025 年报第 99 页）；"
                        "也可能是报表本身的重分类。引用相关数字前请回看现金流量表原文，"
                        "本节的勾稽结果以原始报表为准。")
        else:
            if any(t["status"] == "ok" and t.get("diff") and abs(t["diff"]) > 2
                   for t in ties):
                note(doc, "带 * 的项目存在小额差额：现金流量表里常有未单列的"
                          "「其他」项目，使三类净额之和与净增加额相差净额的 2% 以内。"
                          "本报告按 2% 设为通过阈值，超过则判为不平。")
            para(doc, "上述勾稽关系均已核对。第 4 条为跨表勾稽（利润表 → 资产负债表），"
                      "差额一般来自分红、提取盈余公积或会计政策变更，"
                      "本报告只列差额，不据此判断报表对错。")


    # ---------------- 四、多年趋势
    # **即使没有趋势也要出这一节**：整节消失会让章节号从三跳到五，
    # 读者只看到编号断了、不知道是"没数据"还是"漏了"（评审指出过同类问题）。
    doc.add_heading("四、多年趋势", level=1)
    trend = data.get("trend")
    if not trend:
        para(doc, "这份报告只入库了一期，且年报中没有可用的上期对照列，"
                  "因此无法构成趋势序列。补入相邻年度年报后重新生成，这一节会自动出现。")
    else:
        if trend.get("single_report"):
            para(doc, "库中这份报告只有一期，下表用**年报自身的上期对照列**构成两期对比；"
                      "补入更早年度年报后，这一节会自动延长成真正的多年序列。")
        rows = []
        for name, pts in trend["series"].items():
            rows.append([name] + [yi(p["value"]) for p in pts])
        n = len(trend["periods"])
        caption_auto(doc, f"近 {n} 年主要指标（单位：亿元）")
        # 列宽按实际期间数算：库里可能只有 2 期（茅台年报 2023/2024），
        # 写死 4 期会越界（IndexError: column index [3] is out of range）。
        first_col = min(5.0, 15.8 - 2.6 * n)
        rest = (15.8 - first_col) / max(n, 1)
        table(doc, ["指标"] + [f"{p} 年" for p in trend["periods"]], rows,
              widths=[first_col] + [rest] * n)

        ps = trend["periods"]

        def _cmp(last, first, label):
            if last is None or first is None or not first:
                return f"{label}数据不全，无法比较"
            ch = (last - first) / abs(first) * 100
            return (f"{label}由 {yi(first)} 亿元变为 {yi(last)} 亿元，"
                    f"{'增长' if ch >= 0 else '下降'} {abs(ch):.2f}%")

        revs = [p["value"] for p in trend["series"]["营业收入"]]
        npts = [p["value"] for p in trend["series"]["净利润"]]
        text = (f"{ps[0]}–{ps[-1]} 年，" + _cmp(revs[-1], revs[0], "营业收入")
                + "，" + _cmp(npts[-1], npts[0], "净利润") + "。")
        # 峰值提示只在"峰值既不在首年也不在末年"时才说，否则是废话
        valid = [(i, v) for i, v in enumerate(revs) if v is not None]
        if valid:
            pi, pv = max(valid, key=lambda t: t[1])
            if 0 < pi < len(revs) - 1:
                text += (f"收入峰值出现在 {ps[pi]} 年，当年 {yi(pv)} 亿元，"
                         f"此后回落至 {yi(revs[-1])} 亿元。")
        para(doc, text)
        note(doc, "趋势序列取自 SQLite 中各年度报告的本期列；单年同比取自同一张表的两列。"
                  "两者口径不同：前者是各年原始披露，后者含当期追溯重述。")

        # ---------------- 五、附注缺口
    doc.add_heading("五、附注信息与本次分析的边界", level=1)

    # 5.1 审计意见与关键审计事项 —— 唯一已经结构化进来的附注信息
    au = data.get("audit")
    doc.add_heading("5.1 审计意见与关键审计事项", level=2)
    if not au:
        para(doc, "未能从本报告 PDF 中读取审计报告，故无法给出审计意见。")
    elif not au.get("audited"):
        para(doc, f"{au.get('note') or '未经审计'}。半年报按规则通常不经过审计，"
                  f"因此本报告的报表数字未经独立审计师验证。")
    else:
        opinion = au.get("opinion") or "未识别"
        page = au.get("opinion_page")
        para(doc, f"审计意见类型：{opinion}"
                  f"{f'（第 {page} 页）' if page else ''}。")
        items = au.get("kam_items") or []
        if items:
            caption_auto(doc, "关键审计事项（审计师认为对本期报表审计最重要的事项）")
            table(doc, ["序号", "关键审计事项", "出处"],
                  [[str(i + 1), it["title"], f"第 {it['page']} 页"]
                   for i, it in enumerate(items)],
                  widths=[1.8, 10.6, 3.4], align_right_from=99)
            note(doc, "关键审计事项是审计师与治理层沟通过、并在审计报告中单列的事项，"
                      "通常直接指向本期最需要判断的会计领域——它是判断报表质量最省力的切入点。")
        else:
            para(doc, "审计报告中列有关键审计事项章节，但未能识别出具体条目名。")

    # 5.2 存货跌价准备 —— 与 KAM 咬合
    iv = data.get("inventory")
    doc.add_heading("5.2 存货跌价准备", level=2)
    if not iv:
        para(doc, "未能在附注中定位到与报表存货金额一致的「账面余额 / 跌价准备 / 账面价值」"
                  "合计行，故无法给出计提比例。")
    else:
        c, pv = iv["cur"], iv.get("prev")
        para(doc, f"存货账面余额 {yi(c['gross'])} 亿元，计提跌价准备 "
                  f"{yi(c['provision'])} 亿元，计提比例 {iv['ratio']:.2f}%，"
                  f"账面价值 {yi(c['net'])} 亿元（第 {c['page']} 页）。")
        rows = []
        if pv:
            rows.append(["期初", yi(pv["gross"]), yi(pv["provision"]),
                         f"{pv['provision'] / pv['gross'] * 100:.2f}%"
                         if pv["gross"] else "—", yi(pv["net"])])
        rows.append(["期末", yi(c["gross"]), yi(c["provision"]),
                     f"{iv['ratio']:.2f}%", yi(c["net"])])
        caption_auto(doc, "存货及跌价准备（单位：亿元）")
        table(doc, ["期间", "账面余额", "跌价准备", "计提比例", "账面价值"], rows,
              widths=[2.6, 3.8, 3.4, 3.0, 3.6])
        if pv:
            delta = c["provision"] - pv["provision"]
            verb = "增加" if delta > 0 else "减少"
            para(doc, f"本期跌价准备{verb} {yi(abs(delta))} 亿元。"
                      f"{'计提增加会压低当期利润' if delta > 0 else '减少（转回或核销）会增厚当期利润'}；"
                      f"若该事项被审计师列为关键审计事项，"
                      f"这个方向的变动尤其值得对照附注中的计提依据一起看。")
        note(doc, "交叉校验：附注的「账面价值」与资产负债表中的「存货」一致，"
                  "故这张表的数字与报表口径自洽。")

    # 5.3 应收账款账龄
    ar = data.get("receivables")
    doc.add_heading("5.3 应收账款账龄与坏账准备", level=2)
    if not ar:
        para(doc, "未能在附注中定位到与报表应收账款一致的账龄表，故无法拆解账龄结构。")
    elif ar.get("gross") is None or not ar.get("aging"):
        # **只抽到净值、没抽到余额/账龄**：说清楚，不做结构分析、也不声称校验通过。
        # 实测澜起科技：账面价值 5.70 亿拿到了，账面余额与账龄明细没抽到，
        # 旧版仍打印"账面余额 — 亿元…交叉校验一致"，是**假声明**。
        para(doc, f"应收账款账面价值 {yi(ar.get('net'))} 亿元（第 {ar.get('page')} 页），"
                  f"但附注里的**账面余额与账龄明细未能抽取**，故本节不做账龄结构分析。")
        note(doc, f"需要看账龄结构请回看年报第 {ar.get('page')} 页附注。")
    else:
        ratio_txt = (f"（计提比例 {ar['ratio']:.2f}%）"
                     if ar.get("ratio") is not None else "")
        para(doc, f"应收账款账面余额 {yi(ar['gross'])} 亿元，"
                  f"计提坏账准备 {yi(ar.get('provision'))} 亿元{ratio_txt}，"
                  f"账面价值 {yi(ar.get('net'))} 亿元（第 {ar.get('page')} 页）。")
        rows = []
        for row in ar["aging"]:
            share = (row["cur"] / ar["gross"] * 100) if ar["gross"] else None
            rows.append([row["label"], yi(row["cur"]),
                         f"{share:.2f}%" if share is not None else "—",
                         yi(row["prev"])])
        caption_auto(doc, "应收账款账龄结构（单位：亿元）")
        table(doc, ["账龄", "期末余额", "占比", "期初余额"], rows,
              widths=[4.0, 4.2, 3.2, 4.2])
        # **表内加总校验**：分项之和必须等于账面余额，否则说明有档位没抽到。
        aging_sum = sum(r["cur"] or 0 for r in ar["aging"])
        gap = ar["gross"] - aging_sum
        gap_rate = abs(gap) / ar["gross"]
        if gap_rate > 0.005:
            para(doc, f"⚠️ 账龄分项合计 {yi(aging_sum)} 亿元，与账面余额 "
                      f"{yi(ar['gross'])} 亿元差 {yi(gap)} 亿元，"
                      f"相当于账面余额的 {gap_rate * 100:.1f}%。"
                      f"这说明表里至少有一个档位没抽到（常见是「3 年以上」），"
                      f"因此下面的占比与结论只覆盖已抽取的档位，不能视为完整账龄结构。")
            note(doc, "本节的占比分母仍是账面余额，故各行占比之和也不足 100%。"
                      f"完整账龄表请回看年报第 {ar['page']} 页。")
        else:
            young = next((r for r in ar["aging"] if r["label"] == "1年以内"), None)
            if young and ar["gross"]:
                share = young["cur"] / ar["gross"] * 100
                para(doc, f"一年以内应收账款占比 {share:.2f}%。"
                          + ("账龄结构健康，回款周期集中在一年内。"
                             if share >= 80 else
                             "长账龄占比不低，需结合坏账计提比例与客户集中度一起看；"
                             "若同时伴随收入下滑，可能是放宽信用换规模。"))
            note(doc, "交叉校验：账龄分项合计与账面余额一致；"
                      "附注「账面价值」与资产负债表「应收账款」一致。")

    # 5.4 或有事项 / 承诺 / 关联交易
    q = data.get("qualitative")
    # 5.4 客户集中度
    cu = data.get("customers")
    doc.add_heading("5.4 客户集中度", level=2)
    if not cu:
        para(doc, "未在年报中定位到「前五名客户」的披露（部分行业/公司不披露该指标）。")
    else:
        extra = (f"，其中关联方销售占 {cu['related_ratio']:.2f}%"
                 if cu.get("related_ratio") else "")
        para(doc, f"前五大客户销售额占营业收入 {cu['ratio']:.2f}%{extra}"
                  f"（第 {cu['page']} 页）。")
        if cu["ratio"] >= 30:
            para(doc, "客户集中度偏高：单一或少数客户流失会直接冲击收入，"
                      "需结合客户构成与合同时长判断稳定性。")
        elif cu["ratio"] >= 10:
            para(doc, "客户集中度处于常见区间，未出现对少数客户的显著依赖。")
        else:
            para(doc, "客户高度分散，收入不依赖少数客户 —— 这通常是加分项，"
                      "但也意味着议价能力可能较弱。")
        note(doc, "三大报表看不出一家公司是否依赖少数客户，这一项只能从年报的"
                  "管理层讨论与分析里取。")

    # 5.5 商誉
    gw = data.get("goodwill")
    doc.add_heading("5.5 商誉与减值风险", level=2)
    if not gw or not gw.get("has"):
        para(doc, "资产负债表未列示商誉（或金额为零）—— 该公司不存在商誉减值风险。")
    else:
        share = gw.get("share")
        # 商誉常常小到 0.00x%，此时写 "0.00%" 会被读成"没有" —— 改用"不足 0.01%"
        if share is None:
            seg = ""
        elif share < 0.01:
            seg = "，占归母净资产不足 0.01%"
        else:
            seg = f"，占归母净资产 {share:.2f}%"
        para(doc, f"商誉 {yi(gw['value'])} 亿元{seg}（第 {gw.get('page')} 页）。")
        if share is None:
            para(doc, "未能取得净资产口径，无法判断商誉的重要性。")
        elif share >= 5:
            para(doc, "商誉占净资产比重较高：一旦并购标的业绩不达预期，减值会直接"
                      "侵蚀净资产与当期利润，属于需要重点跟踪的资产负债表风险。")
        elif share >= 1:
            para(doc, "商誉占净资产比重不大，但仍需关注减值测试的关键假设。")
        else:
            para(doc, "商誉金额很小，即使全额减值对净资产的影响也可忽略 —— "
                      "这一项不构成风险点。")
        if gw.get("note_page"):
            para(doc, f"减值测试的具体假设（资产组划分、折现率、增长率）见附注第 "
                      f"{gw['note_page']} 页，本报告不做抽取。")
        else:
            note(doc, "未定位到单独的商誉减值测试附注（金额较小时部分公司不单独披露）。")

    doc.add_heading("5.6 或有事项、承诺事项与关联交易", level=2)
    if not q:
        para(doc, "未在附注中定位到或有事项/承诺事项/关联交易的小节。")
    else:
        for it in q["items"]:
            if it["empty"]:
                bullet(doc, f"{it['kind']}：无重大事项（第 {it['page']} 页）。")
            elif it["excerpt"]:
                bullet(doc, f"{it['kind']}（第 {it['page']} 页）：{it['excerpt']}"
                            + ("…" if len(it["excerpt"]) >= 80 else ""))
            else:
                bullet(doc, f"{it['kind']}：详见附注第 {it['page']} 页"
                            f"（本节为表格式披露，具体金额需回原文核对）。")
        note(doc, "这三项在年报里是散文或复杂表格，本报告只做定位与首句摘录，"
                  "不抽金额 —— 硬抽容易张冠李戴。需要具体金额时可直接按页码回看原文。")

    doc.add_heading("5.7 附注事项的覆盖情况", level=2)
    para(doc, "把本报告对附注**做了什么、做到什么程度**一次列清 —— "
              "比只写「还有哪些没做」更有用：读者能据此判断哪些结论可以放心引用。")
    caption_auto(doc, "附注事项覆盖情况")
    table(doc, ["附注事项", "本报告的处理"], [
        ["审计意见", "已结构化（意见类型 + 段落要点）"],
        ["关键审计事项（KAM）", "已结构化（事项名称列表）"],
        ["资金可用性", "已结构化（现金等价物、受限资金说明）"],
        ["存货跌价准备", "已结构化（计提比例 + 明细表）"],
        ["应收账款账龄", "已结构化（账龄分布 + 坏账计提）"],
        ["客户集中度", "已结构化（前五大客户占比）"],
        ["商誉", "已结构化（账面价值 + 减值测试要点）"],
        ["或有事项 / 承诺 / 关联交易", "仅定位（给出页码 + 首句，金额未抽取）"],
        ["长期资产减值明细", "未覆盖（减值测试的关键假设）"],
        ["关联交易金额与定价依据", "未覆盖（是否存在利益输送需人工判断）"],
        ["或有事项的具体金额", "未覆盖（表外风险敞口大小）"],
        ["投资活动大额流出的构成", "未覆盖（理财 / 定存 / 产能投入的区分）"],
        ["租赁、对外担保金额", "未覆盖"],
    ], widths=[5.4, 10.6])

    para(doc, "「仅定位」指本报告能告诉你这件事在哪一页、原文怎么开头，"
              "但不做金额抽取；「未覆盖」指这三张表和已抽取附注都看不出来，需要人工翻原文。"
              "这些也是下一阶段要补齐的部分 —— 在此之前，本报告的结论应理解为"
              "基于报表数字与已抽取附注的初步判断，不构成对会计质量与表外风险的最终结论。")

    # ---------------- 六、数据质量与可追溯
    doc.add_heading("六、数据质量与可追溯性", level=1)
    doc.add_heading("6.1 数字从哪里来", level=2)
    para(doc, "三张报表的科目取自结构化财务数据（合并口径），每个科目带来源标记；"
              "附注内容（审计意见、关键审计事项、存货跌价、账龄、客户集中度、商誉）"
              "从年报原文抽取，标注页码。比率与同比由这些数字现算，"
              "不由模型生成或复述。")
    para(doc, "缺指标时报告写「未抽到」，不用 0 或估算值顶替；"
              "资产负债表三项对不上时显式告警。本报告本次运行："
              f"未抽到指标 {len(data.get('gaps') or [])} 项，"
              f"恒等式违规 {len(viol)} 项。")

    doc.add_heading("6.2 已完成的校验", level=2)
    ties = data.get("ties") or []
    checked = [t for t in ties if t["status"] in ("ok", "mismatch")]
    passed = [t for t in checked if t["status"] == "ok"]
    if checked:
        para(doc, f"三张报表之间共核对 {len(checked)} 项勾稽关系，{len(passed)} 项通过：")
        for t in checked:
            mark = "通过" if t["status"] == "ok" else "未通过"
            extra = ("" if t.get("diff") is None
                     else f"（差额 {t['diff'] / 1e8:+.2f} 亿元）")
            bullet(doc, f"{t['label']}：{mark}{extra}")
        bad = [t for t in checked if t["status"] == "mismatch"]
        if bad:
            para(doc, "未通过的项已在 3.3 节说明可能原因（合并与母公司口径混排、"
                      "报表重分类），引用相关数字前请回看原文。")
        else:
            para(doc, "报表内与跨表的数字彼此一致，可作为后续分析的可靠基础。")

    val = data.get("validation")
    if val and val.get("ok"):
        doc.add_heading("6.3 外部核验（与东方财富逐项比对）", level=2)
        rows, total = [], {"n": 0, "ok": 0, "bad": 0, "soft": 0, "miss": 0}
        for stmt in ("资产负债表", "利润表", "现金流量表"):
            rs = [r for r in val["rows"] if r["statement"] == stmt]
            if not rs:
                continue
            n = len([r for r in rs if r["status"] != "missing_theirs"])
            ok = sum(1 for r in rs if r["status"] == "ok")
            bad = sum(1 for r in rs if r["status"] == "mismatch")
            soft = sum(1 for r in rs if r["status"] in ("restated", "reclassified"))
            miss = sum(1 for r in rs if r["status"] == "missing_ours")
            rows.append([stmt, str(n), str(ok), str(bad), str(soft), str(miss)])
            total["n"] += n
            total["ok"] += ok
            total["bad"] += bad
            total["soft"] += soft
            total["miss"] += miss
        rows.append(["合计", str(total["n"]), str(total["ok"]), str(total["bad"]),
                     str(total["soft"]), str(total["miss"])])
        caption_auto(doc, "与 AkShare 的逐项比对")
        table(doc, ["报表", "比对项数", "一致", "不符", "口径差异", "漏抽"], rows,
              widths=[3.6, 2.4, 2.0, 2.0, 2.6, 2.0])
        acc = (total["ok"] / total["n"] * 100) if total["n"] else 0.0
        note(doc, f"核验口径：`python main.py validate --company {company}`，"
                  f"容差 2 元。本次严格一致率 {acc:.1f}%。")

    doc.add_heading("6.4 已知局限", level=2)
    bullet(doc, "附注抽取依赖 PDF 版式。个别年份的排版差异可能导致某项附注未定位到，"
                "此时报告写「未定位到」而不是推测。")
    bullet(doc, "「本年比上年增减」栏位年报中也可能给出，但本报告一律用两列金额现算，"
                "避免与年报口径不一致时无法察觉。")
    bullet(doc, "金额单位以入库时识别的声明为准（元/千元/万元/百万元），不做事后猜测。")

    # ---------------- 附录
    doc.add_heading("附录  指标出处清单", level=1)
    rows = []
    for s in data["sections"]:
        for r in s["rows"]:
            rows.append([s["title"].replace("分析", ""), r["label"],
                         cell_value(r["label"], r["cur"]),
                         f"第 {r['page']} 页", r["confidence"]])
    caption_auto(doc, "全部指标及其出处页码与置信度")
    # 指标名是文本，必须左对齐并给足宽度 —— 右对齐会把「经营活动现金流量净额」
    # 折成「经营活动现金流量净 / 额」两行。
    table(doc, ["报表", "指标", "本期", "出处", "置信度"], rows,
          widths=[3.0, 5.6, 3.0, 2.2, 2.2], align_right_from=2)
    note(doc, "confidence=high 表示该指标在报表页上只有一行命中；"
              "medium 表示有多行命中（如「营业总收入」与「其中：营业收入」并存），"
              "已按「最长别名优先」取更具体的一行。")

    # ---------------- 页脚
    footer = doc.sections[0].footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = footer.add_run(f"{company} {period} {suffix}财务分析报告　·　第 ")
    set_run(r, size=8, color=GREY)
    add_page_number(footer)
    r = footer.add_run(" 页")
    set_run(r, size=8, color=GREY)

    return doc


def open_file(path) -> bool:
    """兼容旧调用：委托给 `terminal_link.open_path`。"""
    from terminal_link import open_path
    return open_path(path)


def save(data: dict, narrative: "dict | None", out_path) -> Path:
    """渲染并保存，返回落盘路径。"""
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc = build(data, narrative)

    # **页脚自检**：页脚公司名必须与报告主体一致。曾经出现过"报告是 A 公司、
    # 页脚是 B 公司"的投诉（很可能是旧版本文件），这里落盘前再核一遍，
    # 不一致就地改正，避免再交出去一份自相矛盾的文件。
    try:
        footer = doc.sections[0].footer.paragraphs[0]
        expect = str(data.get("company") or "")
        if expect and expect not in footer.text:
            want = (f"{expect} {data.get('period')} "
                    f"{'年度' if data.get('report_type', '年报') == '年报' else data.get('report_type')}"
                    "财务分析报告　·　第 ")
            for run in list(footer.runs):
                run._element.getparent().remove(run._element)
            r = footer.add_run(want)
            set_run(r, size=8, color=GREY)
            add_page_number(footer)
            r2 = footer.add_run(" 页")
            set_run(r2, size=8, color=GREY)
    except Exception:                        # noqa: BLE001
        pass                                 # 页脚修不了也不能挡住出报告

    doc.save(out_path)
    # **不再自动弹出**：改为在终端打印可点击链接（见 agent._document_suffix）。
    # 想恢复自动打开：`ARA_OPEN_REPORT=1`。
    import os
    if os.environ.get("ARA_OPEN_REPORT") == "1" and not os.environ.get("PYTEST_CURRENT_TEST"):
        open_file(out_path)
    return out_path
