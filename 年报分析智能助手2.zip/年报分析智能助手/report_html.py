"""把库里的数据渲染成一个**自包含 HTML 看板**（单文件，双击就开）。

## 为什么是静态 HTML

- **不依赖服务器**：没有后端进程，交上去、发出去都能直接打开
- **不联网**：图表用内联 SVG 手写，不引 CDN，断网也能看
- **数据内嵌**：所有数字以 JSON 写在页面里，改不了、也丢不了

## 里面有什么

- 选公司 → 选指标 → 看多年趋势（折线 + 数值表）
- 三张报表的勾稽校验结果（一致 / 不平 / 无法核验）
- 每个数字都带出处：`结构化接口` 或 `第 N 页`
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

#: 默认展示的指标（按重要性排序；库里没有的自动跳过）
DEFAULT_METRICS = [
    "营业收入", "营业成本", "净利润", "归母净利润",
    "资产总计", "负债合计", "所有者权益合计",
    "经营活动现金流量净额", "现金及现金等价物净增加额",
]


def collect(db_path=None, companies=None) -> dict:
    """从库里取出看板需要的全部数据。"""
    import sqlite3

    db = str(db_path or (ROOT / "data" / "structured.db"))
    conn = sqlite3.connect(db)
    try:
        rows = conn.execute(
            "SELECT id, company, report_type, period FROM reports ORDER BY company, period"
        ).fetchall()
        data = {}
        for rid, company, rtype, period in rows:
            if companies and company not in companies:
                continue
            ms = conn.execute(
                "SELECT metric_name, period, value, source_page, statement "
                "FROM metrics WHERE report_id=?", (rid,)).fetchall()
            ms_with_stmt = ms
            key = f"{company}|{rtype}"
            entry = data.setdefault(key, {"company": company, "type": rtype,
                                          "periods": [], "metrics": {}})
            if period not in entry["periods"]:
                entry["periods"].append(period)
            stmt_of = entry.setdefault("stmt", {})
            for name, p, value, page, stmt in ms_with_stmt:
                slot = entry["metrics"].setdefault(name, {})
                slot.setdefault(p, {"v": value, "p": page})
                stmt_of.setdefault(name, stmt or "")
            for y in {row[1] for row in ms}:
                if y not in entry["periods"]:
                    entry["periods"].append(y)
        for entry in data.values():
            entry["periods"] = sorted(set(entry["periods"]))
    finally:
        conn.close()
    return data


#: 非金额指标的单位（其余一律按"亿元"显示）
UNIT_OVERRIDES = {
    "基本每股收益": "元/股",
    "稀释每股收益": "元/股",
}


def unit_of(name: str) -> str:
    return UNIT_OVERRIDES.get(name, "亿元")


def _fmt(v) -> str:
    """金额 → 亿元（保留两位），None → —。"""
    if v is None:
        return "—"
    return f"{v / 1e8:,.2f}"


def refresh_quietly(db_path=None) -> "Path | None":
    """**入库后自动刷新看板**。失败不抛、测试环境跳过。

    为什么需要：看板是生成时的快照，新解析一家公司不会自动出现在里面。
    每次入库后顺手重建一次（0.2 秒），用户下次打开就是最新的。
    """
    import os

    if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("ARA_NO_DASHBOARD"):
        return None
    try:
        return build_html(db_path=db_path)
    except Exception:                    # noqa: BLE001
        return None                      # 看板刷不了不能影响入库本身


def count_reports(db_path=None) -> int:
    """库里**真实入库的报告数**（不是期间数）。

    注意区别：一份年报会同时存本期与上期两列科目，所以各公司"期间数"之和
    会大于报告数（实测 50 份 → 89 个期间）。页头必须报报告数，否则数字对不上。
    """
    import sqlite3

    db = str(db_path or (ROOT / "data" / "structured.db"))
    try:
        with sqlite3.connect(db) as conn:
            return conn.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
    except Exception:                    # noqa: BLE001
        return 0


def render_html(db_path=None, companies=None, default_company=None) -> str:
    """返回看板的 HTML 字符串（不落盘）——给本地服务用，每次请求都读最新数据。

    `default_company`：打开时默认选中的公司。用户在对话里问的是哪家，
    看板就默认停在哪家 —— 否则每次都要在 36 项里再找一遍。
    """
    data = collect(db_path, companies)
    payload = json.dumps(data, ensure_ascii=False, default=str)

    all_metrics = sorted({m for e in data.values() for m in e["metrics"]})
    default = [m for m in DEFAULT_METRICS if m in all_metrics] or all_metrics[:5]

    # 默认选中：优先"对话里刚分析的那家"，其次第一条
    default_co = ""
    if default_company:
        for k, e in data.items():
            if e["company"] == default_company:
                default_co = k
                break
    if not default_co and data:
        default_co = next(iter(data))

    # 指标 → 报表归属：**跨公司合并**。某家公司这份报告没解析出归属时，
    # 只要别的公司有，就能归到对应报表，不会落到"其他"里。
    stmt_map = {}
    for e in data.values():
        for m, st in (e.get("stmt") or {}).items():
            if st and m not in stmt_map:
                stmt_map[m] = st

    units = {m: unit_of(m) for m in all_metrics}
    html = _TEMPLATE.replace("__UNITS__", json.dumps(units, ensure_ascii=False)) \
                    .replace("__DATA__", payload) \
                    .replace("__METRICS__", json.dumps(all_metrics, ensure_ascii=False)) \
                    .replace("__DEFAULT__", json.dumps(default, ensure_ascii=False)) \
                    .replace("__NREPORT__", str(count_reports(db_path))) \
                    .replace("__NCOMPANY__", str(len({e["company"] for e in data.values()}))) \
                    .replace("__STAMP__", __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M")) \
                    .replace("__NMETRIC__", str(len(all_metrics))) \
                    .replace("__STMTS__", json.dumps(stmt_map, ensure_ascii=False)) \
                    .replace("__DEFAULT_CO__", json.dumps(default_co, ensure_ascii=False))

    return html


def build_html(db_path=None, companies=None, out_path=None,
               default_company=None) -> Path:
    """生成静态看板文件（发出去/交付时用）。"""
    html = render_html(db_path, companies, default_company)
    out = Path(out_path) if out_path else (ROOT / "reports" / "年报数据看板.html")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    return out


_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>年报数据看板</title>
<style>
  :root{
    --ink:#16241e; --muted:#6d7a72; --line:#e4e2d8;
    --paper:#f6f4ee; --card:#fffdf8;
    --green:#12442f; --green2:#1c5c3f; --gold:#bf9a3e;
    --blue:#2b6cb0; --red:#b4472e; --teal:#0f766e; --plum:#7b3fa0; --amber:#b8770f;
  }
  *{box-sizing:border-box}
  body{
    margin:0; color:var(--ink); background:var(--paper);
    font:15px/1.65 -apple-system,BlinkMacSystemFont,"PingFang SC","Hiragino Sans GB",
         "Microsoft YaHei",sans-serif;
    -webkit-font-smoothing:antialiased;
  }
  h1,h2,h3{font-family:"Songti SC","Noto Serif SC",Georgia,"PingFang SC",serif; font-weight:600}

  /* ---------- 顶部 ---------- */
  header{
    background:linear-gradient(135deg,#0e3a28 0%,#15523a 55%,#1b6647 100%);
    color:#f3efe4; padding:34px 40px 26px; position:relative; overflow:hidden;
  }
  header::after{
    content:""; position:absolute; left:0; right:0; bottom:0; height:3px;
    background:linear-gradient(90deg,var(--gold),#e8d9a8,var(--gold)); opacity:.9;
  }
  .eyebrow{font-size:12px; letter-spacing:.28em; text-transform:uppercase; color:#c9b98f}
  header h1{margin:10px 0 8px; font-size:30px; letter-spacing:.02em; color:#fdfbf4}
  .meta{display:flex; flex-wrap:wrap; gap:10px; margin-top:14px; font-size:12.5px; color:#d8d2bd}
  .meta span{border:1px solid rgba(255,255,255,.22); border-radius:999px; padding:3px 11px}
  .stats{display:flex; gap:14px; flex-wrap:wrap; margin-top:20px}
  .stat{
    background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.16);
    border-radius:10px; padding:10px 16px; min-width:104px; backdrop-filter:blur(2px);
  }
  .stat b{display:block; font-size:22px; font-family:"Songti SC",Georgia,serif; color:#fff8e6}
  .stat i{font-style:normal; font-size:12px; color:#c9c3ae}

  /* ---------- 布局 ---------- */
  .wrap{display:grid; grid-template-columns:300px minmax(0,1fr); gap:22px; padding:24px 40px 56px}
  @media(max-width:900px){ .wrap{grid-template-columns:1fr} header{padding:26px 20px 20px} .wrap{padding:18px 16px 40px} }
  .card{background:var(--card); border:1px solid var(--line); border-radius:14px;
        box-shadow:0 1px 2px rgba(20,35,25,.04),0 8px 24px -18px rgba(20,35,25,.35)}
  .card .hd{padding:16px 18px 0; font-size:12px; letter-spacing:.18em; color:var(--muted);
            text-transform:uppercase}
  .card .bd{padding:14px 18px 18px}

  label{display:block; font-size:12.5px; color:var(--muted); margin:16px 0 7px; letter-spacing:.02em}
  label:first-child{margin-top:0}
  input[type=text],select{
    width:100%; padding:8px 10px; border:1px solid var(--line); border-radius:9px;
    background:#fff; font-size:13.5px; color:var(--ink); outline:none;
  }
  input[type=text]:focus,select:focus{border-color:var(--green2); box-shadow:0 0 0 3px rgba(28,92,63,.10)}

  /* 指标多选列表：**常驻可见**，取消勾选后仍留在列表里，随时可再勾回来 */
  .mlist{margin-top:8px}
  .stmt-panel{border:1px solid var(--line); border-radius:10px; margin-bottom:10px;
              overflow:hidden; background:#fff}
  .stmt-panel:last-child{margin-bottom:0}
  .stmt-panel .rows{max-height:196px; overflow:auto}
  .stmt-panel .phead{display:flex; align-items:center; justify-content:space-between;
                     padding:8px 11px; background:#f7f4ea; border-bottom:1px solid #efece0}
  .stmt-panel .phead b{font-size:12.5px; font-weight:600; letter-spacing:.06em; color:#31473a}
  .stmt-panel .phead .n{font-size:11px; color:var(--muted)}
  .stmt-panel .phead .pick{font-size:11px; color:var(--green2); cursor:pointer;
                           border:1px solid #cfdcd2; border-radius:6px; padding:1px 7px;
                           background:#eef5ef}
  .stmt-panel .phead .pick:hover{background:#e2eee5}
  .mitem{display:flex; align-items:center; gap:9px; padding:7px 11px; font-size:13px; cursor:pointer;
         border-bottom:1px solid #f2efe4}
  .mitem:last-child{border-bottom:0}
  .mitem:hover{background:#f6f3e9}
  .mitem.on{background:#eef5ef}
  .mitem.off{opacity:.45; cursor:not-allowed}
  .mitem.off:hover{background:transparent}
  .box{width:16px; height:16px; border:1.5px solid #c7c3b2; border-radius:4px; flex:none;
       display:inline-flex; align-items:center; justify-content:center;
       font-size:11px; line-height:1; color:#fff; background:#fff; padding:0}
  .box span{display:block; transform:translateY(-1px)}
  .mitem.on .box{background:var(--green2); border-color:var(--green2)}
  .mitem .nm{flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap}
  .mitem .u{color:var(--muted); font-size:11px; flex:none}
  .hint{font-size:11.5px; color:var(--muted); margin-top:8px}
  .subhint{font-size:11px; color:#8a948c; margin-top:6px; line-height:1.5;
           border-left:2px solid #d9d5c6; padding-left:8px}
  .picker{position:relative}
  .picker #csearch{padding-right:30px; cursor:pointer}
  .caret{position:absolute; right:11px; top:50%; transform:translateY(-50%); font-size:11px;
         color:var(--muted); pointer-events:none; transition:transform .15s}
  .clist{position:absolute; left:0; right:0; top:40px; z-index:30; max-height:260px; overflow:auto;
         background:var(--card); border:1px solid var(--line); border-radius:10px;
         box-shadow:0 10px 26px -12px rgba(20,35,25,.45); display:none}
  .clist.open{display:block}
  .bulk{display:flex; gap:8px; margin:10px 0 0}
  .bulk button{flex:1; padding:6px 8px; font-size:12.5px; border:1px solid var(--line);
               border-radius:8px; background:#fff; color:var(--ink); cursor:pointer}
  .bulk button:hover{background:#f4f1e6; border-color:#cfc9b6}
  .ghead{display:flex; align-items:center; justify-content:space-between; gap:8px;
         padding:8px 11px; background:#f7f4ea; font-size:12px; color:#4a5a4f;
         cursor:pointer; border-bottom:1px solid #efecdf; position:sticky; top:0; z-index:1}
  .ghead b{font-weight:600; letter-spacing:.04em}
  .ghead .gcount{color:var(--muted); font-size:11px}
  .ghead:hover{background:#f2eee0}
  .ghead .caret2{transition:transform .15s; font-size:10px; color:var(--muted)}
  .ghead.closed .caret2{transform:rotate(-90deg)}
  .stmt-title{font-size:12px; letter-spacing:.18em; color:var(--muted);
              text-transform:uppercase; margin:0 0 4px}
  .stmt-block{margin-bottom:26px}

  .stmt-block:last-child{margin-bottom:0}
  .insight{margin-top:10px; border:1px solid #e6e2d3; border-left:3px solid var(--green2);
           border-radius:8px; background:#fbfaf4; padding:10px 13px}
  .insight .ih{font-size:11px; letter-spacing:.14em; color:var(--green2); margin-bottom:6px}
  .insight ul{margin:0; padding-left:16px}
  .insight li{font-size:13px; line-height:1.75; color:#33413a}
  .insight .note{font-size:11px; color:var(--muted); margin-top:7px}
  .citem{display:flex; align-items:center; gap:8px; padding:7px 11px; font-size:13px; cursor:pointer;
         border-bottom:1px solid #f2efe4}
  .citem:last-child{border-bottom:0}
  .citem:hover{background:#f6f3e9}
  .citem.on{background:#eef5ef; font-weight:600; color:var(--green2)}
  .citem .nm{flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap}
  .citem .u{color:var(--muted); font-size:11px; flex:none}
  #ylist .citem{justify-content:flex-start}
  .ystate{font-size:11px; color:var(--muted); margin-top:6px}

  /* ---------- 图表 ---------- */
  .chartbox{padding:6px 4px 0}
  .legend{display:flex; gap:16px; flex-wrap:wrap; font-size:12.5px; color:var(--muted); margin-top:10px}
  .legend i{display:inline-block; width:11px; height:11px; border-radius:3px; margin-right:6px; vertical-align:-1px}
  .tips{font-size:12px; color:var(--muted); margin-top:10px; line-height:1.7}

  /* ---------- 表格 ---------- */
  table{width:100%; border-collapse:collapse; font-size:13.5px}
  th,td{padding:9px 10px; border-bottom:1px solid #efece1; text-align:right; white-space:nowrap}
  th:first-child,td:first-child{text-align:left}
  thead th{color:var(--muted); font-weight:600; font-size:12px; letter-spacing:.04em;
           border-bottom:1.5px solid #e0dcce}
  tbody tr:hover{background:#faf8f1}
  .muted{color:var(--muted)}
  .empty{padding:40px 10px; text-align:center; color:var(--muted); font-size:13px}
  .hover-line{stroke:#b9b3a0; stroke-width:1; stroke-dasharray:4 3; opacity:0; pointer-events:none}
  #tip{position:fixed; z-index:99; pointer-events:none; display:none;
       background:#132a20; color:#f6f2e5; border-radius:9px; padding:9px 12px;
       font-size:12.5px; line-height:1.7; box-shadow:0 8px 24px -10px rgba(0,0,0,.55);
       max-width:260px}
  #tip b{font-weight:600; color:#fff}
  #tip .row{display:flex; align-items:center; gap:7px; white-space:nowrap}
  #tip .dot{width:8px; height:8px; border-radius:2px; flex:none}
  #tip .t{opacity:.75; margin-right:2px}
</style>
</head>
<body>
<header>
  <div class="eyebrow">A 股 · 合并口径 · 结构化数据</div>
  <h1>年报数据看板</h1>
  <div class="meta">
    <span>金额单位：亿元</span>
    <span>每股收益：元/股</span>
    <span>数据截至 __STAMP__</span>
  </div>
  <div class="stats">
    <div class="stat"><b>__NCOMPANY__</b><i>家公司</i></div>
    <div class="stat"><b>__NREPORT__</b><i>份报告</i></div>
    <div class="stat"><b>__NMETRIC__</b><i>个可选指标</i></div>
    <div class="stat"><b id="nYr">—</b><i>当前跨度（年）</i></div>
  </div>
</header>

<div class="wrap">
  <aside class="card">
    <div class="hd">筛选</div>
    <div class="bd">
      <label>公司 / 报表类型（可下拉、可搜索）</label>
      <div class="picker">
        <input id="csearch" type="text" placeholder="点此展开全部，或直接输入搜索"
               autocomplete="off" role="combobox" aria-expanded="false">
        <span class="caret" id="ccaret">▾</span>
        <div class="clist" id="clist"></div>
      </div>
      <div class="hint" id="chint"></div>

      <label>年份（可下拉、可多选）</label>
      <div class="picker">
        <input id="ysearch" type="text" placeholder="点此展开全部年份，或输入搜索"
               autocomplete="off" role="combobox">
        <span class="caret" id="ycaret">▾</span>
        <div class="clist" id="ylist"></div>
      </div>
      <div class="hint" id="yhint"></div>

      <label>指标（可搜索、可多选）</label>
      <input id="msearch" type="text" placeholder="搜索，如 营业 / 现金流" autocomplete="off">
      <div class="bulk">
        <button id="mAll" type="button">全选</button>
        <button id="mNone" type="button">清空</button>
        <button id="mDefault" type="button">常用</button>
      </div>
      <div class="mlist" id="mlist"></div>
      <div class="hint" id="mhint"></div>
      <div class="subhint">只显示这家公司报告里有的指标<br>（不同行业科目不同，银行/券商的专用科目在制造业公司里不出现）</div>

    </div>
  </aside>

  <main>
    <section class="card" style="margin-bottom:22px">
      <div class="hd">趋势</div>
      <div class="bd chartbox">
        <div id="chart"></div>
        <div class="legend" id="legend"></div>
        <div class="tips">数值取合并口径，已统一换算为亿元；鼠标悬停圆点看具体数值。</div>
      </div>
    </section>

    <section class="card">
      <div class="hd">数值与出处</div>
      <div class="bd" style="overflow-x:auto">
        <table id="tbl"></table>
      </div>
    </section>
  </main>
</div>

<div id="tip"></div>

<script>
const DATA = __DATA__;
const UNITS = __UNITS__;
const STMT_OF = __STMTS__;
const ALL_METRICS = __METRICS__;
const DEFAULT_METRICS = __DEFAULT__;
const SERIES_COLORS = ["#2b6cb0","#b4472e","#0f766e","#7b3fa0","#b8770f","#2f855a"];

const keys = Object.keys(DATA);
const DEFAULT_CO = __DEFAULT_CO__;
const sel = {
  co: (DEFAULT_CO && DATA[DEFAULT_CO]) ? DEFAULT_CO : keys[0],
  metrics: new Set(DEFAULT_METRICS),
  stmtOf: STMT_OF,
  years: new Set()            // 空 = 用该公司的全部年份
};

/* 全局归属表；兼容老数据里某条空着的情况 */
function syncStmt(){
  sel.stmtOf = Object.assign({}, STMT_OF, DATA[sel.co].stmt || {});
}

function unitOf(m){ return UNITS[m] || "亿元"; }
function disp(v, unit){ return (v === null || v === undefined) ? null : (unit === "亿元" ? v / 1e8 : v); }
function fmtNum(v, digits=2){
  if(v === null || v === undefined) return "—";
  return v.toLocaleString("zh-CN", {minimumFractionDigits:digits, maximumFractionDigits:digits});
}
function niceTicks(lo, hi){
  const span = hi - lo || Math.abs(hi) || 1;
  const raw = span / 4;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
  const start = Math.floor(lo / step) * step;
  const end = Math.ceil(hi / step) * step;
  const ticks = [];
  for(let v = start; v <= end + step * 1e-9; v += step) ticks.push(+v.toFixed(10));
  return {ticks, lo:start, hi:end};
}

function labelOf(k){
  return `${DATA[k].company} · ${DATA[k].type}`;
}

/* 公司选择器：**点开是下拉**（能看到全部），输入则筛选，选中后收起 */
function initSelect(){
  const input = document.getElementById("csearch");
  const list  = document.getElementById("clist");
  const hint  = document.getElementById("chint");
  const caret = document.getElementById("ccaret");

  function matches(){
    const kw = (input.value || "").trim().toLowerCase();
    if(!kw || kw === labelOf(sel.co).toLowerCase()) return keys;   // 未输入=全部
    return keys.filter(k => labelOf(k).toLowerCase().includes(kw));
  }

  function open(){
    list.classList.add("open");
    input.setAttribute("aria-expanded", "true");
    caret.style.transform = "translateY(-50%) rotate(180deg)";
    renderList();
  }
  function close(){
    list.classList.remove("open");
    input.setAttribute("aria-expanded", "false");
    caret.style.transform = "translateY(-50%)";
    input.value = labelOf(sel.co);       // 收起时恢复成当前选中项
  }

  function renderList(){
    const hits = matches();
    hint.textContent = `${hits.length}/${keys.length} 项`;
    list.innerHTML = hits.length
      ? hits.map(k => {
          const on = k === sel.co;
          return `<div class="citem${on?" on":""}" data-k="${k}">
                    <span class="nm">${on ? "✓ " : ""}${labelOf(k)}</span>
                    <span class="u">${DATA[k].periods.length} 期</span>
                  </div>`;
        }).join("")
      : `<div class="empty" style="padding:18px">没有匹配的公司</div>`;
  }

  input.addEventListener("focus", open);
  input.addEventListener("click", open);
  input.addEventListener("input", () => { open(); });   // 输入时保持展开并筛选

  list.addEventListener("mousedown", (ev) => {          // mousedown 抢在 blur 之前
    const it = ev.target.closest(".citem");
    if(!it) return;
    sel.co = it.dataset.k;
    syncStmt();
    if(sel.resetYears) sel.resetYears();      // 换公司：年份回到该公司全部
    close(); renderList(); render();
  });

  document.addEventListener("click", (ev) => {
    if(!ev.target.closest(".picker")) close();
  });
  input.addEventListener("keydown", (ev) => {
    if(ev.key === "Escape"){ close(); input.blur(); }
    if(ev.key === "Enter"){                               // 回车选第一个匹配
      const first = matches()[0];
      if(first){ sel.co = first; close(); renderList(); render(); }
    }
  });

  input.value = labelOf(sel.co);
  renderList();
}

/* 年份选择器：可下拉、可多选、可搜索；选一年或多年都行 */
function allYears(){
  const set = new Set();
  keys.forEach(k => (DATA[k].periods || []).forEach(y => set.add(String(y))));
  return [...set].sort();
}

function initYearPicker(){
  const input = document.getElementById("ysearch");
  const list  = document.getElementById("ylist");
  const hint  = document.getElementById("yhint");
  const caret = document.getElementById("ycaret");
  const years = allYears();

  function available(){                       // 当前公司有哪些年
    return new Set((DATA[sel.co].periods || []).map(String));
  }
  function chosen(){
    const avail = available();
    const base = sel.years.size ? [...sel.years] : [...avail];
    return base.filter(y => avail.has(y));
  }
  function label(){
    const c = chosen().sort();
    if(!c.length) return "未选择年份";
    return c.length === available().size && c.length > 2
      ? `${c[0]}–${c[c.length-1]}（全部 ${c.length} 年）`
      : c.join("、");
  }
  function open(){
    list.classList.add("open");
    caret.style.transform = "translateY(-50%) rotate(180deg)";
    renderList();
  }
  function close(){
    list.classList.remove("open");
    caret.style.transform = "translateY(-50%)";
    input.value = label();
  }
  function renderList(){
    const kw = (input.value || "").trim();
    const filtering = kw && kw !== label();
    const hits = years.filter(y => !filtering || y.includes(kw));
    const avail = available();
    const cur = new Set(chosen());
    hint.textContent = `已选 ${cur.size} 年 · 该公司有 ${avail.size} 年`;
    list.innerHTML = hits.length ? hits.map(y => {
      const has = avail.has(y);
      const on = cur.has(y);
      return `<div class="citem${on ? " on" : ""}${has ? "" : " off"}" data-y="${y}">
                <span class="nm">${on ? "✓ " : ""}${y} 年</span>
                <span class="u">${has ? "" : "无数据"}</span>
              </div>`;
    }).join("") : `<div class="empty" style="padding:18px">没有匹配的年份</div>`;
  }

  input.addEventListener("focus", open);
  input.addEventListener("click", open);
  input.addEventListener("input", open);
  list.addEventListener("mousedown", (ev) => {
    const it = ev.target.closest(".citem");
    if(!it) return;
    const y = it.dataset.y;
    if(!available().has(y)) return;          // 该公司没有这一年
    if(sel.years.size === 0) sel.years = new Set(chosen());   // 首次操作先固化
    if(sel.years.has(y)) sel.years.delete(y); else sel.years.add(y);
    renderList(); render();
    input.value = label();
  });
  document.addEventListener("click", (ev) => {
    if(!ev.target.closest("#ysearch, #ylist, .picker:has(#ysearch)")) {
      if(list.classList.contains("open")) close();
    }
  });
  input.addEventListener("keydown", (ev) => { if(ev.key === "Escape"){ close(); input.blur(); } });

  // 切公司时重置为该公司的全部年份
  sel.resetYears = () => { sel.years = new Set(); input.value = label(); renderList(); };
  input.value = label();
  renderList();
}

/* 指标列表：**三大报表各占一块独立区域**，各自滚动，左栏不留空白 */
const STMT_ORDER = ["资产负债表", "利润表", "现金流量表", "其他"];

function initPicker(){
  const input = document.getElementById("msearch");
  const list  = document.getElementById("mlist");
  const hint  = document.getElementById("mhint");

  function matches(){
    const kw = (input.value || "").trim().toLowerCase();
    return kw ? ALL_METRICS.filter(m => m.toLowerCase().includes(kw)) : ALL_METRICS;
  }

  function renderList(){
    const hits = matches();
    hint.textContent = `已选 ${sel.metrics.size} 个 · 共 ${hits.length}/${ALL_METRICS.length} 个`;
    if(!hits.length){
      list.innerHTML = `<div class="empty" style="padding:22px">没有匹配的指标</div>`;
      return;
    }

    // **只列出这家公司报告里有的指标**：不同行业科目差异很大
    // （银行的"吸收存款"在制造业公司里根本不存在），列出来只会让人困惑。
    const by = {};
    hits.filter(m => DATA[sel.co].metrics[m]).forEach(m => {
      const st = sel.stmtOf[m] || "其他";
      (by[st] = by[st] || []).push(m);
    });

    list.innerHTML = STMT_ORDER.filter(st => by[st]).map(st => {
      const names = by[st];
      const avail = names.filter(n => DATA[sel.co].metrics[n]);
      const on = avail.filter(n => sel.metrics.has(n)).length;
      const rows = names.map(m => {
        const has = !!DATA[sel.co].metrics[m];
        const picked = has && sel.metrics.has(m);
        const cls = "mitem" + (picked ? " on" : "") + (has ? "" : " off");
        return `<div class="${cls}" data-m="${m}"${has ? "" : ' title="这家公司的报告里没有这个指标"'}>
                  <span class="box">${picked ? "<span>✓</span>" : ""}</span>
                  <span class="nm">${m}</span>
                  <span class="u">${has ? unitOf(m) : "无"}</span>
                </div>`;
      }).join("");
      return `<div class="stmt-panel" data-st="${st}">
                <div class="phead">
                  <span><b>${st}</b> <span class="n">${on}/${names.length}</span></span>
                  <span class="pick" data-pick="${st}">${on === avail.length && avail.length ? "清空" : "全选"}</span>
                </div>
                <div class="rows">${rows}</div>
              </div>`;
    }).join("");
  }

  function toggle(m){
    if(!DATA[sel.co].metrics[m]){
      const t = document.getElementById("tip");
      t.textContent = "这家公司的报告里没有「" + m + "」这个指标";
      t.style.display = "block";
      clearTimeout(toggle._t);
      toggle._t = setTimeout(() => { t.style.display = "none"; }, 2200);
      return;
    }
    if(sel.metrics.has(m)) sel.metrics.delete(m); else sel.metrics.add(m);
    renderList(); render();
  }

  input.addEventListener("input", renderList);

  list.addEventListener("click", (ev) => {
    const pick = ev.target.closest(".pick");           // 整组全选 / 清空
    if(pick){
      const st = pick.dataset.pick;
      const names = ALL_METRICS.filter(m => (sel.stmtOf[m] || "其他") === st
                                          && DATA[sel.co].metrics[m]);
      const allOn = names.every(m => sel.metrics.has(m));
      names.forEach(m => allOn ? sel.metrics.delete(m) : sel.metrics.add(m));
      renderList(); render();
      return;
    }
    const it = ev.target.closest(".mitem");
    if(it && it.dataset.m) toggle(it.dataset.m);
  });

  document.getElementById("mAll").onclick = () => {
    ALL_METRICS.forEach(m => { if(DATA[sel.co].metrics[m]) sel.metrics.add(m); });
    renderList(); render();
  };
  document.getElementById("mNone").onclick = () => {
    sel.metrics.clear(); renderList(); render();
  };
  document.getElementById("mDefault").onclick = () => {
    sel.metrics = new Set(DEFAULT_METRICS.filter(
      m => ALL_METRICS.includes(m) && DATA[sel.co].metrics[m]));
    renderList(); render();
  };

  renderList();
}

function seriesFor(e, m, periods, unit){
  return periods.map(p => {
    const hit = (e.metrics[m] || {})[p];
    return hit ? disp(hit.v, unit) : null;
  });
}

function drawOneChart(periods, series, unit){
  const W = 880, H = 330, L = 78, R = 28, T = 30, B = 48;
  const innerW = W - L - R, innerH = H - T - B;
  const vals = series.flatMap(s => s.values).filter(v => v !== null);
  if(!vals.length) return {html: `<div class="empty">所选指标在该公司没有数据。</div>`, cfg: null};

  let hiRaw = Math.max(...vals), loRaw = Math.min(...vals);
  if(hiRaw === loRaw){ hiRaw = loRaw + Math.abs(loRaw || 1) * 0.1; loRaw = Math.min(0, loRaw); }
  const {ticks, lo, hi} = niceTicks(loRaw, hiRaw);
  const x = i => L + (periods.length === 1 ? innerW/2 : innerW * i / (periods.length - 1));
  const y = v => T + innerH * (1 - (v - lo) / (hi - lo || 1));

  let g = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${unit}趋势">`;
  g += `<text x="${L-56}" y="${T-10}" font-size="11.5" fill="#6d7a72">${unit}</text>`;
  ticks.forEach(v => {
    const py = y(v);
    g += `<line x1="${L}" y1="${py}" x2="${W-R}" y2="${py}" stroke="#eee9dc"/>`;
    g += `<text x="${L-10}" y="${py+4}" text-anchor="end" font-size="11.5" fill="#6d7a72">${fmtNum(v, Math.abs(v) < 10 ? 2 : 0)}</text>`;
  });
  g += `<line x1="${L}" y1="${y(lo)}" x2="${W-R}" y2="${y(lo)}" stroke="#d6d1c1"/>`;
  g += `<line x1="${L}" y1="${y(lo)}" x2="${L}" y2="${y(hi)}" stroke="#d6d1c1"/>`;
  periods.forEach((p,i) => {
    g += `<text x="${x(i)}" y="${H-18}" text-anchor="middle" font-size="11.5" fill="#6d7a72">${p}</text>`;
  });
  series.forEach((s,si) => {
    const color = SERIES_COLORS[si % SERIES_COLORS.length];
    let d = "", started = false;
    s.values.forEach((v,i) => {
      if(v === null) return;
      d += (started ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1) + " ";
      started = true;
    });
    if(d) g += `<path d="${d}" fill="none" stroke="${color}" stroke-width="2.4" stroke-linejoin="round"/>`;
    s.values.forEach((v,i) => {
      if(v === null) return;
      g += `<circle cx="${x(i)}" cy="${y(v)}" r="4.2" fill="#fffdf8" stroke="${color}" stroke-width="2.2"/>`;
    });
  });
  // 悬停竖线（默认隐藏，靠 JS 控制）
  g += `<line class="hover-line" x1="0" y1="${T}" x2="0" y2="${T+innerH}" />`;
  g += `</svg>`;

  return {html: g, cfg: {periods, series, unit, L, R, W, innerW, T, innerH, lo, hi}};
}

/* 柱状图：同一组数据换个看法，适合比较各年高低 */
function drawOneBarChart(periods, series, unit){
  const W = 880, H = 300, L = 78, R = 28, T = 26, B = 48;
  const innerW = W - L - R, innerH = H - T - B;
  const vals = series.flatMap(s => s.values).filter(v => v !== null);
  if(!vals.length) return {html: "", cfg: null};

  let hiRaw = Math.max(...vals, 0), loRaw = Math.min(...vals, 0);
  if(hiRaw === loRaw) hiRaw = loRaw + 1;
  const {ticks, lo, hi} = niceTicks(loRaw, hiRaw);
  const y = v => T + innerH * (1 - (v - lo) / (hi - lo || 1));
  const slot = innerW / Math.max(periods.length, 1);
  const nSer = series.length;
  const bw = Math.max(4, Math.min(28, slot / (nSer + 1.4)));

  let g = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${unit}柱状">`;
  g += `<text x="${L-56}" y="${T-8}" font-size="11.5" fill="#6d7a72">${unit}</text>`;
  ticks.forEach(v => {
    const py = y(v);
    g += `<line x1="${L}" y1="${py}" x2="${W-R}" y2="${py}" stroke="#eee9dc"/>`;
    g += `<text x="${L-10}" y="${py+4}" text-anchor="end" font-size="11.5" fill="#6d7a72">${fmtNum(v, Math.abs(v) < 10 ? 2 : 0)}</text>`;
  });
  g += `<line x1="${L}" y1="${y(lo)}" x2="${W-R}" y2="${y(lo)}" stroke="#d6d1c1"/>`;
  g += `<line x1="${L}" y1="${y(lo)}" x2="${L}" y2="${y(hi)}" stroke="#d6d1c1"/>`;

  periods.forEach((p, i) => {
    const cx = L + slot * i + slot / 2;
    g += `<text x="${cx}" y="${H-18}" text-anchor="middle" font-size="11.5" fill="#6d7a72">${p}</text>`;
    series.forEach((s, si) => {
      const v = s.values[i];
      if(v === null || v === undefined) return;
      const color = SERIES_COLORS[si % SERIES_COLORS.length];
      const totalW = nSer * bw;
      const x0 = cx - totalW / 2 + si * bw;
      const yTop = Math.min(y(v), y(0));
      const hgt = Math.abs(y(0) - y(v)) || 1;
      g += `<rect x="${x0.toFixed(1)}" y="${yTop.toFixed(1)}" width="${bw.toFixed(1)}"
                  height="${hgt.toFixed(1)}" fill="${color}" opacity=".88" rx="2">
              <title>${s.name} ${p}：${fmtNum(v)} ${unit}</title></rect>`;
    });
  });
  g += `</svg>`;
  return {html: g, cfg: {periods, series, unit, L, R, W, innerW, T, innerH, lo, hi}};
}

/* **组合图**：柱状表示各年高低，折线叠加趋势 —— 两者在同一坐标系里 */
function drawComboChart(periods, series, unit){
  const W = 880, H = 330, L = 78, R = 28, T = 30, B = 48;
  const innerW = W - L - R, innerH = H - T - B;
  const vals = series.flatMap(s => s.values).filter(v => v !== null);
  if(!vals.length) return {html: `<div class="empty">所选指标在该公司没有数据。</div>`, cfg: null};

  let hiRaw = Math.max(...vals, 0), loRaw = Math.min(...vals, 0);
  if(hiRaw === loRaw) hiRaw = loRaw + 1;
  const {ticks, lo, hi} = niceTicks(loRaw, hiRaw);
  const y = v => T + innerH * (1 - (v - lo) / (hi - lo || 1));

  const n = Math.max(periods.length, 1);
  const slot = innerW / n;
  const cx = i => L + slot * i + slot / 2;
  const nSer = series.length;
  const bw = Math.max(4, Math.min(26, slot / (nSer + 1.6)));
  const y0 = y(0);

  let g = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${unit}趋势">`;
  g += `<text x="${L-56}" y="${T-10}" font-size="11.5" fill="#6d7a72">${unit}</text>`;

  ticks.forEach(v => {
    const py = y(v);
    g += `<line x1="${L}" y1="${py}" x2="${W-R}" y2="${py}" stroke="#eee9dc"/>`;
    g += `<text x="${L-10}" y="${py+4}" text-anchor="end" font-size="11.5" fill="#6d7a72">${fmtNum(v, Math.abs(v) < 10 ? 2 : 0)}</text>`;
  });
  g += `<line x1="${L}" y1="${y0}" x2="${W-R}" y2="${y0}" stroke="#d6d1c1"/>`;
  g += `<line x1="${L}" y1="${y(lo)}" x2="${L}" y2="${y(hi)}" stroke="#d6d1c1"/>`;
  periods.forEach((p,i) => {
    g += `<text x="${cx(i)}" y="${H-18}" text-anchor="middle" font-size="11.5" fill="#6d7a72">${p}</text>`;
  });

  // ① 柱子
  series.forEach((s, si) => {
    const color = SERIES_COLORS[si % SERIES_COLORS.length];
    s.values.forEach((v, i) => {
      if(v === null || v === undefined) return;
      const x0 = cx(i) - (nSer * bw) / 2 + si * bw;
      const yTop = Math.min(y(v), y0);
      const hgt = Math.abs(y0 - y(v)) || 1;
      g += `<rect x="${x0.toFixed(1)}" y="${yTop.toFixed(1)}" width="${bw.toFixed(1)}"
                  height="${hgt.toFixed(1)}" fill="${color}" opacity=".26" rx="2"/>`;
    });
  });

  // ② 折线（压在柱子上面）+ 数据点
  series.forEach((s, si) => {
    const color = SERIES_COLORS[si % SERIES_COLORS.length];
    let d = "", started = false;
    s.values.forEach((v, i) => {
      if(v === null || v === undefined) return;
      d += (started ? "L" : "M") + cx(i).toFixed(1) + " " + y(v).toFixed(1) + " ";
      started = true;
    });
    if(d) g += `<path d="${d}" fill="none" stroke="${color}" stroke-width="2.4" stroke-linejoin="round"/>`;
    s.values.forEach((v, i) => {
      if(v === null || v === undefined) return;
      g += `<circle cx="${cx(i).toFixed(1)}" cy="${y(v).toFixed(1)}" r="4.2"
                fill="#fffdf8" stroke="${color}" stroke-width="2.2"/>`;
    });
  });

  g += `<line class="hover-line" x1="0" y1="${T}" x2="0" y2="${T+innerH}" />`;
  g += `</svg>`;
  return {html: g, cfg: {periods, series, unit, L, R, W, innerW, T, innerH, lo, hi, slot, combo: true}};
}

/* 悬停任意位置 → 竖线 + 提示框（该年份所有指标的值） */
function wireChart(svg, cfg){
  const line = svg.querySelector(".hover-line");
  const tip  = document.getElementById("tip");

  function slotCenter(i){
    if(cfg.combo){
      const slot = cfg.innerW / Math.max(cfg.periods.length, 1);
      return cfg.L + slot * i + slot / 2;
    }
    const n = cfg.periods.length;
    return cfg.L + (n === 1 ? cfg.innerW/2 : cfg.innerW * i / (n - 1));
  }

  function nearestIndex(clientX){
    const box = svg.getBoundingClientRect();
    const scale = cfg.W / box.width;               // viewBox → 屏幕
    const sx = (clientX - box.left) * scale;
    const n = cfg.periods.length;
    if(n === 1) return 0;
    if(cfg.combo){
      const slot = cfg.innerW / n;
      return Math.max(0, Math.min(n - 1, Math.floor((sx - cfg.L) / slot)));
    }
    const step = cfg.innerW / (n - 1);
    return Math.max(0, Math.min(n - 1, Math.round((sx - cfg.L) / step)));
  }

  function move(ev){
    const i = nearestIndex(ev.clientX);
    const px = slotCenter(i);

    if(line){
      line.setAttribute("x1", px); line.setAttribute("x2", px);
      line.style.opacity = 1;
    }

    const rows = cfg.series
      .map((s, si) => {
        const v = s.values[i];
        if(v === null || v === undefined) return "";
        const color = SERIES_COLORS[si % SERIES_COLORS.length];
        return `<div class="row"><span class="dot" style="background:${color}"></span>` +
               `<span class="t">${s.name}</span><b>${fmtNum(v)}</b> ${cfg.unit}</div>`;
      }).join("");

    tip.innerHTML = `<b>${cfg.periods[i]}</b>${rows || '<div class="row">该年暂无数据</div>'}`;
    tip.style.display = "block";
    const tw = tip.offsetWidth, th = tip.offsetHeight;
    let left = ev.clientX + 14, top = ev.clientY - th - 12;
    if(left + tw > window.innerWidth - 8) left = ev.clientX - tw - 14;
    if(top < 8) top = ev.clientY + 16;
    tip.style.left = left + "px";
    tip.style.top = top + "px";
  }

  function leave(){
    if(line) line.style.opacity = 0;
    tip.style.display = "none";
  }

  svg.addEventListener("mousemove", move);
  svg.addEventListener("mouseleave", leave);
}

function drawCharts(periods, byStmt){
  const blocks = STMT_ORDER.filter(st => byStmt[st] && Object.keys(byStmt[st]).length);
  const cfgs = [];

  // 全量统计（供跨报表解读使用，例如"现金流 ≈ 净利润"）
  const globalStats = {};
  blocks.forEach(st => Object.keys(byStmt[st]).forEach(u =>
    byStmt[st][u].forEach(s => { globalStats[s.name] = seriesStats(s.values); })));

  const html = blocks.map(st => {
    const byUnit = byStmt[st];
    let charts = "", legend = "";
    Object.keys(byUnit).forEach(unit => {
      const series = byUnit[unit];
      const built = drawComboChart(periods, series, unit);   // 柱 + 线，一张图
      charts += built.html;
      if(built.cfg) cfgs.push(built.cfg);
      legend += series.map((s,i) =>
        `<span><i style="background:${SERIES_COLORS[i%SERIES_COLORS.length]}"></i>${s.name}</span>`
      ).join("");
    });
    const allSeries = Object.keys(byUnit).reduce((acc, u) => acc.concat(byUnit[u]), []);
    const ins = buildInsight(st, periods, allSeries, globalStats);
    const insHtml = ins.lines.length ? `
      <div class="insight">
        <div class="ih">${ins.title}</div>
        <ul>${ins.lines.map(t => `<li>${t}</li>`).join("")}</ul>
        <div class="note">按你勾选的指标自动生成，只反映这些数字本身的变动，不含行业对比。</div>
      </div>` : "";

    return `<div class="stmt-block">
              <div class="stmt-title">${st}</div>
              ${charts}
              <div class="legend">${legend}</div>
              ${insHtml}
            </div>`;
  }).join("");

  document.getElementById("chart").innerHTML = html;
  const el = document.getElementById("legend");
  if(el) el.innerHTML = "";

  document.querySelectorAll("#chart svg").forEach((svg, i) => {
    if(cfgs[i]) wireChart(svg, cfgs[i]);
  });
}

/* ---------- 指标解读（规则生成，不调用任何模型） ---------- */
function pctText(x){ return (x >= 0 ? "+" : "") + x.toFixed(1) + "%"; }

function seriesStats(values){
  const pts = [];
  values.forEach((v, i) => { if(v !== null && v !== undefined) pts.push([v, i]); });
  if(pts.length < 2) return null;
  const first = pts[0][0], last = pts[pts.length - 1][0];
  const change = first !== 0 ? (last - first) / Math.abs(first) * 100 : null;
  let ups = 0, downs = 0;
  for(let k = 1; k < pts.length; k++){
    const d = pts[k][0] - pts[k - 1][0];
    if(d > 0) ups++; else if(d < 0) downs++;
  }
  const trend = ups === pts.length - 1 ? "逐期上升"
              : downs === pts.length - 1 ? "逐期下降"
              : "有升有降";
  return {first, last, change, trend, n: pts.length};
}

/* 从数值里读出"说了什么"：涨落、转折、幅度 */
function buildInsight(stmt, periods, series, globalStats){
  const lines = [];
  const stats = {};                      // 本报表的统计
  series.forEach(s => { stats[s.name] = seriesStats(s.values); });

  // 跨报表判断（如"现金流 vs 净利润"）用全量统计
  const G = globalStats || stats;

  series.forEach(s => {
    const st = stats[s.name];
    if(!st){
      lines.push(`${s.name}：只有一期数据，看不出变化。`);
      return;
    }
    const yoy = st.change === null ? "" : `，区间变动 ${pctText(st.change)}`;
    lines.push(`${s.name}：${st.n} 期从 ${fmtNum(st.first)} 到 ${fmtNum(st.last)}`
             + `（${s.unit || ""}）${yoy}，${st.trend}。`);
  });

  // 组合判断：利润率（两者都在利润表，但仍从全局取，避免顺序问题）
  const rev = G["营业收入"], np = G["净利润"] || G["归母净利润"];
  if(rev && np && rev.last && rev.first){
    const m1 = np.first / rev.first * 100, m2 = np.last / rev.last * 100;
    const d = m2 - m1;
    if(Math.abs(d) >= 0.3){
      lines.push(`净利润率由 ${m1.toFixed(1)}% 变为 ${m2.toFixed(1)}%（${d > 0 ? "上升" : "下降"} `
               + `${Math.abs(d).toFixed(1)} 个百分点）—— 收入与利润的背离值得留意。`);
    }
  }

  // 组合判断：杠杆
  const ta = G["资产总计"], tl = G["负债合计"];
  if(ta && tl && ta.last && tl.last && ta.first && tl.first){
    const l1 = tl.first / ta.first * 100, l2 = tl.last / ta.last * 100;
    const d = l2 - l1;
    lines.push(`资产负债率由 ${l1.toFixed(1)}% 变为 ${l2.toFixed(1)}%`
             + `（${d >= 0 ? "上升" : "下降"} ${Math.abs(d).toFixed(1)} 个百分点）。`);
  }

  // 现金流含量
  const cf = G["经营活动现金流量净额"];
  if(cf && np && np.last){
    const ratio = cf.last / np.last;
    if(isFinite(ratio) && np.last !== 0){
      lines.push(`经营现金流约为净利润的 ${ratio.toFixed(2)} 倍`
               + (ratio >= 1 ? "，利润有现金支撑。" : "，利润的现金含量偏低，需看应收与存货。"));
    }
  }

  return {title: `${stmt}解读`, lines};
}

function drawTable(e, periods, byUnit){
  let h = `<thead><tr><th>指标</th><th>单位</th>${periods.map(p=>`<th>${p}</th>`).join("")}<th>来源</th></tr></thead><tbody>`;
  Object.keys(byUnit).forEach(unit => {
    byUnit[unit].forEach(s => {
      const src = (e.metrics[s.name] || {})[periods[periods.length-1]];
      h += `<tr><td>${s.name}</td><td class="muted">${unit}</td>` +
        s.values.map(v => `<td>${fmtNum(v)}</td>`).join("") +
        `<td class="muted">${src ? (src.p ? "第 "+src.p+" 页" : "结构化接口") : "—"}</td></tr>`;
    });
  });
  document.getElementById("tbl").innerHTML = h + "</tbody>";
}

function render(){
  const e = DATA[sel.co];
  // 按"年份筛选"取子集；没选就用全部
  const avail = (e.periods || []).map(String);
  const picked = sel.years && sel.years.size
    ? avail.filter(y => sel.years.has(y))
    : avail;
  const periods = picked.length ? picked : avail;
  document.getElementById("nYr").textContent = periods.length;

  const byStmt = {};
  const flat = {};
  [...sel.metrics].forEach(m => {
    if(!e.metrics[m]) return;
    const unit = unitOf(m);
    const st = (e.stmt && e.stmt[m]) || "其他";
    (((byStmt[st] = byStmt[st] || {})[unit]) = byStmt[st][unit] || [])
      .push({name: m, values: seriesFor(e, m, periods, unit)});
    (flat[unit] = flat[unit] || []).push({name: m, unit,
                                          values: seriesFor(e, m, periods, unit)});
  });

  if(!Object.keys(flat).length){
    document.getElementById("chart").innerHTML = `<div class="empty">请在左侧勾选至少一个指标。</div>`;
    document.getElementById("legend").innerHTML = "";
    document.getElementById("tbl").innerHTML = "";
    return;
  }
  drawCharts(periods, byStmt);
  drawTable(e, periods, flat);
}

syncStmt(); initSelect(); initYearPicker(); initPicker(); render();
</script>
</body>
</html>
"""


if __name__ == "__main__":
    import sys
    p = build_html(companies=sys.argv[1:] or None)
    print(f"saved: {p}")
