"""**混合检索**：向量（按意思找）+ 关键词（按字面找），再把两路结果融合。

## 为什么需要第二条路

向量检索擅长"换了说法也能找到"，但**财务术语恰恰是它的弱项**：

- 问「合同负债怎么变的」，向量可能召回一堆"负债""应付"的段落，却漏掉
  真正写着「合同负债」的那一页；
- 问「递延收益」「其他权益工具」「信用减值损失」这类**专有名词**时，
  字面完全一致的段落，用关键词一次就中，用向量反而排到几十名开外。

反过来，用户口语化提问（"钱收回来了吗"）时关键词又完全失效，需要向量。

两路各有盲区，故**都跑，再融合**。

## 融合方式：RRF（Reciprocal Rank Fusion）

    得分 = Σ 1 / (k + 排名)      k 取 60

只看**排名**不看原始分数 —— 向量距离和关键词得分量纲不同，直接加权相加要调参，
RRF 不需要。这是信息检索里的标准做法，稳定且无需训练。
"""
import math
import re
from collections import Counter

#: RRF 的平滑常数。60 是论文里的常用值：让前几名之间的差距不至于过分悬殊。
RRF_K = 60

#: 中文按「字符二元组」切词：不引入 jieba 这类分词依赖，
#: 对"合同负债""递延收益"这种专有名词足够用。
_STOP = set("的了和与及或在是有为对将会把被从到按第号年月日")


def _bigrams(text: str) -> list:
    """中文按二字滑窗切词；英文/数字按整词。"""
    text = re.sub(r"\s+", "", text or "")
    grams = []
    for tok in re.findall(r"[A-Za-z0-9_]+|[\u4e00-\u9fa5]+", text):
        if tok[0].isascii():
            grams.append(tok.lower())
            continue
        for i in range(len(tok) - 1):
            bg = tok[i:i + 2]
            if not (set(bg) & _STOP):
                grams.append(bg)
    return grams


def bm25_scores(query: str, docs: list, k1: float = 1.5, b: float = 0.75) -> list:
    """对一批文档打 BM25 分。`docs` 是纯文本列表，返回同长度分数列表。"""
    q_terms = _bigrams(query)
    if not q_terms or not docs:
        return [0.0] * len(docs)

    doc_terms = [_bigrams(d) for d in docs]
    doc_len = [len(t) or 1 for t in doc_terms]
    avg_len = sum(doc_len) / len(doc_len)

    # 文档频率 → IDF
    df = Counter()
    for terms in doc_terms:
        for t in set(terms):
            df[t] += 1
    n = len(docs)
    idf = {t: math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5)) for t in q_terms if df[t]}

    scores = []
    for terms, dl in zip(doc_terms, doc_len):
        tf = Counter(terms)
        s = 0.0
        for t in q_terms:
            if t not in idf or t not in tf:
                continue
            f = tf[t]
            s += idf[t] * (f * (k1 + 1)) / (f + k1 * (1 - b + b * dl / avg_len))
        scores.append(s)
    return scores


def lexical_search(query: str, docs: list, top_n: int = 20) -> list:
    """关键词检索：返回 [(文档下标, 分数), ...]，按分数降序。"""
    scores = bm25_scores(query, docs)
    ranked = sorted(range(len(docs)), key=lambda i: scores[i], reverse=True)
    return [(i, scores[i]) for i in ranked[:top_n] if scores[i] > 0]


def rrf_fuse(rankings: list, k: int = RRF_K) -> list:
    """把多路排名融合成一个。

    `rankings`：[[id, id, ...], ...]，每路是**按相关性从高到低**的 id 列表。
    返回 [(id, 融合得分), ...]，按得分降序。
    """
    scores = Counter()
    for ranked in rankings:
        for rank, ident in enumerate(ranked):
            scores[ident] += 1.0 / (k + rank + 1)
    return scores.most_common()


def hybrid_rank(query: str, docs: list, vector_order: list, top_n: int = 20) -> list:
    """向量排名 + 关键词排名 → 融合后的文档下标顺序。

    `vector_order` 是向量检索给出的**下标顺序**（已按距离从近到远）。
    """
    lex = lexical_search(query, docs, top_n=top_n)
    lex_order = [i for i, _s in lex]
    fused = rrf_fuse([vector_order[:top_n], lex_order])
    return [i for i, _score in fused]
