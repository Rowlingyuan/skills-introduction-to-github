"""LLM 交叉校验。只判断，不提取。

调用粒度固定为单页——实测 2545 字符耗时 61.4 秒，
20000 字符会触发 SocketTimeoutException。
"""
import json
import re

from client import call_extractor
from models import MetricValue, VerifyOutcome

MAX_CHARS = 3000

_SYSTEM = "你是中国注册会计师。只输出JSON，不要任何解释或markdown标记。"

_TEMPLATE = """下面是从一份报表页面用规则提取出的指标，以及该页的原文。
请核对：数字是否与原文一致？有无遗漏？是否误取了母公司报表而非合并报表？

规则提取结果：
{metrics}

页面原文：
{page_text}

只输出如下JSON：
{{"is_correct": true/false, "corrections": {{"指标名": {{"年份": 数值}}}}, "explanation": "简述"}}
"""


def build_prompt(metrics, page_text: str) -> str:
    if len(page_text) > MAX_CHARS:
        raise ValueError(
            f"页面文本 {len(page_text)} 字符超过 MAX_CHARS={MAX_CHARS}。"
            "LLM 调用粒度必须为单页，禁止拼接或截断。"
        )
    lines = [f"  {m.name} {m.period}: {m.value}" for m in metrics]
    return _TEMPLATE.format(metrics="\n".join(lines) or "（空）", page_text=page_text)


def parse_response(raw: str) -> VerifyOutcome:
    text = (raw or "").strip()
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if not m:
            raise ValueError(f"LLM 返回非 JSON: {raw[:200]}")
        try:
            data = json.loads(m.group())
        except json.JSONDecodeError as e:
            raise ValueError(f"LLM 返回无法解析: {raw[:200]}") from e
    corrections = {}
    for name, years in (data.get("corrections") or {}).items():
        if isinstance(years, dict):
            corrections[str(name)] = {str(k): float(v) for k, v in years.items()}
    return VerifyOutcome(
        is_correct=bool(data.get("is_correct")),
        corrections=corrections,
        explanation=str(data.get("explanation") or ""),
    )


def verify(metrics, page_text: str, page_no: int) -> VerifyOutcome:
    """真实 LLM 调用。page_no 仅用于报错信息。

    两类失败必须可区分：网关调用失败（超时等）与返回内容无法解析。
    只包住 `call_extractor`，别把 `parse_response` 也吞进同一个 except——
    那会把解析 bug 伪装成网关故障，也会漏标页号。
    """
    prompt = build_prompt(metrics, page_text)
    try:
        raw = call_extractor([
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": prompt},
        ], timeout=180)
    except Exception as e:
        raise RuntimeError(f"第{page_no}页 LLM 调用失败: {e}") from e
    try:
        return parse_response(raw)
    except Exception as e:
        raise RuntimeError(f"第{page_no}页 LLM 返回无法解析: {e}") from e


def apply_outcome(metrics, outcome: VerifyOutcome) -> list:
    """把校验结果落到 confidence 上。conflict 保留规则原值，不覆盖。

    **必须用关键字传参。** 只传 5 个位置参数会让 `statement` 回落到默认值
    "利润表"——资产负债表/现金流量表的冲突项会被错标成利润表项。
    值是保住了，归属却错了，而测试因为 helper 也走默认值而完全看不出来。
    """
    out = []
    for m in metrics:
        if outcome.is_correct:
            out.append(m)
            continue
        corrected = outcome.corrections.get(m.name, {}).get(m.period)
        if corrected is not None and abs(corrected - m.value) > 1e-6:
            out.append(MetricValue(name=m.name, period=m.period, value=m.value,
                                   source_page=m.source_page,
                                   confidence="conflict",
                                   statement=m.statement))
        else:
            out.append(m)
    return out
