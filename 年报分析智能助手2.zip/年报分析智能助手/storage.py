"""SQLite 存储层。为二期的跨公司/跨期关系查询预留结构。"""
import sqlite3
from pathlib import Path

from models import MetricValue, ParseResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS reports (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    company       TEXT NOT NULL,
    code          TEXT,
    report_type   TEXT NOT NULL,
    period        TEXT NOT NULL,
    file_path     TEXT,
    parsed_at     TEXT DEFAULT CURRENT_TIMESTAMP,
    verify_status TEXT,
    UNIQUE(company, report_type, period)
);
CREATE TABLE IF NOT EXISTS metrics (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id   INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    statement   TEXT NOT NULL DEFAULT '利润表',
    metric_name TEXT NOT NULL,
    period      TEXT NOT NULL,
    value       REAL,
    source_page INTEGER,
    confidence  TEXT,
    UNIQUE(report_id, statement, metric_name, period)
);
CREATE INDEX IF NOT EXISTS idx_metrics_lookup ON metrics(metric_name, period);
"""


def _connect(db_path):
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(db_path) -> None:
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    with _connect(db_path) as conn:
        conn.executescript(SCHEMA)


def save_result(result: ParseResult, db_path) -> int:
    """幂等：同一 (公司, 类型, 期) 重复写入会覆盖指标。"""
    with _connect(db_path) as conn:
        conn.execute(
            """INSERT INTO reports (company, code, report_type, period, file_path, verify_status)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(company, report_type, period) DO UPDATE SET
                 file_path=excluded.file_path, verify_status=excluded.verify_status""",
            (result.key.company, result.key.code, result.key.report_type,
             result.key.period, result.file_path,
             "has_conflict" if any(m.confidence == "conflict" for m in result.metrics)
             else "ok"),
        )
        report_id = conn.execute(
            "SELECT id FROM reports WHERE company=? AND report_type=? AND period=?",
            (result.key.company, result.key.report_type, result.key.period),
        ).fetchone()[0]
        conn.execute("DELETE FROM metrics WHERE report_id=?", (report_id,))
        conn.executemany(
            """INSERT INTO metrics
                 (report_id, statement, metric_name, period, value, source_page, confidence)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            [(report_id, m.statement, m.name, m.period,
              m.value, m.source_page, m.confidence)
             for m in result.metrics],
        )
    return report_id


def load_metrics(company, report_type, period, db_path, statement=None) -> list:
    sql = """SELECT m.metric_name, m.period, m.value, m.source_page,
                    m.confidence, m.statement
             FROM metrics m JOIN reports r ON r.id = m.report_id
             WHERE r.company=? AND r.report_type=? AND r.period=?"""
    args = [company, report_type, period]
    if statement:
        sql += " AND m.statement=?"
        args.append(statement)
    with _connect(db_path) as conn:
        rows = conn.execute(sql, args).fetchall()
    return [MetricValue(r[0], r[1], r[2], r[3], r[4], r[5]) for r in rows]


def load_conflicts(db_path) -> list:
    """待人工复核清单——新格式问题的主要信号来源。"""
    with _connect(db_path) as conn:
        rows = conn.execute(
            """SELECT r.company, r.report_type, r.period, m.statement,
                      m.metric_name, m.period AS metric_period,
                      m.value, m.source_page
               FROM metrics m JOIN reports r ON r.id = m.report_id
               WHERE m.confidence='conflict'"""
        ).fetchall()
    keys = ["company", "report_type", "period", "statement", "metric_name",
            "metric_period", "value", "source_page"]
    return [dict(zip(keys, r)) for r in rows]


def known_companies(db_path) -> list:
    """库里有哪些公司（去重）。**放在 storage 里**，让 agent 与 analysis 共用，
    避免它们互相 import 形成环。"""
    import sqlite3
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            return [r[0] for r in conn.execute(
                "SELECT DISTINCT company FROM reports").fetchall()]
        finally:
            conn.close()
    except sqlite3.Error:
        return []


def company_by_code(db_path, code: str) -> "str | None":
    """股票代码 → 库里的公司名。用户直接报代码时用。"""
    import sqlite3
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            row = conn.execute(
                "SELECT company FROM reports WHERE code=? LIMIT 1", (code,)).fetchone()
            return row[0] if row else None
        finally:
            conn.close()
    except sqlite3.Error:
        return None
