"""终端对话模式：跑一次，然后一直聊。

## 为什么要有它

`main.py ask "..."` 是一次性调用：每问一句就要重启进程，重复付出
加载 bge-m3（约 2 秒）、开 SQLite、冷读 PDF 的代价。连着问五个问题，
光启动开销就十几秒。

REPL 把进程留住，这些只付一次。

## 设计

- 一切走 `agent.answer`：和 CLI / Web 完全同一条链路，不另写一套逻辑。
- 单轮失败不杀会话：某一问抛异常（网络、模型、PDF）只打印错误，
  回到提示符继续 —— 交互式工具最忌讳一句报错就退出。
- 斜杠命令只做"不属于问答"的事：看库、看帮助、退出。
"""
import re
import traceback
from pathlib import Path

BANNER = """\
你好，我是你的年报分析助手 👋
我可以帮你分析 A 股上市公司的年报 —— 说一句「帮我分析 XXX 公司 XXXX 年的年报」就行。

三张报表的数字取自结构化数据（合并口径，可逐项对账），
附注内容与页码取自年报原文，最后由我算比率、拆解变动、出报告。
查数字和分析报告都不依赖大模型，所以没有 API Key 也能用。
首次运行会让你选一次「问年报原文」用的检索模型（大/中/小/不用），选完记住。

你可以这么问我
  帮我分析中科曙光 2025 年的年报
  中国黄金 2025 年报怎么样            ← 不带"分析"也认
  格力 2025 年报                      ← 只说简称也认
  分析 SZ300308 对应的 2025 年财报     ← 报股票代码也认
  格力电器 2025 年营业收入是多少        ← 只想看一个数字
  帮我分析澜起科技 2025 年报            ← 库里没有？我自动去下载

几点边界，先说清楚
  · 只支持 A 股；港股/美股我会直接告诉你不在范围内
  · 银行/券商/保险 走各自的口径（不算毛利率/流动比率，改用成本收入比）
  · 抽不到的项一律写「未抽到」，不给估计值，也不猜
  · 报告生成后输入 /open 打开；想看图表输入 /html

命令：/open 报告  /pdf 年报原文  /html 数据看板  /model 换模型  /save 存 Word  /exit 退出"""


#: 表示"我在纠正上一句"的词
_CORRECT_WORDS = ("说错", "不对", "不是", "改成", "应该", "纠正", "错了",
                  "换", "重新", "而是")


def _mentions_company(text: str) -> bool:
    """这句里有没有点出公司名。

    判据：去掉客套词、年份、报表词、标点后，还剩 ≥2 个汉字就算提了公司。
    `分析 2024 年年报` → 什么都不剩（是追问）；
    `帮我看看茅台2024年报` → 剩"茅台"（是新问题，不能拿上一句的公司硬套）。
    """
    from agent import _strip_lead

    t = re.sub(r"\s", "", text or "")
    t = _strip_lead(t)
    t = re.sub(r"(?:19|20)\d{2}\s*年?(?:度)?", "", t)
    for w in ("年度报告", "半年报", "一季报", "三季报", "年报", "报告", "财报"):
        t = t.replace(w, "")
    t = re.sub(r"[，,。、；;：:]", "", t)
    return len(re.findall(r"[\u4e00-\u9fa5]", t)) >= 2


def followup_question(text: str, entity: "dict | None") -> "str | None":
    """把"说错了，2025 年年报"这类省略公司名的追问补全成标准问法。

    对话里人会说"说错了，是 2025 年" —— 公司名在上一句里。
    没有这层上下文，这句话会被当成新问题去解析，自然解析不出公司。
    """
    if not entity or not entity.get("company"):
        return None
    t = (text or "").strip()
    # 取最后一个年份：`不是2026，是2025年` 里被纠正的是后面那个
    years = re.findall(r"(?:19|20)\d{2}", t)
    if not years:
        # 口语里常说两位年份：`换成25年`、`看24年的`
        two = re.findall(r"(?<!\d)(2\d)\s*年", t)
        years = [f"20{d}" for d in two]
    year = years[-1] if years else None
    is_fix = any(w in t for w in _CORRECT_WORDS)
    # 只说了一个年份（"2024 年呢"）也算接着上一句
    short_year_only = bool(year) and len(re.sub(r"[\s，,。、；;：:]", "", t)) <= 8

    # 只说了年份、没提公司 → 公司就是上一句那个。
    # 实测对话：先说"中国黄金 2026 年报"（未披露），再说"分析 2024 年年报"，
    # 这句里没有公司名，旧的判断（长度 ≤8）不成立，于是被当成新问题反问"哪家公司"。
    no_company = bool(year) and not _mentions_company(t)

    if not (is_fix or short_year_only or no_company):
        return None

    period = year if year else (entity.get("period") or "")
    rtype = entity.get("report_type") or "年报"
    for w in ("半年报", "一季报", "三季报", "年报"):
        if w in t:
            rtype = w
            break
    return f"分析{entity['company']}{period}{rtype}"


def _render(res: dict) -> str:
    """把 agent 的返回压成终端可读文本。"""
    parts = [res.get("answer", "")]
    cites = res.get("citations") or []
    if cites:
        pages = "、".join(f"第{c['page']}页" for c in cites[:8])
        parts.append(f"\n出处：{pages}")
    return "\n".join(parts)


def _health() -> str:
    """探测模型网关。只在需要"原文归因"时才用得上，但用户应该能先查。"""
    try:
        from client import ping
    except Exception as e:                       # noqa: BLE001
        return f"无法加载模型客户端：{e}"
    got = ping()
    if got.get("ok"):
        return "✅ 模型网关可用（可问「并附原文原因」）"
    return (f"❌ 模型网关不可用（{got.get('kind')}）\n"
            f"   {got.get('detail')}\n"
            f"   依赖模型的功能（原文归因）暂不可用；数字与分析不受影响。")


def _list_reports(db_path) -> str:
    from analysis import available_reports
    rows = available_reports(db_path)
    if not rows:
        return "（库里还没有报告，先说一句「帮我下载并分析某某公司某某年报」）"
    lines = [f"已入库 {len(rows)} 份："]
    for r in rows:
        lines.append(f"  {r['company']:<8}{r['report_type']:<5}{r['period']}")
    return "\n".join(lines)


def _main_model_status() -> str:
    """当前检索模型的一句话状态（启动时打印，让用户看得见）。"""
    try:
        import main as _main
        return _main._model_status()
    except Exception:                 # noqa: BLE001
        return ""


def _open_last_pdf(last: "dict | None", output_fn) -> None:
    """打开刚才那份报告的**年报原文 PDF**。

    实测：用户知道 PDF 存在 data/ 下，但每次去文件夹里翻很麻烦，
    期望像报告一样一条命令就能打开。
    """
    from terminal_link import open_path

    if not last or not last.get("analysis"):
        output_fn("还没有分析过公司。先问一句「分析一下某某公司某年报」。")
        return

    a = last["analysis"]
    from agent import report_pdf_path

    pdf = report_pdf_path(a.get("company") or "", a.get("period") or "",
                          a.get("report_type") or "年报", last["db_path"])
    if not pdf:
        output_fn("（没找到这份报告对应的 PDF 原文）")
        return
    output_fn(f"📂 正在打开：{pdf.name}")
    open_path(pdf)


def _open_last_report(output_fn) -> None:
    """打开 `reports/` 里**最新的一份**报告。

    为什么按修改时间而不是记"上一次生成的路径"：用户可能中途 `/save` 过、
    或者手动删过文件；按 mtime 找最新一份永远对得上他刚看到的那条链接。
    """
    from pathlib import Path

    from terminal_link import open_path

    reports = Path("reports")
    files = sorted(reports.glob("*.docx"), key=lambda p: p.stat().st_mtime,
                   reverse=True) if reports.exists() else []
    if not files:
        output_fn("还没有生成过报告。先问一句「分析一下某某公司某年报」。")
        return
    latest = files[0]
    if open_path(latest):
        output_fn(f"📂 正在打开：{latest.name}")
    else:
        output_fn(f"（打不开文件，路径是：{latest.resolve()}）")


def _save_report(last: "dict | None", arg: str, output_fn) -> "dict | None":
    """把最近一次分析存成 Word。返回更新后的 `last`（失败时原样返回）。

    `/save` 的意义：不必在问题里带"报告"两个字。先问「分析一下 X 年报」看文字，
    觉得满意再 `/save` 落盘；不满意就换个问法，不产生垃圾文件。
    """
    if not last:
        output_fn("还没有可保存的分析。先问一句「分析一下某某公司某年报」。")
        return last

    a = last["analysis"]
    company = a.get("company") or ""
    period = a.get("period") or ""
    report_type = a.get("report_type") or "年报"

    from agent import build_report, default_report_path
    out = None
    name = (arg or "").strip()
    if name:
        p = Path(name)
        out = p if p.is_absolute() else default_report_path(company, period, report_type).parent / p.name

    got = build_report(company, report_type, period, last["db_path"],
                       analysis=a, narrative=last.get("narrative"), out_path=out)
    if got.get("ok"):
        # **说清存的是哪一份**：用户连着问几家公司时，/save 存的是"最近一次分析"，
        # 不报公司名会让人以为存错了（实测：以为存的是中国黄金，其实是上一家）。
        output_fn(f"📄 已保存（{company} {period} {report_type}）：{got['path']}")
    else:
        output_fn(f"（保存失败：{got.get('error')}）")
    return last


def _build_stamp() -> str:
    """给当前进程标一个"代码版本"。

    长驻进程不会热加载已导入的模块 —— 改了代码还开着旧会话，行为就是旧的。
    之前排查"明明修好了却还是老样子"花了很久，因为看不出进程是不是最新的。
    这里用源码最新修改时间做标记，新旧一眼可辨。
    """
    from pathlib import Path
    root = Path(__file__).resolve().parent
    newest = 0.0
    for f in root.glob("*.py"):
        newest = max(newest, f.stat().st_mtime)
    import datetime
    return datetime.datetime.fromtimestamp(newest).strftime("%m-%d %H:%M")


def _enable_line_editing() -> None:
    """打开终端行编辑：方向键、Home/End、Ctrl-U 清行、上下键翻历史。

    不 import readline 时，`input()` 只有最基础的回退行为：
    光标挪不动、删错了只能一直按退格 —— 实测用户反馈"打错字前面的删不掉"。
    macOS 自带 libedit，import 一下即可（失败也不影响运行）。
    """
    try:
        import readline  # noqa: F401

        readline.parse_and_bind("bind ^I rl_complete")   # 兼容 macOS libedit 的 Tab
        readline.set_history_length(200)
    except Exception:                      # noqa: BLE001
        pass


def run_repl(db_path: str, input_fn=input, output_fn=print) -> int:
    """对话主循环。`input_fn`/`output_fn` 可注入，便于离线测试。"""
    if input_fn is input:                  # 只在真终端里折腾行编辑
        _enable_line_editing()
    output_fn(BANNER)
    output_fn(_main_model_status())
    output_fn(f"（代码版本 {_build_stamp()}；若刚改过代码请重启，Python 不热加载）")
    output_fn("（打错字可以按 Ctrl-U 清空整行；↑↓ 翻历史，/exit 退出）")
    last = None          # 最近一次带 analysis 的回答，供 /save 用
    pending = None       # 等用户确认的标准问法（"你问的是不是 X？"）
    last_entity = None   # 上一轮谈到的公司/期间，供"说错了，2025 年"这类追问用
    pending_year = None  # 被问到"哪家公司"时，用户提到过的年份
    history = []         # 最近几轮（用户原话 + 解析结果），供语义解析理解上下文
    while True:
        try:
            line = input_fn("\n你 > ")
        except EOFError:
            output_fn("\n再见。")
            return 0
        except KeyboardInterrupt:
            # **Ctrl-C 不该直接退出**：多数人只是想清掉当前输入。
            # 真退出用 /exit 或 Ctrl-D（实测试用者按了 ^C 回到 shell，
            # 再把问题打进 zsh，得到"command not found"，以为程序坏了）。
            output_fn("\n（退出请按 Ctrl-D 或输入 /exit）")
            continue

        q = (line or "").strip()
        if not q:
            continue
        if q in ("/exit", "/quit", "exit", "quit", "q", ":q"):
            output_fn("再见。")
            return 0
        if q in ("/help", "/h", "?"):
            output_fn(BANNER)
            output_fn(_main_model_status())
            continue
        if q in ("/health", "/ping"):
            output_fn(_health())
            continue
        if q in ("/list", "/ls"):
            output_fn(_list_reports(db_path))
            continue
        if q == "/save" or q.startswith("/save "):
            _save_report(last, q[len("/save"):], output_fn)
            continue
        if q in ("/open", "/open "):
            _open_last_report(output_fn)
            continue
        if q in ("/pdf", "/pdf "):
            _open_last_pdf(last, output_fn)
            continue
        if q in ("/html", "/html "):
            from report_html import build_html
            from terminal_link import link, open_path
            # **默认停在你刚问的那家公司**：否则打开后还得在 36 项里再找
            company = ""
            if last and last.get("analysis"):
                company = last["analysis"].get("company") or ""
            out = build_html(default_company=company or None)
            output_fn(f"📊 看板已生成：{Path(out).name}")
            output_fn(f"   文件位置：{Path(out).resolve()}")
            if company:
                output_fn(f"   已默认选中：{company}")
            output_fn("   正在打开浏览器…")
            open_path(out)
            continue
        if q in ("/model", "/model "):
            import main as _main
            _main.ask_embedding_model(force=True)
            output_fn("（换档位后需要重启对话才生效：/exit 再启动）")
            continue
        if q.startswith("/"):
            output_fn(f"未知命令：{q}（可用 /open /save /health /list /help /exit）")
            continue

        # 上一轮在等确认：只认"是/否"，其余输入当作用户改口，丢弃待确认项
        if pending:
            ask, pending = pending, None
            if q in ("是", "是的", "对", "对的", "好", "好的", "嗯", "yes", "y", "继续"):
                try:
                    from agent import answer
                    res = answer(ask, db_path, history=history)
                    output_fn(_render(res))
                    if res.get("entity"):
                        last_entity = res["entity"]
                    if res.get("analysis"):
                        last = {"analysis": res["analysis"],
                                "narrative": res.get("narrative"),
                                "db_path": db_path}
                    continue
                except Exception as e:          # noqa: BLE001
                    output_fn(f"⚠️ 出错了：{type(e).__name__}: {e}")
                    continue
            # **否掉之后要真的停下**，不能继续把"否"当成新问题去解析
            output_fn("好，那我先不动。直接说公司名和年份就行，例如「中国黄金 2025 年报」。")
            continue

        # 接着上一句问："说错了，2025 年年报" —— 公司名在上文里
        bridged = followup_question(q, last_entity)

        # 上一轮问过"是哪家公司"，用户这次只回了公司名（"中国黄金"）→ 用记住的年份补全
        if (bridged is None and pending_year and not re.search(r"(?:19|20)\d{2}", q)
                and _mentions_company(q)
                and not any(w in q for w in ("年报", "半年报", "季报", "报告"))):
            bridged = f"分析{q.strip()}{pending_year}年报"
            pending_year = None
        ask = bridged or q
        if bridged:
            output_fn(f"（接着上一句：{bridged[2:]}）")

        # 每一轮单独兜底：网络/模型/PDF 任何一处失败都只影响这一问
        try:
            from agent import answer
            res = answer(ask, db_path, history=history)
            if res.get("route") == "confirm":
                message = res.get("answer", "")
                output_fn(message)
                pending = res.get("pending")
                # 用户这句里带了年份（"分析 2024 年年报"）却没说公司 → 记住年份，
                # 等他下一句只回公司名时拼起来
                ys = re.findall(r"(?:19|20)\d{2}", q)
                pending_year = ys[-1] if ys else None
                continue
            output_fn(_render(res))
            if res.get("entity"):
                last_entity = res["entity"]
            # 记录这一轮：原话 + 解析出的实体，供下一轮理解上下文
            history.append({"text": q, "entity": res.get("entity") or last_entity})
            history[:] = history[-4:]
            if res.get("analysis"):
                last = {"analysis": res["analysis"],
                        "narrative": res.get("narrative"),
                        "db_path": db_path}
        except KeyboardInterrupt:
            output_fn("\n（已中断这一问）")
        except Exception as e:                      # noqa: BLE001
            output_fn(f"⚠️ 这一问出错了：{type(e).__name__}: {e}")
            if isinstance(e, ImportError):
                # 长驻进程不会热加载已导入的模块：改完代码必须重启，
                # 否则会出现"新的 analysis 去旧的 agent 里找新函数"这种怪错。
                output_fn("（如果刚改过代码，请 /exit 后重新启动对话模式 —— "
                          "Python 不会热加载已导入的模块）")
            output_fn(traceback.format_exc(limit=2).strip())
