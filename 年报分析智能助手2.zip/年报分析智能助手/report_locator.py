"""报表定位：候选页 → 试提取 → 打分选优。

不使用任何绝对页码假设，不使用页面文案启发式。
唯一判据是"这一页能不能提出结构化指标"。
"""
import pdfplumber

from metric_extractor import _label_of, count_metrics, is_number
from table_reader import read_report_page

#: 标题区真的写着合并表名时给的加权。取值只需压过附注页的那点分数差，
#: 又远小于 `read_report_page` 里 100×命中数的权重。
_NAMED_PAGE_BONUS = 30.0

#: 各表的**特征行**：真报表一定含这一行，附注里的类表几乎不会有。
#: 实测格力 2024 半年报的资产负债表一度被定位到 p186 —— 那是附注的金融工具风险表，
#: 加了借款类科目后它靠「短期借款/长期借款」刷到高分，把真报表挤掉了。
_SIGNATURE_METRIC = {
    "资产负债表": "资产总计",
    "利润表": "营业利润",
    "现金流量表": "经营活动现金流量净额",
}

#: 含特征行时给的加权。要能压过"附注表多命中几个科目"的差距。
_SIGNATURE_BONUS = 120.0

#: 三大报表的表名。**兼容各家写法**用，不做字面匹配。
STATEMENT_NAMES = ("资产负债表", "利润表", "现金流量表")

#: 历史入口：{报表类型: 该表的「合并」字面标题}。仅测试与外部引用需要，定位已改为语义判定。
REPORT_KEYWORDS = {name: f"合并{name}" for name in STATEMENT_NAMES}


def is_consolidated_title(text: str) -> bool:
    """这一行/这一页是不是**合并报表**的表名。

    不能只认「合并利润表」：顺丰的标题是「截至…止六个月期间**合并及公司**利润表」，
    「合并利润表」这四个字根本不存在；而它只是把合并与公司两套数排在一起。
    判据放宽成"含「合并」+ 含某个报表名"。
    """
    text = text or ""
    return "合并" in text and any(n in text for n in STATEMENT_NAMES)


def is_notes_page_head(head: str) -> bool:
    """标题区是不是「财务报表附注」那一类页面（不是报表本身）。

    单看整页文本不行：报表页本身就有「附注」列名。单看 `is_consolidated_title` 也不行：
    附注页满篇「合并」「现金流量表」。故只扫**顶部标题区**，并要求
    **存在一行是真正的合并表名**（含"合并"+表名，且不是"附注/补充资料"）才认。
    实测顺丰附注 p162 的标题区：
        `顺丰控股股份有限公司 / 财务报表附注 / … / 四 合并财务报表项目附注(续) /
         (50) 现金流量表补充资料`
    —— 两行都带"附注/补充资料"，故判定为附注页，不作报表页。
    """
    head = head or ""
    if "财务报表附注" not in head:
        return False
    for line in head.split("\n"):
        if is_consolidated_title(line) and "附注" not in line and "补充资料" not in line:
            return False            # 标题区里真有合并表名 → 是报表页
    return True


def is_parent_title(text: str) -> bool:
    """这一行是不是**母公司（公司）报表**的表名。

    顺丰写的是「**公司**资产负债表(续)」而不是「母公司资产负债表」，
    故「公司」「母公司」都算；但**必须不含「合并」** ——
    「合并及公司利润表」两头都沾，那是合并表。
    """
    text = text or ""
    return ("公司" in text) and ("合并" not in text) and any(
        n in text for n in STATEMENT_NAMES)


def candidate_pages(pdf, statement: str) -> list:
    """含**该合并报表**表名的页 ± 1 页（1-based，升序去重）。

    `statement` 传「利润表」/「资产负债表」/「现金流量表」（不带"合并"）。
    向后兼容：传「合并利润表」也认，内部会剥掉前缀。
    """
    statement = (statement or "").replace("合并", "")
    hit = []
    for i, pg in enumerate(pdf.pages):
        text = pg.extract_text() or ""
        if statement in text and is_consolidated_title(text):
            hit.append(i + 1)
    cand = set()
    for p in hit:
        for d in (-1, 0, 1):
            n = p + d
            if 1 <= n <= len(pdf.pages):
                cand.add(n)
    return sorted(cand)


#: 母公司报表的**表名**。只认完整表名，不认「归属于母公司股东的净利润」这类行内字样 ——
#: 合并利润表里必然出现那一行，按字样判会把每一张合并表都毙掉。
_PARENT_TITLES = ("母公司资产负债表", "母公司利润表", "母公司现金流量表")
_CONSOLIDATED_TITLES = ("合并资产负债表", "合并利润表", "合并现金流量表")

def is_parent_only_page(page) -> bool:
    """这一页**整页**都是母公司报表吗？

    判据：母公司表名出现在**第一张表之上**（即页面一开头就是母公司表）。

    为什么不用"标题在页面上部多少比例"这种固定阈值：茅台 2026 半年报 p28
    的母公司标题在 y=236，占页高 0.28 —— 按 0.35 会整页跳过，
    而这一页上半部分其实是**合并资产负债表的续表**（含`所有者权益合计`），
    一跳就把合计行丢了，分析里只能从后面的母公司页取到个 1.49 亿。

    实测三例：
      茅台 p28  母公司标题 236 > 首表 top 77  → 不是整页母公司（上面有合并表尾）
      海康 p43  母公司标题  89 < 首表 top 115 → 整页母公司，跳过
      恒瑞 p76  母公司标题 404 > 首表 top 77  → 不是整页母公司
    """
    try:
        lines = page.extract_text_lines()
    except Exception:
        return False
    parent_top = None
    for line in lines:
        text = (line.get("text") or "").replace(" ", "").replace("\u3000", "")
        if is_consolidated_title(text):
            return False                     # 先遇到合并标题，这页上是合并表
        if is_parent_title(text):
            parent_top = line["top"]
            break
    if parent_top is None:
        return False
    try:
        tables = page.find_tables()
    except Exception:
        return False
    if not tables:
        return True
    return parent_top < min(t.bbox[1] for t in tables)


#: 每张报表的"开表首行"——出现它说明这页是报表**首页**，而不是续页
#: 只对现金流量表启用：它的续页（净增加额/期初/期末 + 母公司副本）科目命中数
#: 常反超首页。资产负债表/利润表用同一套规则会把首页判错（实测格力一季报利润表）。
_OPENING_ROW = {
    "现金流量表": "经营活动产生的现金流量",
}


def locate(pdf_path, years) -> dict:
    """返回 {报表类型: 页码}。定位不到的报表不出现在结果中。"""
    result = {}
    with pdfplumber.open(pdf_path) as pdf:
        for rtype in STATEMENT_NAMES:
            # 每类报表用各自的别名表打分——资产负债表行匹配不上利润表别名，
            # 反之亦然（否则非利润表永远得 0 分，见 ledger D3）
            def counter(rows, _s=rtype):
                return count_metrics(rows, statement=_s)

            best_score, best_page = 0.0, None
            # **同分或接近时取最早那页**：报表跨页时，表头和「资产总计」在**前一页**，
            # 续页只是科目更多、分数更高。只按分数取会让定位跳到续页，
            # 丢掉表头与首行（实测格力 2025 一季报：资产负债表第 5 页被定到第 6 页）。
            scored_pages = []           # (score, page, 是否含开表首行)
            for pno in candidate_pages(pdf, rtype):
                page = pdf.pages[pno - 1]
                # 整页是母公司报表 → 不参与定位（详见 is_parent_only_page）
                if is_parent_only_page(page):
                    continue
                # **附注页不许当报表页**：候选是靠「合并+表名」扫出来的宽集合，
                # 附注里常有一张叫「现金流量表补充资料」的类表，分数可能反超真报表。
                # 实测顺丰：真表在 p92（分数 168），附注 p162（171）被选中，
                # 于是整张现金流量表只抽出 2 个指标。
                page_text = page.extract_text() or ""
                head = "\n".join(page_text.split("\n")[:6])
                if is_notes_page_head(head):
                    continue
                try:
                    table = read_report_page(page, counter)
                except Exception:
                    continue
                if table is None:
                    continue
                n = count_metrics(table.rows, statement=rtype)
                if n <= 0:
                    continue
                # 特征行加权：真报表一定有「资产总计 / 营业利润 / 经营现金流净额」那一行
                # 特征行必须**短标签 + 带数字**：附注散文里也有"…占资产总额的…"这种句子，
                # 只按别名包含判断会被它骗过（实测 p186 就是这么骗到的）。
                signature = _SIGNATURE_METRIC.get(rtype)
                has_sig = bool(signature) and any(
                    _label_of(r).strip() == signature
                    and any(is_number(c) for c in r)
                    for r in table.rows)
                # **标题区写着合并表名的页优先**。加了借款类科目后，附注里的
                # 「短期借款/长期借款」明细表也能命中若干指标 —— 实测格力 2024 半年报
                # 的资产负债表一度被定位到 p186（附注），而不是 p68 的真报表。
                # 这里只加权重、不排除，避免把"无标题页"（茅台资产负债表没有表头行）误杀。
                head = "\n".join((page.extract_text() or "").split("\n")[:6])
                named = any(is_consolidated_title(line) and "附注" not in line
                            for line in head.split("\n"))
                score = (table.score
                         + (_NAMED_PAGE_BONUS if named else 0.0)
                         + (_SIGNATURE_BONUS if has_sig else 0.0))
                # **按正文判"开表首行"更稳**：折行会把"一、经营活动产生的现金流量"
                # 拆进不同单元格，只看表格前几行常判不出来（实测交行现金流量表
                # 因此被定到最后一页，只剩 4 个科目）。
                _open_kw = str(_OPENING_ROW.get(rtype, "")).replace("|", "")
                # **两级判据**：开表首行出现在**页面顶部**最可信（长江电力 p55）；
                # 但有的报表前几行是标题+单位声明，首行在中间（交通银行 p149），
                # 于是退一步用"整页出现"。优先取 head 级，找不到再用 any 级。
                # 回到"整页出现即可"的简单判据：它让 50 份报告里 49 份的
                # 现金流量表定位正确（快照对比：变多 144 处 / 变少 1 处）。
                # 更精细的"只在页首"判据反而把长江电力拽到附注页，已回退。
                opening_head = bool(_open_kw) and _open_kw in (page_text or "")
                opening_any = opening_head
                scored_pages.append((score, pno, (opening_head, opening_any)))
            if scored_pages:
                # **有开表首行的那页才是报表首页**：续页科目多、命中数更高，
                # 但它没有"一、经营活动产生的现金流量"这类开头行（实测格力 2025
                # 一季报现金流量表被定到第 9 页续页，正文整块丢掉）。
                if _OPENING_ROW.get(rtype):
                    both = [(sc, p) for sc, p, op in scored_pages if op[0]]
                    anyo = [(sc, p) for sc, p, op in scored_pages if op[1]]
                    pool = both or anyo or [(sc, p) for sc, p, _ in scored_pages]
                    # 取命中最多的一页。**试过"取最早页"和"排除补充资料页"，
                    # 都各有反例**（长江电力被附注页抢走；宝钢被拽到利润表尾页），
                    # 已回退到最稳的按分数选。长江电力那份仍是已知缺口。
                    best_page = max(pool, key=lambda t: t[0])[1]
                else:
                    # 没有"开表首行"判据的报表：**同分附近取最早那页**。
                    # 报表跨页时续页科目更多、分数更高，但表头与首行在起始页
                    # （实测格力 2025 一季报：资产负债表起始 p5，续页 p6 分更高）。
                    top = max(sc for sc, _p, _op in scored_pages)
                    near = [p for sc, p, _op in scored_pages if sc >= top * 0.9]
                    best_page = min(near) if near else max(scored_pages, key=lambda t: t[0])[1]
            if best_page is not None:
                result[rtype] = best_page
    return result
