#!/usr/bin/env python3
"""命令行薄壳：把 report_data.py 产出的 JSON 渲染成 DOCX。

日常用**智能体**就够了（`main.py ask "…出份分析报告"`），这个脚本是给
离线调试/批处理留的入口。
"""
import argparse
import json
import sys
from pathlib import Path

from report_docx import save

ROOT = Path(__file__).resolve().parent


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="make_report_docx.py")
    ap.add_argument("--input", default=str(ROOT / "data" / "report_input.json"))
    ap.add_argument("-o", "--output", default=None)
    args = ap.parse_args(argv)

    payload = json.loads(Path(args.input).read_text(encoding="utf-8"))
    data = payload["analysis"]
    out = Path(args.output) if args.output else (
        ROOT / f"{data['company']}{data['period']}财务分析报告.docx")
    save(data, payload.get("narrative"), out)
    print(f"saved: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
