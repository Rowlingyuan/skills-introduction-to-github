"""东方财富**结构化三表**数据源（替代 PDF 切表）。

## 为什么要有这个

PDF 抽三大表要解决：合并/母公司并排、多列年份、标签折行、附注编号列、跨页……
这些问题的组合是**不可穷尽的**（实测 49 份报告里 39 份勾稽通过，剩下 10 份各有各的版式）。

结构化接口把"哪一列是哪一年、是合并还是母公司"变成**显式字段**：
`REPORT_DATE` 是报告期，`REPORT_TYPE` 是报表类型，科目就是列名
（`NETCASH_OPERATE` / `CCE_ADD`）。这一整类 bug 在架构上消失。

## 分工

- **三大表数字** ← 本模块
- **附注内容**（审计意见/KAM/存货跌价/账龄/客户集中度）← 仍用 PDF
- **页码溯源** ← 仍用 PDF（本模块给不出页码，报告里标"结构化接口"）

数据口径为**合并报表**（东财 `by_report` 系列即合并口径）。
"""
from typing import Dict, Optional

import pandas as pd

#: 指标名 → (报表, [候选字段…])。**列表是因为同一个概念在工商企业与金融业里字段名不同**
#: （营业收入：工商企业 `TOTAL_OPERATE_INCOME`，银行 `OPERATE_INCOME`），
#: 取第一个非空值。
FIELD_MAP = {
    # ---------------- 利润表（通用）
    "营业收入": ("利润表", ["OPERATE_INCOME", "TOTAL_OPERATE_INCOME"]),
    "营业成本": ("利润表", ["OPERATE_COST"]),
    "销售费用": ("利润表", ["SALE_EXPENSE"]),
    "管理费用": ("利润表", ["MANAGE_EXPENSE"]),
    "研发费用": ("利润表", ["RESEARCH_EXPENSE"]),
    "财务费用": ("利润表", ["FINANCE_EXPENSE"]),
    "营业利润": ("利润表", ["OPERATE_PROFIT"]),
    "利润总额": ("利润表", ["TOTAL_PROFIT"]),
    "所得税费用": ("利润表", ["INCOME_TAX"]),
    "净利润": ("利润表", ["NETPROFIT"]),
    "归母净利润": ("利润表", ["PARENT_NETPROFIT"]),
    "基本每股收益": ("利润表", ["BASIC_EPS"]),
    # ---------------- 利润表（金融业）
    "利息净收入": ("利润表", ["INTEREST_NI"]),
    "利息收入": ("利润表", ["INTEREST_INCOME"]),
    "利息支出": ("利润表", ["INTEREST_EXPENSE"]),
    "手续费及佣金净收入": ("利润表", ["FEE_COMMISSION_NI"]),
    "手续费及佣金收入": ("利润表", ["FEE_COMMISSION_INCOME"]),
    "手续费及佣金支出": ("利润表", ["FEE_COMMISSION_EXPENSE"]),
    "业务及管理费": ("利润表", ["BUSINESS_MANAGE_EXPENSE", "MANAGE_EXPENSE"]),
    "信用减值损失": ("利润表", ["CREDIT_IMPAIRMENT_LOSS"]),
    "资产减值损失": ("利润表", ["ASSET_IMPAIRMENT_LOSS"]),
    "投资收益": ("利润表", ["INVEST_INCOME"]),
    "已赚保费": ("利润表", ["EARNED_PREMIUM"]),
    # ---------------- 资产负债表（通用）
    "资产总计": ("资产负债表", ["TOTAL_ASSETS"]),
    "负债合计": ("资产负债表", ["TOTAL_LIABILITIES"]),
    "所有者权益合计": ("资产负债表", ["TOTAL_EQUITY"]),
    "归母净资产": ("资产负债表", ["TOTAL_PARENT_EQUITY"]),
    "少数股东权益": ("资产负债表", ["MINORITY_EQUITY"]),
    "货币资金": ("资产负债表", ["MONETARYFUNDS"]),
    "应收账款": ("资产负债表", ["ACCOUNTS_RECE"]),
    "存货": ("资产负债表", ["INVENTORY"]),
    "流动资产合计": ("资产负债表", ["TOTAL_CURRENT_ASSETS"]),
    "流动负债合计": ("资产负债表", ["TOTAL_CURRENT_LIAB"]),
    "未分配利润": ("资产负债表", ["UNASSIGN_RPOFIT"]),
    "盈余公积": ("资产负债表", ["SURPLUS_RESERVE"]),
    "短期借款": ("资产负债表", ["SHORT_LOAN"]),
    "长期借款": ("资产负债表", ["LONG_LOAN"]),
    "应付债券": ("资产负债表", ["BOND_PAYABLE"]),
    # ---------------- 资产负债表（金融业）
    "发放贷款和垫款": ("资产负债表", ["LOAN_ADVANCE"]),
    "吸收存款": ("资产负债表", ["ACCEPT_DEPOSIT"]),
    "拆入资金": ("资产负债表", ["BORROW_FUND"]),
    "买入返售金融资产": ("资产负债表", ["BUY_RESALE_FINASSET"]),
    # ---------------- 现金流量表
    "经营活动现金流量净额": ("现金流量表", ["NETCASH_OPERATE"]),
    "投资活动现金流量净额": ("现金流量表", ["NETCASH_INVEST"]),
    "筹资活动现金流量净额": ("现金流量表", ["NETCASH_FINANCE"]),
    "销售商品收到的现金": ("现金流量表", ["SALES_SERVICES"]),
    "现金及现金等价物净增加额": ("现金流量表", ["CCE_ADD"]),
    "期初现金及现金等价物余额": ("现金流量表", ["BEGIN_CCE"]),
    "期末现金及现金等价物余额": ("现金流量表", ["END_CCE"]),
    "汇率变动对现金及现金等价物的影响": ("现金流量表", ["EXCHANGE_LOSS"]),
}

#: 报表 → 取数函数名（AkShare）
_SHEETS = {
    "利润表": "stock_profit_sheet_by_report_em",
    "资产负债表": "stock_balance_sheet_by_report_em",
    "现金流量表": "stock_cash_flow_sheet_by_report_em",
}


def to_symbol(code: str) -> Optional[str]:
    """6 位代码 → 东财 symbol（`SH601328` / `SZ000651` / `BJ830799`）。"""
    code = (code or "").strip()
    if len(code) != 6 or not code.isdigit():
        return None
    if code[0] == "6":
        return "SH" + code
    if code[0] in "03":
        return "SZ" + code
    if code[0] in "48":
        return "BJ" + code
    return None


def _report_date(period: str, report_type: str) -> str:
    """`('2025','年报')` → `'2025-12-31'`；半年报 → `'2025-06-30'`。"""
    year = str(period)[:4]
    if report_type == "半年报":
        return f"{year}-06-30"
    if report_type in ("一季报", "2025Q1"):
        return f"{year}-03-31"
    return f"{year}-12-31"


def fetch_metrics(code: str, period: str, report_type: str = "年报") -> Dict[str, float]:
    """取一家公司某期的**合并口径**三大表指标。

    返回 {指标名: 数值（元）}；取不到的指标不出现在结果里（不返回 0 或估算）。
    """
    symbol = to_symbol(code)
    if not symbol:
        return {}
    target = _report_date(period, report_type)

    out: Dict[str, float] = {}
    frames = {}
    for statement, fn_name in _SHEETS.items():
        try:
            import akshare as ak
            frames[statement] = getattr(ak, fn_name)(symbol=symbol)
        except Exception:                     # noqa: BLE001
            frames[statement] = None

    for name, (statement, fields) in FIELD_MAP.items():
        df = frames.get(statement)
        if df is None:
            continue
        hit = df[df["REPORT_DATE"].astype(str).str.startswith(target)]
        if hit.empty:
            continue
        row = hit.iloc[0]
        for field in fields:
            if field not in df.columns:
                continue
            value = row.get(field)
            if pd.isna(value):
                continue
            out[name] = float(value)
            break
    return out


def missing_fields(code: str, period: str, report_type: str = "年报") -> list:
    """诊断用：哪些指标在这个数据源里取不到。"""
    got = fetch_metrics(code, period, report_type)
    return [n for n in FIELD_MAP if n not in got]


def sync_to_db(company: str, code: str, period: str, report_type: str,
               db_path: str = "data/structured.db") -> dict:
    """把结构化接口的三大表写入库，**替换**同科目同期数的 PDF 抽取结果。

    要点：
    - 只覆盖 `FIELD_MAP` 里映射到的科目；附注类指标不受影响
    - **按 (科目, 期间) 精确替换**，不能只按科目删 —— 否则会把"上年同期"那一列
      一起删掉，恒等式紧接着变成"无法核实"（实测 32 份报告同时报缺核心三项）
    - 本期与**上年同期**一起同步，保证两列同源
    """
    import sqlite3

    years = [str(period)[:4]]
    try:
        years.append(str(int(years[0]) - 1))
    except ValueError:
        pass

    per_metric: dict = {}
    for year in years:
        values = fetch_metrics(code, year, report_type)
        for name, value in values.items():
            per_metric.setdefault(name, {})[year] = value
    if not per_metric:
        return {"updated": 0, "inserted": 0, "skipped": 0, "error": "结构化取不到数据"}

    conn = sqlite3.connect(db_path)
    try:
        row = conn.execute(
            "SELECT id FROM reports WHERE company=? AND report_type=? AND period=?",
            (company, report_type, period)).fetchone()
        if row is None:
            return {"updated": 0, "inserted": 0, "skipped": 0, "error": "该报告未入库"}
        report_id = row[0]

        updated = inserted = 0
        for name, by_year in per_metric.items():
            statement = FIELD_MAP[name][0]
            for year, value in by_year.items():
                existed = conn.execute(
                    "SELECT COUNT(*) FROM metrics WHERE report_id=? AND metric_name=? "
                    "AND period=?", (report_id, name, year)).fetchone()[0]
                conn.execute(
                    "DELETE FROM metrics WHERE report_id=? AND metric_name=? AND period=?",
                    (report_id, name, year))
                conn.execute(
                    "INSERT INTO metrics (report_id, statement, metric_name, period, value, "
                    "source_page, confidence) VALUES (?,?,?,?,?,?,?)",
                    (report_id, statement, name, year, value, 0, "high"))
                if existed:
                    updated += 1
                else:
                    inserted += 1
        conn.commit()
        return {"updated": updated, "inserted": inserted, "skipped": 0}
    finally:
        conn.close()
