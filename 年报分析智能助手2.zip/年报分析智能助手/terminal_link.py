"""终端里的**可点击链接**（OSC 8）与"打开文件"的统一入口。

为什么不再自动弹出：分析完直接把 Word 推给用户，会打断他正在看的终端输出，
而且一份报告可能只想先看结论、稍后再打开。改成**给一个可点的链接**，
点不点、什么时候点由用户决定；另提供 `/open` 命令随时打开最近一份。
"""
import os
import subprocess
import sys


def is_tty() -> bool:
    try:
        return sys.stdout.isatty()
    except Exception:            # noqa: BLE001
        return False


def link(path, text: str = None) -> str:
    """文件名 + **一行可复制的完整路径**。

    为什么不再写"Cmd+点击 / 点不动就用 /open"：实测用户看不懂这是在说什么。
    文件名本身在支持的终端里就是超链接（能点就直接点），
    路径那行只是"万一点不动时去哪里找"，不需要解释。
    """
    from pathlib import Path

    p = Path(path).resolve()
    label = text or p.name
    return f"{label}\n   文件位置：{p}"


def open_path(path) -> bool:
    """用系统默认程序打开（macOS `open` / Windows 默认 / Linux `xdg-open`）。"""
    from pathlib import Path

    p = Path(path)
    if not p.exists():
        return False
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(p)])
        elif os.name == "nt":
            os.startfile(str(p))          # noqa: S606  (Windows-only)
        else:
            subprocess.Popen(["xdg-open", str(p)])
        return True
    except Exception:                      # noqa: BLE001
        return False
