"""原文归因的**离线**测试：只 stub 网络/模型边界，提示词构造与引用整理是真实代码。"""
import pytest

from narrative import build_digest, build_narrative, build_prompt

ANALYSIS = {
    "sections": [
        {"title": "利润表分析",
         "rows": [
             {"label": "营业收入", "cur": 1000.0, "prev": 800.0, "yoy": 25.0},
             {"label": "净利润", "cur": 200.0, "prev": 150.0, "yoy": 33.33},
             {"label": "基本每股收益", "cur": 1.2, "prev": 1.0, "yoy": 20.0},
         ],
         "mix": {"groups": [{"name": "分产品", "rows": [
             {"name": "甲产品", "cur": 600.0, "prev": 400.0, "yoy": 50.0, "contrib": 90.0},
         ]}]}},
    ],
}

HITS = [{"page": 24, "text": "营业收入增长主要系甲产品销量提升所致。", "relevance": 0.8},
        {"page": 31, "text": "净利润增长还受益于毛利率改善。", "relevance": 0.7}]


def test_digest_carries_the_computed_numbers_as_facts():
    d = build_digest(ANALYSIS)
    assert "营业收入：1,000" in d and "同比 +25.00%" in d
    assert "甲产品" in d and "占总变动 +90.0%" in d
    assert "基本每股收益" not in d          # 只挑关键指标，不把整张表塞进去


def test_prompt_forbids_inventing_and_requires_page_citations():
    msgs = build_prompt("为什么变", "营业收入：1,000", HITS)
    system, user = msgs[0]["content"], msgs[-1]["content"]
    assert "第N页" in system and "未说明" in system      # 必须标页、缺就说缺
    assert "不得改动" in system                          # 数字只许引用
    assert "第24页" in user and "甲产品销量提升" in user  # 原文带页码进上下文


def test_prompt_handles_empty_retrieval():
    msgs = build_prompt("为什么变", "", [])
    assert "未检索到" in msgs[-1]["content"]


def test_narrative_merges_multiple_queries_and_dedupes_by_page():
    """多问句检索要**合并去重**（同一页只留相关度最高的一条）。

    实测只问一个维度会漏：格力 2025 年报把现金流变动原因写得明明白白
    （p29「经营活动现金流量净额同比变动 57.93%，主要系…」），
    但只问"营业收入变动原因"时它排不进前几名，模型只能答"原文未说明"。
    """
    calls = []

    def fake_search(query, company, year, top_k):
        calls.append(query)
        # 每个问句都返回 p30，但相关度不同 —— 去重后只应留最高的那次
        return [{"page": 30, "text": "t", "relevance": 0.5 + 0.1 * len(calls)},
                {"page": 40 + len(calls), "text": "t", "relevance": 0.9}]

    seen = {}

    def fake_reasoner(messages):
        seen["ctx"] = messages[-1]["content"]
        return "…"

    res = build_narrative("测试公司", "年报", "2025", "x.db", ANALYSIS,
                          search_fn=fake_search, reasoner_fn=fake_reasoner)
    assert len(calls) >= 3, f"应按多个维度检索，实际只问了 {len(calls)} 次"
    pages = [c["page"] for c in res["citations"]]
    assert len(pages) == len(set(pages)), f"同一页重复出现: {pages}"
    assert 30 in pages


def test_narrative_returns_citations_from_real_prompt_construction():
    """只有**检索与模型**被 stub；提示词与引用整理走真实代码。"""
    seen = {}

    def fake_reasoner(messages):
        seen["user"] = messages[-1]["content"]
        return "营业收入增长主要系甲产品销量提升（第24页）。"

    res = build_narrative("测试公司", "年报", "2025", "unused.db", ANALYSIS,
                          search_fn=lambda *a, **k: HITS, reasoner_fn=fake_reasoner)
    assert res["ok"] and res["grounded"]
    assert "第24页" in res["answer"]
    assert [c["page"] for c in res["citations"]] == [24, 31]
    assert "甲产品销量提升" in seen["user"]        # 原文确实进了提示词


def test_scan_finds_reason_sentences_lexically():
    """确定性扫描通道：中文财报的"变动原因"句子是**词法可识别**的。

    实测格力 2025 年报 p29 那句在向量检索里排到第 8 名、被附注挤掉，
    模型于是答"原文未说明"——假阴性。故扫描保精度、向量补语境。
    """
    import glob
    import narrative
    import pytest as _pytest

    pdfs = sorted(glob.glob("_fixtures/*.PDF"))
    if not pdfs:
        _pytest.skip("_fixtures 里没有年报 PDF（精简部署常见）")
    got = narrative.scan_reason_passages(pdfs[0])
    assert isinstance(got, list)


def test_narrative_includes_scanned_passages_even_if_vector_misses(monkeypatch):
    """向量检索漏了，扫描通道仍要把"主要系…"送进提示词。"""
    import narrative
    monkeypatch.setattr(narrative, "scan_reason_passages",
                        lambda *a, **k: [{"page": 29, "text": "经营活动现金流量净额同比变动57.93%，主要系…",
                                          "relevance": 1.0, "source": "scan"}])
    seen = {}
    res = narrative.build_narrative(
        "测试公司", "年报", "2025", "x.db", ANALYSIS,
        search_fn=lambda *a, **k: [],
        reasoner_fn=lambda m: seen.setdefault("ctx", m[-1]["content"]) or "…")
    assert res["ok"] and res["grounded"] is True
    assert 29 in [c["page"] for c in res["citations"]]
    assert "主要系" in seen["ctx"]


def test_citations_are_deduped_by_page(monkeypatch):
    """扫描通道与向量通道会捞到同一页的**不同片段** —— 出处必须按页码去重。

    实测未去重时输出成"第30页、第30页、第30页"。
    """
    import narrative
    monkeypatch.setattr(narrative, "scan_reason_passages", lambda *a, **k: [
        {"page": 29, "text": "经营活动现金流量净额同比变动57.93%，主要系…", "relevance": 1.0},
        {"page": 30, "text": "投资活动…主要系…", "relevance": 1.0}])

    def fake_search(q, company, year, top_k):
        return [{"page": 30, "text": "投资活动…", "relevance": 0.8},
                {"page": 29, "text": "经营…", "relevance": 0.7}]

    res = narrative.build_narrative("测试公司", "年报", "2025", "x.db", ANALYSIS,
                                    search_fn=fake_search,
                                    reasoner_fn=lambda m: "…")
    pages = [c["page"] for c in res["citations"]]
    assert pages == sorted(set(pages), key=pages.index), f"出处有重复: {pages}"
    assert pages == [29, 30]


def test_narrative_with_empty_retrieval_never_calls_the_model(monkeypatch):
    import narrative
    monkeypatch.setattr(narrative, "scan_reason_passages", lambda *a, **k: [])
    called = []
    res = build_narrative("测试公司", "年报", "2025", "unused.db", ANALYSIS,
                          search_fn=lambda *a, **k: [],
                          reasoner_fn=lambda *a, **k: called.append(1) or "编的")
    assert called == []
    assert res["ok"] and res["grounded"] is False
    assert "没有检索到" in res["answer"]


def test_narrative_degrades_gracefully_when_search_or_model_fails(monkeypatch):
    """索引缺失、网关挂了都不该让整份分析挂掉 —— 调用方要能照常显示数字部分。"""
    import narrative
    monkeypatch.setattr(narrative, "scan_reason_passages", lambda *a, **k: [])
    def boom(*a, **k):
        raise RuntimeError("connection refused")

    r1 = build_narrative("测试公司", "年报", "2025", "x.db", ANALYSIS, search_fn=boom)
    assert r1["ok"] is False and "检索失败" in r1["error"]

    r2 = build_narrative("测试公司", "年报", "2025", "x.db", ANALYSIS,
                         search_fn=lambda *a, **k: HITS, reasoner_fn=boom)
    assert r2["ok"] is False and "模型调用失败" in r2["error"]


def test_error_messages_do_not_leak_api_keys(monkeypatch):
    import narrative
    monkeypatch.setattr(narrative, "scan_reason_passages", lambda *a, **k: [])
    def boom(*a, **k):
        raise RuntimeError('Unauthorized: api_key="sk-abc123def456"')

    res = build_narrative("测试公司", "年报", "2025", "x.db", ANALYSIS,
                          search_fn=lambda *a, **k: HITS, reasoner_fn=boom)
    assert "sk-abc123def456" not in res["error"]
