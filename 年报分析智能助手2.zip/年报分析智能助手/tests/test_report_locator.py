import pdfplumber
from conftest import require_pdf
from metric_extractor import count_metrics
from report_locator import locate, candidate_pages, REPORT_KEYWORDS
from table_reader import read_report_page


def test_candidate_pages_includes_neighbors():
    """跨页表格的首行可能在上一页，故候选页需含前后各一页。"""
    path = require_pdf("gree_annual")
    with pdfplumber.open(path) as pdf:
        pages = candidate_pages(pdf, "合并利润表")
    assert 88 in pages
    assert 87 in pages and 89 in pages


def test_locate_gree_annual_finds_all_three_statements():
    path = require_pdf("gree_annual")
    got = locate(path, years=["2025", "2024"])
    assert got["利润表"] == 88
    assert got["现金流量表"] == 89
    assert 80 <= got["资产负债表"] <= 90


def test_locate_moutai_annual():
    path = require_pdf("moutai_annual")
    got = locate(path, years=["2025", "2024"])
    assert got["利润表"] == 61


def test_locate_all_three_on_nine_page_quarterly_report():
    """季报只有 9 页——任何绝对页码假设都会在这里暴露。

    这个 PDF 同时含两层陷阱：
      1. 「合并利润表」标头在第 6 页底部，正文却在第 7 页
      2. 标签被切成 ['：', '营业成本', 数字…]，只看 row[0] 会匹配失败

    定位必须能穿过这两层，否则季报（本次重构的初衷）就是坏的。
    """
    path = require_pdf("gree_q1")
    got = locate(path, years=["2025", "2024"])
    assert got.get("利润表") == 7, f"季报利润表定位异常: {got}"
    assert got.get("资产负债表") == 5
    # 现金流量表在第 8 页**起始**、第 9 页续。定位应选中起始页：
    # 实测第 8 页综合分 383.18（3 个指标）、第 9 页 250.43（2 个指标）。
    # 选中续页会丢掉"销售商品收到的现金"与"经营活动现金流量净额"——
    # 现金流分析里最重要的两条。
    assert got.get("现金流量表") == 8, f"季报现金流量表定位异常: {got}"


def test_locate_prefers_real_statement_over_notes_page():
    """格力半年报第 185 页含"合并资产负债表"字样，但那是附注散文
    （"本公司金融资产包括货币资金、应收款项融资等…"），不是报表。

    纯标签匹配会让它反超真正的资产负债表（第 68 页起始、69/70 页续表，
    含 `1、合并资产负债表` 与 `编制单位：`）。真报表行一定带数字单元格，
    附注散文没有。

    **不断言精确页码**：68/69/70 三页是同一张表（正文 + 续表），
    命中数 2/2/3 打平后谁被选中只取决于次序 —— 起点由 `parser._page_span`
    向前回溯连续命中页来兜。本用例要守住的是"**不许选到附注页**"。
    """
    path = require_pdf("gree_semi")
    got = locate(path, years=["2024", "2023"])
    page = got.get("资产负债表")
    assert page is not None, f"半年报资产负债表定位失败: {got}"
    assert 68 <= page <= 70, f"半年报资产负债表定位异常: {got}"
    assert page != 185, "定位落到了附注散文页"


def test_locate_skips_note_pages_and_finds_real_statement():
    """格力年报 p102/124/125 含关键词但无报表数据，不得被选中。"""
    path = require_pdf("gree_annual")
    got = locate(path, years=["2025", "2024"])
    assert got["利润表"] not in (102, 124, 125)


def test_locate_picks_text_strategy_for_gree_annual():
    """格力年报无框线：最终选优必须落到文本策略上。

    选优发生在 read_report_page（结构分 + 100×指标命中数），
    所以这条断言属于本任务，不属于 table_reader。
    """
    path = require_pdf("gree_annual")

    def counter(rows):
        return count_metrics(rows, statement="利润表")

    with pdfplumber.open(path) as pdf:
        best = read_report_page(pdf.pages[87], counter)
    assert best.strategy == "text"
    assert len(best.rows) >= 30
