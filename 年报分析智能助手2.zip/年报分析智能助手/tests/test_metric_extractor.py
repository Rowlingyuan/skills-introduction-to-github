import pytest
from metric_extractor import (
    is_number, parse_number, match_metric, match_metric_detail,
    find_year_columns, extract_metrics, count_metrics, merge_wrapped_rows,
)

GREE_ROWS = [
    ["项目", "附注", "2025年度", "2024年度"],
    ["一、营业总收入", "", "171,118,161,275.41", "190,038,071,604.78"],
    ["其中：营业收入", "五、54", "170,447,058,533.57", "189,163,654,064.64"],
    ["二、营业总成本", "", "137,548,893,694.33", "154,868,311,110.52"],
    ["五、净利润（净亏损以“-”号填列）", "", "28,862,746,016.16", "32,371,069,287.35"],
]


def test_is_number_handles_thousands_separator_and_negatives():
    assert is_number("1,234.56")
    assert is_number("-97,277,745.41")
    assert not is_number("五、54")
    assert not is_number("")


def test_parse_number_returns_float():
    assert parse_number("170,447,058,533.57") == 170447058533.57
    assert parse_number("五、54") is None


def test_match_metric_prefers_specific_alias():
    """'其中：营业收入' 必须匹配到营业收入，而非被更宽的别名抢先。"""
    assert match_metric("其中：营业收入") == "营业收入"


def test_match_metric_ignores_notes_column_content():
    assert match_metric("营业成本") == "营业成本"
    assert match_metric("五、70（1）") is None


def test_find_year_columns_reads_header_years():
    cols = find_year_columns(GREE_ROWS, default_years=["2025", "2024"])
    assert cols == {"2025": 2, "2024": 3}


def test_find_year_columns_falls_back_when_no_year_in_header():
    rows = [["项目", "附注", "本期发生额", "上期发生额"],
            ["营业收入", "", "1,234.00", "1,000.00"]]
    cols = find_year_columns(rows, default_years=["2025", "2024"])
    assert cols == {"2025": 2, "2024": 3}


def test_extract_metrics_emits_one_value_per_name_per_year():
    """每个 (指标名, 年份) 一条。上年同期值是同比/趋势分析的基础，不能丢。

    这里刻意按 (name, period) 建索引而非 {m.name: m} —— 后者会把同名指标
    压成一条，正好掩盖"只留了一年"这种缺陷。
    """
    out = extract_metrics(GREE_ROWS, page=88, years=["2025", "2024"])
    got = {}
    for m in out:
        got.setdefault(m.name, {})[m.period] = m.value
    assert got["营业收入"] == {"2025": 170447058533.57, "2024": 189163654064.64}
    assert got["营业总成本"] == {"2025": 137548893694.33, "2024": 154868311110.52}
    assert got["净利润"] == {"2025": 28862746016.16, "2024": 32371069287.35}


def test_extract_metrics_carries_source_page():
    out = extract_metrics(GREE_ROWS, page=88, years=["2025", "2024"])
    assert all(m.source_page == 88 for m in out)


def test_extract_metrics_prefers_most_specific_alias_not_row_order():
    """"其中：营业收入" 与 "一、营业总收入" 都归属 "营业收入"。

    取**别名最具体**的那行（索引小者）。这个用例把明细行放在汇总行**之前**，
    专门证伪"取最后一行"——按行序会取到 171.00，按具体度才是 170.00。
    """
    rows = [
        ["项目", "2025年度", "2024年度"],
        ["其中：营业收入", "170.00", "189.00"],   # 明细行在前
        ["一、营业总收入", "171.00", "190.00"],   # 汇总行在后
    ]
    got = {}
    for m in extract_metrics(rows, page=1, years=["2025", "2024"]):
        got.setdefault(m.name, {})[m.period] = m.value
    assert got["营业收入"] == {"2025": 170.00, "2024": 189.00}


def test_extract_metrics_marks_ambiguous_rows_medium():
    """同一指标命中多行时降级为 medium，但每年仍各出一条。"""
    rows = [["项目", "2025年度", "2024年度"],
            ["营业收入", "1,000.00", "900.00"],
            ["营业收入", "1,100.00", "950.00"]]
    out = [m for m in extract_metrics(rows, page=1, years=["2025", "2024"])
           if m.name == "营业收入"]
    assert len(out) == 2
    assert {m.period for m in out} == {"2025", "2024"}
    assert all(m.confidence == "medium" for m in out)


def test_count_metrics_counts_distinct_hits():
    assert count_metrics(GREE_ROWS) >= 3
    assert count_metrics([["附注", "2025年度"], ["五、54", "1,234"]]) == 0


SPLIT_LABEL_ROWS = [
    ["：", "营业成本", "30,150,364,481.08", "25,985,115,840.30"],
    ["", "税金及附加", "464,936,322.72", "366,202,950.54"],
    ["", "销售费用", "2,250,814,319.10", "2,345,801,162.48"],
]


def test_label_split_across_cells_still_matches():
    """文本对齐策略会把 "其中：营业成本" 切成 ['：', '营业成本', 数字…]。

    只看 row[0] 得到的是 "："，匹配不到任何指标，整张表被判 0 分 ——
    这正是格力季报利润表定位失败的根因（实测第 7 页）。年报里的
    "其中：XXX" 行也大量存在，所以这是通用缺陷，不是季报特例。
    """
    assert count_metrics(SPLIT_LABEL_ROWS, "利润表") == 3
    got = {(m.name, m.period): m.value
           for m in extract_metrics(SPLIT_LABEL_ROWS, page=7, years=["2025", "2024"])}
    assert got[("营业成本", "2025")] == 30150364481.08
    assert got[("销售费用", "2024")] == 2345801162.48


def test_count_metrics_ignores_prose_rows():
    """附注散文会含指标词但没有数字，不得计入。

    实测格力半年报第 185 页的 8 个"命中"全部长这样，且因此反超了第 68 页
    的真资产负债表。判别依据：真报表数据行一定带数字，说明文字没有。
    """
    prose = [
        ["本公司金融资产包括", "货币资金、应收款项融资等，", "这些金融资产的信用风险源自交易对手违约"],
        ["截至报告期末，本公", "司的应收票据、应收账款、应", "收款项融资、其他应收款、合同资产"],
    ]
    assert count_metrics(prose, "资产负债表") == 0

    real = [["", "货币资金", "", "119,805,076,724.91", "", "",
             "124,104,987,289.62", "", ""]]
    assert count_metrics(real, "资产负债表") == 1


BALANCE_ROWS = [
    ["项目", "附注", "2025年12月31日", "2024年12月31日"],
    ["流动资产合计", "", "100.00", "90.00"],
    ["流动负债合计", "", "50.00", "45.00"],
    ["负债合计", "", "60.00", "55.00"],
    ["资产总计", "", "200.00", "180.00"],
]


def test_match_metric_is_statement_aware():
    """同一行标签在不同表下归属不同，用错表会给定位阶段打错分。"""
    assert match_metric("资产总计") is None                        # 利润表别名里没有
    assert match_metric("资产总计", "资产负债表") == "资产总计"


def test_flow_liability_total_not_shadowed_by_liability_total():
    """'流动负债合计' 含 '负债合计' 子串——长者必须在前，否则被抢先匹配。"""
    assert match_metric("流动负债合计", "资产负债表") == "流动负债合计"
    assert match_metric("负债合计", "资产负债表") == "负债合计"


def test_non_current_totals_are_not_absorbed_by_current_ones():
    """'非流动资产合计' 含 '流动资产合计' 子串 —— 别名表必须显式收下"非流动"这一族。

    不收的后果（实测格力 2025 年报 p86–87）：
        `非流动资产合计 1404 亿` 被记成 `流动资产合计`
        `非流动负债合计  100 亿` 被记成 `流动负债合计`
    于是流动比率从 1.08 变成 14.03。两族数值完全不同，混用是量级级错误。
    """
    assert match_metric("非流动资产合计", "资产负债表") == "非流动资产合计"
    assert match_metric("非流动负债合计", "资产负债表") == "非流动负债合计"
    # 反过来不能串：真·流动合计仍归流动
    assert match_metric("流动资产合计", "资产负债表") == "流动资产合计"
    assert match_metric("流动负债合计", "资产负债表") == "流动负债合计"


def test_extract_balance_sheet_metrics_carries_statement():
    out = extract_metrics(BALANCE_ROWS, page=86, years=["2025", "2024"],
                          statement="资产负债表")
    by_name_period = {(m.name, m.period): m for m in out}
    assert by_name_period[("资产总计", "2025")].value == 200.00
    assert by_name_period[("资产总计", "2025")].statement == "资产负债表"


def test_count_metrics_is_statement_aware():
    assert count_metrics(BALANCE_ROWS, "资产负债表") >= 4
    assert count_metrics(BALANCE_ROWS, "利润表") == 0


# --- 兜底列映射：无表头时年份必须落在**数值列**上，而不是附注列/占位列 ---

MOUTAI_P57_BALANCE_ROWS = [
    # 实测贵州茅台-2025年度报告 p57（资产负债表第 2 页）：本页无表头行，
    # rows[0] 直接是数据行，列 1 是**附注号**列而非数值列。
    ["衍生金融资产", "", "", ""],
    ["应收票据", "4", "", "1,984,407,967.50"],
    ["应收账款", "5", "2,609,048.49", "18,974,192.75"],
    ["应收款项融资", "6", "4,457,064,160.16", ""],
    ["预付款项", "7", "6,637,314.31", "26,975,033.20"],
    ["存货", "10", "61,427,421,796.18", "54,343,285,157.47"],
    ["资产总计", "", "303,834,844,021.44", "298,944,579,918.70"],
]


def test_find_year_columns_fallback_ignores_note_column():
    """兜底路径不得把附注号列当成"本期值"列。

    修前：numeric_cols = [1,2,3] → {"2025": 1, "2024": 2}，
    于是 2025 取到附注号 "5"、2024 取到真正的 2025 值，
    真正的 2024 值被丢弃 —— 且 confidence="high"。
    """
    cols = find_year_columns(MOUTAI_P57_BALANCE_ROWS, default_years=["2025", "2024"])
    assert cols == {"2025": 2, "2024": 3}


def test_extract_metrics_fallback_does_not_fabricate_from_note_column():
    """同一形状走完整抽取：应收账款 2025 必须是真值，不是附注号 5.00。"""
    got = {(m.name, m.period): m.value
           for m in extract_metrics(MOUTAI_P57_BALANCE_ROWS, page=57,
                                    years=["2025", "2024"],
                                    statement="资产负债表")}
    assert got[("应收账款", "2025")] == 2609048.49
    assert got[("应收账款", "2024")] == 18974192.75
    assert got[("资产总计", "2025")] == 303834844021.44
    assert got[("资产总计", "2024")] == 298944579918.70


GREE_P87_BALANCE_ROWS = [
    # 实测格力电器-2025年报 p87：本页无表头行，列 2 是**空占位列**。
    ["一年内到期的非流动负债", "五、39", "", "13,668,113,331.54", "15,577,179,285.89"],
    ["其他流动负债", "五、40", "", "63,698,924,697.49", "62,880,048,180.93"],
    ["流动负债合计", "", "", "200,072,364,635.75", "166,873,448,906.77"],
    ["非流动负债合计", "", "", "31,497,466,560.51", "34,251,992,475.09"],
    ["负债合计", "", "", "231,569,831,196.26", "201,125,441,381.86"],
]


def test_find_year_columns_fallback_ignores_empty_spacer_column():
    """兜底路径不得把空占位列计入数值列，否则整张映射左移一列。

    修前：numeric_cols = [1,2,3,4] → {"2025": 1, "2024": 2}。
    """
    cols = find_year_columns(GREE_P87_BALANCE_ROWS, default_years=["2025", "2024"])
    assert cols == {"2025": 3, "2024": 4}


def test_extract_metrics_fallback_reports_spacer_shape_both_years():
    got = {(m.name, m.period): m.value
           for m in extract_metrics(GREE_P87_BALANCE_ROWS, page=87,
                                    years=["2025", "2024"],
                                    statement="资产负债表")}
    assert got[("负债合计", "2025")] == 231569831196.26
    assert got[("负债合计", "2024")] == 201125441381.86


def test_find_year_columns_fallback_survives_degenerate_table():
    """数值列不足 default_years 个数时，只能少给年份，不能崩。

    实测格力年报 p87 的框线策略候选表：pdfplumber 把整张表压成 2 列，
    第 2 列是一长串首尾相连的数字，`is_number` 判定为 False，
    于是数字列集合为空。取"最右侧若干个"时切片的起点会越过列表上界。
    """
    rows = [["附注", "2025年12月31日"],
            ["五、30五、31", "67,956,629,538.5165,094,952.36"]]
    assert find_year_columns(rows, default_years=["2025", "2024"]) == {}
    assert extract_metrics(rows, page=87, years=["2025", "2024"],
                           statement="资产负债表") == []


def test_find_year_columns_fallback_gives_one_year_when_only_one_numeric_col():
    rows = [["项目", "附注", "本期发生额"],
            ["营业收入", "五、54", "1,234.00"]]
    assert find_year_columns(rows, default_years=["2025", "2024"]) == {"2025": 2}


def test_match_metric_prefers_longest_alias_over_table_order():
    """跨指标的子串必须由「更长的别名」胜出，而非别名表的顺序。

    `归属于母公司股东权益合计` 含 `所有者权益合计`；`归属于母公司股东的净利润`
    含 `净利润`。按表序取的话，归母行会被标成合计类指标，**真正的合计行反被丢弃**
    （实测：比亚迪/顺丰/格力一季报的 `资产总计 = 负债合计 + 所有者权益合计`
    差额恰好等于少数股东权益），而且 `归母净利润`/`归母净资产` 永远抽不到。
    """
    assert match_metric("归属于母公司股东权益合计", "资产负债表") == "归母净资产"
    assert match_metric("归属于母公司股东的净利润", "利润表") == "归母净利润"
    # 合计行本身仍归合计类指标（不能修一个坏一个）
    assert match_metric("所有者权益合计", "资产负债表") == "所有者权益合计"
    assert match_metric("五、净利润（净亏损以“-”号填列）", "利润表") == "净利润"


def test_match_metric_tie_keeps_table_order():
    """平局（等长别名）必须保持表序 —— 这是「不改变既有行为」的保证。

    `其中：营业收入`(7 字) 与 `营业总收入`(5 字) 都比 `营业收入`(4 字) 长，
    但两者分属同一指标的别名表，值都指向 170,447,058,533.57，与表序结论一致。
    """
    assert match_metric("其中：营业收入", "利润表") == "营业收入"
    assert match_metric("一、营业总收入", "利润表") == "营业收入"


def test_merge_wrapped_rows_joins_split_label_around_number_row():
    """标签被折行切成"前半 / 数值行 / 后半"三行时必须拼回一行。

    形态取自茅台 2024 年报 p61（合并资产负债表续表）的真实抽取结果：
        ['归属于母公司所有者权益', '', '', '']
        ['', '', '233,105,984,399.47', '215,668,571,607.43']
        ['或股东权益）合计', '', '', '']
    不拼的话：数值行没有标签、标签行没有数值，`归母净资产` 永远抽不到。
    """
    rows = [
        ["未分配利润", "39", "182,787,415,205.05", "172,983,178,300.09"],
        ["归属于母公司所有者权益", "", "", ""],
        ["", "", "233,105,984,399.47", "215,668,571,607.43"],
        ["或股东权益）合计", "", "", ""],
    ]
    merged = merge_wrapped_rows(rows)
    assert merged[1][0] == "归属于母公司所有者权益或股东权益）合计"
    assert merged[1][2] == "233,105,984,399.47"
    # 拼接只是手段，**能被匹配**才是目的
    assert match_metric(merged[1][0], "资产负债表") == "归母净资产"


def test_merge_wrapped_rows_leaves_normal_tables_alone():
    """结构正常的表不得被改动 —— 规则只在"有数字无标签"的窄条件下触发。"""
    rows = [
        ["项目", "附注", "2025年度", "2024年度"],
        ["一、营业总收入", "", "171,118,161,275.41", "190,038,071,604.78"],
        ["其中：营业收入", "五、54", "170,447,058,533.57", "189,163,654,064.64"],
    ]
    assert merge_wrapped_rows(rows) == rows


def test_match_metric_normalises_equity_parenthetical_idiom():
    """`所有者权益（或股东权益）合计` 是中文财报的标准写法，必须能匹配。

    折行抽取会把括注切开甚至丢字（实测茅台 p61 两种残缺形态都出现过），
    故匹配前做两步归一化：先删成对括注内容，再删残缺的括注片段。
    """
    assert match_metric("所有者权益（或股东权益）合计", "资产负债表") == "所有者权益合计"
    assert match_metric("归属于母公司所有者权益（或股东权益）合计",
                        "资产负债表") == "归母净资产"
    assert match_metric("所有者权益（或股东权）合计", "资产负债表") == "所有者权益合计"
    assert match_metric("归属于母公司所有者权益或股东权益）合计",
                        "资产负债表") == "归母净资产"


# --- 表头年份识别：区分真报表与附注散文被切成的"表" -------------------------

def test_has_year_header_accepts_real_statement_header():
    from metric_extractor import has_year_header
    rows = [["项目", "附注", "2024年12月31日", "2023年12月31日"],
            ["货币资金", "1", "59,295,822,956.89", "69,070,136,376.12"]]
    assert has_year_header(rows, ["2024", "2023"])


def test_has_year_header_rejects_prose_fragment():
    """茅台 2024 年报 p58 的碎片表：审计报告正文，只有一行蹭到年份。"""
    from metric_extractor import has_year_header
    rows = [["导致", "对贵州茅台公司持续经营能力产", "生重大疑虑"],
            ["如果", "我们得出结论认为存在重大不确定性", "2024年"],
            ["货币资金", "1", "59,295,822,956.89"]]
    assert not has_year_header(rows, ["2024", "2023"])


def test_has_year_header_is_false_without_years():
    from metric_extractor import has_year_header
    assert not has_year_header([["项目", "附注", "2024年", "2023年"]], [])


def test_realign_year_columns_fixes_header_shift():
    """恒瑞 p75：表头标签列在 index 1、数据在 0，年份落在第 7/10 列（空格子）。"""
    from metric_extractor import realign_year_columns
    rows = [["", "项目", "", "", "附注", "", "", "2026 年 6 月 30日", "", "", "2025 年 12 月 31日", ""],
            ["货币资金", "", "", "七、1", "", "", "38,734,324,278.37", "", "", "40,955,482,467.79", "", ""],
            ["存货", "", "", "七、10", "", "", "2,993,971,049.37", "", "", "2,878,412,496.88", "", ""],
            ["流动资产合计", "", "", "", "", "", "49,607,557,380.05", "", "", "51,490,372,457.04", "", ""]]
    assert realign_year_columns(rows, {"2026": 7, "2025": 10}) == {"2026": 6, "2025": 9}


def test_realign_year_columns_leaves_correct_mapping_alone():
    from metric_extractor import realign_year_columns
    rows = [["项目", "附注", "2026年", "2025年"],
            ["货币资金", "1", "100", "90"],
            ["存货", "2", "20", "18"]]
    assert realign_year_columns(rows, {"2026": 2, "2025": 3}) == {"2026": 2, "2025": 3}


# --- 被切开的数字：'2' + '62,096,352,174.36' -------------------------------

_BAL_HEAD = ["项目", "附注", "2026年6月30日", "2025年12月31日"]


def test_merge_split_numbers_rebuilds_the_leading_digit():
    """茅台 2026 半年报 p28 的续表：所有者权益合计首位被切走，差 2000 亿。

    该表是上一页的延续，没有表头，靠「附注」定位不到列 —— 判据落在**列形态**上：
    第 2 列清一色是单数字（`2`/`3`），第 3 列才是完整金额，故可拼。
    """
    from metric_extractor import merge_split_numbers
    rows = [["", "未分配利润", "1", "99,683,216,816.20"],
            ["", "归属于母公司所有者权益", "", ""],
            ["", "", "2", "51,253,594,419.50"],
            ["", "所有者权益（或股东权", "", ""],
            ["", "", "2", "62,096,352,174.36"],
            ["", "负债和所有者权益（或", "", ""],
            ["", "", "3", "09,050,784,569.31"]]
    out = merge_split_numbers(rows)
    got = {r[-1] for r in out}
    assert "262,096,352,174.36" in got
    assert "309,050,784,569.31" in got


def test_merge_split_numbers_refuses_to_eat_note_numbers():
    """附注号 `5` 后面跟 `2,609,048.49` 时绝不能拼成 `52,609,048.49`。

    判据是"尾巴首组恰好两位"—— `2,609,048.49` 首组一位，是完整数字。
    """
    from metric_extractor import merge_split_numbers
    rows = [_BAL_HEAD, ["应收账款", "5", "2,609,048.49", "18,974,192.75"]]
    assert merge_split_numbers(rows)[1] == rows[1]


def test_merge_split_numbers_skips_when_note_column_is_ambiguous():
    """表头里找不到「附注」→ 整张表不拼（宁可不修，也不能拼错）。"""
    from metric_extractor import merge_split_numbers
    rows = [["项目", "2026年"], ["所有者权益合计", "2", "62,096,352,174.36"]]
    assert merge_split_numbers(rows)[1] == rows[1]


def test_find_year_columns_prefers_leftmost_group_when_merged_and_company_side_by_side():
    """顺丰 p92：合并2026 | 合并2025 | 公司2026 | 公司2025。

    取最后一个会把年份映射到「公司」那两列（整列是 `-`），整张表只抽出 1 个指标。
    """
    from metric_extractor import find_year_columns
    rows = [["", "项目", "附注", "2026 年", "2025 年", "2026 年", "2025 年"],
            ["", "", "", "合并", "合并", "公司", "公司"],
            ["", "销售商品收到的现金", "", "162,357,719", "151,032,535", "-", "-"]]
    assert find_year_columns(rows, ["2026", "2025"]) == {"2026": 3, "2025": 4}


def test_match_metric_tolerates_direction_slashes():
    """顺丰把净额行写成 `经营活动产生/(使用)的现金流量净额`。"""
    from metric_extractor import match_metric
    assert match_metric("经营活动产生/(使用)的现金流量净额", "现金流量表") == "经营活动现金流量净额"
    assert match_metric("投资活动(使用)/产生的现金流量净额", "现金流量表") == "投资活动现金流量净额"
    assert match_metric("筹资活动(使用)/产生的现金流量净额", "现金流量表") == "筹资活动现金流量净额"
    assert match_metric("经营活动产生的现金流量净额", "现金流量表") == "经营活动现金流量净额"
