"""启动脚本的行为：选环境、选安装位置、国内镜像、可执行权限。

新用户的机器是干净的，装依赖（约 200 MB）是必经步骤；实测反馈集中在两点：
"能不能让我选本机还是新建"、"为什么选择项打不开/没了"。
"""
import builtins
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_macos_launcher_offers_both_install_modes():
    s = (ROOT / "启动.command").read_text(encoding="utf-8")
    assert "复用本机已装依赖" in s
    assert "全新独立环境" in s


def test_windows_launcher_offers_both_install_modes():
    s = (ROOT / "启动.bat").read_text(encoding="utf-8")
    assert "复用本机已装依赖" in s
    assert "全新独立环境" in s
    assert "set /p" in s


def test_launchers_use_domestic_pip_mirror():
    """默认走清华源：直连 pypi.org 是"装得久"的主因。"""
    for name in ("启动.command", "启动.bat"):
        s = (ROOT / name).read_text(encoding="utf-8")
        assert "pypi.tuna.tsinghua.edu.cn" in s, f"{name} 没用国内镜像"
        assert "ARA_PIP_INDEX" in s, f"{name} 不能换源"


def test_launcher_files_are_executable():
    """包里丢了可执行位，双击就报错。"""
    assert os.access(ROOT / "启动.command", os.X_OK)


def test_launcher_always_offers_environment_choice():
    """**每次启动都能选环境**，不需要单独一个"重置环境"文件。

    早期做法是"有 .venv 就秒开，另给一个重置入口"，被指出多余：
    选择本来就应该在启动时出现。
    """
    s = (ROOT / "启动.command").read_text(encoding="utf-8")
    assert "复用本机已装依赖" in s and "删掉重建" in s
    assert "--setup" in s                     # 想换环境时的显式入口

    b = (ROOT / "启动.bat").read_text(encoding="utf-8")
    assert "--setup" in b

    # 多余入口已合并
    assert not (ROOT / "重置环境.command").exists()
    assert not (ROOT / "重置环境.bat").exists()
    assert not (ROOT / "看板.command").exists()
    assert not (ROOT / "看板.bat").exists()


def test_missing_deps_offers_interactive_install(monkeypatch, tmp_path):
    """直接 `python main.py` 时缺依赖，要能就地选安装方式。"""
    import sys as _sys

    import main

    asked = {"prompted": False}

    class FakeStdin:
        def isatty(self):
            return True

    monkeypatch.setattr(_sys, "stdin", FakeStdin())
    monkeypatch.setattr(builtins, "input",
                        lambda *a: (asked.update(prompted=True), "3")[1])

    printed = []
    monkeypatch.setattr(builtins, "print",
                        lambda *a, **k: printed.append(" ".join(map(str, a))))

    assert main._offer_install(tmp_path) is False          # 非法选择 → 不真装
    text = "\n".join(printed)
    assert "复用本机已装依赖" in text and "全新独立环境" in text
    assert asked["prompted"] is True


def test_missing_deps_does_not_prompt_without_tty(monkeypatch, tmp_path):
    """管道/脚本场景不能卡在 input() 上。"""
    import main

    called = {"n": 0}
    monkeypatch.setattr(builtins, "input",
                        lambda *a: called.__setitem__("n", called["n"] + 1) or "2")

    class NoTTY:
        def isatty(self):
            return False

    monkeypatch.setattr(main.sys, "stdin", NoTTY())
    main._offer_install(tmp_path)
    assert called["n"] == 0


def test_installs_show_progress():
    """安装必须**看得见进度**。

    实测：朋友卡在"正在安装（几分钟）…"那行字上，屏幕几分钟不动，
    以为程序死了。根因是 `pip install -q` 把下载进度全吞了。
    """
    main_src = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "--progress-bar" in main_src
    # 装 requirements 时不能再带 -q（`--upgrade pip` 这种引导性调用可以静音）
    import re
    for m in re.finditer(r'\[[^\]]*pip", "install"[^\]]*\]', main_src):
        call = m.group(0)
        if "requirements" not in call:
            continue
        assert '"-q"' not in call, f"安装依赖时用了 -q，用户看不到进度：{call[:60]}"

    for name in ("启动.command", "启动.bat"):
        s = (ROOT / name).read_text(encoding="utf-8")
        assert "--progress-bar" in s, f"{name} 安装时没有进度条"
        for line in s.splitlines():
            if "requirements.txt" in line and "pip install" in line:
                assert " -q " not in line, f"{name} 的依赖安装用了 -q"


def test_rag_install_tells_how_long():
    """1.5 GB 的检索组件要提前说清"多久"，而不是只说"几分钟"。"""
    src = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "约 1.5 GB" in src and "分钟" in src


def test_reuse_mode_avoids_pep668():
    """“装到本机”必须用 --system-site-packages 建环境，而不是直接 pip 到系统。

    实测：朋友选“装到本机”，报 `externally-managed-environment`（PEP 668），
    选项变成了摆设。正确做法是建一个能看见本机包、但不往系统里装的 venv。
    """
    for name in ("启动.command", "启动.bat"):
        s = (ROOT / name).read_text(encoding="utf-8")
        assert "--system-site-packages" in s, f"{name} 没复用本机包"
        # 不能出现“直接装到系统 Python”的调用
        for line in s.splitlines():
            if "pip install" in line and "requirements" in line:
                assert ".venv" in line or "system-site" in line, f"{name} 在直接装到系统：{line.strip()[:70]}"

    main_src = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "--system-site-packages" in main_src


def test_launcher_goes_straight_to_chat():
    """启动就进对话，**不要一开始问"要看板还是对话"**。

    看板的正确时机是"分析完某家公司之后"（/html 或报告后的链接，
    且默认已定位到那家公司），而不是启动时在库里的公司里挑。
    """
    for name in ("启动.command", "启动.bat"):
        s = (ROOT / name).read_text(encoding="utf-8")
        assert "对话模式" not in s, f"{name} 还有模式菜单"
        assert "浏览器看趋势图" not in s, f"{name} 还有看板入口"
    s = (ROOT / "启动.command").read_text(encoding="utf-8")
    assert "exec .venv/bin/python main.py" in s
