import pytest
from models import Announcement
from downloader import pick_official


def _ann(title, pub_date="2025-04-28"):
    return Announcement(title=title, url="http://x/y.PDF", pub_date=pub_date)


def test_pick_official_skips_summary_and_english():
    anns = [
        _ann("2024年年度报告（英文版）"),
        _ann("2024年年度报告摘要"),
        _ann("2024年年度报告"),
    ]
    assert pick_official(anns).title == "2024年年度报告"


def test_pick_official_returns_none_when_only_summaries():
    anns = [_ann("2024年年度报告摘要"), _ann("2024年年度报告（英文版）")]
    assert pick_official(anns) is None


def test_pick_official_prefers_earliest_when_multiple_officials():
    """更正版晚于原版发布，取最早的一条——即原版。

    日期必须不同：若两条 pub_date 相同，Python 的稳定排序会保留输入顺序，
    这条测试就退化成了"什么都不测"，无论实现是否正确都会通过/失败于偶然。
    """
    anns = [
        _ann("2024年年度报告（更正版）", "2025-06-01"),
        _ann("2024年年度报告", "2025-04-28"),
    ]
    assert pick_official(anns).title == "2024年年度报告"


def _ann_year(title, pub_date):
    return Announcement(title=title, url="http://x/y.PDF", pub_date=pub_date)


def test_pick_for_year_selects_requested_year():
    """跨年份查询必须按标题年份收窄，否则会拿到区间里最旧的那份。

    实测：`fetch('五粮液','年报','2023-01-01','2025-12-31')` 拿回了 2022 年年报。
    """
    from downloader import pick_for_year
    anns = [_ann_year("2022年年度报告", "2023-04-28"),
            _ann_year("2023年年度报告", "2024-04-28"),
            _ann_year("2024年年度报告", "2025-04-28")]
    assert pick_for_year(anns, 2023).title == "2023年年度报告"
    assert pick_year_title(anns) == "2024年年度报告"


def pick_year_title(anns):
    from downloader import pick_for_year
    return pick_for_year(anns).title


def test_pick_for_year_without_year_takes_newest():
    from downloader import pick_for_year
    anns = [_ann_year("2022年年度报告", "2023-04-28"),
            _ann_year("2024年年度报告", "2025-04-28")]
    assert pick_for_year(anns).title == "2024年年度报告"


def test_pick_for_year_returns_none_when_year_absent():
    from downloader import pick_for_year
    anns = [_ann_year("2022年年度报告", "2023-04-28")]
    assert pick_for_year(anns, 2024) is None


def test_title_year_parses_the_year():
    from downloader import title_year
    assert title_year(_ann_year("2024年年度报告", "2025-04-28")) == 2024
    assert title_year(_ann_year("看不懂的标题", "2025-04-28")) is None
