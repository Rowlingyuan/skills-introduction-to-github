"""附注定性信息（审计意见 / 关键审计事项）的抽取。"""
import pytest

from notes import _KAM_ITEM_RE, classify_opinion, extract_audit


# --- 审计意见判定 ---------------------------------------------------------

def test_standard_opinion_not_confused_by_substring():
    """「标准的无保留意见」含「保留意见」子串 —— 必须判成标准无保留。

    这是实测踩到的坑：格力、五粮液两份标准意见一开始都被判成了保留意见。
    """
    assert classify_opinion("标准的无保留意见") == "标准无保留意见"
    assert classify_opinion("标准无保留意见") == "标准无保留意见"


def test_emphasis_paragraph_requires_both_keywords():
    assert classify_opinion("带强调事项段的无保留意见") == "带强调事项段的无保留意见"
    assert classify_opinion("无保留意见") == "标准无保留意见"
    assert classify_opinion("强调事项：应收账款回收") == "标准无保留意见" \
        or classify_opinion("强调事项：应收账款回收") is None


def test_adverse_and_disclaimer_win_over_others():
    assert classify_opinion("我们不对财务报表发表意见，无法表示意见") == "无法表示意见"
    assert classify_opinion("否定意见") == "否定意见"


def test_qualified_opinion():
    assert classify_opinion("除……的影响外，我们出具保留意见") == "保留意见"


def test_unknown_text_returns_none():
    assert classify_opinion("") is None
    assert classify_opinion("这是一段无关的正文") is None


# --- KAM 条目名 -----------------------------------------------------------

def test_kam_item_pattern_accepts_both_widths():
    assert _KAM_ITEM_RE.match("（一）存货跌价准备的计提")
    assert _KAM_ITEM_RE.match("(一) 收入确认")
    assert _KAM_ITEM_RE.match("(二)关联方及其交易")


def test_kam_item_pattern_rejects_body_lines():
    assert not _KAM_ITEM_RE.match("关键审计事项是我们根据职业判断……")
    assert not _KAM_ITEM_RE.match("四、其他信息")


# --- 真样本（fixture 缺失则跳过） ----------------------------------------

def test_gree_annual_audit_opinion_and_kam():
    from conftest import require_pdf
    path = require_pdf("gree_annual")
    got = extract_audit(path, "年报")
    assert got["ok"] and got["audited"]
    assert got["opinion"] == "标准无保留意见"
    titles = [i["title"] for i in got["kam_items"]]
    assert "收入确认" in titles
    assert all(i["page"] > 0 for i in got["kam_items"])


def test_semi_annual_report_is_reported_as_unaudited():
    """半年报没有审计报告 —— 要区分「未经审计」与「年报里找不到」。"""
    from conftest import require_pdf
    path = require_pdf("gree_semi")
    got = extract_audit(path, "半年报")
    assert got["ok"] is True
    assert got["audited"] is False
    assert "未经审计" in got["note"]


# --- 存货跌价准备 ---------------------------------------------------------

def test_inventory_provision_on_gree_fixture():
    """格力 2025 年报：附注合计行与审计报告 KAM 段里的数字必须一致。

    KAM 原文：存货账面价值 2,818,346.43 万元、账面余额 3,145,013.11 万元、
    跌价准备 326,666.69 万元 —— 正好用来验抽取对不对。
    """
    from conftest import require_pdf
    from notes import extract_inventory_provision

    path = require_pdf("gree_annual")
    got = extract_inventory_provision(path, expected_net=28_183_464_259.53)
    assert got["ok"]
    cur = got["cur"]
    assert cur["gross"] == pytest.approx(31_450_131_116.46, rel=1e-9)
    assert cur["provision"] == pytest.approx(3_266_666_856.93, rel=1e-9)
    assert cur["net"] == pytest.approx(28_183_464_259.53, rel=1e-9)
    assert got["ratio"] == pytest.approx(10.39, abs=0.01)


def test_inventory_provision_refuses_to_guess_without_matching_net():
    """报表存货对不上任何合计行时**必须返回未找到**，不能拿别的表的合计顶替。

    实测茅台 p93 有个 12.11 亿的三列合计行，而它的存货是 543 亿。
    """
    from conftest import require_pdf
    from notes import extract_inventory_provision

    path = require_pdf("gree_annual")
    got = extract_inventory_provision(path, expected_net=1_000_000_000.0)
    assert got["ok"] is False
    assert "没有一行的账面价值与报表存货一致" in got["note"]


# --- 应收账款账龄 ---------------------------------------------------------

def test_receivables_aging_on_gree_fixture():
    """格力 2025 年报 p131：账龄四档 + 小计/坏账/合计，合计等于报表应收账款。"""
    from conftest import require_pdf
    from notes import extract_receivables

    got = extract_receivables(require_pdf("gree_annual"),
                              expected_net=15_987_180_598.76)
    assert got["ok"]
    assert got["gross"] == pytest.approx(19_066_498_733.80, rel=1e-9)
    assert got["provision"] == pytest.approx(3_079_318_135.04, rel=1e-9)
    assert [a["label"] for a in got["aging"]] == ["1年以内", "1至2年", "2至3年", "3年以上"]
    assert got["ratio"] == pytest.approx(16.15, abs=0.01)


def test_receivables_refuses_mismatched_net():
    from conftest import require_pdf
    from notes import extract_receivables

    got = extract_receivables(require_pdf("gree_annual"), expected_net=123.0)
    assert got["ok"] is False


# --- 或有事项 / 承诺 / 关联交易 ------------------------------------------

def test_qualitative_notes_on_gree_fixture():
    from conftest import require_pdf
    from notes import extract_qualitative_notes

    got = extract_qualitative_notes(require_pdf("gree_annual"))
    assert got["ok"]
    kinds = {i["kind"] for i in got["items"]}
    assert "或有事项" in kinds
    assert "承诺事项" in kinds
    # 承诺事项在格力是"无。"，必须识别成 empty 而不是摘出一句空话
    commit = next(i for i in got["items"] if i["kind"] == "承诺事项")
    assert commit["empty"] is True


def test_kam_title_must_have_meaningful_characters():
    """`（二）、。` 这类被切碎的标点残块不能当成关键审计事项。"""
    from notes import is_valid_kam_title
    assert is_valid_kam_title("货币资金的存在性和完整性")
    assert is_valid_kam_title("收入确认")
    assert not is_valid_kam_title("、。")
    assert not is_valid_kam_title("…——")
    assert not is_valid_kam_title("")


def test_kam_numeric_numbering_is_recognised():
    """泸州老窖用 `1、货币资金的存在性及完整性`（阿拉伯数字），不是 `（一）`。"""
    from pathlib import Path
    import pytest as _pytest
    # 这份报告是运行期下载的，不在 _fixtures 里；两种情况都兜住
    p = Path("data/泸州老窖/年报/2025年年度报告.PDF")
    if not p.exists():
        _pytest.skip("样本缺失（先跑一次「帮我下载并分析泸州老窖2025年报」）")
    from notes import extract_audit
    got = extract_audit(p, "年报")
    titles = [i["title"] for i in got["kam_items"]]
    assert "货币资金的存在性及完整性" in titles


def test_audit_procedure_lines_are_not_kam_titles():
    """审计应对步骤也写成 `1、了解、测试并评价…`，不能当成事项名。"""
    from notes import looks_like_kam_action
    assert not looks_like_kam_action("货币资金的存在性及完整性")
    assert not looks_like_kam_action("收入确认")
    assert looks_like_kam_action("通过对存货库龄情况进行分析性复核，以确")
    assert looks_like_kam_action("对存货盘点进行了监盘，在监盘过程中，除")
    assert looks_like_kam_action("在审计抽样的基础上，执行函证程序，并检")
    assert looks_like_kam_action("事项描述")


# --- 客户集中度 -----------------------------------------------------------

def test_customer_concentration_table_style():
    """格力 p25：表格式，占比在下一行，同段还有关联方占比。"""
    from conftest import require_pdf
    from notes import extract_customer_concentration
    got = extract_customer_concentration(require_pdf("gree_annual"))
    assert got["ok"]
    assert got["ratio"] == pytest.approx(14.40, abs=0.01)
    assert got["related_ratio"] == pytest.approx(2.34, abs=0.01)


def test_customer_concentration_prose_style():
    """中芯 p27：`第一名和前五名客户销售额分别占…8.0%和35.8%`。

    并列写法要取**后一个**（前五名 ≥ 第一名），不能被"占"后第一个数字骗到。
    """
    from pathlib import Path
    import pytest as _pytest
    p = Path("data/中芯国际/年报/中芯国际2025年年度报告.PDF")
    if not p.exists():
        _pytest.skip("样本缺失")
    from notes import extract_customer_concentration
    got = extract_customer_concentration(p)
    assert got["ratio"] == pytest.approx(35.8, abs=0.1)


def test_kam_unnumbered_title_is_recognised():
    """华工科技：KAM 是**无编号裸标题** `收入确认`，下一行才是 `1.事项描述`。"""
    from pathlib import Path
    import pytest as _pytest
    p = Path("data/华工科技/年报/2025年年度报告.PDF")
    if not p.exists():
        _pytest.skip("样本缺失")
    from notes import extract_audit
    got = extract_audit(p, "年报")
    assert "收入确认" in [i["title"] for i in got["kam_items"]]


# --- 商誉 ---------------------------------------------------------------

def test_goodwill_row_is_found():
    """五粮液资产负债表的商誉行：`商誉 1,621,619.53 1,621,619.53`。"""
    from pathlib import Path
    import pytest as _pytest
    p = Path("data/五粮液/年报/2025年年度报告.PDF")
    if not p.exists():
        _pytest.skip("样本缺失")
    from notes import extract_goodwill
    got = extract_goodwill(p)
    assert got["ok"]
    assert got["value"] == pytest.approx(1621619.53, rel=1e-6)
    assert got["page"] == 52


def test_goodwill_absent_company_reports_none():
    """格力没有商誉 —— 必须明确返回"没有"，而不是随便找个数。"""
    from conftest import require_pdf
    from notes import extract_goodwill
    got = extract_goodwill(require_pdf("gree_annual"))
    assert got["ok"] is False
    assert got["value"] is None
    assert "未列示商誉" in got["note"]


def test_kam_title_rejects_sentence_fragments():
    """`键审计事项。`（跨页断行丢了"关"字）不能当成关键审计事项。"""
    from notes import is_valid_kam_title
    assert is_valid_kam_title("收入确认")
    assert not is_valid_kam_title("键审计事项。")
    assert not is_valid_kam_title("应收账款坏账准备的评估。")


def test_kam_title_cut_when_description_merged():
    """表格式 KAM 会把"事项名 + 审计应对"塞进同一格，要切掉描述。"""
    from notes import is_valid_kam_title

    raw = "存货跌价准备的评估 我们了解、评估了与管理层计提存货跌价准"
    assert len(raw) > 20
    assert not is_valid_kam_title(raw)          # 整串不像事项名
    assert is_valid_kam_title(raw.split()[0])   # 切掉描述后成立
