"""终端对话模式：命令、退出、单轮失败不杀会话。"""
import pytest

import chat


def _run(lines, monkeypatch=None, db=":memory:"):
    out = []
    it = iter(lines)

    def fake_input(_prompt=""):
        try:
            return next(it)
        except StopIteration:
            raise EOFError

    rc = chat.run_repl(db, input_fn=fake_input, output_fn=out.append)
    return rc, "\n".join(out)


def test_banner_and_help():
    rc, out = _run(["/help", "/exit"])
    assert rc == 0
    assert "年报分析助手" in out
    assert out.count("年报分析助手") >= 2       # 开场 + /help 各一次


def test_unknown_command_does_not_exit():
    rc, out = _run(["/nope", "/exit"])
    assert rc == 0
    assert "未知命令" in out


def test_eof_exits_cleanly():
    rc, out = _run([])
    assert rc == 0
    assert "再见" in out


def test_list_uses_db(tmp_path):
    import sqlite3
    db = tmp_path / "x.db"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE reports (company TEXT, report_type TEXT, period TEXT)")
    conn.execute("INSERT INTO reports VALUES ('格力电器','年报','2025')")
    conn.commit()
    conn.close()
    rc, out = _run(["/list", "/exit"], db=str(db))
    assert "已入库 1 份" in out
    assert "格力电器" in out


def test_one_bad_turn_does_not_kill_session(monkeypatch):
    """某一问抛异常时只打印错误，回到提示符继续 —— 交互工具最忌一句报错就退出。"""
    calls = {"n": 0}

    def boom(question, db_path, **kw):
        calls["n"] += 1
        raise RuntimeError("网关挂了")

    monkeypatch.setattr("agent.answer", boom)
    rc, out = _run(["随便问一句", "再问一句", "/exit"])
    assert rc == 0
    assert calls["n"] == 2          # 两次都进了 answer，说明会话没断
    assert out.count("这一问出错了") == 2


def test_save_without_analysis_tells_you_what_to_do():
    rc, out = _run(["/save", "/exit"])
    assert rc == 0
    assert "还没有可保存的分析" in out


def test_save_after_analysis_writes_a_file(monkeypatch, tmp_path):
    """先问分析（只出文字），再 /save —— 不必在问题里带"报告"两个字。"""
    fake_analysis = {
        "ok": True, "company": "格力电器", "report_type": "年报", "period": "2025",
        "cur_period": "2025", "prev_period": "2024",
        "sections": [], "trend": None, "gaps": [], "identity_violations": [],
    }
    monkeypatch.setattr("agent.answer",
                        lambda q, db, **kw: {"answer": "分析结果…",
                                             "analysis": fake_analysis})
    saved = {}

    def fake_build(company, report_type, period, db_path, **kw):
        saved["args"] = (company, report_type, period)
        path = tmp_path / "x.docx"
        path.write_text("dummy", encoding="utf-8")
        return {"ok": True, "path": str(path)}

    monkeypatch.setattr("agent.build_report", fake_build)

    rc, out = _run(["分析一下格力电器2025年报", "/save", "/exit"], db=str(tmp_path / "a.db"))
    assert rc == 0
    assert "已保存" in out
    assert saved["args"] == ("格力电器", "年报", "2025")


def test_save_accepts_custom_filename(monkeypatch, tmp_path):
    fake_analysis = {"ok": True, "company": "五粮液", "report_type": "年报",
                     "period": "2024", "cur_period": "2024", "prev_period": "2023",
                     "sections": [], "trend": None, "gaps": [], "identity_violations": []}
    monkeypatch.setattr("agent.answer",
                        lambda q, db, **kw: {"answer": "…", "analysis": fake_analysis})
    captured = {}
    monkeypatch.setattr("agent.build_report",
                        lambda *a, **kw: (captured.update(kw) or {"ok": True, "path": "/tmp/y.docx"}))
    monkeypatch.setattr("agent.default_report_path",
                        lambda *a: tmp_path / "reports" / "默认.docx")

    rc, out = _run(["分析一下五粮液2024年报", "/save 年报终稿.docx", "/exit"],
                   db=str(tmp_path / "a.db"))
    assert rc == 0
    assert str(captured["out_path"]).endswith("年报终稿.docx")


# --- 上下文追问 -----------------------------------------------------------

def test_followup_uses_previous_company():
    """「说错了，2025 年年报」要接上上一句的公司，而不是当成新问题。"""
    from chat import followup_question
    ent = {"company": "格力电器", "report_type": "年报", "period": "2026"}
    assert followup_question("说错了，2025 年年报并分析", ent) == "分析格力电器2025年报"
    assert followup_question("不是2026，是2025年", ent) == "分析格力电器2025年报"
    assert followup_question("2024年呢", ent) == "分析格力电器2024年报"
    # 没提年份、也不是纠正 → 当新问题
    assert followup_question("帮我看看茅台", ent) is None
    # 没有上文 → 不做补全
    assert followup_question("说错了，2025 年年报", None) is None


def test_chat_corrects_previous_year(monkeypatch):
    """对话里：先问 2026（没有），再说"说错了是 2025"，应当分析 2025。"""
    import chat
    out = []
    it = iter(["帮我看看格力电器2026年报", "说错了，2025 年年报并分析", "/exit"])

    def fake_input(_p=""):
        try:
            return next(it)
        except StopIteration:
            raise EOFError

    seen = []

    def fake_answer(q, db, **kw):
        seen.append(q)
        if "2026" in q:
            return {"route": "ingest", "answer": "2026 年年报还没披露",
                    "entity": {"company": "格力电器", "report_type": "年报",
                               "period": "2026"}}
        return {"route": "analysis", "answer": "2025 的分析结果",
                "entity": {"company": "格力电器", "report_type": "年报",
                           "period": "2025"}}

    monkeypatch.setattr("agent.answer", fake_answer)
    chat.run_repl(":memory:", input_fn=fake_input, output_fn=out.append)
    assert seen == ["帮我看看格力电器2026年报", "分析格力电器2025年报"]
    assert any("接着上一句" in o for o in out)


def test_year_only_followup_keeps_previous_company():
    """只说年份、不提公司 → 公司是上一句那个。

    实测对话：先问"中国黄金 2026 年报"（未披露），再说"分析 2024 年年报"，
    旧逻辑因为句子里没公司名，反问"是哪家公司"——上下文丢了。
    """
    from chat import followup_question
    ent = {"company": "中国黄金", "report_type": "年报", "period": "2026"}
    assert followup_question("分析 2024 年年报", ent) == "分析中国黄金2024年报"
    assert followup_question("2024年呢", ent) == "分析中国黄金2024年报"
    # 提了别的公司 → 不能硬套上一句
    assert followup_question("帮我看看茅台2024年报", ent) is None
    assert followup_question("分析一下格力电器2024年报", ent) is None


def test_two_digit_year_in_followup():
    """口语常说两位年份："换成25年"。"""
    from chat import followup_question
    ent = {"company": "中国黄金", "report_type": "半年报", "period": "2024"}
    assert followup_question("换成25年", ent) == "分析中国黄金2025半年报"
    assert followup_question("看24年的", ent) == "分析中国黄金2024半年报"


def test_ctrl_c_at_prompt_does_not_exit():
    """Ctrl-C 只清当前输入，不退出会话。

    实测试用者按 ^C 后回到 shell，把问题敲进 zsh 得到 "command not found"，
    以为程序坏了。
    """
    import chat

    out, it = [], iter(["__INT__", "__INT__", "/exit"])

    def fake_input(_p=""):
        try:
            v = next(it)
        except StopIteration:
            raise EOFError
        if v == "__INT__":
            raise KeyboardInterrupt
        return v

    rc = chat.run_repl(":memory:", input_fn=fake_input, output_fn=out.append)
    assert rc == 0
    assert sum(1 for o in out if "退出请按" in o) == 2   # 两次都没退出
    assert any(o.strip() == "再见。" for o in out)


def test_declining_the_guess_stops_there(monkeypatch):
    """反问后回"否"，不能继续把"否"当成新问题去解析。"""
    import chat

    calls = []

    def fake_answer(q, db, **kw):
        calls.append(q)
        if len(calls) == 1:
            return {"route": "confirm", "answer": "你找的是不是「中际旭创」？",
                    "pending": "分析中际旭创2025年报"}
        return {"route": "analysis", "answer": "不该走到这里"}

    monkeypatch.setattr("agent.answer", fake_answer)
    out, it = [], iter(["分析中旭创科 2025 年年报", "否", "/exit"])

    def fake_input(_p=""):
        try:
            return next(it)
        except StopIteration:
            raise EOFError

    chat.run_repl(":memory:", input_fn=fake_input, output_fn=out.append)
    assert calls == ["分析中旭创科 2025 年年报"]      # 只有第一轮
    assert any("那我先不动" in o for o in out)


def test_open_command_opens_latest_report(monkeypatch, tmp_path):
    """/open 打开 reports/ 里最新的一份（不依赖"上一次生成的路径"）。"""
    import chat

    reports = tmp_path / "reports"
    reports.mkdir()
    (reports / "旧报告.docx").write_text("x")
    (reports / "新报告.docx").write_text("y")

    opened = {}
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("terminal_link.open_path",
                        lambda p: opened.setdefault("path", p) or True)

    out = []
    chat._open_last_report(out.append)
    assert opened["path"].name == "新报告.docx"
    assert any("正在打开" in o for o in out)


def test_repl_enables_line_editing(monkeypatch):
    """真终端里要启用行编辑（方向键 / Ctrl-U / 历史）。

    实测反馈：打错字后前面的删不掉 —— 不 import readline 时
    `input()` 的光标行为很受限，只能一直按退格。
    """
    import chat

    called = {"n": 0}
    monkeypatch.setattr(chat, "_enable_line_editing",
                        lambda: called.__setitem__("n", called["n"] + 1))

    # 注入的 input_fn（测试用）不该触发终端设置
    chat.run_repl("data/structured.db", input_fn=lambda p="": "/exit",
                  output_fn=lambda *a, **k: None)
    assert called["n"] == 0

    # 用内置 input 时才启用（默认参数在定义时就绑定好了，故用 inspect 确认）
    import inspect

    assert "input_fn is input" in inspect.getsource(chat.run_repl)
    assert "_enable_line_editing()" in inspect.getsource(chat.run_repl)


def test_pdf_command_opens_source_pdf(monkeypatch):
    """/pdf 打开年报原文（和 /open、/html 一样一键）。

    实测：知道 PDF 在 data/ 下，但每次翻文件夹很麻烦。
    """
    import chat

    opened = {}
    monkeypatch.setattr("terminal_link.open_path",
                        lambda p: opened.setdefault("p", p) or True)

    out = []
    last = {"analysis": {"company": "海尔智家", "period": "2025", "report_type": "年报"},
            "db_path": "data/structured.db"}
    chat._open_last_pdf(last, out.append)

    if opened:
        assert opened["p"].suffix.lower() == ".pdf"
        assert any("正在打开" in o for o in out)
    else:                                  # 库里没有就给出明确提示
        assert any("没找到" in o for o in out)


def test_pdf_command_without_analysis():
    import chat

    out = []
    chat._open_last_pdf(None, out.append)
    assert any("还没有分析过" in o for o in out)
