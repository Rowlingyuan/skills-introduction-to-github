"""语义解析（自由语序）：解析、缓存、失败不缓存。"""
import intent


def test_cached_parse_does_not_call_model_again(tmp_path, monkeypatch):
    monkeypatch.setattr(intent, "_CACHE_PATH", tmp_path / "cache.json")
    calls = {"n": 0}

    def fake_model(role, messages, **kw):
        calls["n"] += 1
        return '{"company":"中国黄金","report_type":"年报","period":"2025","confidence":0.9}'

    monkeypatch.setattr("client.call_model", fake_model)
    q = "中国黄金的年报帮我看看2025年的"
    a = intent.parse(q)
    b = intent.parse(q)
    assert a == b and a["company"] == "中国黄金"
    assert calls["n"] == 1, "第二次应该命中缓存，不再调模型"


def test_failure_is_not_cached(tmp_path, monkeypatch):
    """模型超时/空回复是瞬时故障，缓存下来会永久错下去。"""
    monkeypatch.setattr(intent, "_CACHE_PATH", tmp_path / "cache.json")
    monkeypatch.setattr("client.call_model",
                        lambda *a, **k: (_ for _ in ()).throw(TimeoutError("x")))
    assert intent.parse("随便一句") is None
    assert not (tmp_path / "cache.json").exists()


def test_canonical_question_is_parseable_by_regex():
    """语义解析产出的标准问法，必须能被正则管道认出（否则会死循环）。"""
    import agent
    canon = intent.canonical({"company": "中国黄金", "report_type": "年报",
                              "period": "2025"})
    assert canon == "分析中国黄金2025年报"
    assert agent._candidate_company(canon) == "中国黄金"
    assert not agent._needs_semantic_parse(canon)
