"""黄金集回归测试。

`run_all()` 只调用一次并缓存——解析两份年报（格力 219 页、茅台 ~100 页）耗时长，
逐测试重复调用会让整个套件慢得不可接受。
"""
from pathlib import Path

import pytest

from models import MetricValue, ParseResult, ReportKey
from run_golden import (   # tests/ 已在 sys.path 上
    HUNDRED_MILLION,
    IDENTITY_TOLERANCE,
    KNOWN_IDENTITY_DEFECTS,
    run_all,
    run_identities_from,
)

_RESULT = None


def _result():
    global _RESULT
    if _RESULT is None:
        _RESULT = run_all()
    return _RESULT


def _format_violations(violations) -> str:
    lines = ["资产负债表恒等式违规（非已知缺陷）:"]
    for v in violations:
        lines.append(f"  {v['case']} {v['year']} | {v['direction']} | "
                     f"期望 {v['expected']} | 实际 {v['actual']}")
    return "\n".join(lines)


def test_golden_accuracy_meets_threshold():
    """一期完成标准：准确率 >95%。"""
    r = _result()
    if r["total"] == 0:
        pytest.skip("无可用黄金样本")
    assert r["accuracy"] >= 95.0, f"准确率 {r['accuracy']:.1f}% 未达标，失败项: {r['failures']}"


def test_balance_sheet_accounting_identities_hold():
    """资产负债表恒等式自洽——无需人工真值，专抓"捏造的数字"。

    结构性断言（"抽到了几个指标"）在数值凭空捏造时照样通过：Task 8 之前
    年份→列映射整体左移一列，把附注号当成本期数、本期数当成上期数，
    却仍带 confidence="high"。恒等式交叉验算是这类缺陷唯一不依赖人工真值的探针。

    现有违规见 KNOWN_IDENTITY_DEFECTS（格力资产负债表行/标签错位，二期修复）。
    """
    r = _result()
    if r["total"] == 0:
        pytest.skip("无可用黄金样本")
    violations = [v for v in r["identity_violations"]
                  if (v["case"], v["year"], v["check"]) not in KNOWN_IDENTITY_DEFECTS]
    assert violations == [], _format_violations(violations)


def test_identity_checks_cover_both_cases():
    """恒等式必须真的在跑：每个用例都应产出若干条可核实或被显式标为不可核实的结论。

    没有这一条，"violations == []" 可能只是因为一条检查都没执行（例如
    别名表写错、statement 过滤条件写错），测试会静默变成空转。
    """
    r = _result()
    if r["total"] == 0:
        pytest.skip("无可用黄金样本")
    checks = r["identity_checks"]
    assert checks, "恒等式检查一条都没执行"
    cases = {c["case"] for c in checks}
    assert len(cases) >= 2, f"恒等式检查未覆盖两个用例，实际: {sorted(cases)}"
    for c in checks:
        assert c["status"] in ("pass", "fail", "unverifiable")
        if c["status"] == "unverifiable":
            assert c["missing"], f"不可核实却未指明缺失指标: {c}"


# --------------------------------------------------------------------------
# 合成数据（不依赖 PDF）：恒等式年份枚举 + 容差传导
# --------------------------------------------------------------------------

def _metric(name, period, value, statement="资产负债表"):
    return MetricValue(name=name, period=period, value=value,
                       source_page=1, confidence="high", statement=statement)


def _parse_result(metrics):
    key = ReportKey("合成公司", "000000", "年报", "2099")
    return ParseResult(key=key, file_path="<synthetic>",
                       sections={"资产负债表": 1}, metrics=metrics)


# 一份"完整"的资产负债表年份：每条恒等式都能得到可核实结论。
_FULL_BS = [
    _metric("资产总计", "2099", 1000.0),
    _metric("负债合计", "2099", 400.0),
    _metric("所有者权益合计", "2099", 600.0),
    _metric("流动负债合计", "2099", 300.0),
    _metric("流动资产合计", "2099", 700.0),
    _metric("货币资金", "2099", 100.0),
    _metric("存货", "2099", 200.0),
    _metric("应收账款", "2099", 150.0),
]

# 只有 资产总计 / 负债合计：足以触发 `资产总计 = 负债 + 权益` 的
# "输入指标缺失"分支（缺 所有者权益合计），即产生 unverifiable。
_PARTIAL_BS = [
    _metric("资产总计", "2098", 1000.0),
    _metric("负债合计", "2098", 400.0),
]


def test_identity_years_come_from_balance_sheet_even_when_expect_is_unrelated():
    """资产负债表解析出的年份必须产出恒等式——**expect 与这些年份无关**时也一样。

    本用例的 `expect` 只含利润表指标 `营业收入`，其映射里**没有** 2099 这个年份：
    `{"营业收入": {"2098": 1.0}}`。这是真实形态——`expect` 一期只覆盖利润表，
    与资产负债表年份通常**对不上**。于是"仅取 expect 年"枚举只会得到 {2098}，
    2099 的 4 条恒等式会**整年消失**（既不核对也不报告）——正是
    "显式报告或失败，绝不静默跳过"纪律的泄漏点。并集则两年都覆盖。

    与两个兄弟用例的分工（**并集的两个来源各自被单独钉住**）：
      - 本用例：`expect` **有**年份、但只有 2098，资产负债表**只有** 2099
        → 若枚举退回"仅 expect"，`years` 会缺 2099（第一条断言失败）；
          若枚举退回"仅资产负债表"，`years` 会多出 2098（第二条断言失败）。
          即本用例**同时钉住**并集的两个来源，不再有"无法区分"的盲区。
      - `test_identity_years_include_expect_only_years`：同型，另给出
        "expect 独有年份必须落 unverifiable 并点名缺失指标"的逐条断言；
      - `test_identity_missing_year_is_reported_unverifiable_not_skipped`：
        `expect` 为空、输入指标不全 → 证明缺指标是 unverifiable 而非消失。
    """
    res = _parse_result(_FULL_BS)   # 资产负债表只有 2099 年
    case = {"name": "合成-年份并集",
            "expect": {"营业收入": {"2098": 1.0}}}   # 只有 2098，与 2099 无关

    checks = run_identities_from(res, case)
    years = {c["year"] for c in checks}
    # 来源一（资产负债表）：2099 必须出现，否则就是"仅取 expect"的回归。
    assert "2099" in years, (
        "资产负债表实际解析出的 2099 年未被检查——年份枚举没读资产负债表: "
        f"{sorted(years)}")
    # 年份并集：枚举既不多算也不少算（来源一 2099 + 来源二独有 2098）。
    assert years == {"2099", "2098"}, f"年份应为并集，实际 {sorted(years)}"
    assert len(checks) == 8, (
        f"两年各 4 条，应为 8 条恒等式，实际 {len(checks)} 条，年份 {sorted(years)}")
    # 来源二（expect）：2098 只来自 expect，资产负债表没有它 → unverifiable。
    y2098 = [c for c in checks if c["year"] == "2098"]
    assert len(y2098) == 4 and all(c["status"] == "unverifiable" for c in y2098), (
        f"expect 独有年份 2098 应落 4 条 unverifiable，实际 {y2098}")


def test_identity_years_include_expect_only_years():
    """并集的另一半：资产负债表没有、但 expect 要求的年份仍须产出结论。

    这些年份没有资产负债表数据，应全部落成 `unverifiable` 并点名缺失指标，
    而不是从结论集中消失。
    """
    res = _parse_result(_FULL_BS)   # 只有 2099 年
    case = {"name": "合成-并集另一半", "expect": {"营业收入": {"2099": 1.0,
                                                              "2098": 1.0}}}

    checks = run_identities_from(res, case)
    years = {c["year"] for c in checks}
    assert years == {"2099", "2098"}, f"年份应为并集，实际: {sorted(years)}"
    y2098 = [c for c in checks if c["year"] == "2098"]
    assert len(y2098) == 4
    assert all(c["status"] == "unverifiable" for c in y2098)
    assert all(c["missing"] for c in y2098), (
        "无数据的年份必须逐条点名缺失指标")


def test_identity_missing_year_is_reported_unverifiable_not_skipped():
    """资产负债表有该年、但输入指标不全时，必须产出 unverifiable 而非消失。"""
    res = _parse_result(_PARTIAL_BS)
    case = {"name": "合成-缺指标", "expect": {}}   # expect 完全没有年份

    checks = run_identities_from(res, case)
    assert len(checks) == 4, f"2098 年应产出 4 条，实际 {len(checks)}"
    missing_eq = [c for c in checks
                  if c["check"] == "资产总计 = 负债合计 + 所有者权益合计"]
    assert len(missing_eq) == 1
    assert missing_eq[0]["status"] == "unverifiable"
    assert missing_eq[0]["missing"] == ["所有者权益合计"]


def test_identity_tolerance_is_threaded_from_run_identities_from():
    """`run_identities_from` 的 tolerance 必须真正到达恒等式判据。

    构造一个差额远大于默认容差、却小于放宽后容差的 `==` 恒等式：
    默认下应为 fail，放宽后应转为 pass。若参数被吞掉，两条断言会同时失败。
    """
    delta = HUNDRED_MILLION * 10          # 10 亿，远超默认 1 亿容差
    loose = HUNDRED_MILLION * 100         # 放宽到 100 亿
    res = _parse_result([
        _metric("资产总计", "2099", 1000.0 + delta),
        _metric("负债合计", "2099", 400.0),
        _metric("所有者权益合计", "2099", 600.0),
    ])
    case = {"name": "合成-容差", "expect": {}}

    strict = [c for c in run_identities_from(res, case)
              if c["check"] == "资产总计 = 负债合计 + 所有者权益合计"]
    assert len(strict) == 1
    assert strict[0]["status"] == "fail", (
        f"默认容差下应为 fail，实际 {strict[0]}")

    relaxed = [c for c in run_identities_from(res, case, tolerance=loose)
               if c["check"] == "资产总计 = 负债合计 + 所有者权益合计"]
    assert len(relaxed) == 1
    assert relaxed[0]["status"] == "pass", (
        f"容差放宽到 {loose} 后应为 pass，说明 tolerance 未传到判据: {relaxed[0]}")


# --------------------------------------------------------------------------
# `run_all` 层的容差传导（合成数据 + 打桩 parse，不依赖 PDF）
#
# 为什么必须在这一层测：上面 `run_identities_from` 的单测覆盖的是**下游**，
# 而"参数陷阱"最初就住在 `run_all` 转不转发的那一行（`run_golden.py` 的
# `for c in run_identities_from(res, case, ...)`）。只测下游 = 恰好漏掉案发现场：
# 把转发参数删掉，下游单测全绿，回归照过。本组测试专钉这一层。
# --------------------------------------------------------------------------

def _run_all_with_stub(monkeypatch, metrics, tolerance_marker):
    """打桩 `run_golden.parse`，让 `run_all` 只处理一份合成 ParseResult。

    返回 `(r, seen)`：`r` 是 `run_all(...)` 的返回；`seen` 是打桩 parse 记下的
    实际收到参数（用来断言 `verify=False` 等调用契约没被顺带改掉）。
    """
    import run_golden

    seen = []
    res = _parse_result(metrics)
    # 路径只需 `exists()` 为真——`parse` 已被打桩，不会真去读文件。
    case = {"name": "合成-run_all", "pdf": Path(__file__), "key": res.key,
            "expect": {}}

    def fake_parse(pdf, key, *args, **kwargs):
        seen.append((pdf, key, args, kwargs))
        return res

    monkeypatch.setattr(run_golden, "parse", fake_parse)
    monkeypatch.setattr(run_golden, "CASES", [case])
    return run_golden.run_all(**tolerance_marker), seen


def test_run_all_forwards_tolerance_to_identity_checks(monkeypatch):
    """`run_all(tolerance=X)` 的 X 必须真的落到恒等式结论上。

    `run_all` 是唯一公开入口，也是最容易"收下参数却不转发"的那一层。若那一行
    转发被删掉，恒等式会静默回落到默认值（1 亿），而下面这条断言会失败。
    断言的是**结论里回填的实际生效值**，不是"函数有没有收下参数"。
    """
    marker = HUNDRED_MILLION * 12345          # 1.2345e12，与两个默认值都不同
    r, _ = _run_all_with_stub(monkeypatch, _FULL_BS, {"tolerance": marker})

    assert r["identity_checks"], "打桩后应产出恒等式结论"
    applied = {c["tolerance"] for c in r["identity_checks"]}
    assert applied == {marker}, (
        f"run_all(tolerance={marker}) 未传到恒等式结论，实际生效值 {applied}")


def test_run_all_without_tolerance_keeps_identity_default(monkeypatch):
    """**不传** `tolerance` 时，恒等式保留自己的默认值 1e8。

    这是 `tolerance: float | None = None` 存在的理由：`None` 表示"两趟各用各的
    默认值"，而不是"把恒等式一起收紧到真值对拍的 1.0 元"。若有人把默认值写回
    具体的 `1.0`（即让默认路径等同显式传 1.0），本测试失败——1e8 这个恒等式
    默认值就会变成**没有任何公开入口可达**的死参数。
    """
    r, _ = _run_all_with_stub(monkeypatch, _FULL_BS, {})

    assert r["identity_checks"], "打桩后应产出恒等式结论"
    applied = {c["tolerance"] for c in r["identity_checks"]}
    assert applied == {IDENTITY_TOLERANCE}, (
        f"未传 tolerance 时恒等式应用默认 {IDENTITY_TOLERANCE}，实际 {applied}")


def test_run_all_identity_tolerance_reaches_verdict(monkeypatch):
    """端到端语义：`run_all(tolerance=X)` 的 X 要能**翻转恒等式的裁决**。

    前两条断言"回填值对不对"，这一条断言"值真的参与判断"。用一条差额 10 亿的
    `==` 恒等式：默认 1 亿门禁下 fail；`run_all(tolerance=100 亿)` 下转 pass。
    只回填不生效（例如回填了 X、判据却仍用默认）会在这里被抓到。
    """
    delta = HUNDRED_MILLION * 10              # 10 亿，超过默认 1 亿门禁
    loose = HUNDRED_MILLION * 100             # 100 亿，足以容纳
    metrics = [
        _metric("资产总计", "2099", 1000.0 + delta),
        _metric("负债合计", "2099", 400.0),
        _metric("所有者权益合计", "2099", 600.0),
    ]

    def _eq(r):
        got = [c for c in r["identity_checks"]
               if c["check"] == "资产总计 = 负债合计 + 所有者权益合计"]
        assert len(got) == 1, f"应恰有 1 条该恒等式，实际 {len(got)}"
        return got[0]

    strict, _ = _run_all_with_stub(monkeypatch, metrics, {})
    assert _eq(strict)["status"] == "fail", (
        f"默认门禁下应为 fail: {_eq(strict)}")

    relaxed, _ = _run_all_with_stub(monkeypatch, metrics, {"tolerance": loose})
    assert _eq(relaxed)["status"] == "pass", (
        f"run_all(tolerance={loose}) 下应为 pass，说明 X 未参与判据: {_eq(relaxed)}")


def test_run_all_keeps_accuracy_scoped_to_golden_truth(monkeypatch):
    """打桩路径上复核：恒等式结论**不得**混入 `total` / `passed` / `accuracy`。

    合成用例的 `expect` 为空，故真值对拍为 0 断言；而恒等式一定产出了结论。
    若哪天有人把恒等式结论并进 `total`，`accuracy` 会被污染成非零，本测试失败。
    """
    r, seen = _run_all_with_stub(monkeypatch, _FULL_BS, {})

    assert r["total"] == 0 and r["passed"] == 0
    assert r["accuracy"] == 0.0
    assert len(r["identity_checks"]) == 4, "恒等式应照常产出"
    assert seen and seen[0][3].get("verify") is False, (
        f"parse 调用契约（verify=False）被改动: {seen}")
