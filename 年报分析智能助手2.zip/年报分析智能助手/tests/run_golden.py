"""黄金集回归：.venv/bin/python tests/run_golden.py

两趟校验：
1. 利润表人工真值对拍（`accuracy`，一期目标 >95%）——见 golden/cases.py。
2. 资产负债表会计恒等式自洽（`identity_checks` / `identity_violations`）——
   不依赖人工真值，专抓"结构上抽到了指标、数值却凭空捏造"的缺陷。
   一期只有利润表有核对过的真值（见 ledger Ruling D3），若无第二趟，
   资产负债表/现金流量表就只剩"抽到了几条"这种空转断言。

**容差语义：一个可选参数；`None` 时两趟各用各的默认值**
    `run_all(tolerance=...)` 的 `tolerance` 是**绝对金额**（元）容差，默认 **`None`**，
    含义是"未指定，由两趟各自决定"：
      - `tolerance is None`（默认）：真值对拍用 `TOLERANCE` = **1.0 元**；
        恒等式用 `IDENTITY_TOLERANCE` = **1e8 元（1 亿）**。
      - `tolerance = X`（显式传参，含 `X=1.0`）：**两趟都用 X**。
    注意 `run_all()` 与 `run_all(tolerance=1.0)` **含义不同**：前者让恒等式留在 1 亿，
    后者把恒等式收紧到 1 元。恒等式结论里逐条回填实际生效的 `tolerance`，事后可核对。

    为什么两趟的默认值**就该不同**（这是判据性质，不是疏漏）：
      - 真值对拍比的是**逐字人工核对过的原文**，理应逐分不差，1 元只是浮点余量——门禁要**紧**；
      - 恒等式两侧**都是抽取出来的数字**、且常跨行相加，小数位舍入会累计到上千元级，
        故默认用 1 亿的绝对门禁，只抓"量级级"错误（列错位、张冠李戴），不抓小数点——门禁要**松**。
    之所以能放心用 1 亿这么松：实测把它收紧到 1.0 元，16 条恒等式结论**一条都不翻转**
    （两条真实违规的差额是 143–154 **亿**，远超 1 亿门禁，照样报出）——
    即 1 亿的松弛**不掩盖任何已知缺陷**。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))  # 仓库根，供 import parser
sys.path.insert(0, str(Path(__file__).resolve().parent))         # tests/，供 import golden

from parser import parse        # noqa: E402
from golden.cases import CASES  # noqa: E402

TOLERANCE = 1.0  # 真值对拍的默认浮点误差容忍（元）；调用方传 tolerance 时被覆盖

# 恒等式这趟的**默认**容差：以亿为单位，小数位舍入不构成违规。
# 这是 IDENTITY 的默认值、不是硬编码上限：`run_all(tolerance=X)` 显式传参时改用它。
# 只在 `run_all` 的 tolerance 为 None（未指定）时生效——见 run_all 文档字符串。
HUNDRED_MILLION = 1e8
IDENTITY_TOLERANCE = HUNDRED_MILLION  # 语义同 HUNDRED_MILLION，供恒等式这趟引用


def _values_by_period(metrics, statement):
    """[(name, period, value)] → {指标名: {年份: 值}}，仅取指定报表。"""
    out = {}
    for m in metrics:
        if m.statement == statement and m.value is not None:
            out.setdefault(m.name, {})[m.period] = m.value
    return out


def _check(name, expect, actual, terms, present, direction="==",
           tolerance=IDENTITY_TOLERANCE):
    """把一条恒等式结论落成 dict。

    `terms` 是本式用到的指标名；`present` 是**本条用例该年确实抽到**的指标名。
    缺任何一个都判 unverifiable 并点名缺失项，绝不当作通过、也绝不静默跳过。

    `direction` ∈ {"==", "<=", ">="}。**必须按方向判**：若一律用 `abs(diff)`
    判等，`流动负债合计 <= 负债合计` 会在差额超过容差时被误判为违规——
    哪怕它正好是**符合**方向的（茅台即如此）。方向判据是：
      "<=": actual - expect <= tol
      ">=": expect - actual <= tol

    `tolerance` 为绝对金额（元）容差，默认 `IDENTITY_TOLERANCE`（1 亿元）。
    结论里回填实际生效值，便于事后核对"到底用了几亿的门禁"。
    """
    missing = [t for t in terms if t not in present]
    if missing:
        return {"check": name, "status": "unverifiable", "expected": expect,
                "actual": actual, "missing": missing, "direction": direction,
                "tolerance": tolerance}
    diff = actual - expect
    if direction == "==":
        ok = abs(diff) <= tolerance
    elif direction == "<=":
        ok = diff <= tolerance
    else:
        ok = -diff <= tolerance
    return {"check": name, "status": "pass" if ok else "fail",
            "expected": expect, "actual": actual,
            "diff": round(diff, 2), "missing": missing, "direction": direction,
            "tolerance": tolerance}


# 恒等式：(检查名, 方向, 参与指标名, 期望值算式, 实际值算式)
# 算式接收 {指标名: 该年值}；参与指标名全部到位才会被调用。
IDENTITIES = [
    ("资产总计 = 负债合计 + 所有者权益合计", "==",
     ["资产总计", "负债合计", "所有者权益合计"],
     lambda v: v["负债合计"] + v["所有者权益合计"],
     lambda v: v["资产总计"]),
    ("流动负债合计 <= 负债合计", "<=",
     ["流动负债合计", "负债合计"],
     lambda v: v["负债合计"],
     lambda v: v["流动负债合计"]),
    ("流动资产合计 <= 资产总计", "<=",
     ["流动资产合计", "资产总计"],
     lambda v: v["资产总计"],
     lambda v: v["流动资产合计"]),
    ("流动资产合计 >= 货币资金 + 存货 + 应收账款", ">=",
     ["流动资产合计", "货币资金", "存货", "应收账款"],
     lambda v: v["货币资金"] + v["存货"] + v["应收账款"],
     lambda v: v["流动资产合计"]),
]


def check_identities(got, year, tolerance=IDENTITY_TOLERANCE) -> list:
    """对单年做四条会计恒等式检查。返回结论列表，含 unverifiable 项。"""
    present = {name for name, years in got.items() if year in years}
    values = {name: got[name][year] for name in present}
    out = []
    for name, direction, terms, expect_fn, actual_fn in IDENTITIES:
        if all(t in present for t in terms):
            res = _check(name, expect_fn(values), actual_fn(values),
                         terms, present, direction, tolerance)
        else:
            res = _check(name, None, None, terms, present, direction, tolerance)
        res["year"] = year
        out.append(res)
    return out


def run_identities_from(res, case, tolerance=IDENTITY_TOLERANCE) -> list:
    """从已解析的 ParseResult 取资产负债表指标做恒等式检查（复用同一份解析结果）。

    **年份取并集**，两个来源都要：
      1. 该用例**资产负债表实际解析出的**年份 —— 只有这一条能保证"抽到了就核"；
      2. `case["expect"]` 列出的年份 —— 保住"人工真值要求了、却整页没抽到"的年份，
         它会落成 `unverifiable` 并点名缺失指标，而不是从结论集中消失。

    只取第 2 条是错的：`expect` 一期只覆盖利润表，某年抽到资产负债表却没列进
    `expect`，这一年就会被**静默跳过**（既不核对也不报告）——正是本套件
    "显式报告或失败，绝不静默跳过"纪律的泄漏点。二期扩集时必然踩到。
    """
    got = _values_by_period(res.metrics, "资产负债表")
    years = set()
    for years_of_metric in got.values():
        years.update(years_of_metric)
    for years_of_expect in case.get("expect", {}).values():
        years.update(years_of_expect)
    checks = []
    for year in sorted(years):
        checks.extend(check_identities(got, year, tolerance))
    return checks


def run_all(tolerance: float | None = None, identities: bool = True) -> dict:
    """跑完整黄金集。

    `tolerance` 为绝对金额（元）容差，默认 **`None`**，作用于两趟（真值对拍与恒等式）：

      - `tolerance is None`（不传）：**两趟各用自己的默认值**——
        真值对拍 `TOLERANCE` = 1.0 元，恒等式 `IDENTITY_TOLERANCE` = 1e8 元（1 亿）。
        两个默认值不同是**刻意的**：前者比对人工核对过的原文，门禁要紧；后者两侧都是
        抽取值、常跨行相加，只需抓"量级级"错误，门禁要松（理由见模块 docstring）。
      - `tolerance = X`（显式传参，含 `X = 1.0`）：**两趟都用 X**，传下去就一定生效。

    故 `run_all()` **不等价于** `run_all(tolerance=1.0)`：后者会把恒等式一起收紧到 1 元。
    恒等式结论里逐条回填实际生效的 `tolerance`（`identity_checks[*]["tolerance"]`）。

    返回键：`total` / `passed` / `skipped` / `accuracy` / `failures` 只覆盖
    利润表人工真值（`accuracy` 不得混入恒等式结论）；恒等式另存
    `identity_checks` / `identity_violations` / `identity_unverifiable`。
    """
    truth_tol = TOLERANCE if tolerance is None else tolerance
    identity_tol = IDENTITY_TOLERANCE if tolerance is None else tolerance
    total = passed = skipped = 0
    failures = []
    checks = []
    for case in CASES:
        if not case["pdf"].exists():
            print(f"⏭️  跳过（样本缺失）: {case['name']}")
            skipped += 1
            continue
        res = parse(case["pdf"], case["key"], verify=False)
        got = {}
        for m in res.metrics:
            got.setdefault(m.name, {})[m.period] = m.value
        for metric, years in case["expect"].items():
            for year, want in years.items():
                total += 1
                have = got.get(metric, {}).get(year)
                if have is not None and abs(have - want) <= truth_tol:
                    passed += 1
                else:
                    failures.append({
                        "case": case["name"], "metric": metric,
                        "period": year, "want": want, "got": have,
                    })
        if identities:
            for c in run_identities_from(res, case, identity_tol):
                c["case"] = case["name"]
                checks.append(c)

    acc = (passed / total * 100) if total else 0.0
    violations = [c for c in checks if c["status"] == "fail"]
    unverifiable = [c for c in checks if c["status"] == "unverifiable"]
    return {"total": total, "passed": passed, "skipped": skipped,
            "accuracy": acc, "failures": failures,
            "identity_checks": checks,
            "identity_violations": violations,
            "identity_unverifiable": unverifiable}


# 已知缺陷清单（本任务**不得**修复，只登记）：ledger Ruling 7 —— 格力 p86/p87
# 资产负债表的文本对齐策略存在行/标签错位，`table_reader` 把行首字切掉后
# 行与标签整体错开一格（实测：真实"非流动资产合计"行被标成 `流动资产合计`，
# 真实"资产总计"行被标成 `产总计`）。后果是 `流动资产合计` 比自身分项之和还小。
# 该缺陷已被刻意推迟到二期，且不得通过删除检查来绕过——二期修好 table_reader
# 后本集合应清空。
#
# 为什么只有这两条：错位是"整列整体偏移"，于是 `流动负债合计` 与 `负债合计`
# 落在同一行上、数值相等，`<=` 恰好成立——**缺陷被掩盖在通过项里**。
# 真正暴露它的只有 `流动资产合计 >= 分项之和` 这一条（分项来自同一页，
# 却与合计不同源）。二期修复时请一并复核 格力 资产负债表已"通过"的条目。
KNOWN_IDENTITY_DEFECTS = {
    # Ruling 7：格力 p86 行/标签错位，`流动资产合计` 取到了非流动资产合计
    # （140,428,447,922.06 / 143,228,795,870.98），小于其分项之和。
    ("格力电器-2025年报-利润表", "2025", "流动资产合计 >= 货币资金 + 存货 + 应收账款"),
    ("格力电器-2025年报-利润表", "2024", "流动资产合计 >= 货币资金 + 存货 + 应收账款"),
    # 别名缺陷（**与 Ruling 15 的 period 语义无关，Task 2 只登记不修**）：
    # `config.py:121` 中 `所有者权益合计` 的别名 `"所有者权益合计"` 是
    # `归属于母公司所有者权益合计`（`config.py:122`）的**子串**，而
    # `match_metric_detail` 取别名表里**第一个命中**，故归母行先胜出 ——
    # 抽到的是 143,186,373,760.39（归母），真值 `所有者权益合计` 是
    # p6 最后一行的 147,292,760,314.46，差额恰为 少数股东权益 4,106,386,554.07。
    # 已在**未改动的 d7fcf32** 上复现，故不是 Task 2 引入的回归。
    ("格力电器-2025一季报-利润表", "2025Q1", "资产总计 = 负债合计 + 所有者权益合计"),
    ("格力电器-2025一季报-利润表", "2024", "资产总计 = 负债合计 + 所有者权益合计"),
}


if __name__ == "__main__":
    r = run_all()
    print(f"\n{'='*56}")
    print(f"  断言总数 {r['total']}  通过 {r['passed']}  跳过文件 {r['skipped']}")
    print(f"  准确率 {r['accuracy']:.1f}%   （一期目标 >95%）")
    print(f"{'='*56}")
    for f in r["failures"]:
        print(f"  ❌ {f['case']} | {f['metric']} {f['period']}: "
              f"期望 {f['want']:,} 实际 {f['got']}")
    print(f"\n  恒等式检查 {len(r['identity_checks'])} 条："
          f"通过 {len(r['identity_checks']) - len(r['identity_violations']) - len(r['identity_unverifiable'])}  "
          f"违规 {len(r['identity_violations'])}  不可核实 {len(r['identity_unverifiable'])}")
    for c in r["identity_unverifiable"]:
        print(f"  ❓ {c['case']} {c['year']} | {c['check']}: "
              f"缺少指标 {c['missing']}")
    for c in r["identity_violations"]:
        print(f"  ⚠️ {c['case']} {c['year']} | {c['check']}: "
              f"期望 {c['expected']:,} 实际 {c['actual']:,}（差 {c['diff']:,}）")
    sys.exit(0 if r["accuracy"] >= 95 and r["total"] else 1)
