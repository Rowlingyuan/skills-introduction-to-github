"""构成表抽取的离线测试。

纯逻辑（行解析 / 贡献度）用合成文本；真实 PDF 的 e2e 只钉**结构与不变量**，
不钉具体数字 —— 具体数字随年份变化，钉死了只会变成维护负担。
"""
import pytest

from conftest import require_pdf
from segments import (_from_lines, _mk_row, _normalise, _tokens,
                      contributions, extract_revenue_mix)

# 三种真实形态（取自本仓库样本的原文）
GREE_LINES = """（1）营业收入构成
单位：元
项目 占营业收入 占营业收 同比增减
金额 金额
比重 入比重
营业收入合计 170,447,058,533.57 100.00% 189,163,654,064.64 100.00% -9.89%
分行业
制造业 153,781,972,343.46 90.22% 169,715,353,002.47 89.72% -9.39%
其他业务 16,665,086,190.11 9.78% 19,448,301,062.17 10.28% -14.31%
分产品
消费电器 133,055,208,627.13 78.06% 148,559,931,838.58 78.54% -10.44%
智能装备 680,790,474.57 0.40% 424,131,758.64 0.22% 60.51%
""".split("\n")

MOUTAI_LINES = """(1). 主营业务分行业、分产品、分地区、分销售模式情况
单位：元 币种：人民币
主营业务分行业情况
营业收入比上 营业成本比上 毛利率比上年
分行业 营业收入 营业成本 毛利率（%）
年增减（%） 年增减（%） 增减（%）
酒类 168,774,585,187.65 14,805,900,139.59 91.23 -1.08 8.63
主营业务分产品情况
茅台酒 146,499,906,480.49 9,484,757,825.54 93.53 0.39 9.50
其他系列酒 22,274,678,707.16 5,321,142,314.05 76.11 -9.76 7.11
""".split("\n")


def test_mix_lines_parse_with_total_and_groups():
    rows = _from_lines(GREE_LINES, "mix")
    struct = _normalise(rows, "mix", 1.0)
    assert struct["total"]["name"] == "营业收入合计"
    assert struct["total"]["cur"] == pytest.approx(170447058533.57)
    names = [r["name"] for g in struct["groups"] for r in g["rows"]]
    assert "消费电器" in names and "制造业" in names
    assert [g["name"] for g in struct["groups"]] == ["分行业", "分产品"]


def test_biz_lines_parse_and_derive_previous_from_yoy():
    """上交所格式**不给上期金额**，要由同比反推 —— 否则贡献度整块算不出来。"""
    rows = _from_lines(MOUTAI_LINES, "biz")
    struct = _normalise(rows, "biz", 1.0)
    assert struct["total"] is None            # 该格式没有合计行
    row = next(r for r in struct["groups"][0]["rows"] if r["name"] == "茅台酒")
    assert row["cur"] == pytest.approx(146499906480.49)
    assert row["margin"] == pytest.approx(93.53)
    assert row["yoy"] == pytest.approx(0.39)
    # 146,499,906,480.49 / 1.0039 ≈ 145,930,776,452
    assert row["prev"] == pytest.approx(146499906480.49 / 1.0039, rel=1e-6)


def test_contribution_measures_share_of_total_change():
    """贡献度 = 该分部变动额 / 合计变动额 —— 这才是"变动主因"的判据。"""
    struct = _normalise(_from_lines(GREE_LINES, "mix"), "mix", 1.0)
    cons = contributions(struct)
    d = {c["name"]: c for c in cons}
    # 绝对变动额最大的是"制造业"（-15.9bn，比消费电器的 -15.5bn 略大）
    assert cons[0]["name"] == "制造业"
    # 消费电器解释了 82.8% 的降幅：(133.06-148.56) / (170.45-189.16)
    assert d["消费电器"]["contrib"] == pytest.approx(82.8, abs=0.5)
    assert d["智能装备"]["yoy"] > 0            # 逆势增长的分部也要能看出来


def test_contribution_needs_a_total_or_fallback():
    """没有合计行、也没给兜底 → 不给贡献度（不猜分母）。"""
    struct = _normalise(_from_lines(MOUTAI_LINES, "biz"), "biz", 1.0)
    assert contributions(struct) == []
    # 给了兜底就能算
    fb = {"cur": 170_899_152_276.34, "prev": 147_693_604_994.14}
    assert contributions(struct, fb)


def test_tokens_rejoin_cells_split_by_pdfplumber():
    """同一格里的数字会被切成多片，相连即还原 —— 实测比亚迪形态。"""
    toks = _tokens(["", "371,28", "0,948,00", "0.", "00", "100%", "-7.13%"])
    assert [v for _, v in toks] == [371280948000.00, 100.0, -7.13]


def test_mk_row_rejects_wrong_shapes():
    """形状不符必须返回 None，不能凑出一行假数据。"""
    assert _mk_row("x", "mix", [(False, 1.0), (True, 2.0)]) is None
    assert _mk_row("x", "biz", [(False, 1.0)]) is None


def test_biz_row_accepts_percent_and_bare_forms():
    """毛利率/同比写不写 `%` 都要能收 —— 茅台不写、宁德时代写。"""
    bare = _mk_row("酒类", "biz", [(False, 168.0), (False, 14.0), (False, 91.23),
                                   (False, -1.08), (False, 8.63)])
    withpct = _mk_row("动力电池系统", "biz",
                      [(False, 192.0), (False, 152.0), (True, 20.63),
                       (True, 46.02), (True, 49.38)])
    assert bare["margin"] == pytest.approx(91.23)
    assert withpct["margin"] == pytest.approx(20.63)


# --------------------------------------------------------------------------
# 真实 PDF 的 e2e：只钉结构与不变量
# --------------------------------------------------------------------------

def test_gree_annual_mix_is_consistent_with_income_statement(tmp_path):
    """构成表的合计必须与利润表的营业收入对得上 —— 这是"来源正确"的硬证据。"""
    from models import ReportKey
    from parser import parse
    path = require_pdf("gree_annual")
    key = ReportKey("格力电器", "000651", "年报", "2025")
    res = parse(path, key, verify=False)
    income = {m.period: m.value for m in res.metrics if m.name == "营业收入"}
    mix = extract_revenue_mix(path)
    assert mix and mix["total"], "格力年报的构成表应能抽出合计行"
    assert mix["total"]["cur"] == pytest.approx(income["2025"], rel=1e-9)
    assert mix["total"]["prev"] == pytest.approx(income["2024"], rel=1e-9)


def test_gree_annual_attribution_lands_on_a_concrete_segment():
    """归因必须落在**具体分部**上，而不是笼统的合计数。"""
    cons = contributions(extract_revenue_mix(require_pdf("gree_annual")))
    by_name = {c["name"]: c for c in cons}
    # 归因要落到**具体分部**：消费电器一项解释了过半降幅
    assert by_name["消费电器"]["group"] == "分产品"
    assert by_name["消费电器"]["contrib"] > 50
    # 占比维度也要有（构成表自带"占营业收入比重"）
    assert by_name["消费电器"]["share"] > 50
