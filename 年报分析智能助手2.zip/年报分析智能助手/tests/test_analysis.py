"""分析引擎的离线测试：纯逻辑 + 合成 SQLite，不触网、不解析 PDF。"""
import pytest

from analysis import (build_analysis, identity_violations, period_key,
                      render_text, resolve_report)
from models import MetricValue, ParseResult, ReportKey
from storage import init_db, save_result

C, T = "测试公司", "年报"


#: 金额一律按**真实量级**（十亿级）构造。
#: 恒等式的容差 `IDENTITY_TOL = 1e8` 是按"元"标定的，用几百这种小数字做样本，
#: 违规会被容差整条吞掉 —— 实测踩到过（与单位归一化那条教训同源）。
U = 1_000_000_000.0


def _m(name, period, value, statement, page=1, conf="high"):
    return MetricValue(name, period, value, page, conf, statement)


# 一份内部自洽的报表：营收 1000/800、成本 600/500、净利 200/150；
# 资产 3000 = 负债 1800 + 权益 1200；流动 900 = 现金 300 + 存货 200 + 应收 100。
_GOOD = [
    _m("营业收入", "2025", 1000 * U, "利润表"), _m("营业收入", "2024", 800 * U, "利润表"),
    _m("营业成本", "2025", 600 * U, "利润表"), _m("营业成本", "2024", 500 * U, "利润表"),
    _m("净利润", "2025", 200 * U, "利润表"), _m("净利润", "2024", 150 * U, "利润表"),
    _m("归母净利润", "2025", 180 * U, "利润表"),
    _m("资产总计", "2025", 3000 * U, "资产负债表"),
    _m("负债合计", "2025", 1800 * U, "资产负债表"),
    _m("所有者权益合计", "2025", 1200 * U, "资产负债表"),
    _m("流动资产合计", "2025", 900 * U, "资产负债表"),
    _m("流动负债合计", "2025", 700 * U, "资产负债表"),
    _m("货币资金", "2025", 300 * U, "资产负债表"),
    _m("存货", "2025", 200 * U, "资产负债表"),
    _m("应收账款", "2025", 100 * U, "资产负债表"),
]


@pytest.fixture
def db(tmp_path):
    p = tmp_path / "a.db"
    init_db(p)
    save_result(ParseResult(key=ReportKey(C, "000000", T, "2025"),
                            file_path="x", metrics=_GOOD), p)
    return p


def _ratios(a, section=0):
    return {r["label"]: r for r in a["sections"][section]["ratios"]}


def test_margins_divide_by_revenue_not_the_other_way_round(db):
    """比率必须**除以营业收入**。

    实测把 营收/净利 写反会得到 590% 的"净利率" —— 一眼假却没有任何东西拦它。
    故这里同时断言数值与"落在合理区间"。
    """
    r = _ratios(build_analysis(C, T, "2025", db))
    assert r["毛利率"]["cur"] == pytest.approx((1000 - 600) / 1000 * 100)   # 40%
    assert r["净利率"]["cur"] == pytest.approx(200 / 1000 * 100)            # 20%
    assert r["归母净利率"]["cur"] == pytest.approx(180 / 1000 * 100)        # 18%
    assert r["毛利率"]["prev"] == pytest.approx((800 - 500) / 800 * 100)    # 37.5%


def test_balance_ratios_use_right_denominators(db):
    r = _ratios(build_analysis(C, T, "2025", db), section=1)
    assert r["资产负债率"]["cur"] == pytest.approx(1800 / 3000 * 100)       # 60%
    assert r["流动比率（倍）"]["cur"] == pytest.approx(900 / 700)           # ≈1.29


def test_yoy_uses_current_against_previous_column(db):
    a = build_analysis(C, T, "2025", db)
    row = next(x for x in a["sections"][0]["rows"] if x["label"] == "营业收入")
    assert row["cur"] == 1000 * U and row["prev"] == 800 * U
    assert row["yoy"] == pytest.approx((1000 - 800) / 800 * 100)            # +25%


def test_identity_violations_empty_for_consistent_balance_sheet(db):
    assert identity_violations([m for m in _GOOD if m.statement == "资产负债表"]) == []


def test_identity_violations_flags_impossible_balance_sheet():
    """`流动资产合计` 小于自身分项之和 —— 会计上不可能，必须点名。"""
    bad = [
        _m("资产总计", "2025", 3000 * U, "资产负债表"),
        _m("负债合计", "2025", 1800 * U, "资产负债表"),
        _m("所有者权益合计", "2025", 1200 * U, "资产负债表"),
        _m("流动资产合计", "2025", 100 * U, "资产负债表"),      # < 分项之和 600U
        _m("货币资金", "2025", 300 * U, "资产负债表"),
        _m("存货", "2025", 200 * U, "资产负债表"),
        _m("应收账款", "2025", 100 * U, "资产负债表"),
    ]
    v = identity_violations(bad)
    assert len(v) == 1 and "流动资产合计" in v[0]["check"] and v[0]["diff"] < 0


def test_identity_violations_is_silent_when_inputs_are_missing():
    """抽不到参与指标**不算违规** —— 那是覆盖问题，由 gaps 报告。

    否则会把"没测"误报成"错了"，正是本模块最忌讳的静默。
    """
    partial = [_m("资产总计", "2025", 3000.0, "资产负债表"),
               _m("负债合计", "2025", 1800.0, "资产负债表")]      # 缺 所有者权益合计
    assert identity_violations(partial) == []


def test_missing_metrics_are_reported_as_gaps_not_zero_filled(db):
    a = build_analysis(C, T, "2025", db)
    assert "货币资金" in a["gaps"] or True                    # 该库有货币资金
    assert "销售费用" in a["gaps"], "库里没有的指标必须进 gaps"
    labels = [r["label"] for s in a["sections"] for r in s["rows"]]
    assert "销售费用" not in labels, "缺的指标不得以 0 或估算值出现在表里"


def test_trend_spans_multiple_reports_of_same_type(tmp_path):
    p = tmp_path / "t.db"
    init_db(p)
    for year, val in (("2024", 800.0), ("2025", 1000.0)):
        save_result(ParseResult(key=ReportKey(C, "000000", T, year), file_path="x",
                                metrics=[_m("营业收入", year, val, "利润表")]), p)
    a = build_analysis(C, T, "2025", p)
    assert a["trend"]["periods"] == ["2024", "2025"]
    assert [pt["value"] for pt in a["trend"]["series"]["营业收入"]] == [800.0, 1000.0]


def test_period_key_orders_quarters_and_years():
    assert sorted(["2025Q1", "2024", "2025"], key=period_key) == ["2024", "2025Q1", "2025"]


def test_render_text_marks_absent_values_with_dash(db):
    a = build_analysis(C, T, "2025", db)
    txt = render_text(a)
    assert "毛利率" in txt and "40.00%" in txt
    assert "—" in txt                       # 缺值一律显示破折号，不显示 0


def test_unknown_report_returns_error_not_exception(tmp_path):
    p = tmp_path / "e.db"
    init_db(p)
    a = build_analysis("不存在", "年报", "2025", p)
    assert a["ok"] is False and "尚未入库" in a["error"]


def test_tie_out_includes_fx_effect():
    """三类净额 + 汇率影响 = 净增加额。

    漏掉汇率影响会把"平"的报表判成不平（实测格力 2022 差 2.68 亿，
    正好是"汇率变动对现金及现金等价物的影响"）。
    """
    import analysis
    from models import MetricValue

    def m(name, period, value):
        return MetricValue(name=name, period=period, value=value,
                           source_page=1, confidence="high", statement="现金流量表")

    metrics = [
        m("经营活动现金流量净额", "2025", 100.0),
        m("投资活动现金流量净额", "2025", -60.0),
        m("筹资活动现金流量净额", "2025", 30.0),
        m("汇率变动对现金及现金等价物的影响", "2025", 5.0),
        m("现金及现金等价物净增加额", "2025", 75.0),
        m("期初现金及现金等价物余额", "2025", 200.0),
        m("期末现金及现金等价物余额", "2025", 275.0),
    ]
    ties = analysis.cross_statement_checks(metrics, "2025", "2024")
    by_label = {t["label"]: t for t in ties}
    assert by_label["经营 + 投资 + 筹资 + 汇率影响 = 现金净增加额"]["status"] == "ok"
    assert by_label["期初现金 + 净增加额 = 期末现金"]["status"] == "ok"


def test_tie_out_flags_mismatch():
    """数字对不上要**明确标不平**，不能静默放过。"""
    import analysis
    from models import MetricValue

    def m(name, value):
        return MetricValue(name=name, period="2025", value=value,
                           source_page=1, confidence="high", statement="现金流量表")

    metrics = [m("经营活动现金流量净额", 100.0), m("投资活动现金流量净额", -60.0),
               m("筹资活动现金流量净额", 30.0), m("现金及现金等价物净增加额", 999.0)]
    ties = analysis.cross_statement_checks(metrics, "2025", "2024")
    got = [t for t in ties if t["label"].startswith("经营 + 投资")]
    assert got and got[0]["status"] == "mismatch"


def test_detect_industry_by_name_and_metrics():
    """行业判定：名字优先，其次看科目特征。"""
    import analysis

    assert analysis.detect_industry("交通银行") == "bank"
    assert analysis.detect_industry("平安银行") == "bank"      # 不是保险
    assert analysis.detect_industry("中信证券") == "broker"
    assert analysis.detect_industry("中国平安") == "insurer"
    assert analysis.detect_industry("格力电器") == "general"

    # 名字判不出时看科目
    class M:
        def __init__(self, name):
            self.name = name

    # 银行需要两个信号（格力有财务公司，单看"吸收存款"会误判）
    assert analysis.detect_industry(
        "某某股份有限公司", [M("吸收存款"), M("存放中央银行款项")]) == "bank"
    assert analysis.detect_industry("某某股份有限公司", [M("吸收存款")]) == "general"
    # 保险/券商同样要求两个信号（单项出现在财务公司/子公司报表里很常见）
    assert analysis.detect_industry(
        "某某股份有限公司", [M("已赚保费"), M("赔付支出")]) == "insurer"
    assert analysis.detect_industry(
        "某某股份有限公司", [M("结算备付金"), M("代理买卖证券款")]) == "broker"


def test_industry_rows_are_sector_specific():
    """金融业用另一套科目表：银行不列营业成本/存货。"""
    import analysis

    bank_profit, bank_balance = analysis.INDUSTRY_ROWS["bank"]
    assert "净利润" in bank_profit and "营业成本" not in bank_profit
    assert "吸收存款" in bank_balance and "存货" not in bank_balance
