"""报告的**内部一致性**：不能自己打自己脸。

这几条来自一次外部评审，指出的都不是"数字抽错"，而是"数据缺失时模板照旧输出结论"：
 - 分产品表只剩一行，却写"它是变动最大的分部"
 - 账龄分项加起来不等于合计，却写"交叉校验一致"
 - 表号 2→5→10 断号、`**` 星号漏进 Word

用真实报告（华工科技，分产品表恰好残缺）生成一次，逐条断言。
"""
import re

import pytest
from docx import Document

DB = "data/structured.db"


@pytest.fixture(scope="module")
def hg(tmp_path_factory):
    from analysis import build_analysis
    from report_docx import save

    from pathlib import Path

    # **依赖 PDF 的测试要能跳过**：换了机器/精简了包，年报原文可能不在。
    if not list(Path("data/华工科技/年报").glob("*.PDF")):
        pytest.skip("华工科技年报 PDF 不在本地（精简部署常见）")
    try:
        a = build_analysis("华工科技", "年报", "2025", DB)
    except Exception:                       # noqa: BLE001
        pytest.skip("样本库不可用")
    if not a.get("ok"):
        pytest.skip("华工科技 2025 未入库")
    p = save(a, None, tmp_path_factory.mktemp("rep") / "x.docx")
    return Document(p)


def _texts(doc):
    return [p.text for p in doc.paragraphs]


def test_table_numbers_are_continuous(hg):
    """表号必须 1..N 连续 —— 手写编号删节后会断号（曾出现 2→5→10）。"""
    nums = [int(p.text.split()[1]) for p in hg.paragraphs
            if re.match(r"^表 \d+", p.text)]
    assert nums == list(range(1, len(nums) + 1)), nums


def test_no_markdown_asterisks_leak_into_word(hg):
    """Word 不认 markdown，`**粗体**` 必须渲染成真粗体，不能留星号。"""
    assert not [t for t in _texts(hg) if "**" in t]


def test_incomplete_aging_table_does_not_claim_consistency(hg):
    """账龄分项与合计不闭合时，**不能**写"交叉校验一致"。

    华工科技：1年内 39.52 + 1-2年 3.97 + 2-3年 0.74 = 44.23 亿，
    而账面余额 47.12 亿，差 2.9 亿（"3 年以上"没抽到）。
    """
    joined = "\n".join(_texts(hg))
    assert "账龄分项合计" in joined          # 必须显式告警
    assert "交叉校验：账龄分项合计与账面余额一致" not in joined


def test_incomplete_product_mix_does_not_claim_leader(hg):
    """分产品表只覆盖 25% 收入时，不能断言某个分部"变动最大"。"""
    joined = "\n".join(_texts(hg))
    assert "很可能没有抽全" in joined
    # 结论句要么给出覆盖率，要么改用完整口径的分组，不能直接套"变动最大"
    for line in _texts(hg):
        if "是变动最大的分部" in line:
            assert "口径" in line, line


def test_negative_base_items_show_amount_not_percentage(hg):
    """上期为负的科目（财务费用）不列同比百分比。"""
    joined = "\n".join(_texts(hg))
    assert "上期为负数的科目" in joined
    assert "不计算百分比" in joined


def test_top_level_chapters_are_complete(hg):
    """六章必须齐全。整节消失会让编号从"三"跳到"五"，读者分不清是没数据还是漏了。"""
    hs = [p.text for p in hg.paragraphs if p.style.name == "Heading 1"]
    for prefix in ("一、", "二、", "三、", "四、", "五、", "六、"):
        assert any(h.startswith(prefix) for h in hs), f"缺 {prefix} 章：{hs}"


def test_partial_receivables_does_not_claim_consistency(tmp_path):
    """只抽到应收账款净值、没抽到余额与账龄时，不能打印"交叉校验一致"。

    澜起科技 2025 就是这种情况：账面价值 5.70 亿拿到了，余额与账龄没抽到，
    旧版仍写"账面余额 — 亿元…交叉校验一致"，属于假声明。
    """
    from analysis import build_analysis
    from report_docx import save

    from pathlib import Path

    if not list(Path("data/澜起科技/年报").glob("*.PDF")):
        pytest.skip("澜起科技年报 PDF 不在本地（精简部署常见）")
    try:
        a = build_analysis("澜起科技", "年报", "2025", DB)
    except Exception:                       # noqa: BLE001
        pytest.skip("样本库不可用")
    if not a.get("ok") or (a.get("receivables") or {}).get("gross") is not None:
        pytest.skip("样本状态不适用")

    doc = Document(save(a, None, tmp_path / "x.docx"))
    text = "\n".join(p.text for p in doc.paragraphs)
    assert "账龄明细未能抽取" in text
    assert "交叉校验：账龄分项合计与账面余额一致" not in text


def test_report_builds_when_a_statement_is_missing(tmp_path):
    """缺表不能崩：银行/保险常抽不到现金流量表（实测交通银行报"写入失败"）。"""
    from report_docx import save

    data = {"company": "某银行", "period": "2025", "prev_period": "2024",
            "report_type": "年报", "cur_period": "2025",
            "sections": [{"title": "利润表分析",
                          "rows": [{"label": "营业收入", "cur": 1e8, "prev": 9e7,
                                    "yoy": 11.1, "page": 1, "confidence": "high"}],
                          "ratios": []}],
            "trend": None, "gaps": [], "identity_violations": [], "quality_flags": []}
    p = save(data, None, tmp_path / "x.docx")
    text = "\n".join(x.text for x in Document(p).paragraphs)
    assert "现金流量表" in text
    assert "无法判断杠杆水平" in text


def test_bank_report_hides_inapplicable_ratios():
    """银行报告不能出现"毛利率 —""流动比率 —"这类空指标。"""
    import analysis
    from report_docx import build

    a = analysis.build_analysis("交通银行", "年报", "2025", "data/structured.db")
    if not a.get("ok"):
        import pytest
        pytest.skip("交通银行未入库")
    doc = build(a, None)
    text = "\n".join(p.text for p in doc.paragraphs)
    assert a["industry"] == "bank"
    assert "不计算流动比率" in text
    assert "毛利率与研发费用率均不适用" in text


def test_footer_uses_current_company(tmp_path):
    """页脚必须是**当前**公司/年份，不能串到上一份报告。

    实测试用者反馈：问另一家公司时，页脚还是「格力电器 2025」。
    """
    import analysis
    from docx import Document
    from report_docx import save

    a = analysis.build_analysis("中国黄金", "年报", "2025", "data/structured.db")
    if not a.get("ok"):
        import pytest
        pytest.skip("中国黄金 2025 未入库")
    p = save(a, None, tmp_path / "x.docx")
    footer = Document(p).sections[0].footer.paragraphs[0].text
    assert "中国黄金" in footer
    assert "格力" not in footer


def test_save_repairs_wrong_footer(tmp_path):
    """页脚与正文公司不一致时，落盘前必须**自动改正**。

    实测有用户拿到过"正文是 A 公司、页脚是 B 公司"的报告（多半是旧版本生成的文件）；
    这里把修复逻辑钉住，任何路径产出都不会再自相矛盾。
    """
    import analysis
    from docx import Document
    from report_docx import build, save

    a = analysis.build_analysis("中国黄金", "年报", "2025", "data/structured.db")
    if not a.get("ok"):
        import pytest
        pytest.skip("中国黄金 2025 未入库")

    # 先造一份"页脚写错"的文档
    doc = build(a, None)
    footer = doc.sections[0].footer.paragraphs[0]
    for run in list(footer.runs):
        run._element.getparent().remove(run._element)
    footer.add_run("格力电器 2025 年度财务分析报告　·　第 ")
    broken = tmp_path / "broken.docx"
    doc.save(broken)
    assert "格力电器" in Document(broken).sections[0].footer.paragraphs[0].text

    # save() 会重写页脚
    fixed = save(a, None, tmp_path / "fixed.docx")
    text = Document(fixed).sections[0].footer.paragraphs[0].text
    assert "中国黄金" in text and "格力" not in text
