"""金额单位声明的读取（不联网、不开 PDF）。"""
from units import SCALES, detect_from_texts


def test_detects_bank_style_million_yuan():
    """招商银行 2024 年报报表页表头：`单位：人民币百万元`。"""
    scale, unit = detect_from_texts(["合并资产负债表\n单位：人民币百万元\n2024年"])
    assert (scale, unit) == (1e6, "百万元")


def test_detects_thousand_yuan():
    assert detect_from_texts(["单位：人民币千元"]) == (1e3, "千元")


def test_plain_yuan_is_explicit_and_wins_by_count():
    """多页取出现次数最多者：偶发正文提及不会翻盘。"""
    texts = ["单位：元", "单位：元", "单位：万元"]
    assert detect_from_texts(texts) == (1.0, "元")


def test_returns_none_without_declaration():
    """读不到就返回 None —— 由调用方退回「元」并告警，绝不按数字大小反推。"""
    assert detect_from_texts(["货币资金 1,234.00 2,345.00"]) == (None, None)
    assert detect_from_texts([]) == (None, None)


def test_million_wins_over_yuan_substring():
    """`百万元` 含 `万元`/`元` 子串，正则必须优先匹配长词。"""
    assert detect_from_texts(["单位：百万元"])[1] == "百万元"
    assert SCALES["百万元"] == 1e6
