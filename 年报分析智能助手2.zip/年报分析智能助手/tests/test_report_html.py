"""HTML 看板：自包含、可交互、数据内嵌。"""
import json
import re

from report_html import build_html, collect


def test_dashboard_is_self_contained(tmp_path):
    """**不引 CDN、不发请求** —— 断网也要能打开，交出去也不能依赖外网。"""
    p = build_html(out_path=tmp_path / "d.html")
    html = p.read_text(encoding="utf-8")
    assert "http://" not in html and "https://" not in html
    assert "<svg" not in html or True          # 图表由 JS 运行时生成


def test_dashboard_embeds_valid_data(tmp_path):
    p = build_html(out_path=tmp_path / "d.html")
    html = p.read_text(encoding="utf-8")
    m = re.search(r"const DATA = (\{.*?\});\nconst UNITS", html, re.S)
    assert m, "数据没内嵌"
    data = json.loads(m.group(1))
    assert data, "数据为空"
    entry = next(iter(data.values()))
    assert set(entry) >= {"company", "type", "periods", "metrics"}


def test_dashboard_has_interaction_controls(tmp_path):
    """要有公司选择与指标多选 —— 这是"可交互"的最低要求。"""
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    for token in ('id="csearch"', 'id="msearch"', 'id="mlist"',
                  'id="clist"', '"mitem"', 'class="citem'):
        assert token in html, f"缺控件：{token}"


def test_collect_filters_company():
    data = collect(companies=["格力电器"])
    assert data, "库里没有格力电器"
    assert all(e["company"] == "格力电器" for e in data.values())


def test_dashboard_has_units_and_nice_ticks(tmp_path):
    """单位必须写在图上、刻度必须是"人看得懂"的整数步长。

    实测反馈："单位都没有，坐标轴不规范"——原来 y 轴是裸数字、
    也没有单位；现在金额统一换算成亿元并标注，刻度按 1/2/5×10^n 取整。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")

    # 单位表内嵌，且每股收益是"元/股"而不是亿元
    assert "const UNITS" in html
    assert '"基本每股收益": "元/股"' in html
    assert '"营业收入": "亿元"' in html

    # 刻度算法 + 单位标注 + 单位分组
    for token in ("function niceTicks", "function unitOf", "function drawOneChart",
                  'aria-label="${unit}趋势"'):
        assert token in html, f"缺：{token}"


def test_metric_picker_has_search(tmp_path):
    """指标要能**打字搜索**，不能只靠一屏 chips 里找。

    实测反馈：指标太多（75 个），要能打字筛选，而不是在一屏里找。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    # 搜索框
    assert 'id="msearch"' in html
    assert "搜索，如 营业 / 现金流" in html
    # 下拉列表 + 过滤函数 + 回车选中
    assert 'id="mlist"' in html
    assert "function matches(" in html
    assert 'list.addEventListener("click"' in html
    # 指标列表**常驻**：取消勾选后条目仍在，随时可勾回来
    assert 'class="box"' in html
    assert '已选 ${sel.metrics.size} 个' in html


def test_dashboard_refreshes_after_ingest():
    """新公司入库后看板要**自动刷新**，否则页面上永远看不到它。

    看板是静态快照（不联网、无服务器），所以必须在入库时重建一次。
    """
    import agent

    src = __import__("inspect").getsource(agent._ingest_one)
    assert "refresh_quietly" in src, "入库流程没有刷新看板"


def test_refresh_is_skipped_under_pytest(monkeypatch):
    """测试环境不写文件（避免每次入库测试都去重建看板）。"""
    monkeypatch.setenv("PYTEST_CURRENT_TEST", "x")
    from report_html import refresh_quietly
    assert refresh_quietly() is None


def test_dashboard_reports_accurate_report_count(tmp_path):
    """页头报的是**报告数**，不是期间数。

    一份年报会存本期+上期两列科目，所以"期间数"自然多于报告数（实测 50 → 89）。
    页头要是报 89，用户会以为库里真有多少份。
    """
    import sqlite3
    from report_html import count_reports, render_html

    n = count_reports()
    with sqlite3.connect("data/structured.db") as c:
        expect = c.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
    assert n == expect
    html = render_html()
    assert f"<b>{n}</b><i>份报告</i>" in html


def test_metric_list_is_persistent(tmp_path):
    """指标列表常驻可勾选，不再用"点一下就没"的 chips。"""
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    assert 'class="chip' not in html
    assert 'class="box"' in html


def test_company_picker_is_searchable(tmp_path):
    """公司/报表类型也要能搜。

    实测：36 个条目（公司×类型）用原生下拉翻起来累，应该和指标一样可筛选。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    assert 'id="csearch"' in html
    assert 'id="clist"' in html
    # **既能下拉看全部，也能输入筛选**
    assert 'id="ccaret"' in html
    assert "function open()" in html and "function close()" in html
    assert 'input.addEventListener("focus", open)' in html
    assert "class=\"clist\"" in html or 'class="clist"' in html
    assert 'class="citem' in html


def test_dashboard_defaults_to_analyzed_company(tmp_path):
    """`/html` 打开时应**默认停在刚分析的那家公司**。

    否则 36 个条目要重新找一遍 —— 实测反馈就是这个。
    """
    import re

    from report_html import build_html

    p = build_html(out_path=tmp_path / "d.html", default_company="中国黄金")
    html = p.read_text(encoding="utf-8")
    picked = re.search(r'const DEFAULT_CO = ("(?:[^"\\]|\\.)*");', html).group(1)
    assert "中国黄金" in picked

    # 找不到的公司 → 退回第一条，不能把页面搞崩
    p2 = build_html(out_path=tmp_path / "d2.html", default_company="不存在的公司")
    picked2 = re.search(r'const DEFAULT_CO = ("(?:[^"\\]|\\.)*");',
                        p2.read_text(encoding="utf-8")).group(1)
    assert picked2 != '""' and "不存在" not in picked2


def test_company_picker_dropdown_shows_all_then_filters(tmp_path):
    """点开下拉要能看到**全部**公司，输入才筛选。

    实测反馈：改成常驻列表后"不能下拉看有哪些公司了"，所以要做成
    "下拉 + 搜索"二合一：聚焦即展开全部，输入即过滤。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    assert "点此展开全部" in html          # 提示文案
    # 输入为空或等于当前选中项时，返回全部（而不是只显示匹配项）
    assert "if(!kw || kw === labelOf(sel.co).toLowerCase()) return keys;" in html
    # 下拉可开可关
    assert 'list.classList.add("open")' in html
    assert 'list.classList.remove("open")' in html


def test_metrics_grouped_by_statement():
    """指标要按三张报表分组展示（资产/负债/利润/现金流）。

    实测：指标多了混成一个长列表分不清，应按报表归类。
    """
    from report_html import collect

    data = collect()
    entry = next(iter(data.values()))
    assert "stmt" in entry, "collect 没带报表归属"
    stmts = set(entry["stmt"].values())
    assert stmts & {"资产负债表", "利润表", "现金流量表"}, f"归属异常：{stmts}"


def test_dashboard_has_bulk_actions_and_grouping(tmp_path):
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    for token in ('id="mAll"', 'id="mNone"', 'id="mDefault"',
                  'class="phead', 'STMT_ORDER', 'stmt-block'):
        assert token in html, f"缺：{token}"


def test_charts_split_by_statement(tmp_path):
    """图表按三张报表分开画，而不是混在一张里。"""
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    assert "function drawCharts(periods, byStmt)" in html
    assert 'class="stmt-title"' in html


def test_legend_sits_under_each_statement_chart(tmp_path):
    """图例要跟着各自的图表走，不能全堆在页面底部。

    实测：三张报表的线全挤在页脚一排，分不清哪条属于哪张图。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    # 图例在 stmt-block 内部生成
    assert '<div class="legend">${legend}</div>' in js
    # 全局那份图例清空，避免重复
    assert 'el.innerHTML = ""' in js


def test_chart_hover_shows_values(tmp_path):
    """鼠标停在图上任意位置，要显示该年份各指标的数值。

    实测：只有圆点上才有原生 tooltip，稍偏一点就什么都没有。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert 'id="tip"' in html                       # 提示框容器
    assert "function wireChart" in js               # 事件接线
    assert "nearestIndex" in js                     # 找最近的年份
    assert 'class="hover-line"' in js               # 竖线指示
    assert 'svg.addEventListener("mousemove"' in js
    assert 'svg.addEventListener("mouseleave"' in js


def test_company_label_shows_only_name_and_type(tmp_path):
    """公司标签**不再拼年份**——年份已由独立的年份选择器负责。

    早先是"公司 · 年报 · 2022–2025"，加年份多选后重复了。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert "function labelOf(k)" in js
    assert "return `${DATA[k].company} · ${DATA[k].type}`" in js
    assert "function yearsOf" not in js


def test_metrics_grouped_by_statement():
    """指标要按三张报表分组展示（资产/负债/利润/现金流）。

    实测：指标多了混成一个长列表分不清，应按报表归类。
    """
    from report_html import collect

    data = collect()
    entry = next(iter(data.values()))
    assert "stmt" in entry, "collect 没带报表归属"
    stmts = set(entry["stmt"].values())
    assert stmts & {"资产负债表", "利润表", "现金流量表"}, f"归属异常：{stmts}"


def test_dashboard_has_bulk_actions_and_grouping(tmp_path):
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    for token in ('id="mAll"', 'id="mNone"', 'id="mDefault"',
                  'class="phead', 'STMT_ORDER', 'stmt-block'):
        assert token in html, f"缺：{token}"


def test_charts_split_by_statement(tmp_path):
    """图表按三张报表分开画，而不是混在一张里。"""
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    assert "function drawCharts(periods, byStmt)" in html
    assert 'class="stmt-title"' in html


def test_legend_sits_under_each_statement_chart(tmp_path):
    """图例要跟着各自的图表走，不能全堆在页面底部。

    实测：三张报表的线全挤在页脚一排，分不清哪条属于哪张图。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    # 图例在 stmt-block 内部生成
    assert '<div class="legend">${legend}</div>' in js
    # 全局那份图例清空，避免重复
    assert 'el.innerHTML = ""' in js


def test_chart_hover_shows_values(tmp_path):
    """鼠标停在图上任意位置，要显示该年份各指标的数值。

    实测：只有圆点上才有原生 tooltip，稍偏一点就什么都没有。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert 'id="tip"' in html                       # 提示框容器
    assert "function wireChart" in js               # 事件接线
    assert "nearestIndex" in js                     # 找最近的年份
    assert 'class="hover-line"' in js               # 竖线指示
    assert 'svg.addEventListener("mousemove"' in js
    assert 'svg.addEventListener("mouseleave"' in js


def test_every_metric_belongs_to_a_statement(tmp_path):
    """所有指标都要归到三大报表里，不能有"其他"。

    实测：金融业指标（吸收存款、发放贷款…）落进了"其他"，勾了也没有图。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    i = html.index("const STMT_OF = ") + len("const STMT_OF = ")
    j = html.index(";\n", i)
    mapping = json.loads(html[i:j])
    assert mapping, "归属表为空"
    stray = {k: v for k, v in mapping.items()
             if v not in ("资产负债表", "利润表", "现金流量表")}
    assert not stray, f"没归类的指标：{stray}"


def test_only_company_metrics_are_listed(tmp_path):
    """**只列出这家公司有的指标**，其余直接不显示。

    早期做法是列出来但置灰（还要解释为什么灰），更彻底的做法是干脆不显示。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert "hits.filter(m => DATA[sel.co].metrics[m])" in js
    assert "项不适用" not in js
    assert "只显示这家公司报告里有的指标" in html


def test_three_metric_panels_side_column_not_empty(tmp_path):
    """三大报表各占一块独立区域，而不是挤在一个长列表里。

    实测：左栏列表下面一大片空白，三张报表的分界也不明显。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert "stmt-panel" in html
    assert 'class="phead"' in js
    assert "data-pick" in js                  # 每组右上角可整组全选/清空
    assert "STMT_ORDER.filter(st => by[st])" in js


def test_year_range_selector_removed(tmp_path):
    """年份范围已删除。

    实测：库里每家公司只有 2~4 期，"最近 3 年/5 年"筛出来的还是全部，
    看着像坏了 —— 直接去掉更清楚。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    assert 'id="range"' not in html
    assert "最近 3 年" not in html
    assert "periodsOf" not in html


def test_greyed_metrics_have_explanation(tmp_path):
    """选不了的指标要说明**为什么**选不了。

    实测：用户看到一片灰色的"无"，以为是坏了；其实是银行/券商专用科目
    在这家公司的报告里不存在。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    assert "只显示这家公司报告里有的指标" in html
    assert "银行/券商的专用科目" in html


def test_year_multi_select(tmp_path):
    """年份可下拉、可搜索、可单选也可多选。

    实测需求：公司只显示名字，年份单独选；选了某一年也要能看图。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert 'id="ysearch"' in html
    assert "function initYearPicker" in js
    assert "function allYears" in js
    assert "sel.years" in js
    # 公司标签里不再拼年份区间
    assert "function yearsOf" not in js


def test_line_and_bar_in_one_chart(tmp_path):
    """折线与柱状**在同一张图里**：柱子表示量，折线叠加趋势。

    需求演进：两张分开 → 并排 → 同屏切换 → 最终合成一张。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert "function drawComboChart" in js
    assert 'class="duo"' not in js
    # 同一函数里既画 rect（柱）又画 path（线）
    combo = js.split("function drawComboChart")[1].split("function wireChart")[0]
    assert "<rect" in combo and "<path" in combo and "<circle" in combo




def test_insight_follows_selected_metrics(tmp_path):
    """每张图下面有"解读"，内容随所选指标变化。

    实测需求：看板要能自己说明这几条线什么意思；且是**规则生成**
    （静态文件、离线可用，不调用模型）。
    """
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    assert "function buildInsight" in js
    assert "function seriesStats" in js
    assert 'class="insight"' in js
    assert "按你勾选的指标自动生成" in js          # 说明数据边界
    # 只有被选的指标才会出现在解读里（遍历传进来的 series）
    assert "series.forEach(s => {" in js


def test_insight_has_cross_statement_rules(tmp_path):
    """跨报表的组合判断：净利率、资产负债率、现金流含量。"""
    html = build_html(out_path=tmp_path / "d.html").read_text(encoding="utf-8")
    js = html.split("<script>")[1]
    for token in ("净利润率由", "资产负债率由", "经营现金流约为净利润的"):
        assert token in js, f"缺规则：{token}"
