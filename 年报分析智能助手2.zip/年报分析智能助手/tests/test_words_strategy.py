"""按文字坐标重建行：专治"无框线、标签被拆碎"的报表。

验收样本是中国黄金 600916（A 股）的合并现金流量表：p86 是标题页、p87 是续页，
表没有竖线，一个科目被切成三行、数字单独夹在中间。
"""
from pathlib import Path

import pytest

PDF = Path("data/中国黄金/年报/中国黄金集团黄金珠宝股份有限公司2025年年度报告.PDF")


@pytest.fixture(scope="module")
def gz_rows():
    if not PDF.exists():
        pytest.skip("样本缺失")
    import pdfplumber
    from table_reader import rows_from_words
    with pdfplumber.open(PDF) as pdf:
        return rows_from_words(pdf.pages[85])      # p86


def test_wrapped_label_is_rejoined(gz_rows):
    """`经营活动产生的现金流` + `量净额` 要拼回一个完整科目名。"""
    labels = [r[0] for r in gz_rows]
    assert "经营活动产生的现金流量净额" in labels
    assert "销售商品、提供劳务收到的现金" in labels


def test_footnote_ref_is_dropped_from_label(gz_rows):
    """附注编号（七、79（1））夹在标签中间，必须丢掉，否则匹配不上科目。"""
    assert not any("七、79" in r[0] for r in gz_rows)


def test_values_go_to_the_right_year_column(gz_rows):
    """数字要按**表头锚点**归列：销售收现 2025 是 736.8 亿，不是 2024 的 643.1 亿。"""
    from metric_extractor import extract_metrics
    ms = extract_metrics(gz_rows, page=86, years=["2025", "2024"],
                         statement="现金流量表")
    got = {(m.name, m.period): m.value for m in ms}
    assert got[("销售商品收到的现金", "2025")] == pytest.approx(73_681_672_975.50, rel=1e-9)
    assert got[("经营活动现金流量净额", "2025")] == pytest.approx(502_014_483.51, rel=1e-9)


def test_words_table_only_used_when_page_has_period_header():
    """续页（无表头）不启用坐标策略 —— 列含义无从判断。"""
    if not PDF.exists():
        pytest.skip("样本缺失")
    import pdfplumber
    from table_reader import _cluster_lines, _period_anchors
    with pdfplumber.open(PDF) as pdf:
        assert _period_anchors(_cluster_lines(pdf.pages[85].extract_words()))   # p86 有
        assert not _period_anchors(_cluster_lines(pdf.pages[86].extract_words()))  # p87 无
