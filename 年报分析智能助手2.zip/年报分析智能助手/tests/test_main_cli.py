from main import build_parser


def test_cli_parses_ask_subcommand():
    p = build_parser()
    a = p.parse_args(["ask", "格力电器2025年营业收入是多少"])
    assert a.command == "ask"
    assert a.question == "格力电器2025年营业收入是多少"


def test_cli_parses_ingest_subcommand():
    p = build_parser()
    a = p.parse_args(["ingest", "格力电器", "一季报", "2025-01-01", "2025-12-31"])
    assert a.command == "ingest"
    assert a.keyword == "格力电器"
    assert a.report_type == "一季报"


def test_cli_has_reindex_flag():
    p = build_parser()
    a = p.parse_args(["ingest", "格力电器", "年报", "2025-01-01", "2025-12-31",
                      "--reindex"])
    assert a.reindex is True


def test_cli_quarter_period_carries_quarter(monkeypatch):
    """季报的 period 必须带 Q —— 丢了季度，Task 2 的季度标签就永不触发。"""
    import main
    monkeypatch.setattr("downloader.resolve_org",
                        lambda kw: ("000651", "gssz0000651", "格力电器"))
    assert main._report_key("格力电器", "一季报", "2025-01-01").period == "2025Q1"
    assert main._report_key("格力电器", "三季报", "2025-01-01").period == "2025Q3"
    assert main._report_key("格力电器", "年报", "2025-01-01").period == "2025"


def test_cli_ingest_accepts_local_pdf():
    """本地已有 PDF 时不该被迫重新下载（批量回灌、离线环境都要用）。"""
    p = build_parser()
    a = p.parse_args(["ingest", "格力电器", "年报", "2025-01-01", "2025-12-31",
                      "--pdf", "/tmp/x.PDF"])
    assert a.pdf == "/tmp/x.PDF"


def test_cli_ingest_unit_defaults_to_yuan():
    p = build_parser()
    a = p.parse_args(["ingest", "格力电器", "年报", "2025-01-01", "2025-12-31"])
    assert a.unit == "元"


def test_cli_ingest_accepts_thousand_yuan_unit():
    """千元报表必须能显式声明 —— 实测比亚迪/宁德时代/顺丰都是千元。"""
    p = build_parser()
    a = p.parse_args(["ingest", "比亚迪", "半年报", "2026-01-01", "2026-06-30",
                      "--unit", "千元"])
    assert a.unit == "千元"


def test_unit_scales_are_yuan_normalisers():
    from main import UNIT_SCALES
    assert UNIT_SCALES == {"元": 1.0, "千元": 1000.0, "万元": 10000.0}


def test_report_key_local_pdf_skips_network_org_lookup(monkeypatch):
    """`--pdf` 路径**不该碰网络**：本地回灌要能离线跑。

    `resolve_org` 会打巨潮 API 把简称规范成全名+代码。本地文件已有全名，
    再走一趟网络既慢又无必要，且离线环境会直接失败。
    """
    import main
    calls = []
    monkeypatch.setattr("downloader.resolve_org",
                        lambda kw: calls.append(kw) or ("x", "y", "z"))
    k = main._report_key("贵州茅台", "年报", "2025-01-01", resolve=False)
    assert calls == [], "本地路径不该调用 resolve_org"
    assert (k.company, k.period, k.code) == ("贵州茅台", "2025", "")
    # 对照：默认路径仍须规范化公司名（下载路径靠它拿到全名与代码）
    k2 = main._report_key("格力", "年报", "2025-01-01")
    assert calls == ["格力"] and k2.company == "z"
