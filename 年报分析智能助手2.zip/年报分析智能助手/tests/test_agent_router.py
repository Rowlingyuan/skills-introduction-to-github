"""路由是纯字符串匹配，不需要网络也不需要 LLM —— 这一层的测试必须离线可跑。"""
import pytest

from agent import route, answer
from models import MetricValue, ParseResult, ReportKey
from storage import init_db, save_result
from config import STATEMENT_ALIASES


@pytest.fixture
def db(tmp_path):
    p = tmp_path / "t.db"
    init_db(p)
    save_result(ParseResult(
        key=ReportKey("格力电器", "000651", "年报", "2025"),
        file_path="x.PDF",
        sections={"利润表": 88},
        metrics=[MetricValue("营业收入", "2025", 170447058533.57, 88, "high")],
    ), p)
    return p


def test_route_structured_for_metric_question(db):
    r = route("格力电器2025年营业收入是多少", db)
    assert r is not None
    assert r["company"] == "格力电器"
    assert r["metric"] == "营业收入"
    assert r["period"] == "2025"
    assert r["statement"] == "利润表"


def test_route_returns_none_for_open_question(db):
    assert route("格力电器2025年经营情况讨论", db) is None


def test_route_handles_quarter_period(db):
    r = route("格力电器2025Q1营业收入", db)
    assert r is not None and r["period"] == "2025Q1"


def test_route_returns_none_for_unknown_company(db):
    """库里没有的公司：不得崩，交给 RAG。"""
    assert route("比亚迪2025年营业收入是多少", db) is None


@pytest.fixture
def db_semi(tmp_path):
    """库里只有一份**半年报**：period 同为裸年份（"2026"），靠 report_type 区分。"""
    p = tmp_path / "s.db"
    init_db(p)
    save_result(ParseResult(
        key=ReportKey("比亚迪", "002594", "半年报", "2026"),
        file_path="y.PDF",
        sections={"利润表": 67},
        metrics=[MetricValue("营业收入", "2026", 371281000000.0, 67, "high")],
    ), p)
    return p


def test_route_returns_none_when_no_year_in_question(db):
    assert route("格力电器的营业收入是多少", db) is None


def test_answer_structured_returns_traceable_value(db):
    res = answer("格力电器2025年营业收入是多少", db)
    assert res["route"] == "structured"
    assert "170,447,058,533.57" in res["answer"]
    # 每个数值行必须标出年份——库里同期存有本期与上期两列，
    # 不标年份就会输出两串无从分辨的数字（e2e 实测踩到）。
    assert "2025：170,447,058,533.57" in res["answer"]
    assert res["metrics"][0]["source_page"] == 88
    assert res["metrics"][0]["confidence"] == "high"


def test_answer_when_report_not_in_db_does_not_fall_back_to_rag(db):
    """路由判了结构化但库里没有该期数据 —— 必须明说，不得让 LLM 去猜。"""
    res = answer("格力电器2024年营业收入是多少", db)
    assert res["route"] == "structured"
    assert res["metrics"] == []
    assert "未入库" in res["answer"] or "没有" in res["answer"]


def test_missing_metric_in_ingested_report_is_not_blamed_on_missing_ingest(db):
    """报告已入库、只是这一项没抽到 —— 不能提示"请先 ingest"（会让人白跑）。

    实测踩到过：格力 2025 年报已入库（利润表/现金流量表都抽到了），问它的
    `资产总计`（该项没抽到）却得到"该报告尚未入库，请先执行 ingest 把它落库"。
    """
    res = answer("格力电器2025年资产总计是多少", db)      # 该用例库里只有营业收入
    assert res["metrics"] == []
    assert "已入库" in res["answer"] and "未抽到" in res["answer"]
    assert "尚未入库" not in res["answer"]


def test_alias_tables_cover_all_three_statements():
    assert set(STATEMENT_ALIASES) == {"利润表", "资产负债表", "现金流量表"}


def test_answer_refuses_numeric_question_for_unindexed_company(db, monkeypatch):
    """未入库公司的「指标+年份」问题**绝不能退到 RAG**。

    实测过：问「比亚迪2025年营业收入是多少」，路由判不出公司 → 退 RAG，
    而检索没有公司护栏，捞回的全是格力的段落（引用页码也全是格力的）。
    数字类问题的可追溯答案只能来自 SQLite，故这里必须直接明说，
    而不是让 LLM 拿别家公司的资料复述一个数。
    """
    import agent
    called = []
    monkeypatch.setattr(agent, "_search",
                        lambda *a, **k: called.append("search") or [])
    monkeypatch.setattr(agent, "_call_reasoner",
                        lambda *a, **k: called.append("llm") or "编造的答案")
    res = agent.answer("比亚迪2025年营业收入是多少", db)
    assert called == [], "不应触发 RAG（检索 + LLM）"
    assert res["route"] == "structured"
    assert res["metrics"] == [] and res["citations"] == []
    assert "格力电器" in res["answer"], "应告知当前已入库的公司"


def test_route_honours_explicit_report_type_keyword(db_semi):
    """问题里写了「半年报」就必须查半年报 —— 否则半年报数据永远够不着。

    半年报的 period 与年报同为裸年份（`models.py:11`），只能靠 report_type 区分；
    若一律默认"年报"，灌进去的半年报数据会**全部不可达**：
    问「比亚迪2026年营业收入」只会得到"年报口径尚未入库"。
    """
    r = route("比亚迪2026年半年报营业收入是多少", db_semi)
    assert r is not None
    assert r["report_type"] == "半年报"
    assert r["period"] == "2026"


def test_answer_reaches_semi_annual_data(db_semi):
    res = answer("比亚迪2026年半年报营业收入是多少", db_semi)
    assert res["route"] == "structured"
    assert res["metrics"], "半年报数据应当可达"
    assert "371,281,000,000.00" in res["answer"]


def test_route_defaults_to_annual_without_keyword(db):
    """没写报告类型时仍默认年报（既有行为，回归基线）。"""
    assert route("格力电器2025年营业收入是多少", db)["report_type"] == "年报"


def test_report_type_hint_prefers_half_year_over_annual_substring(db_semi):
    """「半年度报告」含「年度报告」子串 —— 半年报必须排在年报之前判断。"""
    r = route("比亚迪2026年半年度报告营业收入", db_semi)
    assert r is not None and r["report_type"] == "半年报"


def test_answer_still_routes_open_question_without_metric_to_rag(db, monkeypatch):
    """护栏只拦「指标+年份」的数字问题；没有指标年份的开放问题仍走 RAG。"""
    import agent
    sentinel = {"route": "rag", "metrics": [], "citations": [],
                "companies": [], "answer": "rag"}
    monkeypatch.setattr(agent, "answer_rag", lambda *a, **k: sentinel)
    assert agent.answer("格力电器2025年经营情况讨论", db) == sentinel


@pytest.fixture
def db_bad_balance(tmp_path):
    """资产负债表三项对不上的报告（模拟抽取被切坏单元格）。"""
    p = tmp_path / "b.db"
    init_db(p)
    save_result(ParseResult(
        key=ReportKey("贵州茅台", "600519", "半年报", "2026"),
        file_path="z.PDF",
        metrics=[
            MetricValue("资产总计", "2026", 309050784569.31, 26, "high", "资产负债表"),
            MetricValue("负债合计", "2026", 46954432394.95, 27, "high", "资产负债表"),
            # 真值 262,096,352,174 —— 首位数字被切走
            MetricValue("所有者权益合计", "2026", 62096352174.36, 28, "high", "资产负债表"),
        ],
    ), p)
    return p


def test_balance_sheet_identity_failure_is_flagged_in_answer(db_bad_balance):
    """对不上就必须**显式告警**，不能把错值当事实端出去。"""
    res = answer("贵州茅台2026年半年报所有者权益合计是多少", db_bad_balance)
    assert res["route"] == "structured"
    assert "62,096,352,174.36" in res["answer"]      # 数字照给（可追溯）
    assert "⚠️" in res["answer"] and "资产总计" in res["answer"]


@pytest.fixture
def db_good_balance(tmp_path):
    """资产负债表三项**精确对得上**的报告。"""
    p = tmp_path / "g.db"
    init_db(p)
    save_result(ParseResult(
        key=ReportKey("贵州茅台", "600519", "年报", "2025"),
        file_path="w.PDF",
        metrics=[
            MetricValue("资产总计", "2025", 300000000000.0, 59, "high", "资产负债表"),
            MetricValue("负债合计", "2025", 50000000000.0, 60, "high", "资产负债表"),
            MetricValue("所有者权益合计", "2025", 250000000000.0, 61, "high", "资产负债表"),
        ],
    ), p)
    return p


def test_balance_sheet_identity_ok_has_no_warning(db_good_balance):
    """对得上就不许多话 —— 噪声告警会把用户训练成忽略告警。"""
    res = answer("贵州茅台2025年所有者权益合计是多少", db_good_balance)
    assert "250,000,000,000.00" in res["answer"]
    assert "⚠️" not in res["answer"]


def test_identity_warning_not_applied_to_income_statement(db_bad_balance):
    """告警只针对资产负债表 —— 利润表/现金流量表没有这套恒等式。"""
    res = answer("贵州茅台2026年半年报净利润是多少", db_bad_balance)
    assert "⚠️" not in res["answer"]


# --------------------------------------------------------------------------
# 「出一份分析报告」意图
# --------------------------------------------------------------------------

def _analysis_db(tmp_path):
    p = tmp_path / "an.db"
    init_db(p)
    U = 1_000_000_000.0
    save_result(ParseResult(
        key=ReportKey("格力电器", "000651", "年报", "2025"), file_path="x",
        metrics=[
            MetricValue("营业收入", "2025", 1000 * U, 1, "high", "利润表"),
            MetricValue("营业收入", "2024", 800 * U, 1, "high", "利润表"),
            MetricValue("营业成本", "2025", 600 * U, 1, "high", "利润表"),
            MetricValue("净利润", "2025", 200 * U, 1, "high", "利润表"),
        ]), p)
    return p


def test_explicit_analysis_request_returns_a_report(tmp_path, monkeypatch):
    """「帮我分析一下」→ 出分析报告，不是单个数字。"""
    import agent
    # 原文归因要调检索 + 大模型，这里 stub 掉（那两条链路各自有测试）
    monkeypatch.setattr(agent, "_narrative",
                        lambda *a, **k: {"ok": True, "grounded": False,
                                         "answer": "年报里没有检索到相关说明。",
                                         "citations": []})
    # 分析请求现在会顺手出 Word；这里的假数据不足以排版，stub 掉
    monkeypatch.setattr(agent, "build_report",
                        lambda *a, **k: {"ok": True, "path": "/tmp/x.docx"})
    db = _analysis_db(tmp_path)
    res = answer("把格力电器2025年报给我分析一下", db)
    assert res["route"] == "analysis"
    # 终端给**结论摘要**（规模/盈利/现金/结构），不再是六十多行抽取明细
    assert "规模" in res["answer"] and "盈利" in res["answer"]
    assert "报告做好啦" in res["answer"]
    assert res["analysis"]["company"] == "格力电器"
    # **默认不调大模型**：网关经常超时，一次白等 30~60 秒，故不附原文归因。
    assert "年报原文对变动原因的说明" not in res["answer"]

    # 明确要的时候才附上（来源另标）
    res2 = answer("把格力电器2025年报给我分析一下，并附原文原因", db)
    assert "年报原文对变动原因的说明" in res2["answer"]


def test_bare_metric_question_still_wins_over_analysis(tmp_path):
    """问具体指标时仍走结构化精确查询 —— 分析意图不得抢在前面。"""
    db = _analysis_db(tmp_path)
    assert answer("格力电器2025年营业收入是多少", db)["route"] == "structured"


def test_open_question_without_explicit_analysis_verb_stays_rag(db, monkeypatch):
    """「经营情况讨论」不带分析动词 → 仍走 RAG。

    触发词刻意不含「情况」：实测它会把这句开放问题误劫持成分析报告。
    """
    import agent
    sentinel = {"route": "rag", "metrics": [], "citations": [],
                "companies": [], "answer": "rag"}
    monkeypatch.setattr(agent, "answer_rag", lambda *a, **k: sentinel)
    assert agent.answer("格力电器2025年经营情况讨论", db) == sentinel


def test_company_matching_normalises_fullwidth_names(tmp_path):
    """巨潮返回 `万科Ａ`（全角），用户打 `万科A`（半角）—— 必须能认出来。

    实测问「帮我出一份万科A2025年报的分析报告」时被判成"库里没这家公司"，
    直接掉到 RAG 答"未收录"，报告也就出不来。
    """
    import sqlite3
    from agent import _norm_name, match_company

    db = tmp_path / "x.db"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE reports (company TEXT, report_type TEXT, period TEXT)")
    conn.execute("INSERT INTO reports VALUES ('万科Ａ','年报','2025')")
    conn.commit()
    conn.close()

    assert _norm_name("万科Ａ") == _norm_name("万科A") == "万科A"
    assert match_company("帮我出一份万科A2025年报的分析报告", db) == "万科Ａ"
    assert match_company("分析一下五粮液2025年报", db) is None


def test_unknown_company_gets_actionable_message_not_rag_hallucination(tmp_path, monkeypatch):
    """问一家库里没有的公司时，不能拿别家段落拼"未收录"。

    实测：问「上纬新材」检索到的是别的公司页面，模型据此答"未收录该公司"，
    还附了一串不相干的页码 —— 既没用又误导。
    """
    import agent

    def _no_retrieval(*a, **k):
        raise AssertionError("不该走检索")

    monkeypatch.setattr(agent, "_search", _no_retrieval)
    db = _analysis_db(tmp_path)
    res = answer("帮我分析一下某某科技2025年年报", db)
    assert res["route"] == "rag"
    assert "某某科技" in res["answer"]
    # 措辞已改成"没能在巨潮检索到"——因为自动下载已经先试过了，
    # 走到这一步说明**连公司都没解析出来**，不是"库里有没下载"的问题
    assert "没能在巨潮检索到" in res["answer"]
    assert res["citations"] == []


def test_report_message_tells_where_files_are(tmp_path):
    """结尾要说明文件**放在哪**，以及年报 PDF 的位置。

    实测：只给文件名，用户不知道去哪个文件夹找；PDF 更是没提过。
    """
    import agent

    src = __import__("inspect").getsource(agent._document_suffix)
    assert "📍" in src and "位置" in src
    assert "年报原文" in src or "PDF" in src
    assert "_report_pdf_path" in src


def test_report_message_lists_three_items_with_locations():
    """结尾要说清**三样东西**（报告 / 看板 / 年报原文），各自带位置与打开方式。

    实测：只提两样，PDF 那行还换了格式，用户找不到。
    """
    import inspect

    import agent

    src = inspect.getsource(agent._document_suffix)
    assert "三样东西" in src
    assert "还有年报原文" in src
    assert src.count("📍 位置：") >= 3
    assert src.count("👉") >= 3


def test_pdf_lookup_falls_back_to_directory(tmp_path, monkeypatch):
    """库里没记 file_path 时，按 data/<公司>/<类型>/ 兜底找。

    实测：有的记录 file_path 为空、有的用户清理过 PDF；
    只要文件还在目录里，就应该能找到。
    """
    import agent

    root = tmp_path
    d = root / "data" / "测试公司" / "年报"
    d.mkdir(parents=True)
    (d / "测试公司2024年年度报告.PDF").write_text("x")
    (d / "测试公司2025年年度报告.PDF").write_text("y")

    monkeypatch.setattr(agent, "__file__", str(root / "agent.py"))
    got = agent._report_pdf_path("测试公司", "2025", "年报", str(root / "nope.db"))
    assert got is not None and "2025" in got.name
