"""模型调用的错误分类与重试策略（全部离线，不碰网络）。"""
from unittest.mock import patch

import pytest

import client
from client import ModelError, classify_error


@pytest.mark.parametrize("message,kind", [
    ("Request timed out.", "timeout"),
    ("Connection error.", "connection"),
    ("Error code: 401 - invalid api key", "auth"),
    ("429 Too Many Requests", "rate_limit"),
    ("502 Bad Gateway", "server"),
    ("模型返回空内容", "empty"),
])
def test_classify_error(message, kind):
    assert classify_error(Exception(message)) == kind


def test_model_error_message_is_actionable():
    """提示里要能看出**该怎么办**，而不是只有一句 Request timed out。"""
    e = ModelError("auth", "invalid api key", model="m", attempts=1)
    text = str(e)
    assert "auth" in text
    assert "API_KEY" in text          # 告诉用户去哪改
    assert "model=m" in text


def test_auth_error_is_not_retried(monkeypatch):
    """key 错了重试三次只是白等 —— 必须一次失败立刻抛。"""
    calls = {"n": 0}

    def boom(**kw):
        calls["n"] += 1
        raise Exception("Error code: 401 - invalid api key")

    with patch.object(client.client.chat.completions, "create", boom):
        with pytest.raises(ModelError) as ei:
            client.call_model("reasoner", [{"role": "user", "content": "hi"}],
                              max_retries=3)
    assert ei.value.kind == "auth"
    assert ei.value.attempts == 1
    assert calls["n"] == 1


def test_timeout_is_retried(monkeypatch):
    calls = {"n": 0}

    def boom(**kw):
        calls["n"] += 1
        raise TimeoutError("Request timed out.")

    monkeypatch.setattr(client.time, "sleep", lambda *_: None)
    with patch.object(client.client.chat.completions, "create", boom):
        with pytest.raises(ModelError) as ei:
            client.call_model("reasoner", [{"role": "user", "content": "hi"}],
                              max_retries=3)
    assert ei.value.kind == "timeout"
    assert ei.value.attempts == 3
    assert calls["n"] == 3


def test_empty_reply_counts_as_failure(monkeypatch):
    """200 但正文为空 —— 必须当失败，不能当成功返回空字符串。"""
    class R:
        class M:
            content = "   "
        choices = [type("C", (), {"message": M()})()]

    monkeypatch.setattr(client.time, "sleep", lambda *_: None)
    with patch.object(client.client.chat.completions, "create", lambda **kw: R()):
        with pytest.raises(ModelError) as ei:
            client.call_model("reasoner", [{"role": "user", "content": "hi"}],
                              max_retries=2)
    assert ei.value.kind == "empty"


def test_ping_reports_kind_on_failure(monkeypatch):
    def boom(*a, **k):
        raise ModelError("connection", "Connection error.", model="m")
    monkeypatch.setattr(client, "call_model", boom)
    got = client.ping()
    assert got["ok"] is False and got["kind"] == "connection"


def test_ping_ok(monkeypatch):
    monkeypatch.setattr(client, "call_model", lambda *a, **k: "ok")
    assert client.ping()["ok"] is True


def test_reasoner_falls_back_to_backup_model(monkeypatch):
    """主模型 timeout 时切备用模型 —— 实测 deepseek 挂了但 qwen 是通的。"""
    seen = []

    def fake_call_model(role, messages, **kw):
        seen.append(role)
        if role == "reasoner":
            raise ModelError("timeout", "Request timed out.", model="deepseek")
        return "备用模型给的答案"

    monkeypatch.setattr(client, "call_model", fake_call_model)
    assert client.call_reasoner([{"role": "user", "content": "hi"}]) == "备用模型给的答案"
    assert seen == ["reasoner", "reasoner_backup"]


def test_reasoner_does_not_fall_back_on_auth_error(monkeypatch):
    """key 错了，换模型也没用 —— 不该再打一次。"""
    seen = []

    def fake_call_model(role, messages, **kw):
        seen.append(role)
        raise ModelError("auth", "invalid api key", model="x")

    monkeypatch.setattr(client, "call_model", fake_call_model)
    with pytest.raises(ModelError):
        client.call_reasoner([{"role": "user", "content": "hi"}])
    assert seen == ["reasoner"]
