"""「库里没有 → 联网下载 → 分析」这条路径的离线测试（网络全部注入假实现）。"""
import pytest

from agent import _candidate_company, _try_ingest


def test_candidate_company_strips_politeness_and_verbs():
    assert _candidate_company("帮我下载并分析五粮液2024年的年报") == "五粮液"
    assert _candidate_company("请下载中国平安2023年年度报告") == "中国平安"
    assert _candidate_company("分析一下贵州茅台2019年报") == "贵州茅台"


def test_candidate_company_rejects_generic_words():
    assert _candidate_company("这家公司的年报怎么样") is None
    assert _candidate_company("帮我分析一下年报") is None
    assert _candidate_company("") is None


def test_try_ingest_requires_explicit_intent(tmp_path):
    """只提到公司不够 —— 必须有「报表类型 + 分析类意图」，否则不该联网下 5MB PDF。"""
    db = tmp_path / "x.db"
    called = []
    res = _try_ingest("五粮液怎么样", db,
                      resolve_fn=lambda n: called.append(n) or ("1", "o", n),
                      fetch_and_parse=lambda: called.append("fetch") or {})
    assert res is None
    assert called == []


def test_try_ingest_skips_companies_already_in_db(tmp_path):
    """库里已有该公司时不该重复下载（本地秒回）。"""
    import sqlite3
    db = tmp_path / "x.db"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE reports (company TEXT, report_type TEXT, period TEXT)")
    conn.execute("INSERT INTO reports VALUES ('五粮液','年报','2024')")
    conn.commit()
    conn.close()

    called = []
    res = _try_ingest("分析一下五粮液2024年的年报", db,
                      resolve_fn=lambda n: called.append("resolve") or ("1", "o", n),
                      fetch_and_parse=lambda: called.append("fetch") or {})
    assert res is None
    assert "fetch" not in called


def test_try_ingest_returns_none_when_company_unknown(tmp_path):
    """巨潮查不到这家公司 → 不接管，交给 RAG 链路。"""
    db = tmp_path / "x.db"
    def boom(name):
        raise LookupError("未找到公司")
    assert _try_ingest("分析一下不存在公司2024年的年报", db,
                       resolve_fn=boom, fetch_and_parse=lambda: {}) is None


def test_try_ingest_reports_download_failure(tmp_path):
    db = tmp_path / "x.db"
    def fail():
        raise RuntimeError("连接超时")
    res = _try_ingest("分析一下五粮液2024年的年报", db,
                      resolve_fn=lambda n: ("000858", "o", "五粮液"),
                      fetch_and_parse=fail)
    assert res is not None
    assert "下载/解析失败" in res["answer"]


def test_ingest_runs_when_company_known_but_that_year_missing(tmp_path):
    """库里已有五粮液 **2024**，不代表 **2025** 也在 —— 必须去下载。

    这是实测踩到的 bug：「帮我下载并分析 五粮液 2025 年年报」被当成
    "公司在库"直接跳过下载，最后掉到 RAG 答"未找到资料"。
    """
    import sqlite3
    from storage import init_db
    db = tmp_path / "x.db"
    init_db(str(db))            # 用真实 schema，别手搓表（少一列就会在 join 处炸）
    conn = sqlite3.connect(db)
    conn.execute("INSERT INTO reports (company, report_type, period) "
                 "VALUES ('五粮液','年报','2024')")
    conn.commit()
    conn.close()

    called = []
    res = _try_ingest("帮我下载并分析 五粮液 2025 年年报", db,
                      resolve_fn=lambda n: ("000858", "o", "五粮液"),
                      fetch_and_parse=lambda: called.append("fetch") or {
                          "company": "五粮液", "report_type": "年报",
                          "period": "2025", "pdf": "x.PDF", "indexed": 0})
    assert "fetch" in called            # 真的去下载了，没有被"公司在库"挡住
    assert res is not None


def test_has_report_is_period_aware(tmp_path):
    import sqlite3
    from agent import has_report
    db = tmp_path / "x.db"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE reports (company TEXT, report_type TEXT, period TEXT)")
    conn.execute("INSERT INTO reports VALUES ('五粮液','年报','2024')")
    conn.commit()
    conn.close()
    assert has_report("五粮液", "年报", "2024", db) is True
    assert has_report("五粮液", "年报", "2025", db) is False
    assert has_report("五粮液", "年报", None, db) is False


def test_download_path_always_produces_a_report(monkeypatch, tmp_path):
    """「下载并分析」应当**直接出 Word**，不用再补一句"出份报告"。

    既然已经付了下载 + 解析的代价，报告是自然的交付物。
    """
    from agent import _document_suffix
    monkeypatch.setattr("agent.build_report",
                        lambda *a, **k: {"ok": True, "path": "/tmp/报告.docx"})
    out = _document_suffix("帮我下载并分析五粮液2025年报", "五粮液", "年报", "2025",
                           str(tmp_path / "x.db"), {"ok": True}, {}, force=True)
    assert "报告做好啦" in out


def test_plain_analysis_does_not_force_a_report(monkeypatch, tmp_path):
    from agent import _document_suffix
    monkeypatch.setattr("agent.build_report",
                        lambda *a, **k: {"ok": True, "path": "/tmp/报告.docx"})
    assert _document_suffix("分析一下五粮液2025年报", "五粮液", "年报", "2025",
                            str(tmp_path / "x.db"), {"ok": True}, {}) == ""


def test_company_extracted_when_year_comes_first():
    """`帮我分析一下 2025 年上纬新材的年报` —— 年份在前也要能认出公司。

    实测这句在巨潮**有**这只股票（688585），却因为截不出公司名掉到检索，
    回了一句"未收录该公司"。问题不在数据源，在解析顺序。
    """
    from agent import _candidate_company
    assert _candidate_company("帮我分析一下 2025 年上纬 新材的年报") == "上纬新材"
    assert _candidate_company("分析一下2025年的五粮液年报") == "五粮液"
    assert _candidate_company("帮我分析上纬新材2025年报") == "上纬新材"


def test_company_extraction_rejects_generic_fragments():
    from agent import _candidate_company
    assert _candidate_company("2025年年报分析") is None
    assert _candidate_company("帮我分析一下年报") is None


def test_ingest_announces_that_report_is_missing(tmp_path, capsys):
    """库里没有时要**主动说明并自动下载**，不能让用户再说一次"下载"。"""
    import sqlite3
    from storage import init_db
    db = tmp_path / "x.db"
    init_db(str(db))

    res = _try_ingest("帮我分析澜起科技2025年报", db,
                      resolve_fn=lambda n: ("688008", "o", "澜起科技"),
                      fetch_and_parse=lambda: {"company": "澜起科技",
                                               "report_type": "年报",
                                               "period": "2025",
                                               "pdf": "x.PDF", "indexed": 0})
    out = capsys.readouterr().out
    assert "库里没有" in out and "自动" in out
    assert res is not None


def test_ambiguous_short_name_prefers_the_one_in_the_question(tmp_path, monkeypatch, capsys):
    """简称有歧义时，优先选问句里真正出现过的那个。

    巨潮搜「海螺」先返回 000619 海螺新材，但用户说的是「海螺水泥」→ 必须挑 600585。
    """
    import downloader
    from storage import init_db

    db = tmp_path / "x.db"
    init_db(str(db))
    monkeypatch.setattr(downloader, "search_orgs", lambda k: [
        {"code": "000619", "orgId": "o1", "name": "海螺新材"},
        {"code": "600585", "orgId": "o2", "name": "海螺水泥"},
    ])
    _try_ingest("帮我分析海螺水泥2024年报", db,
                resolve_fn=lambda n: ("000619", "o1", "海螺新材"),
                fetch_and_parse=lambda: {"company": "海螺水泥",
                                         "report_type": "年报",
                                         "period": "2024",
                                         "pdf": "x", "indexed": 0})
    # 进度行里应当出现**问句里的公司**，而不是接口的首选（海螺新材）
    out = capsys.readouterr().out
    assert "海螺水泥" in out
    assert "📭 库里没有 海螺新材" not in out


def test_ambiguous_short_name_warns_when_it_has_to_guess(tmp_path, monkeypatch, capsys):
    """实在挑不出来时要**告警**，不能默默用第一个候选下载。"""
    import downloader
    from storage import init_db

    db = tmp_path / "x.db"
    init_db(str(db))
    monkeypatch.setattr(downloader, "search_orgs", lambda k: [
        {"code": "000619", "orgId": "o1", "name": "海螺新材"},
        {"code": "600585", "orgId": "o2", "name": "海螺水泥"},
    ])
    _try_ingest("帮我分析海螺2024年报", db,
                resolve_fn=lambda n: ("000619", "o1", "海螺新材"),
                fetch_and_parse=lambda: {"company": "海螺新材",
                                         "report_type": "年报", "period": "2024",
                                         "pdf": "x", "indexed": 0})
    out = capsys.readouterr().out
    assert "对应多家公司" in out and "海螺水泥" in out


def test_missing_annual_report_explains_and_suggests_semi(tmp_path, monkeypatch):
    """问还没披露的年报时，要说清"还没发布"，并提示可以先看半年报。"""
    from storage import init_db
    import downloader

    db = tmp_path / "x.db"
    init_db(str(db))
    monkeypatch.setattr(downloader, "list_announcements",
                        lambda *a, **k: [{"title": "2026年半年度报告"}])

    def _fail():
        raise LookupError("未找到 上纬新材 年报 2026")

    res = _try_ingest("帮我分析上纬新材2026年报", db,
                      resolve_fn=lambda n: ("688585", "o", "上纬新材"),
                      fetch_and_parse=_fail)
    assert res is not None
    assert "还没有披露" in res["answer"]
    assert "半年报" in res["answer"]


def test_full_legal_name_is_searchable():
    """用户说全称时要去掉"股份有限公司"再查 —— 巨潮只认简称。"""
    from agent import _candidate_company, strip_legal_suffix

    assert strip_legal_suffix("中国黄金股份有限公司") == "中国黄金"
    assert _candidate_company("帮我分析中国黄金股份有限公司 2025 年年报") == "中国黄金"
    assert _candidate_company("帮我分析一下 中国黄金 2025 年年报") == "中国黄金"


def test_report_degrades_when_cash_flow_missing(tmp_path):
    """经营现金流没抽到时，不能写"同比增长 0.00%""现金含量弱化"这种假结论。

    中国黄金 2025 只抽到 3 个现金流科目，就是这种情况。
    """
    from analysis import build_analysis
    from report_docx import save
    from docx import Document

    try:
        a = build_analysis("中国黄金", "年报", "2025", str(
            Path(__file__).resolve().parent.parent / "data" / "structured.db"))
    except Exception:                       # noqa: BLE001
        pytest.skip("样本库不可用")
    if not a.get("ok"):
        pytest.skip("中国黄金未入库")

    text = "\n".join(p.text for p in Document(save(a, None, tmp_path / "x.docx")).paragraphs)
    assert "同比增长 0.00%" not in text
    assert "现金含量" in text                 # 要么给出值，要么明确说没抽到


def test_free_word_order_goes_through_semantic_parse(tmp_path, monkeypatch):
    """乱序问法走语义解析：模型只负责理解意图，答案前缀要说明"我理解为…"。"""
    import agent

    db = tmp_path / "x.db"
    from storage import init_db
    init_db(str(db))

    calls = {}

    def fake_parse(question, history=None):
        calls["q"] = question
        return {"company": "中国黄金", "report_type": "年报",
                "period": "2025", "confidence": 0.95}

    monkeypatch.setattr("intent.parse", fake_parse)
    # 标准问法重跑时走分析路径（这里 stub 掉，只验证路由与前缀）
    # 原句走正则会落到检索（rag），标准问法才走分析 —— 模拟真实行为
    def fake_direct(q, d, top_k=5, **kw):
        if q == "2025年报 中国黄金":
            return {"route": "rag", "answer": "没找到", "metrics": [],
                    "citations": [], "companies": []}
        return {"route": "analysis", "answer": "分析结果", "metrics": [],
                "citations": [], "companies": []}

    monkeypatch.setattr(agent, "_answer_direct", fake_direct)
    # 用一句正则肯定解析不了的（年份在前的倒装），走"先检索失败 → 再语义解析"的兜底
    res = agent.answer("2025年报 中国黄金", db)
    assert calls["q"] == "2025年报 中国黄金"
    assert res["route"] == "analysis"
    assert "我理解为" in res["answer"] and "中国黄金" in res["answer"]


def test_low_confidence_asks_before_running(tmp_path, monkeypatch):
    """置信度低时不执行，先反问确认。"""
    import agent
    from storage import init_db

    db = tmp_path / "x.db"
    init_db(str(db))
    monkeypatch.setattr("intent.parse", lambda q, history=None: {
        "company": "中国黄金", "report_type": "年报",
        "period": "2025", "confidence": 0.3})
    res = agent.answer("帮我看看那家公司的年报", db)
    assert res["route"] == "confirm"
    assert res["pending"] == "分析中国黄金2025年报"
    assert "你是想问" in res["answer"]


def test_chat_confirms_then_runs(monkeypatch):
    """对话里：先说一句含糊的，再回「是」，才真正执行。"""
    import chat

    out = []
    it = iter(["帮我看看那家公司的年报", "是", "/exit"])

    def fake_input(_p=""):
        try:
            return next(it)
        except StopIteration:
            raise EOFError

    calls = []

    def fake_answer(q, db, **kw):
        calls.append(q)
        if len(calls) == 1:
            return {"route": "confirm", "answer": "你是想问 X 吗？",
                    "pending": "分析中国黄金2025年报"}
        return {"route": "analysis", "answer": "分析结果"}

    monkeypatch.setattr("agent.answer", fake_answer)
    chat.run_repl(":memory:", input_fn=fake_input, output_fn=out.append)
    assert calls == ["帮我看看那家公司的年报", "分析中国黄金2025年报"]
    assert any("你是想问" in o for o in out)
    assert any("分析结果" in o for o in out)


def test_hk_stock_is_rejected_with_clear_reason(tmp_path):
    """港股（周大福 00659）要明说"不支持"，不能报成"年报未披露"。"""
    from storage import init_db
    db = tmp_path / "x.db"
    init_db(str(db))
    res = _try_ingest("帮我看看周大福2026年报", db,
                      resolve_fn=lambda n: ("00659", "gshk0000659", "周大福创建"),
                      fetch_and_parse=lambda: {"company": "周大福创建"})
    assert res is not None
    assert "港股" in res["answer"] and "A 股" in res["answer"]


def test_history_is_forwarded_to_semantic_parse(tmp_path, monkeypatch):
    """有上文时，语义解析要能拿到历史 —— "那看看它的半年报"全靠这个才懂。"""
    import agent
    from storage import init_db

    db = tmp_path / "x.db"
    init_db(str(db))
    seen = {}

    def fake_parse(question, history=None):
        seen["history"] = history
        return {"company": "中国黄金", "report_type": "半年报",
                "period": "2024", "confidence": 0.9}

    monkeypatch.setattr("intent.parse", fake_parse)
    monkeypatch.setattr(agent, "_answer_direct",
                        lambda q, d, top_k=5, **kw: {"route": "analysis", "answer": "结果",
                                                     "metrics": [], "citations": [],
                                                     "companies": []})
    hist = [{"text": "分析一下中国黄金 2024 年年报",
             "entity": {"company": "中国黄金", "report_type": "年报",
                        "period": "2024"}}]
    res = agent.answer("那看看它的半年报", db, history=hist)
    assert seen["history"] == hist
    assert "中国黄金 2024 半年报" in res["answer"]


def test_chat_keeps_a_rolling_history(monkeypatch):
    """对话里要维护最近几轮（原话 + 实体），并传给 answer。"""
    import chat

    out, seen = [], []
    it = iter(["分析中国黄金2024年报", "那看看它的半年报", "/exit"])

    def fake_input(_p=""):
        try:
            return next(it)
        except StopIteration:
            raise EOFError

    def fake_answer(q, db, **kw):
        seen.append(list(kw.get("history") or []))   # 存快照，别存引用
        return {"route": "analysis", "answer": "ok",
                "entity": {"company": "中国黄金", "report_type": "年报",
                           "period": "2024"}}

    monkeypatch.setattr("agent.answer", fake_answer)
    chat.run_repl(":memory:", input_fn=fake_input, output_fn=out.append)
    # 第一轮没有历史；第二轮应当带上第一轮的实体
    assert seen[0] == []
    assert seen[1] and seen[1][0]["entity"]["company"] == "中国黄金"


def test_stock_code_and_common_wording():
    """用户常直接报代码、或用"财报"这个词。

    实测试用者输入「分析SZ300308 对应的2025 年财报」「分析中际旭创2025 年财报」，
    前者解析不出公司、后者因为"财报"不在报表词里而没触发下载。
    """
    from agent import _candidate_company

    assert _candidate_company("分析中际旭创2025 年财报") == "中际旭创"
    assert _candidate_company("分析SZ300308 对应的2025 年财报") == "300308"
    assert _candidate_company("分析中际旭创，对应的股票代码为SZ300308，分析对应的2025 年财报") == "中际旭创"


def test_report_words_cover_common_aliases():
    from agent import _REPORT_WORDS
    for w in ("年报", "财报", "半年报", "季报", "年度报告"):
        assert w in _REPORT_WORDS, w


def test_statement_style_questions_trigger_analysis():
    """陈述式问法（没有"分析/看看"动词）也要按分析处理。

    实测试用者输入：
        中国黄金2025年报怎么样 / 澜起科技2025年半年报 / 上纬新材2025年度报告
    这些都没有动词，旧逻辑全掉到检索，答"未在已索引的内容中找到资料"。
    """
    import agent
    from storage import init_db

    for q in ("中国黄金2025年报怎么样", "澜起科技2025年半年报",
              "上纬新材2025年度报告", "2025年报 中国黄金"):
        # 只验证"能被识别为公司+期间"，不真的跑分析
        assert agent._candidate_company(q), q
        assert agent._PERIOD_RE.search(q), q


def test_fuzzy_company_match_for_typos(tmp_path):
    """名字记错时要能猜出相近的公司，并且**反问确认**。

    实测用户把"中际旭创"说成"中旭创科"，只得到"简称不准确"，很挫败。
    """
    import sqlite3
    from agent import _fuzzy_company
    from storage import init_db

    db = tmp_path / "x.db"
    init_db(str(db))
    conn = sqlite3.connect(db)
    conn.execute("INSERT INTO reports (company, report_type, period) VALUES ('中际旭创','年报','2025')")
    conn.execute("INSERT INTO reports (company, report_type, period) VALUES ('中科曙光','年报','2025')")
    conn.commit()
    conn.close()

    got = _fuzzy_company("中旭创科", db)
    assert got and got[0] == "中际旭创"

    res = _try_ingest("分析中旭创科2025年报", db,
                      resolve_fn=lambda n: (_ for _ in ()).throw(LookupError("没有")))
    assert res is not None and res["route"] == "confirm"
    assert "中际旭创" in res["answer"] and res["pending"] == "分析中际旭创2025年报"


def test_brand_name_resolves_via_prefix_fallback(tmp_path):
    """品牌名不是工商全称时，逐字截短再查：绝味鸭脖 → 绝味 → 绝味食品。

    实测用户输入「分析绝味鸭脖 2025 年年报」，巨潮按精确名查不到，
    直接回一句"简称不准确"，体验很差 —— 而按「绝味」就能定位到绝味食品(603517)。
    """
    import agent
    from storage import init_db

    db = tmp_path / "x.db"
    init_db(str(db))

    tried = []

    def fake_resolve(name):
        tried.append(name)
        if name == "绝味":
            return ("603517", "org1", "绝味食品")
        raise LookupError("查不到")

    def fake_fetch(*a, **k):
        raise RuntimeError("到此为止（不发网络请求）")

    res = agent._try_ingest("分析绝味鸭脖2025年报", db, resolve_fn=fake_resolve,
                            fetch_and_parse=fake_fetch, announce=False)
    assert "绝味" in tried                      # 确实做了截短重试
    assert res is not None and res["route"] == "ingest"


def test_prefix_fallback_rejects_unrelated_company(tmp_path):
    """截短查到的公司必须以该前缀开头，否则不能硬配。"""
    import agent
    from storage import init_db

    db = tmp_path / "x.db"
    init_db(str(db))

    def fake_resolve(name):
        # 任何输入都返回一家不相干的公司
        return ("000001", "org2", "平安银行")

    res = agent._try_ingest("分析中旭创科2025年报", db, resolve_fn=fake_resolve,
                            fetch_and_parse=lambda *a, **k: (_ for _ in ()).throw(RuntimeError("不该调用")),
                            announce=False)
    # 不能把它当成"平安银行"去下载
    assert res is None or res["route"] != "ingest"
