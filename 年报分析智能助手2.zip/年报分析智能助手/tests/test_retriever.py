"""检索层的过滤条件构造（纯函数，离线可测，不加载模型、不连 ChromaDB）。

这个函数存在的理由是**一个真实崩溃**：把 `{"company":.., "year":..}` 直接交给
ChromaDB 的 `query(where=...)` 会抛
`ValueError: Expected where to have exactly one operator`。
多条件必须包成 `$and`。RAG 链路端到端实测踩到过。
"""
from retriever import build_where_filter


def test_where_filter_is_none_when_no_conditions():
    assert build_where_filter() is None


def test_where_filter_passes_single_condition_through():
    assert build_where_filter(company="格力电器") == {"company": "格力电器"}
    assert build_where_filter(year="2025") == {"year": "2025"}


def test_where_filter_combines_two_conditions_with_and():
    """双条件必须 `$and` —— 裸放两个键会被 ChromaDB 拒收。"""
    assert build_where_filter("格力电器", "2025") == {
        "$and": [{"company": "格力电器"}, {"year": "2025"}]}
