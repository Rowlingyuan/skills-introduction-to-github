"""RAG 分支的组装逻辑离线可测：只把**网络边界**（call_reasoner）stub 掉，
被测的提示词构造、引用整理、空检索处理都是真实代码。"""
from agent import build_rag_prompt, answer_rag

HITS = [{"page": 42, "text": "公司主营业务为空调…", "relevance": 0.81,
         "company": "格力电器", "year": "2025"}]


def test_build_rag_prompt_includes_page_citations():
    msgs = build_rag_prompt("主营业务是什么", HITS)
    body = msgs[-1]["content"]
    assert "第42页" in body or "第 42 页" in body
    assert "空调" in body


def test_build_rag_prompt_forbids_inventing_when_context_missing():
    msgs = build_rag_prompt("主营业务是什么", [])
    body = msgs[-1]["content"]
    assert "未找到" in body or "不知道" in body


def test_build_rag_prompt_declares_covered_companies():
    """提示词必须**声明资料覆盖了哪些公司**，并要求对其它公司拒答。

    实测踩到过：问「比亚迪2025年营业收入」，检索没有公司护栏，捞回的全是格力的
    段落，引用页码也全是格力的 —— 只靠 LLM 自觉才没把格力的数据答成比亚迪的。
    把覆盖范围写进提示词，是生成层唯一能做的确定性护栏。
    """
    msgs = build_rag_prompt("主营业务是什么", HITS)
    system = msgs[0]["content"]
    assert "格力电器" in system, "未声明资料覆盖的公司"
    assert "未收录" in system, "未要求对范围外的公司拒答"


def test_answer_rag_reports_covered_companies(monkeypatch):
    """结果要暴露资料覆盖的公司，调用方/界面才能显示"本次只覆盖了谁"（含空检索）。"""
    import agent
    monkeypatch.setattr(agent, "_search", lambda *a, **k: HITS, raising=True)
    monkeypatch.setattr(agent, "_call_reasoner",
                        lambda msgs, **k: "公司主营空调业务。", raising=True)
    assert agent.answer_rag("主营业务是什么", "unused.db")["companies"] == ["格力电器"]

    monkeypatch.setattr(agent, "_search", lambda *a, **k: [], raising=True)
    assert agent.answer_rag("主营业务是什么", "unused.db")["companies"] == []


def test_answer_rag_empty_retrieval_never_calls_llm(monkeypatch):
    """检索为空时必须直接明说，绝不能让 LLM 凭空作答。"""
    import agent
    monkeypatch.setattr(agent, "_search",
                        lambda *a, **k: [], raising=True)
    called = []
    monkeypatch.setattr(agent, "_call_reasoner",
                        lambda *a, **k: called.append(1) or "编造的答案")
    res = agent.answer_rag("主营业务是什么", "unused.db")
    assert called == [], "检索为空时不应该调用 LLM"
    assert res["citations"] == []
    assert "未" in res["answer"]


def test_answer_rag_returns_citations(monkeypatch):
    import agent
    monkeypatch.setattr(agent, "_search", lambda *a, **k: HITS, raising=True)
    monkeypatch.setattr(agent, "_call_reasoner",
                        lambda msgs, **k: "公司主营空调业务。", raising=True)
    res = agent.answer_rag("主营业务是什么", "unused.db")
    assert res["route"] == "rag"
    assert res["answer"] == "公司主营空调业务。"
    assert res["citations"][0]["page"] == 42
