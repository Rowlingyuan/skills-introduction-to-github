import pytest
from pathlib import Path
from conftest import require_pdf
from models import ReportKey
from parser import parse


def test_parse_gree_annual_without_llm():
    """核心回归：格力年报必须能被解析出利润表核心指标。"""
    path = require_pdf("gree_annual")
    key = ReportKey("格力电器", "000651", "年报", "2025")
    res = parse(path, key, verify=False)
    assert "利润表" in res.sections
    assert res.sections["利润表"] == 88
    by_name = {}
    for m in res.metrics:
        by_name.setdefault(m.name, {})[m.period] = m.value
    assert by_name["营业收入"]["2025"] == 170447058533.57
    assert by_name["营业收入"]["2024"] == 189163654064.64
    assert by_name["净利润"]["2025"] == 28862746016.16
    assert by_name["营业总成本"]["2025"] == 137548893694.33


def test_parse_gree_annual_extracts_all_three_statements():
    """spec §4 目标2 要求三大报表，不只是利润表。

    注意：资产负债表与现金流量表在**一期没有人工核对过的真值**，
    只做"能定位、能抽出指标"的结构验证（见 ledger Ruling D3）。
    """
    path = require_pdf("gree_annual")
    key = ReportKey("格力电器", "000651", "年报", "2025")
    res = parse(path, key, verify=False)
    assert set(res.sections) == {"利润表", "资产负债表", "现金流量表"}
    assert {m.statement for m in res.metrics} == {"利润表", "资产负债表", "现金流量表"}


def test_parse_moutai_annual_without_llm():
    path = require_pdf("moutai_annual")
    key = ReportKey("贵州茅台", "600519", "年报", "2025")
    res = parse(path, key, verify=False)
    by_name = {}
    for m in res.metrics:
        by_name.setdefault(m.name, {})[m.period] = m.value
    assert by_name["营业收入"]["2025"] == 168838102514.79
    assert by_name["营业收入"]["2024"] == 170899152276.34


def test_parse_survives_nine_page_quarterly_report():
    """季报只有9页，任何绝对页码假设都会在这里暴露。"""
    path = require_pdf("gree_q1")
    key = ReportKey("格力电器", "000651", "一季报", "2025")
    res = parse(path, key, verify=False)
    assert res.sections.get("利润表") is not None
    assert len(res.metrics) > 0


def test_parse_merges_cross_page_statement_continuation():
    """季报的利润表跨 7→8 页：第 7 页是主体，第 8 页顶部是"基本每股收益"等尾部。

    只取定位页会静默丢掉这些指标——不是报错，是"看起来成功但少了几条"，
    这正是最难发现的一类缺陷。
    """
    path = require_pdf("gree_q1")
    key = ReportKey("格力电器", "000651", "一季报", "2025")
    res = parse(path, key, verify=False)
    names = {m.name for m in res.metrics if m.statement == "利润表"}
    assert "基本每股收益" in names, f"未捕获跨页续表的指标，实际: {sorted(names)}"


def test_parse_quarterly_income_statement_keeps_headline_rows():
    """季报利润表跨 p6→p8，定位页 p7 只是中间页。

    只读定位页与其次页会丢掉 p6 上的顶行，而营业收入是分析里最重要的数。
    """
    path = require_pdf("gree_q1")
    key = ReportKey("格力电器", "000651", "一季报", "2025")
    res = parse(path, key, verify=False)
    got = {}
    for m in res.metrics:
        if m.statement == "利润表":
            got.setdefault(m.name, {})[m.period] = m.value
    assert "营业收入" in got, f"利润表顶行丢失，实际指标: {sorted(got)}"
    assert got["营业收入"]["2025"] == 41506860074.79
    assert got["营业总成本"]["2025"] == 34873712063.16
    assert got["净利润"]["2025"] == 5941618723.39


def test_parse_moutai_balance_sheet_values_are_not_fabricated():
    """茅台 p57 资产负债表无表头行、列 1 是附注号，走 find_year_columns 的兜底路径。

    修前该页被整体左移一列，"应收账款 2025" 读的是附注号 `5` —— 一个凭空出现的
    数字，却带着 confidence="high"。
    """
    path = require_pdf("moutai_annual")
    key = ReportKey("贵州茅台", "600519", "年报", "2025")
    res = parse(path, key, verify=False)
    assert res.sections["资产负债表"] == 57
    got = {(m.name, m.period): m for m in res.metrics}
    assert got[("应收账款", "2025")].value == 2609048.49
    assert got[("应收账款", "2025")].confidence == "high"
    assert got[("资产总计", "2025")].value == 303834844021.44
    assert got[("资产总计", "2024")].value == 298944579918.70


def test_parse_moutai_cash_flow_uses_consolidated_not_parent_company():
    """茅台现金流量表必须抽**合并**口径，不能被母公司表顶掉。

    `销售商品收到的现金` 是合并表(p64)与母公司表(p66)共用的指标名，两张表都在抽取
    区间内，靠 `extract_metrics` 的"先出现者优先"取胜。改动前区间是 (65, 66)，
    抽到的是母公司数 110,369,954,530.92 却标成合并口径。

    锁定两点：值必须是合并表的 183,990,403,487.80，且必须来自 p64。
    source_page 是区分合并表/母公司表的唯一凭据——只断值的话，
    母公司表若恰好也出现同一个数就会漏网。
    """
    path = require_pdf("moutai_annual")
    key = ReportKey("贵州茅台", "600519", "年报", "2025")
    res = parse(path, key, verify=False)
    got = {(m.name, m.period): m for m in res.metrics}
    m = got[("销售商品收到的现金", "2025")]
    assert m.value == 183990403487.80
    assert m.source_page == 64


def test_parse_writes_to_db(tmp_path):
    path = require_pdf("gree_annual")
    key = ReportKey("格力电器", "000651", "年报", "2025")
    db = tmp_path / "t.db"
    parse(path, key, verify=False, db_path=db)
    from storage import load_metrics
    assert len(load_metrics("格力电器", "年报", "2025", db)) > 0


def test_quarterly_period_labels_are_quarter_aware():
    """季报的三个月的数不能与全年混在同一个 key 上（Ruling 15）。

    `ReportKey.period` 必须带季度（`"2025Q1"`，见 `models.py:11`）：季度标签由 `period`
    携带。这是与 Task 5 一致的数据流 —— `main._report_key` 对季报产出 `"2025Q1"`/`"2025Q3"`
    （`_PERIOD_SUFFIX`），并由 `test_cli_quarter_period_carries_quarter` 钉住。
    若这里传裸 `"2025"`，季度标签就永不触发 —— 正是 D2 记的那个静默失效形态。
    """
    path = require_pdf("gree_q1")
    key = ReportKey("格力电器", "000651", "一季报", "2025Q1")
    res = parse(path, key, verify=False)
    periods = {}
    for m in res.metrics:
        periods.setdefault(m.statement, set()).add(m.period)
    # 利润表/现金流量表：上年同期是 2024Q1，必须与全年 2024 区分
    assert periods["利润表"] == {"2025Q1", "2024Q1"}
    assert periods["现金流量表"] == {"2025Q1", "2024Q1"}
    # 资产负债表：上年年末就是 2024-12-31，标 2024 以便与年报 join
    assert periods["资产负债表"] == {"2025Q1", "2024"}


def test_quarterly_balance_sheet_satisfies_identity_exactly():
    """季报资产负债表恒等式**精确成立**（合计口径，不是归母口径）。

    本用例原先只断言"差额在少数股东权益以内"，因为 `match_metric_detail`
    取别名表第一个命中，`归属于母公司所有者权益合计` 被 `所有者权益合计`
    的子串规则抢占 —— 抽到的是归母那一行，差额恰为少数股东权益 4,106,386,554.07。
    该别名缺陷已修（改为最长别名优先），故这里收紧成**精确相等**：
    合计口径下 `资产总计 = 负债合计 + 所有者权益合计` 本就应当分毫不差
    （真值：247,276,037,775.29 + 147,292,760,314.46 = 394,568,798,089.75）。
    """
    path = require_pdf("gree_q1")
    key = ReportKey("格力电器", "000651", "一季报", "2025Q1")
    res = parse(path, key, verify=False)
    d = {(m.name, m.period): m.value for m in res.metrics
         if m.statement == "资产负债表"}
    for year in ("2025Q1", "2024"):
        assert d[("资产总计", year)] == (
            d[("负债合计", year)] + d[("所有者权益合计", year)]
        ), f"{year} 恒等式不成立（合计口径应精确相等）"
    # 归属母公司的净资产是**另一行**，必须与合计分开抽取（不再互相顶替）
    assert d[("所有者权益合计", "2025Q1")] == 147292760314.46
    assert d[("归母净资产", "2025Q1")] == 143186373760.39
    # 差额 = 少数股东权益（1e11 量级的浮点减法，故用 approx 而非精确相等）
    minority = d[("所有者权益合计", "2025Q1")] - d[("归母净资产", "2025Q1")]
    assert minority == pytest.approx(4106386554.07, abs=1.0)


def test_annual_period_labels_unchanged():
    """年报标签必须原样不动——这是回归基线。"""
    path = require_pdf("gree_annual")
    key = ReportKey("格力电器", "000651", "年报", "2025")
    res = parse(path, key, verify=False)
    got = {(m.name, m.period): m.value for m in res.metrics
           if m.statement == "利润表"}
    assert got[("营业收入", "2025")] == 170447058533.57
    assert got[("营业收入", "2024")] == 189163654064.64


def test_unit_scale_normalises_to_yuan():
    """`unit_scale` 必须真的作用到抽出的数字上（千元报表 → 归一化到元）。

    用格力一季报（单位是元）当样本，传 1000 验证缩放确实生效：真值 41,506,860,074.79
    取自黄金集（人工逐字核对过 p6 原文）。
    **为什么必须显式传而非自动探测**：单位声明未必在报表页上 —— 实测比亚迪写在附注
    （"财务报表及附注的单位为：千元"），报表页只字未提；宁德时代/顺丰同样是千元。
    猜错会带来 1000 倍误差，且会计恒等式**查不出来**（两边同倍缩放）。
    """
    path = require_pdf("gree_q1")
    key = ReportKey("格力电器", "000651", "一季报", "2025Q1")
    res = parse(path, key, verify=False, unit_scale=1000.0)
    d = {(m.name, m.period): m.value for m in res.metrics}
    assert d[("营业收入", "2025Q1")] == 41506860074.79 * 1000
    assert d[("净利润", "2025Q1")] == 5941618723.39 * 1000


@pytest.mark.slow
def test_parse_gree_annual_with_llm_verification():
    path = require_pdf("gree_annual")
    key = ReportKey("格力电器", "000651", "年报", "2025")
    res = parse(path, key, verify=True)
    assert any(m.confidence == "conflict" for m in res.metrics) is False
