import pytest
from models import ReportKey, MetricValue, ParseResult
from storage import init_db, save_result, load_metrics, load_conflicts


@pytest.fixture
def db(tmp_path):
    p = tmp_path / "t.db"
    init_db(p)
    return p


def _result():
    key = ReportKey("格力电器", "000651", "年报", "2025")
    metrics = [
        MetricValue("营业收入", "2025", 170447058533.57, 88, "high"),
        MetricValue("净利润", "2025", 28862746016.16, 88, "conflict"),
    ]
    return ParseResult(key=key, file_path="data/x.PDF",
                       sections={"利润表": 88}, metrics=metrics)


def test_save_then_load_roundtrip(db):
    save_result(_result(), db)
    got = load_metrics("格力电器", "年报", "2025", db)
    assert len(got) == 2
    names = {m.name for m in got}
    assert names == {"营业收入", "净利润"}


def test_save_is_idempotent(db):
    save_result(_result(), db)
    save_result(_result(), db)
    assert len(load_metrics("格力电器", "年报", "2025", db)) == 2


def test_load_conflicts_returns_only_conflicts(db):
    save_result(_result(), db)
    conflicts = load_conflicts(db)
    assert len(conflicts) == 1
    assert conflicts[0]["metric_name"] == "净利润"


def test_load_metrics_preserves_source_page(db):
    save_result(_result(), db)
    got = load_metrics("格力电器", "年报", "2025", db)
    assert all(m.source_page == 88 for m in got)


def test_load_metrics_filters_by_statement(db):
    save_result(_result(), db)
    assert len(load_metrics("格力电器", "年报", "2025", db, statement="利润表")) == 2
    assert len(load_metrics("格力电器", "年报", "2025", db, statement="资产负债表")) == 0
