"""对**本地点**的结构化库做会计恒等式与覆盖度自检（数据质量闸门）。

为什么需要：`tests/test_golden.py` 只盯**黄金集**（4 个用例、有人工核对真值的利润表）；
批量回灌进来的公司没有任何东西看着它们。而回灌实测暴露了两类问题，都必须**显式**，
不能靠"没报错"蒙混：
  1. **错值** —— 恒等式不成立（抽到了数字但不对）；
  2. **缺值** —— 核心三项有缺，恒等式压根核不了（**不是通过，是没测**）。
第 2 类尤其危险：它长得像"没问题"，实则是抽取覆盖不足。故本用例把两类都钉住，
只允许**已登记**的缺陷存在；新增一份坏报表 / 新增一份缺值报表 → 立刻失败点名。

库不存在（新克隆、CI）时跳过 —— `data/` 是 gitignore 的本地产物。
"""
import sqlite3
from pathlib import Path

import pytest

from run_golden import check_identities          # tests/ 已在 sys.path 上
from storage import load_metrics

DB = Path(__file__).resolve().parent.parent / "data" / "structured.db"
CORE = "资产总计 = 负债合计 + 所有者权益合计"

#: 恒等式**不成立**（算得出、但对不上）。根因都是 Ruling 7 那一族的**单元格切分**：
#: pdfplumber 的文本策略会把单元格切开 —— 标签丢首字（顺丰 p87 的
#: `归属于母公司股东权益合计` → `属于母公司股东权益合计`，于是 `股东权益合计`
#: 这个别名命中它，归母值被当成合计值），或**数字丢首位**（茅台 2026 半年报的
#: `所有者权益合计` 抽成 62,096,352,174，真值 262,096,352,174，差额恰好 2000 亿）。
#:
#: 【2026-10 更新】`table_reader.clipped_left_edges` 修好了"整页标签被切首字"那一支
#: （格力 2025 年报 p86–87 的合计行顶格在 x0=48、被缩进行挤掉边界），
#: `config.BALANCE_ALIASES` 补上"非流动"两族后，违规从 **7 份降到 3 份**。
#: 剩下这 3 份是**另外两个**根因，尚未修：
#:   - 恒瑞 / 海康：`_page_span` 把**母公司报表**页一起读进来，合并与母公司混用
#:     （海康 2026 半年报：资产总计 712.64 亿 vs 合并口径 1376.90 亿）
#:   - 茅台：数字被切成两格（`'2'` + `'62,096,352,174.36'`），首位丢失
KNOWN_IDENTITY_FAILURES = {
    ("恒瑞医药", "半年报", "2026"),
    ("海康威视", "半年报", "2026"),
    ("贵州茅台", "半年报", "2026"),
    # 保险业样本（泛化探测时入库）：所有者权益合计抽成 14 亿，真值约 1.4 万亿，
    # 比例尺差了 1000 倍。保险报表科目结构（保险合同负债/独立账户资产）与工商企业
    # 差异极大，当前别名表覆盖不到 —— 报告里会由 `quality_flags` 显式告警。
    ("中国平安", "年报", "2025"),
    # 银行（泛化验证时入库）：资产负债表科目体系与工商企业完全不同，
    # 核心三项抽不全属已知结构差异，报告首页会带可信度告警。
    ("交通银行", "年报", "2025"),
}

#: 核心三项（资产总计 / 负债合计 / 所有者权益合计）**缺值**，恒等式无法核实。
#: 2026-10 修完边界与"非流动"别名后**已清零** —— 18 份报告的核心三项全部抽到。
#: 保留这个集合是为了让闸门继续盯"新的缺值"，别让它悄悄回来。
KNOWN_MISSING_CORE = {
    # 券商样本（泛化探测时入库）：资产/负债总计的标签写法与工商企业不同，
    # 核心三项没抽到。同属"金融业科目结构差异"，报告里有 quality_flags 告警。
    ("中信证券", "年报", "2025"),
}


def _reports():
    conn = sqlite3.connect(str(DB))
    try:
        return conn.execute(
            "SELECT company, report_type, period FROM reports").fetchall()
    finally:
        conn.close()


def _core_status(company, report_type, period) -> set:
    """返回该报告各年份上 CORE 恒等式的状态集合（fail / unverifiable / pass）。"""
    ms = load_metrics(company, report_type, period, DB, statement="资产负债表")
    got = {}
    for m in ms:
        got.setdefault(m.name, {})[m.period] = m.value
    years = {y for ys in got.values() for y in ys}
    out = set()
    for y in sorted(years):
        for c in check_identities(got, y):
            if c["check"] == CORE:
                out.add(c["status"])
    return out


def _scan():
    failures, missing = set(), set()
    for company, report_type, period in _reports():
        st = _core_status(company, report_type, period)
        if "fail" in st:
            failures.add((company, report_type, period))
        elif "unverifiable" in st:
            missing.add((company, report_type, period))
    return failures, missing


def test_local_db_core_identity_scoped_to_known_state():
    if not DB.exists():
        pytest.skip(f"本地点没有结构化库: {DB}")
    reports = _reports()
    assert len(reports) >= 2, f"库里只有 {len(reports)} 份报表，自检会空转"

    failures, missing = _scan()

    unexpected_fail = sorted(failures - KNOWN_IDENTITY_FAILURES)
    assert unexpected_fail == [], (
        "以下报表的核心恒等式不成立，且未登记 —— 请核查抽取结果或补登 "
        f"KNOWN_IDENTITY_FAILURES：{unexpected_fail}")

    unexpected_missing = sorted(missing - KNOWN_MISSING_CORE)
    assert unexpected_missing == [], (
        "以下报表的核心三项出现**新的缺失**，恒等式无法核实 —— "
        f"请核查抽取覆盖或补登 KNOWN_MISSING_CORE：{unexpected_missing}")


def test_local_db_core_identity_still_verified_somewhere():
    """反向保证：闸门不能因为"所有报表都缺值"而空转成永远通过。"""
    if not DB.exists():
        pytest.skip(f"本地点没有结构化库: {DB}")
    failures, missing = _scan()
    verified = len(_reports()) - len(failures) - len(missing)
    assert verified >= 3, (
        f"只有 {verified} 份报表的核心恒等式真正得到核实 —— "
        "覆盖度塌到无法说明问题，闸门形同空转")
