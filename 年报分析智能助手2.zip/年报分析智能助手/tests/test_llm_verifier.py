import pytest
from models import MetricValue
from llm_verifier import build_prompt, parse_response, apply_outcome, verify, MAX_CHARS


def _m(name, period, value, statement="利润表"):
    return MetricValue(name, period, value, 88, "high", statement)


def test_build_prompt_includes_metrics_and_page_text():
    p = build_prompt([_m("营业收入", "2025", 1.0)], "第88页原文")
    assert "营业收入" in p and "第88页原文" in p


def test_build_prompt_rejects_oversized_page_text():
    """超限必须抛异常而非静默截断——截断会导致误判。"""
    with pytest.raises(ValueError, match="MAX_CHARS"):
        build_prompt([_m("营业收入", "2025", 1.0)], "x" * (MAX_CHARS + 1))


def test_parse_response_handles_clean_json():
    out = parse_response('{"is_correct": true, "corrections": {}, "explanation": "ok"}')
    assert out.is_correct is True
    assert out.corrections == {}


def test_parse_response_handles_markdown_fence():
    raw = '```json\n{"is_correct": false, "corrections": {"净利润": {"2025": 1.0}}, "explanation": "x"}\n```'
    out = parse_response(raw)
    assert out.is_correct is False
    assert out.corrections["净利润"]["2025"] == 1.0


def test_parse_response_raises_on_garbage():
    with pytest.raises(ValueError):
        parse_response("这不是 JSON")


def test_apply_outcome_marks_conflict_without_overwriting():
    metrics = [_m("净利润", "2025", 100.0)]
    out = parse_response('{"is_correct": false, "corrections": {"净利润": {"2025": 200.0}}, "explanation": "原文是200"}')
    result = apply_outcome(metrics, out)
    assert len(result) == 1
    assert result[0].confidence == "conflict"
    # 规则提取的原值必须保留，不得被静默覆盖
    assert result[0].value == 100.0


def test_apply_outcome_keeps_high_when_correct():
    metrics = [_m("净利润", "2025", 100.0)]
    out = parse_response('{"is_correct": true, "corrections": {}, "explanation": ""}')
    assert apply_outcome(metrics, out)[0].confidence == "high"


def test_apply_outcome_preserves_statement_on_conflict():
    """conflict 项必须保留原 statement，不能回落到默认的 "利润表"。

    只传 5 个位置参数会让 statement 走默认值：资产负债表/现金流量表的冲突项
    被错标成利润表项——值保住了、归属错了。旧测试的 helper 也走默认值，
    所以这个缺陷在套件里完全隐形。
    """
    metrics = [_m("资产总计", "2025", 100.0, statement="资产负债表")]
    out = parse_response(
        '{"is_correct": false, "corrections": {"资产总计": {"2025": 200.0}}, "explanation": "x"}')
    result = apply_outcome(metrics, out)
    assert result[0].statement == "资产负债表"
    assert result[0].value == 100.0          # 规则原值仍未被覆盖
    assert result[0].confidence == "conflict"


@pytest.mark.slow
def test_verify_against_real_page():
    """真实 LLM 调用。默认被 -m "not slow" 跳过；没配 Key 也跳过。"""
    import pytest as _pytest

    from client import HAS_KEY

    if not HAS_KEY:
        _pytest.skip("没有配置 API_KEY（精简部署常见），跳过真实模型调用")
    import pdfplumber
    from conftest import require_pdf
    from metric_extractor import extract_metrics
    from table_reader import read_report_page, score_structure
    from metric_extractor import count_metrics

    path = require_pdf("gree_annual")
    with pdfplumber.open(path) as pdf:
        page = pdf.pages[87]
        table = read_report_page(page, count_metrics)
        text = page.extract_text()
    metrics = extract_metrics(table.rows, page=88, years=["2025", "2024"])
    out = verify(metrics, text, page_no=88)
    assert out.is_correct is True
