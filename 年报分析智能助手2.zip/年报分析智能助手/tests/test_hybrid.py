"""混合检索：关键词通道 + RRF 融合。

为什么需要它：纯向量检索在**专有名词**上会漏（问"合同负债"召回一堆"应付账款"），
纯关键词在**口语化提问**上会漏（"钱收回来了吗"搜不到"销售商品收到的现金"）。
两路融合才稳。
"""
import hybrid


def test_bm25_prefers_exact_term():
    docs = ["本公司合同负债较上年增加 12 亿元",
            "货币资金余额 105 亿元",
            "应收账款账龄结构如下"]
    scores = hybrid.bm25_scores("合同负债", docs)
    assert scores[0] > 0
    assert scores[1] == 0 and scores[2] == 0


def test_lexical_search_ranks_and_filters_zero():
    docs = ["合同负债 12 亿", "合同负债 8 亿", "固定资产 3 亿"]
    got = hybrid.lexical_search("合同负债", docs)
    assert [i for i, _ in got] == [0, 1]        # 分数为 0 的不返回


def test_rrf_fuse_combines_two_lists():
    """两路都排第一的，融合后必须仍排第一。"""
    fused = hybrid.rrf_fuse([["a", "b", "c"], ["b", "c", "d"]])
    order = [i for i, _ in fused]
    assert order[0] == "b"                       # b 在两路里都靠前
    assert set(order) == {"a", "b", "c", "d"}


def test_hybrid_rank_rescues_keyword_hit():
    """向量把"合同负债"那页排到第 4，关键词能把它救回前面。"""
    docs = ["货币资金 100 亿",
            "应收账款 20 亿",
            "存货 30 亿",
            "合同负债较上年增加 12 亿"]
    vector_order = [0, 1, 2, 3]                  # 向量把正确的排最后
    order = hybrid.hybrid_rank("合同负债", docs, vector_order)
    assert order[0] == 3, f"关键词命中没被救回：{order}"


def test_bigrams_split_on_punctuation_not_space():
    """空格不算断句（PDF 里常见"合同 负债"这种排版），标点才算。"""
    assert hybrid._bigrams("合同 负债，增加") == ["合同", "同负", "负债", "增加"]


def test_retriever_warns_when_index_built_with_other_model(monkeypatch):
    """换了检索模型但索引没重建时，要给出**可执行的**提示而不是维度报错。"""
    import retriever as R

    class FakeCol:
        metadata = {"hnsw:space": "cosine", "embedding_model": "BAAI/bge-m3"}

    class FakeRetriever(R.ReportRetriever):
        def __init__(self):                      # 跳过真实加载
            self.collection = FakeCol()

    monkeypatch.setattr(R, "EMBEDDING_MODEL", "BAAI/bge-small-zh-v1.5")

    import pytest
    with pytest.raises(RuntimeError) as ei:
        FakeRetriever()._check_model_match()
    msg = str(ei.value)
    assert "reindex.py" in msg and "维度" in msg


def test_retriever_accepts_matching_model(monkeypatch):
    import retriever as R

    class FakeCol:
        metadata = {"hnsw:space": "cosine", "embedding_model": "BAAI/bge-small-zh-v1.5"}

    class FakeRetriever(R.ReportRetriever):
        def __init__(self):
            self.collection = FakeCol()

    monkeypatch.setattr(R, "EMBEDDING_MODEL", "BAAI/bge-small-zh-v1.5")
    FakeRetriever()._check_model_match()          # 不该抛
