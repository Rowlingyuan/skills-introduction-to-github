from pathlib import Path
import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
FIXTURES = REPO_ROOT / "_fixtures"

SAMPLE_PDFS = {
    "gree_annual":   FIXTURES / "格力电器-2025年报.PDF",
    "gree_semi":     FIXTURES / "格力电器-2024半年报.pdf",
    "gree_q1":       FIXTURES / "格力电器-2025一季报.pdf",
    "moutai_annual": FIXTURES / "贵州茅台-2025年度报告.PDF",
}


def require_pdf(name: str) -> Path:
    """返回样本 PDF 路径；缺失则跳过该测试。"""
    p = SAMPLE_PDFS[name]
    if not p.exists():
        pytest.skip(f"样本缺失: {p}")
    return p


@pytest.fixture(autouse=True)
def _isolate_user_settings(tmp_path, monkeypatch):
    """**隔离用户设置**：`data/settings.json` 是用户自己的状态（选过哪个嵌入模型）。

    测试若往真实文件里写，会污染本机配置；反过来，本机已有的选择也会
    影响测试结果 —— 实测随机顺序跑时出现过「上一轮写了 settings.json，
    下一轮 config 读到的模型变了」导致的偶发失败。
    """
    try:
        import settings

        monkeypatch.setattr(settings, "PATH", tmp_path / "settings.json")
    except Exception:          # noqa: BLE001
        pass
    # 确保环境变量不会从外部串进来
    monkeypatch.delenv("EMBEDDING_MODEL", raising=False)
