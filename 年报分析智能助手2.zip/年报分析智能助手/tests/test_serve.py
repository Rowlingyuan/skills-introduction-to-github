"""本地看板服务：数据实时、只读、挡住路径穿越。"""
import json
import threading
import urllib.request
from http.server import ThreadingHTTPServer

import pytest

from serve import DashboardHandler, list_reports, make_server


@pytest.fixture()
def server():
    httpd = make_server(port=0)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{httpd.server_address[1]}"
    httpd.shutdown()
    httpd.server_close()


def _get(url):
    with urllib.request.urlopen(url, timeout=10) as r:
        return r.status, r.headers.get("Content-Type", ""), r.read()


def test_index_serves_live_dashboard(server):
    code, ctype, body = _get(server + "/")
    assert code == 200 and "text/html" in ctype
    html = body.decode()
    assert "年报数据看板" in html
    assert "const DATA = {" in html


def test_api_data_returns_json(server):
    code, ctype, body = _get(server + "/api/data")
    assert code == 200 and "application/json" in ctype
    data = json.loads(body)
    assert data and all("company" in v for v in data.values())


def test_api_reports_lists_files(server):
    code, _ctype, body = _get(server + "/api/reports")
    payload = json.loads(body)
    assert payload["ok"] is True
    assert isinstance(payload["reports"], list)


def test_file_download_blocks_traversal(server):
    """`../` 之类的路径必须挡住 —— 这个服务只暴露 reports/。"""
    import urllib.error

    try:
        _code, _ctype, body = _get(server + "/files/..%2F..%2Fdata%2Fstructured.db")
    except urllib.error.HTTPError as e:
        assert e.code == 404
        return
    # 万一返回了 200，也绝不能是数据库内容
    assert body[:16] != b"SQLite format 3\x00"


def test_cache_is_disabled(server):
    """数据要"最新"，不能让浏览器拿缓存。"""
    with urllib.request.urlopen(server + "/api/data", timeout=10) as r:
        assert r.headers.get("Cache-Control") == "no-store"


def test_list_reports_only_docx_and_html(tmp_path, monkeypatch):
    import serve as S

    (tmp_path / "a.docx").write_text("x")
    (tmp_path / "b.pdf").write_text("y")
    monkeypatch.setattr(S, "REPORTS", tmp_path)
    names = [r["name"] for r in S.list_reports()]
    assert "a.docx" in names and "b.pdf" not in names


def test_port_conflict_falls_back():
    """端口被占用时要自动换一个，而不是甩 traceback。"""
    from serve import make_server

    first = make_server(8899)
    try:
        second = make_server(8899)
        try:
            assert second.server_address[1] != first.server_address[1]
        finally:
            second.server_close()
    finally:
        first.server_close()
