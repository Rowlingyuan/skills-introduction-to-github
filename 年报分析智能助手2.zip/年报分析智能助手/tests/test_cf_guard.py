"""现金流量表抽取的**回归护栏**（先立测试，再改代码）。

背景：为了让银行/券商的现金流量表能抽全，改了若干切表/拼接规则，
结果出现"修好一个、弄坏另一个"（交通银行 ↑ 但中际旭创 ↓ 8→4）。
这个文件把**每份样本至少必须抽到哪些科目**钉死，任何改动只要让
这些断言失败就说明引入回归。

判据用"包含"而不是"相等"：允许以后抽得更多，不允许变少。
"""
import sqlite3

import pytest

DB = "data/structured.db"

#: (公司, 期间, 报表类型) → 必须存在的现金流量表科目
REQUIRED = {
    # 工商企业：三净额 + 销售收现是分析的基础
    ("中际旭创", "2025", "年报"): ["经营活动现金流量净额", "投资活动现金流量净额",
                                   "筹资活动现金流量净额", "销售商品收到的现金"],
    ("中国黄金", "2025", "年报"): ["经营活动现金流量净额", "投资活动现金流量净额",
                                   "筹资活动现金流量净额", "销售商品收到的现金"],
    ("格力电器", "2022", "年报"): ["经营活动现金流量净额", "投资活动现金流量净额",
                                   "筹资活动现金流量净额", "销售商品收到的现金",
                                   "现金及现金等价物净增加额"],
    # 券商：三净额 + 期初
    ("中信证券", "2025", "年报"): ["经营活动现金流量净额", "投资活动现金流量净额",
                                   "筹资活动现金流量净额", "期初现金及现金等价物余额"],
    # 保险：三净额里缺投资活动（该项确实没抽到，暂不强制）+ 期初期末净增加
    ("中国平安", "2025", "年报"): ["经营活动现金流量净额", "筹资活动现金流量净额",
                                   "期初现金及现金等价物余额", "期末现金及现金等价物余额",
                                   "现金及现金等价物净增加额"],
}

#: 曾经的缺口，现已达成 —— 保留在同一份护栏里，防止回退
TARGET = {
    ("交通银行", "2025", "年报"): ["经营活动现金流量净额", "投资活动现金流量净额",
                                   "筹资活动现金流量净额", "期初现金及现金等价物余额",
                                   "期末现金及现金等价物余额", "现金及现金等价物净增加额"],
}

#: **绝对不允许出现**的科目（别名误配的典型）。目前为空 ——
#: 中际旭创出现的"收到原保险合同保费取得的现金"经核对**是 PDF 里真实存在的行**
#: （现金流量表附注中的模板行），不属于误配。
FORBIDDEN = {}


def _cf_names(company, period, report_type):
    conn = sqlite3.connect(DB)
    try:
        row = conn.execute(
            "SELECT id FROM reports WHERE company=? AND period=? AND report_type=?",
            (company, period, report_type)).fetchone()
        if row is None:
            pytest.skip(f"{company} {period} 未入库")
        return {n for (n,) in conn.execute(
            "SELECT DISTINCT metric_name FROM metrics WHERE report_id=? AND statement='现金流量表'",
            (row[0],))}
    finally:
        conn.close()


@pytest.mark.parametrize("key,names", list(REQUIRED.items()))
def test_required_cashflow_items_present(key, names):
    got = _cf_names(*key)
    missing = [n for n in names if n not in got]
    assert not missing, f"{key[0]} {key[1]} 缺现金流量表科目：{missing}（实得 {sorted(got)}）"


@pytest.mark.parametrize("key,names", list(FORBIDDEN.items()))
def test_no_bogus_cashflow_items(key, names):
    got = _cf_names(*key)
    bad = [n for n in names if n in got]
    assert not bad, f"{key[0]} {key[1]} 出现不该有的科目：{bad}"


@pytest.mark.parametrize("key,names", list(TARGET.items()))
def test_target_cashflow_items_present(key, names):
    """**目标项**：银行现金流量表的尾部三行（净变动额/年初/年末）。"""
    got = _cf_names(*key)
    missing = [n for n in names if n not in got]
    assert not missing, f"{key[0]} {key[1]} 目标科目未达成：{missing}"


# ---------------------------------------------------------------------------
# 定位：现金流量表必须定在**报表页**，不能是附注页
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("company,period,report_type,expected_max_page", [
    # 长江电力 2026 半年报：真表在 p55，附注里的"现金流量表补充资料"在 p161
    ("长江电力", "2026", "半年报", 60),
    ("交通银行", "2025", "年报", 155),
    ("中信证券", "2025", "年报", 200),
])
@pytest.mark.xfail(reason="长江电力 2026 半年报：现金流量表被定位到附注页 p161。"
                          "试过两种修法（取最早页 / 排除补充资料页）都各有反例"
                          "（会弄坏宝钢或交通银行），已回退，留作已知缺口",
                   strict=False)
def test_cashflow_located_on_statement_page(company, period, report_type,
                                            expected_max_page):
    """现金流量表的定位页必须**早于附注区**（用页码上界做粗略断言）。"""
    from report_locator import locate

    conn = sqlite3.connect(DB)
    try:
        row = conn.execute(
            "SELECT file_path FROM reports WHERE company=? AND period=? AND report_type=?",
            (company, period, report_type)).fetchone()
    finally:
        conn.close()
    if row is None:
        pytest.skip(f"{company} {period} 未入库")

    pages = locate(row[0], [int(period), int(period) - 1])
    got = pages.get("现金流量表")
    assert got is not None, f"{company} 没定位到现金流量表：{pages}"
    assert got <= expected_max_page, f"{company} 现金流量表定到了附注页 p{got}"
