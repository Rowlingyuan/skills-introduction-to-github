"""现金流量表的**列对齐**（单元测试，用交通银行 2025 年报 p153 的真实行结构）。

这张表的难点，四条同时出现：
  1. 表头被切成两格：`'2025'` + `'年'`
  2. 中间夹一列「附注」编号（`六、50(1)`），不是数字
  3. 数字被切成两格：`'(35,48'` + `'8)'`、`'161,95'` + `'0'`
  4. 四个数据列并排：本集团2025 / 本集团2024 / 本行2025 / 本行2024

期望：只取**本集团（合并）**的两列，且数值必须与原表一致
（−35,488 / 161,950 / 126,462，单位为百万元）。

先写测试、再改实现：下面 `test_...` 失败即说明实现还没做到。
"""
import pytest

from metric_extractor import (extract_metrics, find_year_columns,
                              merge_split_numbers, merge_wrapped_rows)

#: 交通银行 2025 年报 p153（合并现金流量表续页）的原始行，未做任何拼接
RAW_ROWS = [
    ["", "", "2025", "年度", "", "", ""],
    ["", "", "", "本集", "团", "本行", ""],
    ["", "附注", "2025", "年", "2024 年", "2025 年", "2024 年"],
    ["四、汇率变动对现金及现金", "", "", "", "", "", ""],
    ["等价物的影响", "", "(40", "9)", "(594)", "(325)", "(701"],
    ["", "", "-------------", "--", "---------------", "---------------", "---------------"],
    ["五、现金及现金等价物净变", "", "", "", "", "", ""],
    ["动额", "六、50(1)", "(35,48", "8)", "(113,511)", "(42,937)", "(107,472"],
    ["加：年初现金及现金", "", "", "", "", "", ""],
    ["等价物余额", "", "161,95", "0", "275,461", "139,761", "247,233"],
    ["六、年末现金及现金等价物", "", "", "", "", "", ""],
    ["余额", "六、50(2)", "126,46", "2", "161,950", "96,824", "139,761"],
]


def _extract():
    return {m.name: m for m in extract_metrics(RAW_ROWS, 153, [2025, 2024], "现金流量表")
            if str(m.period) == "2025"}


def test_header_fragments_are_merged():
    """`'2025'` + `'年'` 必须拼成 `'2025年'`，否则年份列整体错位。"""
    merged = merge_split_numbers(RAW_ROWS)
    header = [str(c) for c in merged[2]]
    assert "2025年" in header, f"表头没拼上：{header}"


def test_year_columns_point_at_the_consolidated_numbers():
    """年份列必须**指向本集团那两格的数字**（列号本身随排版而变，不写死）。

    数据行：`动额 | 六、50(1) | (35,488) | (113,511) | (42,937) | (107,472)`
    → 2025 应指向 −35,488，2024 应指向 −113,511（本行那两列不许选）。
    """
    from metric_extractor import _drop_empty_columns, parse_number

    merged = _drop_empty_columns(merge_wrapped_rows(merge_split_numbers(RAW_ROWS)))
    cols = find_year_columns(merged, [2025, 2024])
    data = next(r for r in merged if "动额" in str(r[0]))

    assert parse_number(data[cols[2025]]) == pytest.approx(-35488.0), \
        f"2025 列指错了：第 {cols[2025]} 列 = {data[cols[2025]]!r}"
    assert parse_number(data[cols[2024]]) == pytest.approx(-113511.0), \
        f"2024 列指错了：第 {cols[2024]} 列 = {data[cols[2024]]!r}"


def test_net_change_value():
    """净变动额：本集团 2025 = −35,488 百万元。"""
    got = _extract()
    assert "现金及现金等价物净增加额" in got, f"没抽到净增加额：{sorted(got)}"
    assert got["现金及现金等价物净增加额"].value == pytest.approx(-35488.0)


def test_opening_balance_value():
    """期初（年初）余额：本集团 2025 = 161,950 百万元。

    数字被切成 `'161,95'` + `'0'` 两格 —— 只看第一格会得到 161.95。
    """
    got = _extract()
    assert "期初现金及现金等价物余额" in got, f"没抽到期初：{sorted(got)}"
    assert got["期初现金及现金等价物余额"].value == pytest.approx(161950.0)


def test_closing_balance_value():
    """期末（年末）余额：本集团 2025 = 126,462 百万元。"""
    got = _extract()
    assert "期末现金及现金等价物余额" in got, f"没抽到期末：{sorted(got)}"
    assert got["期末现金及现金等价物余额"].value == pytest.approx(126462.0)


def test_tie_holds_within_the_page():
    """页内勾稽：期初 + 净变动 = 期末（161,950 − 35,488 = 126,462）。"""
    got = _extract()
    beg = got["期初现金及现金等价物余额"].value
    net = got["现金及现金等价物净增加额"].value
    end = got["期末现金及现金等价物余额"].value
    assert beg + net == pytest.approx(end)


# ---------------------------------------------------------------------------
# 第二组：标签跨**列**折行（交通银行 2025 年报 p150）
#
#   ['一、', '经营活动产生的现金', '', '']            ← 标签前半（第 0、1 列）
#   ['',    '现金流量净额', '六、50(1)', '132,44', '1'] ← 标签后半 + 数字（还被切开）
#
# 目标：拼出「经营活动产生的现金流量净额」= 132,441 百万元。
# ---------------------------------------------------------------------------
RAW_ROWS_SPLIT_COLS = [
    ["", "附注", "2025", "年", "2024 年", "2025 年", "2024 年"],
    ["一、", "经营活动产生的现金", "", "", "", "", ""],
    ["", "现金流量净额", "六、50(1)", "132,44", "1", "(57,348)", "(110,558)"],
]


def test_label_of_stops_before_note_reference():
    """标签里不能把附注编号（`六、50(1)`）算进去。"""
    from metric_extractor import _label_of

    row = ["", "现金流量净额", "六、50(1)", "132,44", "1"]
    assert _label_of(row) == "现金流量净额"


def test_net_operating_value_when_label_spans_two_columns():
    """标签跨列折行 + 数字也被切开，仍应抽出 132,441（并归到 2025 年）。"""
    got = {str(m.period): m for m in extract_metrics(RAW_ROWS_SPLIT_COLS, 150, [2025, 2024],
                                                     "现金流量表")}
    assert "经营活动现金流量净额" in {m.name for m in got.values()}, \
        f"没抽到经营净额：{[ (k, v.name) for k, v in got.items() ]}"
    hit = next(m for m in got.values() if m.name == "经营活动现金流量净额")
    assert hit.value == pytest.approx(132441.0)
    assert str(hit.period) == "2025", f"年份归错：{hit.period}"


# ---------------------------------------------------------------------------
# 第三组：**附注编号被当成数值**（中国平安 2025 年报 p189）
#
#   ['少数股东权益', '41', '415,569', '376,112']
#                  ↑ 附注序号     ↑ 2025      ↑ 2024
#
# 现象：2025 年抽成 415（实为 41,5569 的"41"），权益合计因此差三个数量级，
# 恒等式报警。要求：附注编号列必须被跳过。
# ---------------------------------------------------------------------------
RAW_ROWS_NOTE_COLUMN = [
    ["项目", "附注", "2025", "2024"],
    ["少数股东权益", "41", "415,569", "376,112"],
    ["股东权益合计", "42", "1,415,988", "1,304,712"],
    ["负债和股东权益总计", "", "13,898,471", "12,957,827"],
]


def test_note_number_column_is_skipped():
    """`附注` 列是序号（41、42），不能当作年份数据。"""
    got = {(m.name, str(m.period)): m
           for m in extract_metrics(RAW_ROWS_NOTE_COLUMN, 189, [2025, 2024], "资产负债表")}
    assert ("所有者权益合计", "2025") in got, f"没抽到权益合计：{sorted(got)}"
    assert got[("所有者权益合计", "2025")].value == pytest.approx(1415988.0)
    assert got[("少数股东权益", "2025")].value == pytest.approx(415569.0)
    # 2024 列本来就应该是对的，不能被改坏
    assert got[("所有者权益合计", "2024")].value == pytest.approx(1304712.0)
