"""外部真值校验层的离线测试（不联网：`fetch_table` 全部注入假数据）。"""
import pandas as pd

from models import MetricValue
from validator import (compare, fetch_external, report_date, resolver, symbol,
                       summarize)


def _mv(name, value, statement="资产负债表", page=1):
    return MetricValue(name=name, period="2025", value=value,
                       source_page=page, confidence="high", statement=statement)


# --- 报告期 / 代码 --------------------------------------------------------

def test_report_date_maps_each_report_type():
    assert report_date("年报", "2025") == "2025-12-31"
    assert report_date("半年报", "2026") == "2026-06-30"
    assert report_date("一季报", "2025Q1") == "2025-03-31"
    assert report_date("三季报", "2025Q3") == "2025-09-30"


def test_report_date_returns_none_for_junk():
    assert report_date("年报", "") is None
    assert report_date("未知类型", "2025") is None


def test_symbol_adds_exchange_prefix():
    assert symbol("000651") == "SZ000651"
    assert symbol("600519") == "SH600519"
    assert symbol("830799") == "BJ830799"


def test_resolver_prefers_exact_name():
    code_map = {"格力电器": "000651", "格力": "999999"}
    assert resolver("格力电器", code_map) == "000651"


def test_resolver_refuses_ambiguous_substring():
    """两个候选都沾边时不猜 —— 猜错会把甲公司的数字当成乙公司的真值。"""
    code_map = {"格力电器": "000651", "格力地产": "600185"}
    assert resolver("格力", code_map) is None


# --- 抽取外部真值 ---------------------------------------------------------

def _fake_table(api, sym):
    """两张报表各一份假 DataFrame，含干扰行（不同报告期）。"""
    if api == "stock_balance_sheet_by_report_em":
        return pd.DataFrame([
            {"REPORT_DATE": "2025-06-30 00:00:00", "TOTAL_ASSETS": 1.0,
             "TOTAL_LIABILITIES": 1.0},
            {"REPORT_DATE": "2025-12-31 00:00:00", "TOTAL_ASSETS": 391_371_999_819.49,
             "TOTAL_LIABILITIES": 241_580_719_144.79},
        ])
    if api == "stock_profit_sheet_by_report_em":
        return pd.DataFrame([
            {"REPORT_DATE": "2025-12-31 00:00:00", "OPERATE_INCOME": float("nan"),
             "OPERATE_COST": 119_641_353_216.21},
        ])
    raise RuntimeError("no such api")


def test_fetch_external_picks_the_matching_report_date():
    out = fetch_external("格力电器", "年报", "2025", {"格力电器": "000651"},
                         fetch_table=_fake_table)
    assert out["资产负债表"]["资产总计"] == 391_371_999_819.49
    assert out["资产负债表"]["负债合计"] == 241_580_719_144.79


def test_fetch_external_drops_nan_fields():
    out = fetch_external("格力电器", "年报", "2025", {"格力电器": "000651"},
                         fetch_table=_fake_table)
    assert "营业收入" not in out["利润表"]          # NaN 视为"外部没有"
    assert out["利润表"]["营业成本"] == 119_641_353_216.21


def test_fetch_external_skips_failing_statement_but_keeps_others():
    out = fetch_external("格力电器", "年报", "2025", {"格力电器": "000651"},
                         fetch_table=_fake_table)
    assert "现金流量表" not in out                  # 该接口抛异常 → 整张表跳过
    assert "资产负债表" in out


def test_fetch_external_without_code_returns_empty():
    assert fetch_external("未知公司", "年报", "2025", {}) == {}


# --- 比对 ----------------------------------------------------------------

def test_compare_marks_equal_values_ok():
    metrics = [_mv("资产总计", 391_371_999_819.49)]
    rows = compare(metrics, {"资产负债表": {"资产总计": 391_371_999_819.50}})
    assert [r["status"] for r in rows] == ["ok"]


def test_compare_catches_the_gree_current_ratio_bug():
    """回归：修前 `流动负债合计` 被记成 `非流动负债合计` 的 100 亿。

    这是恒等式检查抓不到的类型 —— 内部自洽、confidence=high，只有外部真值能发现。
    """
    metrics = [_mv("流动负债合计", 10_010_887_948.53)]
    rows = compare(metrics, {"资产负债表": {"流动负债合计": 231_569_831_196.26}})
    assert rows[0]["status"] == "mismatch"
    assert rows[0]["diff"] < -2e11


def test_compare_reports_missing_ours_and_theirs():
    metrics = [_mv("存货", 28_183_464_259.53)]
    rows = compare(metrics, {"资产负债表": {"负债合计": 241_580_719_144.79}})
    status = {r["metric"]: r["status"] for r in rows}
    assert status["负债合计"] == "missing_ours"     # 外部有、我们没抽到
    assert status["存货"] == "missing_theirs"       # 我们抽到、外部没有


def test_compare_tolerance_is_tight():
    """容差只容忍浮点误差；任何差异都必须被**标出来**，只是分轻重两档。

    - 差 1 元 → `ok`（四舍五入）
    - 差 0.01%（约 3900 万）→ `restated`，仍然列出、不吞掉
    - 差 10% → `mismatch`，这是真错误
    """
    base = 391_371_999_819.49
    assert compare([_mv("资产总计", base)], {"资产负债表": {
        "资产总计": base - 1}})[0]["status"] == "ok"
    assert compare([_mv("资产总计", base)], {"资产负债表": {
        "资产总计": base * 1.0001}})[0]["status"] == "restated"
    assert compare([_mv("资产总计", base)], {"资产负债表": {
        "资产总计": base * 1.1}})[0]["status"] == "mismatch"


def test_summarize_computes_accuracy_over_checked_only():
    rows = [{"status": "ok"}, {"status": "ok"}, {"status": "mismatch"},
            {"status": "missing_ours"}, {"status": "missing_theirs"}]
    s = summarize(rows)
    assert s["checked"] == 3
    assert s["accuracy"] == 2 / 3
    assert s["missing_ours"] == 1


def test_normalise_name_strips_spaces():
    """东财写成「五 粮 液」，年报写「五粮液」——不归一化就永远匹配不上。"""
    from validator import normalise_name
    assert normalise_name("五 粮 液") == "五粮液"
    assert normalise_name(" 贵州　茅台 ") == "贵州茅台"


def test_resolver_matches_spaced_eastmoney_name():
    from validator import resolver
    code_map = {"五粮液": "000858", "泸州老窖": "000568"}
    assert resolver("五粮液", code_map) == "000858"


# --- 口径差异：把"重述/重分类"从真错误里分出来 -----------------------------

def _mv_pair(a_name, a_val, b_name, b_val, statement="利润表"):
    from models import MetricValue
    return [MetricValue(name=a_name, period="2025", value=a_val, source_page=1,
                        confidence="high", statement=statement),
            MetricValue(name=b_name, period="2025", value=b_val, source_page=1,
                        confidence="high", statement=statement)]


def test_tiny_relative_difference_is_restated():
    """格力 2022：资产总计差 0.46 亿 = 0.013%，属于追溯重述而非抽取错误。"""
    metrics = [_mv("资产总计", 355_025_000_000.0)]
    rows = compare(metrics, {"资产负债表": {"资产总计": 355_071_000_000.0}})
    assert rows[0]["status"] == "restated"
    assert "重述" in rows[0]["note"]


def test_equal_and_opposite_pair_is_reclassified():
    """格力 2023：营业成本 +23.27 亿、销售费用 −23.28 亿，合计不变。"""
    metrics = _mv_pair("营业成本", 141_626_000_000.0,
                       "销售费用", 17_130_000_000.0)
    external = {"利润表": {"营业成本": 143_953_000_000.0,
                           "销售费用": 14_802_000_000.0}}
    rows = compare(metrics, external)
    status = {r["metric"]: r["status"] for r in rows}
    assert status == {"营业成本": "reclassified", "销售费用": "reclassified"}
    notes = {r["metric"]: r["note"] for r in rows}
    assert "销售费用" in notes["营业成本"]
    assert "营业成本" in notes["销售费用"]


def test_real_error_stays_mismatch():
    """海康那种量级错误不能被"软分类"放过去。"""
    metrics = [_mv("投资活动现金流量净额", 1_590_000_000.0, statement="现金流量表")]
    rows = compare(metrics, {"现金流量表": {
        "投资活动现金流量净额": -1_479_000_000.0}})
    assert rows[0]["status"] == "mismatch"


def test_summarize_reports_strict_and_explained_accuracy():
    rows = [{"status": "ok"}, {"status": "ok"}, {"status": "restated"},
            {"status": "reclassified"}, {"status": "mismatch"}]
    s = summarize(rows)
    assert s["checked"] == 5
    assert s["accuracy"] == 2 / 5
    assert s["accurate_or_explained"] == 4 / 5
