"""「说一句话就出报告」：智能体的文档生成意图与落盘。"""
from pathlib import Path

from agent import (build_report, default_report_path, wants_document,
                   _document_suffix)


def test_wants_document_distinguishes_text_from_document():
    assert wants_document("帮我出一份格力电器2025年报的分析报告")
    assert wants_document("导出茅台2024年报Word")
    assert wants_document("把这个分析生成文档")
    # 只要文字分析时不落文件
    assert not wants_document("分析一下格力电器2025年报")
    assert not wants_document("格力电器2025年营业收入是多少")


def test_default_report_path_names_company_and_period(tmp_path=None):
    p = default_report_path("格力电器", "2025", "年报")
    assert p.name == "格力电器2025年度财务分析报告.docx"
    assert p.parent.name == "reports"
    assert default_report_path("比亚迪", "2026", "半年报").name.endswith("半年报财务分析报告.docx")


def test_build_report_refuses_when_analysis_failed(tmp_path):
    got = build_report("不存在", "年报", "2025", str(tmp_path / "x.db"),
                       analysis={"ok": False, "error": "尚未入库"},
                       out_path=tmp_path / "a.docx")
    assert got["ok"] is False
    assert "尚未入库" in got["error"]


def test_document_suffix_is_silent_without_intent(tmp_path):
    """不要文档时不能产生任何"已生成报告"的提示。"""
    assert _document_suffix("分析一下格力2025年报", "格力电器", "年报", "2025",
                            str(tmp_path / "x.db"), {"ok": True}, {}) == ""


def test_report_renderer_has_no_hardcoded_company():
    """回归：核验口径那行曾经写死 `--company 格力电器`，给茅台/五粮液出报告时也照抄。

    这条用例盯的是"模板里出现具体公司名"这一类泄漏 —— 一旦再有人把公司名写进
    输出字符串，这里就红。
    """
    import inspect

    import report_docx

    src = inspect.getsource(report_docx)
    assert "--company 格力电器" not in src
    assert "{company}`" in src          # 核验口径用 f-string 拼，而不是写死
