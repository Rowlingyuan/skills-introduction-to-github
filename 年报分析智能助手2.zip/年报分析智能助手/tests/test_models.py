import pytest
from models import ReportKey, MetricValue, ParsedTable, CONFIDENCE_LEVELS


def test_report_key_is_hashable_and_value_equal():
    a = ReportKey("格力电器", "000651", "年报", "2025")
    b = ReportKey("格力电器", "000651", "年报", "2025")
    assert a == b
    assert len({a, b}) == 1


def test_metric_value_rejects_unknown_confidence():
    with pytest.raises(ValueError, match="confidence"):
        MetricValue("营业收入", "2025", 1.0, 88, "maybe")


def test_metric_value_accepts_known_confidence():
    m = MetricValue("营业收入", "2025", 170447058533.57, 88, "high")
    assert m.confidence in CONFIDENCE_LEVELS


def test_parsed_table_holds_rows_verbatim():
    rows = [["项目", "附注", "2025年度"], ["营业收入", "五、54", "1,234.00"]]
    t = ParsedTable(page=88, rows=rows, strategy="text", score=42.0)
    assert t.rows[1][2] == "1,234.00"
