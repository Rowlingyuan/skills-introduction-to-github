"""文档不能写死本机路径 —— 发给别人会看不懂。

实测反馈：快速开始里那段"先确认路径：…/年报分析智能助手/…"
是我电脑上的目录结构，别人的机器不一定长这样。
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOCS = ["README.md", "快速开始.md", "项目骨架.txt"]


def test_docs_have_no_absolute_user_paths():
    for name in DOCS:
        p = ROOT / name
        if not p.exists():
            continue
        text = p.read_text(encoding="utf-8")
        assert "/Users/" not in text, f"{name} 里写死了本机绝对路径"
        assert "C:\\Users\\" not in text, f"{name} 里写死了本机绝对路径"


def test_quickstart_has_no_path_check_block():
    p = ROOT / "快速开始.md"
    text = p.read_text(encoding="utf-8")
    assert "先确认路径" not in text


def test_messages_avoid_developer_jargon():
    """面向用户的提示不能出现"点不动""Cmd+点击"这类开发者视角的说法。

    实测反馈：用户不知道"点不动就用 /open"是在说什么。
    现在统一成"文件位置 + 打开方式"。
    """
    import inspect

    import agent

    src = inspect.getsource(agent._document_suffix)
    assert "点不动" not in src
    assert "Cmd+点击" not in src
    assert "👉" in src                 # 用箭头直接指路，代替术语

    import terminal_link

    link_src = inspect.getsource(terminal_link.link)
    assert "点不动" not in link_src.split('"""')[-1]   # 说明文字里可以提，返回内容里不行
