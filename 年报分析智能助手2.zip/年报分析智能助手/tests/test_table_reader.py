import pytest
from table_reader import clean_rows, score_structure, read_page
from conftest import require_pdf
import pdfplumber


def test_clean_rows_strips_whitespace_and_drops_empty():
    rows = [[" 项目 ", "附注", None], ["", "  ", ""], ["营业收入", "五、54", "1,234"]]
    assert clean_rows(rows) == [["项目", "附注", ""], ["营业收入", "五、54", "1,234"]]


def test_clean_rows_removes_newlines_inside_cells():
    assert clean_rows([["营业\n收入", "a"]] ) == [["营业收入", "a"]]


def test_score_structure_rewards_header_and_rowcount():
    good = [["项目", "附注", "2025年度", "2024年度"]] + [["行", "1", "2", "3"]] * 30
    bad = [["附注", "2025年度"], ["五、54\n五、55", "171,118\n170,447"]]
    assert score_structure(good) > score_structure(bad)


def test_score_structure_rejects_tiny_tables():
    assert score_structure([["a", "b"]]) == 0.0


def test_read_page_runs_both_strategies():
    """两种策略都必须被尝试——不存在"预判格式走捷径"这回事。"""
    path = require_pdf("gree_annual")
    with pdfplumber.open(path) as pdf:
        cands = read_page(pdf.pages[87])
    assert {c.strategy for c in cands} == {"default", "text"}


def test_gree_annual_default_strategy_collapses():
    """格力年报 p88 无框线：默认策略塌缩到 <5 行，结构分判 0；文本策略给出完整表。

    注意：本任务只断言**结构**。最终选哪个策略是 report_locator 的职责
    （结构分 + 100×指标命中数），在 Task 5 断言。
    """
    path = require_pdf("gree_annual")
    with pdfplumber.open(path) as pdf:
        cands = read_page(pdf.pages[87])
    default_cand = next(c for c in cands if c.strategy == "default")
    text_cand = next(c for c in cands if c.strategy == "text")
    assert len(default_cand.rows) < 5
    assert len(text_cand.rows) >= 30
    assert score_structure(default_cand.rows) == 0.0
    assert text_cand.score > 0


def test_text_strategy_keeps_adjacent_number_columns_parseable():
    """钉住 TEXT_SETTINGS["text_x_tolerance"]：把它改回 pdfplumber 默认的 3 即失败。

    症状：tol=3 时格力年报第 89 页（现金流量表）一个数字单元格都提不出来
    （实测仅 2 个，且都不属于现金流量表指标），count_metrics(..., "现金流量表")
    == 0，现金流量表定位失败。tol<3 时恢复为 82 个数字单元格、5 个命中。

    本用例直接从 read_page 走 TEXT_SETTINGS，不写死容差值——所以任何能让该页
    重新变成 0 命中的改动都会让它红（当前只有把 text_x_tolerance 改回 3 会）。
    """
    from table_reader import TEXT_SETTINGS
    from metric_extractor import is_number, count_metrics

    path = require_pdf("gree_annual")
    with pdfplumber.open(path) as pdf:
        cands = read_page(pdf.pages[88])
    text_cand = next(c for c in cands if c.strategy == "text")
    numeric_cells = [c for row in text_cand.rows for c in row if is_number(c)]
    assert numeric_cells, (
        f"text 策略在 p89 提不出任何数字单元格——"
        f"TEXT_SETTINGS['text_x_tolerance']={TEXT_SETTINGS.get('text_x_tolerance')!r} 是否被改回 3？"
    )
    assert count_metrics(text_cand.rows, "现金流量表") > 0


# ---------------------------------------------------------------------------
# 被丢弃的左边界：pdfplumber 只保留"词最多"的那条左对齐线，另一种对齐会被整条吃掉，
# 于是那批行掉第一个字。见 table_reader.clipped_left_edges 的 docstring。
# ---------------------------------------------------------------------------

def _w(text, x0, x1):
    return {"text": text, "x0": x0, "x1": x1}


def test_clipped_left_edges_recovers_the_outdented_alignment():
    """顶格行（x0=48）与缩进行（x0=57）共存时，48 那条被 pdfplumber 丢了，须补回。"""
    from table_reader import clipped_left_edges

    words = [_w("流动负债合计", 48.0, 102.12),
             _w("负债合计", 48.0, 84.12),
             _w("其他权益工具", 57.0, 111.0),
             _w("少数股东权益", 57.0, 111.0)]
    assert clipped_left_edges(words, surviving_xs=[57.0, 254.04]) == [48.0]


def test_clipped_left_edges_never_touches_lines_inside_the_table():
    """表格内部的边界（数字列 x0）绝不能补——它们会贯穿全页，把别处的数字切成碎片。

    实测反例：格力 p86 补了 15 条内部线后，`资产总计 391,371,999,819.49`
    被切成 `3` + `91,371,999,819.49`，整张表碎掉。
    """
    from table_reader import clipped_left_edges

    words = [_w("合计", 48.0, 90.0), _w("合计", 48.0, 90.0),
             _w("391,371,999,819.49", 355.92, 470.0),
             _w("368,031,704,522.86", 355.92, 470.0)]
    assert clipped_left_edges(words, surviving_xs=[57.0, 355.92, 547.5]) == [48.0]


def test_clipped_left_edges_is_empty_without_a_lower_cluster():
    from table_reader import clipped_left_edges

    words = [_w("应收账款", 57.0, 90.0), _w("存货", 57.0, 80.0)]
    assert clipped_left_edges(words, surviving_xs=[57.0]) == []


def test_clipped_left_edges_survives_missing_edges():
    from table_reader import clipped_left_edges

    assert clipped_left_edges([], []) == []


def test_gree_balance_sheet_keeps_the_first_character_of_clipped_labels():
    """回归：格力 2025 年报 p86–87 的合计行顶格在 x0=48，被缩进行（x0=57）挤掉了边界。

    修前表现（全部 confidence=high）：
        流动负债合计 被记成 非流动负债合计 的 100 亿（实际 2315 亿）
        流动资产合计 被记成 非流动资产合计 的 1404 亿（实际 2509 亿）
        资产总计     标签变成「产总计」，直接丢失
    → 分析报告算出**流动比率 14.03 倍**（真值 1.08），且无任何告警。

    本用例把 6 个真值钉死；任何"掉第一个字"的回归都会让它红。
    """
    from table_reader import read_report_page_all
    from metric_extractor import count_metrics, extract_metrics

    path = require_pdf("gree_annual")
    metrics = []
    with pdfplumber.open(path) as pdf:
        for pno in (86, 87):
            tables = read_report_page_all(
                pdf.pages[pno - 1], lambda r: count_metrics(r, "资产负债表"))
            metrics += extract_metrics(tables[0].rows, pno, ["2025", "2024"],
                                       "资产负债表")
    got = {(m.name, m.period): m.value for m in metrics}

    assert got[("资产总计", "2025")] == pytest.approx(391_371_999_819.49)
    assert got[("流动资产合计", "2025")] == pytest.approx(250_943_551_897.43)
    assert got[("流动负债合计", "2025")] == pytest.approx(231_569_831_196.26)
    assert got[("负债合计", "2025")] == pytest.approx(241_580_719_144.79)
    assert got[("所有者权益合计", "2025")] == pytest.approx(149_791_280_674.70)

    # 会计恒等式必须闭合，且流动比率落在合理区间（修前是 14.03）
    assert got[("资产总计", "2025")] == pytest.approx(
        got[("负债合计", "2025")] + got[("所有者权益合计", "2025")], abs=1.0)
    current_ratio = got[("流动资产合计", "2025")] / got[("流动负债合计", "2025")]
    assert 0.5 < current_ratio < 3.0, f"流动比率 {current_ratio:.2f} 明显异常"


# ---------------------------------------------------------------------------
# 合并表与母公司表被拼成一张表：必须在母公司标题处截断
# ---------------------------------------------------------------------------

def test_truncate_at_parent_title_cuts_the_parent_half():
    from table_reader import truncate_at_parent_title
    rows = [["流动资产：", "", ""],
            ["货币资金", "1", "100"],
            ["负债和所有者权益总计", "", "1000"],
            ["母公", "司资", "产负债表"],      # 标题被切碎
            ["项目", "附注", "2026年"],
            ["货币资金", "1", "999"]]
    out = truncate_at_parent_title(rows)
    assert len(out) == 3
    assert out[-1][0] == "负债和所有者权益总计"


def test_truncate_at_parent_title_drops_table_when_title_first():
    """整张表都是母公司表 → 整张丢弃（返回空）。"""
    from table_reader import truncate_at_parent_title
    assert truncate_at_parent_title([["母公司资产负债表"], ["货币资金", "1", "9"]]) == []


def test_truncate_at_parent_title_keeps_normal_tables():
    from table_reader import truncate_at_parent_title
    rows = [["项目", "附注", "2026年"], ["货币资金", "1", "100"]]
    assert truncate_at_parent_title(rows) == rows
