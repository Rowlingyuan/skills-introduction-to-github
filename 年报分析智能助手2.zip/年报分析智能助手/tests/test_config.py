

def test_embedding_presets_and_rag_switch(monkeypatch):
    """嵌入模型可选：small/base/m3/none。

    实测用户首次运行要下 2.2 GB 的 bge-m3，卡了十几分钟 —— 默认改成 small（约 100 MB），
    并允许 `none` 彻底关掉向量检索（查数字与出报告不受影响）。
    """
    import importlib

    import config
    import settings

    # **隔离用户设置**：真实机器上 data/settings.json 可能存着用户选过的档位
    monkeypatch.setattr(settings, "PATH", __import__("pathlib").Path("/nonexistent/x.json"))

    for preset, expect in (("small", "BAAI/bge-small-zh-v1.5"),
                           ("base", "BAAI/bge-base-zh-v1.5"),
                           ("m3", "BAAI/bge-m3")):
        monkeypatch.setenv("EMBEDDING_MODEL", preset)
        assert importlib.reload(config).EMBEDDING_MODEL == expect

    monkeypatch.setenv("EMBEDDING_MODEL", "none")
    cfg = importlib.reload(config)
    assert cfg.ENABLE_RAG is False

    monkeypatch.delenv("EMBEDDING_MODEL")
    monkeypatch.delenv("ENABLE_RAG", raising=False)
    # **没选过时的默认规则**：本地已缓存 m3 就用 m3，没缓存就用 small。
    # 为什么不一味默认 m3：非交互场景（脚本/CI）不会弹选择，默认 m3 会悄悄下 2.2 GB。
    # 注意不能用 reload 来测：reload 会把 `_model_cached` 重新绑定回真实实现，
    # 打桩就失效了 —— 直接调用选择函数。
    monkeypatch.setattr(config, "_model_cached", lambda _m: True)
    assert config._embedding_choice() == "m3"

    monkeypatch.setattr(config, "_model_cached", lambda _m: False)
    assert config._embedding_choice() == "small"


def test_embedding_priority_env_over_settings(tmp_path, monkeypatch):
    """优先级：环境变量 > data/settings.json > 默认 m3。

    首次运行会问一次「大/中/小/不用」，选择写进 settings.json；
    显式设环境变量时以环境变量为准（便于临时切换）。
    """
    import importlib
    import json

    import settings

    monkeypatch.setattr(settings, "PATH", tmp_path / "settings.json")
    (tmp_path / "settings.json").write_text(
        json.dumps({"embedding_model": "small"}), encoding="utf-8")

    import config

    monkeypatch.delenv("EMBEDDING_MODEL", raising=False)
    assert importlib.reload(config).EMBEDDING_MODEL == "BAAI/bge-small-zh-v1.5"

    monkeypatch.setenv("EMBEDDING_MODEL", "base")
    assert importlib.reload(config).EMBEDDING_MODEL == "BAAI/bge-base-zh-v1.5"


def test_first_run_asks_and_saves_choice(monkeypatch, tmp_path):
    """首次运行必须**问**用户选哪个模型，并把选择存下来。

    实测试用者反馈"提示没了"：因为本机残留了一份 settings.json，
    程序以为选过了就跳过。这里锁住行为：没记录时一定要问、问完要存。
    """
    import builtins
    import json

    import settings

    monkeypatch.setattr(settings, "PATH", tmp_path / "settings.json")
    monkeypatch.delenv("EMBEDDING_MODEL", raising=False)
    monkeypatch.setattr("sys.stdin.isatty", lambda: True, raising=False)
    monkeypatch.setattr(builtins, "input", lambda *a: "2")

    import main

    main.ask_embedding_model()

    saved = json.loads((tmp_path / "settings.json").read_text(encoding="utf-8"))
    assert saved["embedding_model"] == "base"


def test_ask_is_skipped_when_env_explicit(monkeypatch, tmp_path):
    """显式设了环境变量就不该再问（脚本场景）。"""
    import builtins
    import json

    import settings

    monkeypatch.setattr(settings, "PATH", tmp_path / "settings.json")
    monkeypatch.setenv("EMBEDDING_MODEL", "small")

    called = {"n": 0}
    monkeypatch.setattr(builtins, "input",
                        lambda *a: called.__setitem__("n", called["n"] + 1) or "2")

    import main

    main.ask_embedding_model()
    assert called["n"] == 0
    assert not (tmp_path / "settings.json").exists()


def test_embedding_uses_domestic_mirror_and_local_cache(monkeypatch):
    """模型走国内镜像、缓存放在项目内。

    实测试用者从 huggingface.co 下载 2.2 GB 卡了很久；同时默认缓存目录
    `~/.cache` 在 macOS 上会触发「授予文件夹访问权限」弹窗。
    """
    import importlib

    import embedding

    e = importlib.reload(embedding)
    assert e.HF_ENDPOINT == "https://hf-mirror.com"
    assert "data/hf_cache" in e.HF_HOME.replace("\\", "/")

    # 环境变量可覆盖（想用官方源或自建镜像）
    monkeypatch.setenv("HF_ENDPOINT", "https://huggingface.co")
    e2 = importlib.reload(embedding)
    assert e2.HF_ENDPOINT == "https://huggingface.co"
    monkeypatch.delenv("HF_ENDPOINT")


def test_rag_deps_install_is_opt_in(monkeypatch, tmp_path):
    """检索组件（1.5 GB）不该偷偷装：没装时只打印安装指引。"""
    import main

    monkeypatch.setattr(main, "_rag_deps_installed", lambda: False)
    printed = []
    monkeypatch.setattr("builtins.print", lambda *a, **k: printed.append(" ".join(map(str, a))))

    main.ensure_rag_deps(interactive=False)

    text = "\n".join(printed)
    assert "检索组件" in text
    assert "requirements-rag.txt" in text
    # 非交互场景不许自己跑 pip
    assert "现在安装吗" not in text


def test_requirements_split_keeps_core_light():
    """核心依赖里不能出现 torch/chromadb —— 那是可选的检索组件。"""
    from pathlib import Path

    core = Path("requirements.txt").read_text(encoding="utf-8").lower()
    rag = Path("requirements-rag.txt").read_text(encoding="utf-8").lower()

    assert "chromadb" not in core and "sentence-transformers" not in core
    assert "chromadb" in rag and "sentence-transformers" in rag
    assert "pdfplumber" in core and "python-docx" in core
