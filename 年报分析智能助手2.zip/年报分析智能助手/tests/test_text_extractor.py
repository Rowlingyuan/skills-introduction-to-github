from conftest import require_pdf
from text_extractor import extract_chunks


def test_extract_chunks_returns_one_chunk_per_nonempty_page():
    path = require_pdf("gree_annual")
    chunks = extract_chunks(path)
    assert chunks, "应至少抽到一块"
    assert all(c["text"].strip() for c in chunks), "不应返回空文本块"
    assert all(isinstance(c["page"], int) and c["page"] >= 1 for c in chunks)


def test_extract_chunks_makes_no_page_number_assumption():
    """9 页的季报是页码假设的照妖镜：任何 skip-pages 逻辑都会在这里暴露。"""
    path = require_pdf("gree_q1")
    chunks = extract_chunks(path)
    pages = {c["page"] for c in chunks}
    # 首页是公司抬头页，不应被跳过
    assert 1 in pages, f"首页被跳过，实际页集合: {sorted(pages)}"
    # 报表所在的 5/6/7/8 页必须都在
    assert {5, 6, 7, 8} <= pages, f"缺页，实际: {sorted(pages)}"


def test_extract_chunks_page_numbers_are_within_document():
    path = require_pdf("gree_q1")
    chunks = extract_chunks(path)
    assert max(c["page"] for c in chunks) <= 9
