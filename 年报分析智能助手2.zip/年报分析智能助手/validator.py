"""外部真值交叉校验：把**规则抽取**的数字与 AkShare 披露的报表数据逐项比对。

## 为什么必须有这一层

`analysis.identity_violations` 只能校验**内部自洽**（资产 = 负债 + 权益），
校验不了"**与外部真值一致**"。而实测最危险的一类错误恰好是内部仍自洽的：
格力 2025 年报 p86–87 的合计行标签被 pdfplumber 切掉第一个字，于是

    流动资产合计 ← 被记成 非流动资产合计（1404 亿，真值 2509 亿）
    流动负债合计 ← 被记成 非流动负债合计（ 100 亿，真值 2315 亿）
    资产总计     ← 标签变成「产总计」，直接丢失

三者**都**带 `confidence="high"`，恒等式检查因为缺项被跳过，报告照常输出
**流动比率 14.03 倍**（真值 1.08）。这类错误只能靠外部真值发现。

## 分工（本项目底线）

- 本模块**只读**库里的数，**不改**库、不改 confidence、不参与报告生成；
- 它产出的是"体检表"，供人和后续的降级策略使用；
- 校验失败**不等于**年报错，也不等于 AkShare 对 —— 两边都可能口径不同
  （合并/母公司、追溯重述、财报单位），故差异一律**并排列出**，由人判断。

## 数据来源

AkShare（东方财富接口），单位**元**，与 `metrics.value` 的归一化口径一致。
"""
import contextlib
import io
import re
import sqlite3
from pathlib import Path

#: 我们的指标名 → 东方财富报表字段名。
#: 只收三张表里**含义确定、口径无歧义**的科目；像"营业总成本"这种
#: （= 营业成本 + 税金及附加 + 三费 + 研发 …）各家列法不同，不做校验。
FIELD_MAP = {
    "资产负债表": {
        "资产总计":     "TOTAL_ASSETS",
        "负债合计":     "TOTAL_LIABILITIES",
        "所有者权益合计": "TOTAL_EQUITY",
        "流动资产合计":  "TOTAL_CURRENT_ASSETS",
        "流动负债合计":  "TOTAL_CURRENT_LIAB",
        "货币资金":     "MONETARYFUNDS",
        "应收账款":     "ACCOUNTS_RECE",
        "存货":         "INVENTORY",
        # 有息负债构成（东财字段名，取不到会自动跳过）
        "短期借款":     "SHORT_LOAN",
        "一年内到期的非流动负债": "NONCURRENT_LIAB_1YEAR",
        "长期借款":     "LONG_LOAN",
        "应付债券":     "BOND_PAYABLE",
        "租赁负债":     "LEASE_LIAB",
    },
    "利润表": {
        "营业收入":     "OPERATE_INCOME",
        "营业成本":     "OPERATE_COST",
        "销售费用":     "SALE_EXPENSE",
        "管理费用":     "MANAGE_EXPENSE",
        "研发费用":     "RESEARCH_EXPENSE",
        "财务费用":     "FINANCE_EXPENSE",
        "营业利润":     "OPERATE_PROFIT",
        "利润总额":     "TOTAL_PROFIT",
        "净利润":       "NETPROFIT",
        "归母净利润":   "PARENT_NETPROFIT",
        "基本每股收益": "BASIC_EPS",
    },
    "现金流量表": {
        "经营活动现金流量净额": "NETCASH_OPERATE",
        "投资活动现金流量净额": "NETCASH_INVEST",
        "筹资活动现金流量净额": "NETCASH_FINANCE",
        "销售商品收到的现金":   "SALES_SERVICES",
    },
}

#: 报表 → AkShare 接口名（东方财富「按报告期」口径）。
STATEMENT_API = {
    "资产负债表": "stock_balance_sheet_by_report_em",
    "利润表":     "stock_profit_sheet_by_report_em",
    "现金流量表": "stock_cash_flow_sheet_by_report_em",
}

#: 报告类型 → 报告期日期的「月-日」。年报是 12-31，半年报 06-30，季报按季度末。
_PERIOD_MONTH_DAY = {"年报": "12-31", "半年报": "06-30",
                     "一季报": "03-31", "三季报": "09-30"}

#: 相对/绝对容差。东财的报表字段与年报原文**应当逐元一致**，故相对容差压到近乎精确，
#: 只用 `ABS_TOL` 兜住"东财把金额四舍五入到整元"这类末位差。
#: **不要放大**：3900 亿的 0.01% 就是 3900 万，松到那个量级等于放弃校验。
REL_TOL = 1e-9
ABS_TOL = 2.0

#: 非金额科目的绝对容差。每股收益是"元/股"，用 2 元当容差等于不校验
#: （差 0.5 元也是重大错误）；东财保留 2 位小数，故给 0.02。
ABS_TOL_OVERRIDE = {"基本每股收益": 0.02}

#: 不是金额的科目 —— 体检表里按"元"打印，不压成亿元。
NON_MONEY_METRICS = {"基本每股收益"}

#: 相对差小于此值 → 判为「疑似追溯重述」。
#: 实测格力 2022 年报：`资产总计 3,550.25 亿` vs 东财 `3,550.71 亿`，差 0.46 亿 = **0.013%**。
#: 这种量级不可能是抽取错误（抽错至少错一行、动辄几个百分点），
#: 而是我们取的是**当年原报表**、东财取的是**后年重述后的数**。
RESTATE_REL_TOL = 1e-3

#: 两个科目差额「大小相等、方向相反」的容差 —— 判为「疑似重分类」。
#: 实测格力 2023 年报：营业成本 +23.27 亿、销售费用 −23.28 亿，**两者合计几乎不变**。
#: 这是运输费从销售费用调入营业成本的典型重分类，两边都对，只是归类不同。
RECLASS_REL_TOL = 0.02

CODE_CACHE = Path("data") / "stock_codes.csv"

#: 年报里的公司全称/旧称 → A 股简称。**精确匹配与子串匹配都覆盖不到**的才登记在这里：
#: 牧原食品（年报）↔ 牧原股份（A 股简称，002714）——两者没有公共子串，
#: 靠字符串相似度猜会把「牧原」匹到别的公司，故显式声明。
NAME_ALIASES = {"牧原食品": "牧原股份"}


def report_date(report_type: str, period: str) -> "str | None":
    """('年报','2025') → '2025-12-31'；('一季报','2025Q1') → '2025-03-31'。"""
    md = _PERIOD_MONTH_DAY.get(report_type)
    year = (period or "")[:4]
    if not md or not year.isdigit():
        return None
    return f"{year}-{md}"


def symbol(code: str) -> str:
    """'000651' → 'SZ000651'（东财接口要带交易所前缀）。"""
    code = str(code or "").strip()
    if not code:
        raise ValueError("缺少股票代码")
    if code.startswith(("5", "6", "9")):
        return f"SH{code}"
    if code.startswith(("4", "8")):
        return f"BJ{code}"
    return f"SZ{code}"


def normalise_name(name) -> str:
    """公司名归一化：去掉所有空白（含全角空格）。

    **必须做**：东财为了三字名对齐，把简称写成「五 粮 液」「泸 州 老 窖」，
    与年报里的「五粮液」精确匹配不上，于是外部真值一直取不到。
    """
    return re.sub(r"[\s\u3000]", "", str(name or ""))


def load_code_map(cache_path=CODE_CACHE) -> dict:
    """公司简称 → 6 位代码。本地缓存，避免每次校验都拉 5577 行全表。"""
    cache_path = Path(cache_path)
    if cache_path.exists():
        lines = cache_path.read_text(encoding="utf-8").splitlines()
        out = {}
        for line in lines[1:]:
            code, _, name = line.partition(",")
            if code and name:
                out[normalise_name(name)] = code
        if out:
            return out
    import akshare as ak
    df = ak.stock_info_a_code_name()
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(
        "code,name\n" + "\n".join(f"{r.code},{r.name}" for r in df.itertuples()),
        encoding="utf-8")
    return {normalise_name(r.name): r.code for r in df.itertuples()}


def resolver(company: str, code_map: dict) -> "str | None":
    """公司名 → 代码。先查别名表，再精确匹配，最后退到"简称是库名子串"。"""
    company = normalise_name(company)
    alias = NAME_ALIASES.get(company)
    if alias and alias in code_map:
        return code_map[alias]
    if company in code_map:
        return code_map[company]
    hits = [c for n, c in code_map.items()
            if n and (n in company or company in n)]
    return hits[0] if len(hits) == 1 else None


def fetch_external(company: str, report_type: str, period: str,
                   code_map: dict, fetch_table=None) -> dict:
    """取外部真值：{statement: {指标名: 值}}。取不到的报表整个跳过。

    `fetch_table(api_name, symbol) -> DataFrame` 可注入，测试里用它离线跑。
    """
    date = report_date(report_type, period)
    code = resolver(company, code_map)
    if not date or not code:
        return {}
    if fetch_table is None:
        import akshare as ak
        fetch_table = lambda api, sym: getattr(ak, api)(symbol=sym)  # noqa: E731

    sym = symbol(code)
    out = {}
    for statement, api in STATEMENT_API.items():
        try:
            # akshare 的分页接口会往 stderr 刷 tqdm 进度条，把体检表冲得没法读
            with contextlib.redirect_stderr(io.StringIO()):
                df = fetch_table(api, sym)
        except Exception:
            continue
        if df is None or not len(df) or "REPORT_DATE" not in df.columns:
            continue
        rows = df[df["REPORT_DATE"].astype(str).str.startswith(date)]
        if not len(rows):
            continue
        row = rows.iloc[0]
        vals = {}
        for metric, field in FIELD_MAP[statement].items():
            if field not in df.columns:
                continue
            raw = row[field]
            try:
                val = float(raw)
            except (TypeError, ValueError):
                continue
            if val != val:          # NaN
                continue
            vals[metric] = val
        if vals:
            out[statement] = vals
    return out


def compare(metrics, external: dict) -> list:
    """逐项比对。返回 [{statement, metric, ours, theirs, diff, status}]。

    status:
      - `ok`               两边一致
      - `mismatch`         **都有值但不一致** —— 这就是要找的「抽取错误」
      - `restated`         差异极小（< 0.1%），疑似**追溯重述**（口径差异，非错误）
      - `reclassified`     与另一科目**差额等大反向**，疑似**科目重分类**（口径差异，非错误）
      - `missing_ours`     AkShare 有、我们没抽到（覆盖问题）
      - `missing_theirs`  我们抽到了、AkShare 没有（罕见，可能是科目口径差异）

    **为什么要分这两档**：格力 2022/2023 各有 2 项"不符"，追下去都是口径差异——
    追溯重述差 0.013%，重分类是两个科目各差 23 亿但**合计不变**。
    一律标红会让体检表永远挂着 4 个假阳性，把真正的错误（海康的符号、茅台的首位）
    淹掉；一律放过又会漏掉真错。故用两条**不变式**把它们分开。
    """
    have = {(m.statement, m.name): m for m in metrics}
    rows = []
    for statement, fields in external.items():
        for metric, theirs in fields.items():
            m = have.get((statement, metric))
            ours = None if m is None else m.value
            if ours is None:
                rows.append({"statement": statement, "metric": metric,
                             "ours": None, "theirs": theirs, "diff": None,
                             "status": "missing_ours",
                             "page": None})
                continue
            diff = ours - theirs
            abs_tol = ABS_TOL_OVERRIDE.get(metric, ABS_TOL)
            ok = abs(diff) <= max(abs_tol, abs(theirs) * REL_TOL)
            rows.append({"statement": statement, "metric": metric,
                         "ours": ours, "theirs": theirs, "diff": diff,
                         "status": "ok" if ok else "mismatch",
                         "page": m.source_page})
    # 我们抽到、外部没有的科目
    covered = {(s, n) for s, f in external.items() for n in f}
    for (statement, name), m in have.items():
        if name in FIELD_MAP.get(statement, {}) and (statement, name) not in covered:
            rows.append({"statement": statement, "metric": name,
                         "ours": m.value, "theirs": None,
                         "diff": None, "status": "missing_theirs",
                         "page": m.source_page})
    _classify_soft_differences(rows)

    order = {"mismatch": 0, "restated": 1, "reclassified": 2,
             "missing_ours": 3, "missing_theirs": 4, "ok": 5}
    rows.sort(key=lambda r: (order[r["status"]], r["statement"], r["metric"]))
    return rows


def _classify_soft_differences(rows) -> None:
    """把 `mismatch` 里的「口径差异」拆出来，就地改 `status`。

    两条判据都是**不变式**，不是拍脑袋的阈值：
      1. **重分类**：同一张表里两个科目的差额等大反向（|a+b| ≤ 2%×|a|），
         说明只是归类变了、总额没变；
      2. **追溯重述**：单项相对差 < 0.1%，量级上不可能是抽取错误。
    先判重分类再判重述 —— 重分类的一对往往差额很大（23 亿），不能被 0.1% 抢走。
    """
    bad = [r for r in rows if r["status"] == "mismatch" and r["diff"] is not None]
    used = set()

    for i, a in enumerate(bad):
        if i in used:
            continue
        for j in range(i + 1, len(bad)):
            if j in used:
                continue
            b = bad[j]
            if a["statement"] != b["statement"]:
                continue
            scale = max(abs(a["diff"]), abs(b["diff"])) or 1.0
            if abs(a["diff"] + b["diff"]) <= scale * RECLASS_REL_TOL:
                a["status"] = b["status"] = "reclassified"
                # 两边的说明要**各自指向对方** —— 早先写成 `a["note"] = b["note"] = ...`
                # 会让销售费用那条也显示"与「销售费用」等大反向"，等于自己跟自己配对。
                a["note"] = f"与「{b['metric']}」等大反向，合计不变（疑科目重分类）"
                b["note"] = f"与「{a['metric']}」等大反向，合计不变（疑科目重分类）"
                used.update({i, j})
                break

    for k, r in enumerate(bad):
        if k in used:
            continue
        base = abs(r["theirs"]) or abs(r["ours"]) or 1.0
        if abs(r["diff"]) / base < RESTATE_REL_TOL:
            r["status"] = "restated"
            r["note"] = f"相对差 {abs(r['diff']) / base * 100:.3f}%（疑追溯重述）"


def validate_report(company: str, report_type: str, period: str, db_path,
                    code_map=None, fetch_table=None) -> dict:
    """单份报告的体检结果。任何外部失败都降级为 `ok=False`，不抛异常。"""
    from storage import load_metrics
    metrics = load_metrics(company, report_type, period, db_path)
    if not metrics:
        return {"ok": False, "error": f"{company} {report_type} {period} 尚未入库"}
    try:
        code_map = code_map if code_map is not None else load_code_map()
        external = fetch_external(company, report_type, period, code_map,
                                  fetch_table=fetch_table)
    except Exception as e:                      # 断网 / 接口变更都不该炸掉调用方
        return {"ok": False, "error": f"取外部真值失败：{e}"}
    if not external:
        return {"ok": False,
                "error": f"AkShare 上找不到 {company} {period} 的报表（代码或报告期不匹配）"}
    rows = compare(metrics, external)
    return {"ok": True, "company": company, "report_type": report_type,
            "period": period, "rows": rows, "summary": summarize(rows)}


def summarize(rows) -> dict:
    out = {"ok": 0, "mismatch": 0, "restated": 0, "reclassified": 0,
           "missing_ours": 0, "missing_theirs": 0}
    for r in rows:
        out[r["status"]] = out.get(r["status"], 0) + 1
    checked = (out["ok"] + out["mismatch"] + out["restated"]
               + out["reclassified"])
    out["checked"] = checked
    # `accuracy` 是**严格一致率**（只认逐元相等）；口径差异单列，不混进来。
    out["accuracy"] = (out["ok"] / checked) if checked else None
    out["accurate_or_explained"] = (
        (out["ok"] + out["restated"] + out["reclassified"]) / checked
        if checked else None)
    return out


def available_reports(db_path) -> list:
    conn = sqlite3.connect(str(db_path))
    try:
        return conn.execute(
            "SELECT company, report_type, period FROM reports "
            "ORDER BY company, report_type, period").fetchall()
    finally:
        conn.close()


def validate_db(db_path, code_map=None, fetch_table=None) -> list:
    """全库体检。返回 [{company, report_type, period, ok, summary, rows, error}]。"""
    code_map = code_map if code_map is not None else load_code_map()
    out = []
    for company, report_type, period in available_reports(db_path):
        res = validate_report(company, report_type, period, db_path,
                              code_map=code_map, fetch_table=fetch_table)
        res.update({"company": company, "report_type": report_type,
                    "period": period})
        out.append(res)
    return out
